﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace AccSystem.ClassesProject
{
    class AccDefintionSQL
    {
        DataTable dt;
        ConnectionDB con = new ConnectionDB();


        /////////////////////////////////////////////////////


        ///////////////////////////////////////////////////

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        /// 
        #region 
        public List<string> CanUpdateAccBox()
        {
            List<string> data = new List<string>();
            string
             query = " SELECT  Accounts.Acc_id_father ";
            query += "   FROM            AccCurrency INNER JOIN ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "  Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk   ";
            query += "  group by  Accounts.Acc_id_father  ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            #region
                    /*
                   SELECT        Accounts.Acc_id_father
                    FROM            AccCurrency INNER JOIN
                                 Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                                 Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk 
                                 group by  Accounts.Acc_id_father
                    */
                    #endregion

        }
        public List<string> CanUpdateAccCustomer()
        {
            List<string> data = new List<string>();
            string
             query = " SELECT  Accounts.Acc_id_father ";
            query += "   FROM      Customers INNER JOIN ";
            query += "   AccCurrency ON Customers.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN  ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id   ";
            query += "   group by  Accounts.Acc_id_father  ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            #region
            /*
          SELECT        Accounts.Acc_id_father
            FROM            Customers INNER JOIN
                         AccCurrency ON Customers.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
						  group by  Accounts.Acc_id_father
            */
            #endregion

        }
        public List<string> CanUpdateAccGroupStore(string AccCurr_id)
        {
            List<string> data = new List<string>();
            string
             query = "    SELECT  Accounts.Acc_id_father ";
            query += "    FROM  AccCurrency INNER JOIN ";
            query += "    Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  ";
            query += "    WHERE  AccCurrency.AccCurr_id =   "+ AccCurr_id;
            query += "    group by   Accounts.Acc_id_father  ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            #region
            /*
         SELECT        Accounts.Acc_id_father
        FROM            AccCurrency INNER JOIN
                                 Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
        WHERE        AccCurrency.AccCurr_id = 18
        group by   Accounts.Acc_id_father
            */
            #endregion

        }
        public List<string> CanUpdateExching(string AccCurr_id="-1")
        {
          //  MessageBox.Show(AccCurr_id, "CanUpdateExching");
            
            List<string> data = new List<string>();
            string
             query = "      SELECT  AccCurr_id_fk FROM  DaylyBody ";
            query += "    WHERE  AccCurr_id_fk = "+ AccCurr_id;
            query += "   group by AccCurr_id_fk  ";
            query += "     union all   " ;
            query += "    SELECT  AccCurr_id_fk FROM  EntriesBody   ";
            query += "  WHERE    AccCurr_id_fk =   "+ AccCurr_id;
            query += "  group by AccCurr_id_fk   ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            #region
            /*
        SELECT  AccCurr_id_fk FROM  DaylyBody
		WHERE  AccCurr_id_fk = 18 group by AccCurr_id_fk
        union all
        SELECT  AccCurr_id_fk FROM  EntriesBody
		        WHERE    AccCurr_id_fk = 18 group by AccCurr_id_fk
            */
            #endregion

        }
        public List<string> GetAcc_cost4GroupStored()
        {
            List<string> data = new List<string>();
            string
             query = "  SELECT  Acc_cost_fk FROM  GroupStored group by Acc_cost_fk ";
           
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            #region
            /*
        SELECT  Acc_cost_fk FROM  GroupStored group by Acc_cost_fk
            */
            #endregion

        }
        public List<string> GetAcc_sales4GroupStored()
        {
            List<string> data = new List<string>();
            string
             query = "  SELECT  Acc_sales_fk FROM  GroupStored group by Acc_sales_fk ";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            #region
            /*
      sELECT  Acc_sales_fk FROM  GroupStored group by Acc_sales_fk
            */
            #endregion

        }
        public List<string> GetAcc_return_sales4GroupStored()
        {
            List<string> data = new List<string>();
            string
             query = "  SELECT  Acc_return_sales_fk FROM  GroupStored group by Acc_return_sales_fk ";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            #region
            /*
     sELECT  Acc_return_sales_fk FROM  GroupStored group by Acc_return_sales_fk
            */
            #endregion

        }
        public List<string> GetAcc_stored4GroupStored()
        {
            List<string> data = new List<string>();
            string
             query = "  SELECT  Acc_stored_fk FROM  GroupStored group by Acc_stored_fk ";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            #region
            /*
     sELECT  Acc_stored_fk FROM  GroupStored group by Acc_stored_fk
            */
            #endregion

        }

        #endregion
        //
        public DataTable GetDataAccDefintion()
        {
            string
             query = " SELECT ";
            query += " AccBox  ";
            query += "  ,ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id = AccBox),'') as AccBox ";

            query += "   ,AccSales ";
            query += "   ,ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id =AccSales),'') as AccSales ";

            query += " ,AccSalesReturn ";
            query += ",ISNULL((SELECT Acc_name FROM Accounts WHERE Acc_id = AccSalesReturn),'') as AccSalesReturn ";

            query += " ,AccPurchasesCost as AccCost ";
            query += "  , ISNULL((SELECT Acc_name FROM  Accounts WHERE  Acc_id = AccPurchasesCost),'') as AccCost ";
            query += " ,AccStored ";
            query += " ,ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id = AccStored),'') as AccStored ";

            query += "  ,AccCustomer ";
           query += " , ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id = AccCustomer),'') as AccCustomer ";

            query += " ,ISNULL((SELECT    Accounts.Acc_id  FROM     AccCurrency INNER JOIN  ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE   AccCurrency.AccCurr_id =  ";
            query += " AccDifferenceExchingCurrForeigner),'') as AccDifferenceExchingCurrForeigner  ";

            query += " ,ISNULL((SELECT    Accounts.Acc_name  FROM     AccCurrency INNER JOIN  ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE   AccCurrency.AccCurr_id =  ";
            query += " AccDifferenceExchingCurrForeigner),'') as AccDifferenceExchingCurrForeigner  ";

            query += " , ISNULL( AccLastLevel,'') as AccLastLevel  ";
            query += " ,AccDifferenceExchingCurrForeigner  ";

            query += " FROM AccDefine ";
            //  
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

            /*
            SELECT      
         AccBox
	    ,ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id = AccBox),'') as AccBox

		,AccSales
        ,ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id =AccSales),'') as AccSales

		,AccSalesReturn
        , ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id = AccSalesReturn),'') as AccSalesReturn

		,AccPurchasesCost as AccCost
        , ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id = AccPurchasesCost),'') as AccCost

		,AccStored
        ,ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id = AccStored),'') as AccStored

		,AccCustomer
        , ISNULL((SELECT Acc_name FROM    Accounts WHERE   Acc_id = AccCustomer),'') as AccCustomer

		

		,ISNULL((SELECT    Accounts.Acc_id  FROM     AccCurrency INNER JOIN
           Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE        AccCurrency.AccCurr_id =  AccDifferenceExchingCurrForeigner),'') as AccDifferenceExchingCurrForeigner

        ,ISNULL((SELECT        Accounts.Acc_name
        FROM            AccCurrency INNER JOIN
                                 Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
        WHERE        AccCurrency.AccCurr_id =  AccDifferenceExchingCurrForeigner),'') as AccDifferenceExchingCurrForeigner

		  , ISNULL( AccLastLevel,'') as AccLastLevel
          ,AccDifferenceExchingCurrForeigner

        FROM            AccDefine
	


            */

        }
        public void UpdateIdAccFatherBox
            (
              string AccBox
            , string AccSales
            , string AccSalesReturn
            , string AccPurchasesCost
            , string AccStored
            , string AccCustomer
            , string AccDifferenceExchingCurrForeigner
            , string AccLastLevel
            )
        {
            string query = null;
            if (CheckIfExistRowInAccDefintionTable())
            {
                
                query = "   UPDATE[dbo].[AccDefine]";
                query += "  SET[AccBox] ="+ AccBox;
                query += " ,[AccSales] ="+ AccSales;
                query += " ,[AccSalesReturn] ="+ AccSalesReturn;
                query += " ,[AccPurchasesCost] ="+ AccPurchasesCost;
                query += " ,[AccStored] =" + AccStored;
                query += " ,[AccCustomer] =" + AccCustomer;
                query += " ,[AccDifferenceExchingCurrForeigner] =" + AccDifferenceExchingCurrForeigner;
                query += " ,[AccLastLevel] =" + AccLastLevel;
               
            }
           else
            {
               
                query = "INSERT INTO [dbo].[AccDefine]";
                query += " ([AccBox] ";
                query += " ,[AccSales]";
                query += " ,[AccSalesReturn]";
                query += " ,[AccPurchasesCost]";
                query += " ,[AccStored]";
                query += " ,[AccCustomer]";
                query += " ,[AccDifferenceExchingCurrForeigner]";
                query += " ,[AccLastLevel] ";
                query += " ,[AccStoredFristBalance]";
                query += " ,[AccPurchasesReturn]";
                query += " ,[AccDiscountAllow]";
                query += " ,[AccDiscountGained]";
                query += " ,[AccQuantityFree]";
                query += " ,[AccSuplliers]";          
                query += " ) ";
                query += "   VALUES ";
                query += "("+ AccBox; //AccBox
                query += ","+ AccSales; //AccSales
                query += ","+ AccSalesReturn; //AccSalesReturn
                query += ","+ AccPurchasesCost; //AccPurchasesCost
                query += ","+ AccStored; //AccPurchasesReturn
                query += ","+ AccCustomer; //AccDiscountAllow
                query += ","+ AccDifferenceExchingCurrForeigner; //AccDiscountGained
                query += ","+ AccLastLevel; //AccStored
                query += ",NULL"; //AccStoredFristBalance
                query += ",NULL"; //AccPurchasesReturn
                query += ",NULL";//AccDiscountAllow
                query += ",NULL"; //AccDiscountGained
                query += ",NULL"; //AccQuantityFree
                query += ",NULL"; //AccSuplliers
                query += ")"; 
            }
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            /*
            INSERT INTO [dbo].[AccDefine]
           ([AccBox]
           ,[AccSales]
           ,[AccSalesReturn]
           ,[AccPurchasesCost]
           ,[AccStored]
           ,[AccCustomer]
		   ,[AccDifferenceExchingCurrForeigner]
           ,[AccLastLevel]
           ,[AccStoredFristBalance]
		   ,[AccPurchasesReturn]
           ,[AccDiscountAllow]
           ,[AccDiscountGained]
		   ,[AccQuantityFree]
		   ,[AccSuplliers]
		   )
     VALUES
            */
        }

        /*
          [AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
          [AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
         ,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
        */
        public bool CheckIfExistRowInAccDefintionTable()
        { //هل يوجد سجل لتعريف الحسابات ام لا
            //في حال كان موش موجد يعمل اضافة لسجل واحد فقط ويكون فارغ
            //في حال كان موجود يستخدم دوال التعديل فقط
            string query = "SELECT [AccBox] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
         dt=  con.Query(query, true);
            con.CloseConnetion();
            if (dt.Rows.Count > 0)
            {
               // MessageBox.Show("يوجد صفوف في جدول تعريف الحسابات" + "  " + dt.Rows.Count.ToString());
                return true;
            }
            else
            {
               // MessageBox.Show("لا يوجد صفوف في جدول تعريف الحسابات" + "  " + dt.Rows.Count.ToString());
                return false;
            } 
        }
        public string GetIdAccFatherBox()
        {//ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccBox] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }
        public string GetIdAccSalesFather()
        { //
          /*
       [AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
       [AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
      ,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
     */
          //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccSales] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
           // MessageBox.Show(query, "GetIdAccSalesFather");
            return query;
           
        }
        public bool AccSalesFatherNotNull()
        {
            /*
            اذا كان حساب المبعيات فارغ يرجع فولس
            اذا في حساب مبيعات معرف يرجع تروو
            */
            string a= GetIdAccSalesFather();
           
            if (a == "NULL"||a==string.Empty)
            {
                
                return false;
            }
            else return true;
        }
        public bool AccSalesReturnFatherNotNull()
        {
            string a = GetIdAccSalesReturnFather();
            if (a == "" || a == "NULL")
            {
                return false;
            }
            else
                return true;

        }
        public bool AccStoredFatherNotNull()
        {
            string a = GetIdAccStoredFather();
            if (a == "" || a == "NULL")
            {
                return false;
            }
            else
                return true;

        }
        public bool AccCostFatherNotNull()
        {
            string a = GetIdAccPurchasesFather();
            if (a == "" || a == "NULL")
            {
                return false;
            }
            else
                return true;

        }

      
        public string GetIdAccSalesReturnFather()
        { //
            /*
       [AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
       [AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
      ,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
     */
            //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccSalesReturn] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }

        public string GetIdAccPurchasesFather()
        {//
            /*
       [AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
       [AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
      ,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
     */
            //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccPurchasesCost] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }

        public string GetIdAccPurchasesReturnFather()
        { //
          /*
    [AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
    [AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
   ,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
  */
          //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccPurchasesReturn] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }
        public string GetIdAccDiscountAllowFather()
        { //الخصم المسموح به
          /*
 [AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
 [AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
*/
          //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccDiscountAllow] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }
        public string GetIdAccDiscountGainedFather()
        { //الخصم المكتسب
          /*
[AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
[AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
*/
          //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccDiscountGained] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }
        public string GetIdAccStoredFather()
        { //المخزون
          /*
 [AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
 [AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
 ,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
 */
          //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccStored] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }

        public string GetIdAccQuantityFreeFather()
        { //المخزون المجاني
          /*
[AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
[AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
*/
          //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccQuantityFree] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }
        public string GetIdAccCustomerFather()
        {
            /*
[AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
[AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
*/
            //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccCustomer] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                query = dt.Rows[0][0].ToString();
            else return "0";
            return query;

        }

        public string GetIdAccSuplliersFather()
        {
            /*
[AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
[AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
*/
            //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccSuplliers] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }
        public string GetIdAccStoredFristBalanceFather()
        {
            /*
[AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
[AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
*/
            //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccStoredFristBalance] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }
        public string GetIdAccLastLevelFather()
        {
            /*
[AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
[AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
*/
            //ترجع الحساب الرئيسي للصناديق المخزن في جدول تعريف الحسابات عشان يضيف الحسابات عن طريقها
            string query = "SELECT [AccLastLevel] FROM [dbo].[AccDefine]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            query = dt.Rows[0][0].ToString();
            return query;
        }
    }
}
