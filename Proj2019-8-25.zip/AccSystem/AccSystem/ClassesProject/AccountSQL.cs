﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace AccSystem.ClassesProject
{
    class AccountSQL
    {
        ConnectionDB con = new ConnectionDB();
        AccDefintionSQL accDefinSql = new AccDefintionSQL();
        DataTable dt,dtFr3i;

        ///////////////////////////////////////////
        string AddApostropheToString(string txt)
        {
            //اضافة نص احادي للكلمات
            if (txt != "NULL")
            {
                txt = "'" + txt + "'";
            }

            return txt;
        }
        public string GetMaxFr3iAcc(string idAccFather)
        {
            string query = "SELECT isnull(max([Acc_id])+1,(select ([Acc_id]*1000+1) FROM [dbo].[Accounts] where [Acc_id]='"+ idAccFather + "'  )) FROM [dbo].[Accounts] where [Acc_id_father] ='"+ idAccFather + "' ";
            con.OpenConnetion();
            dtFr3i = new DataTable();
            dtFr3i = con.Query(query, true);
           
            string id;
            if (dtFr3i.Rows.Count > 0)
            {
                id = dtFr3i.Rows[0][0].ToString();
              //  MessageBox.Show("GetIdAcc"+ id);
                return id;

            }

            else
            {
                MessageBox.Show("Error in Class Acc in GetMaxfr3i");
                return null;
            }

           // con.CloseConnetion();

        }
        #region الاستعلام عن رصيد حساب 
        public string Acount(string AccCurrid="-1")
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string 
             query = "SELECT ";

            #region اذا كانت عملة الحساب محلية
            query += "  iif(Currencys.Curr_is_local=1, "; //يجيب الرصيد محلي
            query += "  iif(Accounts.Acc_nature_fk=1, ";
            #region اذا كان طبيعة الحساب مدين
            query += "  (sum(DaylyBody.Debt_local)- sum(DaylyBody.Credit_local)), "; //يطرح المدين من الدائن
            #endregion
            #region اذا كان طبيعة الحساب دائن
            query += "  (sum (DaylyBody.Credit_local)-sum(DaylyBody.Debt_local))), "; //يطرح الدائن  من المدين
            #endregion
            #endregion
            #region اذا كانت عملة الحساب اجنبية
            query += "  iif(Accounts.Acc_nature_fk=1, "; //يجيب الرصيد اجنبي
            #region اذا كان طبيعة الحساب مدين
            query += "  (sum(DaylyBody.Debt_foreign)- sum(DaylyBody.Credit_foreign)), ";
            #endregion
            #region اذا كان طبيعة الحساب دائن
            query += "  (sum (DaylyBody.Credit_foreign)-sum(DaylyBody.Debt_foreign)))) as Account ";
            #endregion
            #endregion
            query += " FROM            AccCurrency INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "  DaylyBody ON AccCurrency.AccCurr_id = DaylyBody.AccCurr_id_fk INNER JOIN ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id ";
            query += " WHERE  ";
            query += "   (DaylyBody.AccCurr_id_fk = "+ AccCurrid + ")  ";
            query += "     group by Currencys.Curr_is_local,Accounts.Acc_nature_fk ";
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            try
            { return dt.Rows[0][0].ToString(); }catch { MessageBox.Show("لم يتم العثور على الحساب المحدد في اليومية العامة", AccCurrid, MessageBoxButtons.OK, MessageBoxIcon.Warning); return "0"; }

            /*
            اذا كان الناتج بالسالب يعني انه عكس طبيعة حسابة
            */

            #region الاستعلام
            /*
            SELECT       
 
						 iif(Currencys.Curr_is_local=1,
						 iif(Accounts.Acc_nature_fk=1,
						 (sum(DaylyBody.Debt_local)- sum(DaylyBody.Credit_local)),
						 (sum (DaylyBody.Credit_local)-sum(DaylyBody.Debt_local))),
						 iif(Accounts.Acc_nature_fk=1,
						 (sum(DaylyBody.Debt_foreign)- sum(DaylyBody.Credit_foreign)),
						 (sum (DaylyBody.Credit_foreign)-sum(DaylyBody.Debt_foreign)))) as Account
FROM            AccCurrency INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                         DaylyBody ON AccCurrency.AccCurr_id = DaylyBody.AccCurr_id_fk INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
WHERE 
       (DaylyBody.AccCurr_id_fk = 12) 
	   group by Currencys.Curr_is_local,Accounts.Acc_nature_fk
            */
            #endregion
           
        }
        public string MaxAccount(string AccCurrid = "-1")
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "SELECT  Maximum ";
            query += " FROM ";
            query += " AccCurrency  ";
            query += " WHERE ";
            query += " (AccCurr_id = "+ AccCurrid + ") ";
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            try
            { return dt.Rows[0][0].ToString(); }
            catch { MessageBox.Show("لم يتم العثور على الحساب التالي في جدول حسابات عملات", AccCurrid, MessageBoxButtons.OK, MessageBoxIcon.Warning); return "0"; }
            #region الاستعلام
            /*
            SELECT        Maximum
FROM            AccCurrency
WHERE        (AccCurr_id = 8)
            */
            #endregion

        }

        public string GetAccCurrId4BoxId(string Box_id="-1")
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "SELECT  AccCurr_id_fk ";
            query += " FROM ";
            query += " Boxes  ";
            query += " WHERE ";
            query += " (Box_id = " + Box_id + ") ";
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            try
            { return dt.Rows[0][0].ToString(); }
            catch { MessageBox.Show("لم يتم العثور على الحساب المتربط بهذا الصندوق", Box_id, MessageBoxButtons.OK, MessageBoxIcon.Warning); return "0"; }

            /*SELECT        AccCurr_id_fk
FROM            
WHERE        (Box_id = 1)*/
        }

        public string GetAccCurrId4CustomerId(string Cust_id = "-1")
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "SELECT  AccCurr_id_fk ";
            query += " FROM ";
            query += " Customers  ";
            query += " WHERE ";
            query += " (Cust_id = " + Cust_id + ") ";
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            try
            { return dt.Rows[0][0].ToString(); }
            catch { MessageBox.Show("لم يتم العثور على الحساب المتربط بهذا الصندوق", Cust_id, MessageBoxButtons.OK, MessageBoxIcon.Warning); return "0"; }

            /*SELECT        AccCurr_id_fk
FROM            Customers
WHERE        (Cust_id = 1)*/
        }

        #endregion
        public DataTable ShowAllAcc()
        {
            string query = "SELECT    Accounts.* FROM Accounts";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }

        public DataTable ShowAllMainAcc()

        {
            string query = "  SELECT Accounts.* FROM     Accounts where Acc_type_fk = 1";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }
        public DataTable GetAllFr3iAcc(string idAccFather)
        {
            string
            q = "SELECT ";
            q += "    Accounts.Acc_id ";
            q += "  , Accounts.Acc_name ";
            q += "  , AccCurrency.AccCurr_id ";
            q += " FROM    AccCurrency INNER JOIN ";
            q += " Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id ";
            q += "  where ";
            q += "  Accounts.Acc_id_father =" + idAccFather;
          
           
           
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            return dt;
            /*
            SELECT       
         Accounts.Acc_id
        , Accounts.Acc_name
        , AccCurrency.AccCurr_id
        FROM            AccCurrency INNER JOIN
                                 Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
        WHERE    
             (Accounts.Acc_type_fk = 1) 
        AND (Accounts.Acc_id_father = 1) 
        AND (Accounts.Acc_level = 1)
            */
        }
        public void DeletAcc(string Acc_id)
        {
            string
            q = "    DELETE FROM [dbo].[Accounts]   ";
            q += "    WHERE Acc_id=   "+ Acc_id;
            con.OpenConnetion();
            con.Query(q, false); 
          
            con.CloseConnetion();
            /*
            DELETE FROM [dbo].[Accounts]
      WHERE Acc_id=1
            */

        }
        public DataTable GetAccDefin(string AccLevel)
        {
            string
           q = "   SELECT  Acc_id, Acc_name FROM  Accounts WHERE   Acc_level =   "+ AccLevel;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            return dt;
            /*
            SELECT  Acc_id, Acc_name FROM  Accounts WHERE   Acc_level = 4
            */
        }
        public DataTable GetAccDefin()
        {
            string
            q  = "     SELECT        Accounts.Acc_id, Accounts.Acc_name, AccCurrency.AccCurr_id   ";
            q += "     FROM            AccCurrency INNER JOIN  ";
            q += "       Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            return dt;
            /*
           SELECT        Accounts.Acc_id, Accounts.Acc_name, AccCurrency.AccCurr_id
            FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
            */
        }
        public DataTable GetAccCurrOprtion(string AccCurr_id_fk)
        {
            /*
            ترجع لي الصناديق او العملاء اي اي مجموعه مخزنية مرتبطة مع حسابات عملات المحدد
            */

            string
            q = "    SELECT        Box_id, Box_name,'الصناديق'    ";
            q += "   FROM            Boxes  ";
            q += "   WHERE        AccCurr_id_fk =  "+ AccCurr_id_fk;
            q += "    union all  ";

            q += "     SELECT        Cust_id, Cust_name ,'العملاء'  ";
            q += "    FROM            Customers  ";
            q += "    WHERE        AccCurr_id_fk =  "+ AccCurr_id_fk;
            q += "   union all  ";

            q += "      SELECT        Group_id, Group_name ,'المجموعة المخزنية'  ";
            q += "   FROM    GroupStored where Acc_sales_fk=   "+ AccCurr_id_fk;
            q += "     union all  ";

            q += "      SELECT        Group_id, Group_name ,'المجموعة المخزنية'  ";
            q += "   FROM    GroupStored where Acc_cost_fk=   "+ AccCurr_id_fk;
            q += "     union all  ";

            q += "      SELECT        Group_id, Group_name ,'المجموعة المخزنية'  ";
            q += "   FROM    GroupStored where Acc_return_sales_fk=   "+ AccCurr_id_fk;
            q += "     union all  ";

            q += "      SELECT        Group_id, Group_name ,'المجموعة المخزنية'  ";
            q += "   FROM    GroupStored where Acc_stored_fk=   "+ AccCurr_id_fk;

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            return dt;

            #region
            /*
          SELECT        Box_id, Box_name,'الصناديق'
              FROM            Boxes
              WHERE        AccCurr_id_fk = 17
              union all
              SELECT        Cust_id, Cust_name ,'العملاء'
              FROM            Customers
              WHERE        AccCurr_id_fk = 17
              union all
              SELECT        Group_id, Group_name ,'المجموعة المخزنية'
              FROM            GroupStored where Acc_sales_fk=16
              union all
              SELECT        Group_id, Group_name ,'المجموعة المخزنية'
              FROM            GroupStored where Acc_cost_fk=17
              union all
              SELECT        Group_id, Group_name ,'المجموعة المخزنية'
              FROM            GroupStored where Acc_return_sales_fk=17
              union all
              SELECT        Group_id, Group_name ,'المجموعة المخزنية'
              FROM            GroupStored where Acc_stored_fk=17
          */
            #endregion

        }
        public DataTable GetAccCurr4Acc(string Acc_id)
        {
            string
            q = "   SELECT        AccCurrency.AccCurr_id   ";
            q += "    FROM            AccCurrency INNER JOIN ";
            q += " Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id   ";
            q += "  WHERE Accounts.Acc_id=  "+ Acc_id;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            return dt;

            /*
            SELECT        AccCurrency.AccCurr_id 
                FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
						 WHERE Accounts.Acc_id=1131002
            */
        }
        public void InsertNewAcc(string Acc_id, string Acc_name, string Acc_id_father, string Acc_level, string Acc_state, string Acc_nature_fk ,string Acc_type_fk, string Report_type_fk)
        {

            //AccId.Text, AccName.Text, AccFather.Text, AccLevel.Text, (StatActive.Checked ? "1" : "0"), (StatDaain.Checked ? "2" : "1"), (StateRasi.Checked ? "1" : "2"), (Report1.Checked ? "1" : "2")
            try
            {
               
                string query = "INSERT INTO [dbo].[Accounts]" +
            "   ([Acc_id],[Acc_name] ,[Acc_id_father],[Acc_level],[Acc_state] ,[Acc_nature_fk],[Acc_type_fk],[Report_type_fk])" +
        " VALUES ( " + GetMaxFr3iAcc(Acc_id_father) + ",'" + Acc_name + "' ," + Acc_id_father + ", " + Acc_level + "," + Acc_state + " ," + Acc_nature_fk + " ," + Acc_type_fk + " ," + Report_type_fk + "   )";
                con.OpenConnetion();
                con.Query(query, false);
                con.CloseConnetion();
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString()); }
            
        }

        public string GetMaxLevel(string idAccFather)
        {
            string query = "SELECT Acc_level + 1 FROM Accounts WHERE(Acc_id ="+ idAccFather + ")";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            string id;
            id = dt.Rows[0][0].ToString();
            return id;
        }


        public void UpdateNameAcc(
            string Acc_id
            , string Acc_name
            ,string Acc_state 
            ,string Acc_nature_fk
            ,string Report_type_fk
            )
        {
            string query = " UPDATE[dbo].[Accounts] ";
            query += "  SET  ";
            query += "  [Acc_name] = "+con.AddApostropheToString(Acc_name);
            query += " ,[Acc_state] = "+ Acc_state;
            query += " ,[Acc_nature_fk] = "+ Acc_nature_fk;
            query += " ,[Report_type_fk] = "+ Report_type_fk;
            query += "  WHERE  [Acc_id] = "+ Acc_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            /*
            UPDATE [dbo].[Accounts]
   SET 
       [Acc_name] = ''
      ,[Acc_state] = 0
      ,[Acc_nature_fk] =1
      ,[Acc_type_fk] = 1
      ,[Report_type_fk] = 1
 WHERE  [Acc_id] =1
            */
        }

        public string GetNameAccWhereIdAcc(string idAcc)
        {
            //داله تجيب اسم الحساب عن طريق رقمه
            string query = "SELECT  [Acc_name]  FROM [dbo].[Accounts] where [Acc_id] =" + idAcc;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt.Rows.Count > 0)
            {
                query = dt.Rows[0][0].ToString();
                return query;
            }
            else MessageBox.Show(" لم يتم ارجاع بيانات ", "Calss AccountSql function GetNameAccWhereIdAcc");
            return null;


        }

        public bool IsMainAcc(string idAcc)
        {
            //داله ترجع ترو اذا كان الحساب رئيسي ولا فوولس اذا كان فرعي
            //تسختدم عند عرض العملات
            string query = " SELECT  [Acc_type_fk] FROM [dbo].[Accounts] where[Acc_id] ="+ idAcc + "";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            if (dt.Rows.Count > 0) {
                if (dt.Rows[0][0].ToString() == "1")
                    return true;
                else 
                return false;
            }
            else
            {
                //MessageBox.Show("Class AccSQL IsMainAcc Error");
                return true;   
            }


        }




        ///////////////////////////////////////////

        #region دوال عملات الحسابات AccCurrFunctions


       


        public DataTable GetCurrAcc(string idAcc)
        {
            string 
            query =  " SELECT ";
            query += " Currencys.Curr_name,";
            query += " AccCurrency.Maximum,";
            query += " AccCurrency.State,";
            query += " AccCurrency.AccCurr_id";
            query += " FROM AccCurrency INNER JOIN";
            query += " Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN";
            query += " Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id";
            query += " WHERE(AccCurrency.Acc_id_fk = " + idAcc + ")";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }

      

        public void InsertNewCurrAcc(string idAcc,string idCurr)
        {
            string query = " INSERT INTO[dbo].[AccCurrency]" +
        "   (  [Acc_id_fk] ,[Curr_id_fk] ,[Maximum]  ,[State])" +
 "    VALUES  ("+ idAcc + "  ,"+ idCurr + " ,0,1)";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();



        }

        public void UpdetCurrAcc(string idAccCurr , string max,string state)
        {

            

            //string query = "UPDATE [dbo].[AccCurrency]"+
            //     " SET  [Maximum] = "+ max + " ,[State] = "+ state +
            //                                " WHERE AccCurr_id = "+ idAccCurr;
            MessageBox.Show("idAccCurr= "+ idAccCurr+" ||max= "+max+" ||State= "+state);
            string query = "UPDATE [dbo].[AccCurrency]  SET [Maximum] = " + max + " ,[State] = " + state + " WHERE  [AccCurr_id] =" + idAccCurr;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

        }

        //نهاية دوال عملات الحسابات
        #endregion

            /// <summary>
            /// ////////////////////////////////////////////////////
            /// </summary>
            /// <returns></returns>

        #region دوال ليسته سند القيد
        
           #region جلب ارقام الحسابات من جدول عملات الحسابات بدون تكرار عشان اخليه يعمل القيد للحسابات الي معاهم عملات فقط
   public     DataTable GetAllAccidFromAccCurr()
        {
            //تستخدم في اليسته حق عرض الحسابات الي بتعمل لها قيود
            string 
            query = " SELECT ";
            query += " DISTINCT "; //عشان يبعد التكرار
            query += " AccCurrency.Acc_id_fk, ";
            query += "  dbo.Accounts.Acc_name,  ";
            query += " dbo.Accounts.Acc_state ";
            query += " FROM ";
            query += "  dbo.AccCurrency AS AccCurrency INNER JOIN ";
            query += " dbo.Accounts ON AccCurrency.Acc_id_fk = dbo.Accounts.Acc_id ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }
        #endregion
        #region رقم عمله الحساب واسم العمله عشان اعبي الكمبو بوكس فيها واعمل القيد المحاسبي حسب عمله الحساب المحددة
        public DataTable GetAccCurrIdAndNameCurr(string AccId)
        {
            string
            query = " SELECT ";
            query += " AccCurrency.AccCurr_id, ";
            query += " Currencys.Curr_name ";
            query += " FROM ";
            query += "   AccCurrency INNER JOIN ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";
            query += " WHERE ";
            query += "   AccCurrency.Acc_id_fk ="+ AccId;
            query += "  and AccCurrency.State = 1 "; //والعمله متاحه لهذا الحساب
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
        public DataTable GetAccCurrAll()
        {
            string
            query = "  SELECT ";
            query += "   AccCurrency.AccCurr_id ";
            query += " , AccCurrency.Acc_id_fk ";
            query += " , Accounts.Acc_name ";
            query += " , Currencys.Curr_name ";
            query += " , Currencys.Curr_is_local ";
            query += " , Currencys.Curr_echange ";
            query += " , Currencys.Curr_maximum ";
            query += " , Currencys.Curr_minimum ";
            query += " , Accounts.Acc_state ";
            query += " , AccCurrency.State ";
            query += "   FROM    ";
            query += "   AccCurrency  ";
            query += "   INNER JOIN  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id ";
            query += "   INNER JOIN  Currencys   ON AccCurrency.Curr_id_fk = Currencys.Curr_id  ";
            query += "   order by  AccCurrency.Acc_id_fk ";
            #region الاستعلام
            /*


       SELECT       
        AccCurrency.AccCurr_id
        , AccCurrency.Acc_id_fk
        , AccCurrency.Curr_id_fk
        , Accounts.Acc_name
        , Currencys.Curr_name
        , Currencys.Curr_is_local
        ,  Currencys.Curr_echange
        , Currencys.Curr_maximum
        , Currencys.Curr_minimum
        , Accounts.Acc_state
        , AccCurrency.State
       FROM   
          AccCurrency 
          INNER JOIN  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
          INNER JOIN  Currencys   ON AccCurrency.Curr_id_fk = Currencys.Curr_id 

                                order by  AccCurrency.Acc_id_fk

           */
            #endregion

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }

        public DataTable GetAccCurrSerch(string txtSerch)
        {
            string
            query = "  SELECT ";
            query += "   AccCurrency.AccCurr_id ";
            query += " , AccCurrency.Acc_id_fk ";
            query += " , Accounts.Acc_name ";
            query += " , Currencys.Curr_name ";
            query += " , Currencys.Curr_is_local ";
            query += " , Currencys.Curr_echange ";
            query += " , Currencys.Curr_maximum ";
            query += " , Currencys.Curr_minimum ";
            query += " , Accounts.Acc_state ";
            query += " , AccCurrency.State ";
            query += "   FROM    ";
            query += "   AccCurrency  ";
            query += "   INNER JOIN  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id ";
            query += "   INNER JOIN  Currencys   ON AccCurrency.Curr_id_fk = Currencys.Curr_id  ";
            query += "   where  ";
            query += "  AccCurrency.Acc_id_fk like '%"+ txtSerch + "%'";
            query += " 	or 	 Accounts.Acc_name like '%"+ txtSerch + "%'";
            query += " 	or 	 Currencys.Curr_name like '%"+ txtSerch + "%'";
            query += "   order by  AccCurrency.Acc_id_fk ";
            #region الاستعلام
            /*


       SELECT       
        AccCurrency.AccCurr_id
        , AccCurrency.Acc_id_fk
        , AccCurrency.Curr_id_fk
        , Accounts.Acc_name
        , Currencys.Curr_name
        , Currencys.Curr_is_local
        ,  Currencys.Curr_echange
        , Currencys.Curr_maximum
        , Currencys.Curr_minimum
        , Accounts.Acc_state
        , AccCurrency.State
       FROM   
          AccCurrency 
          INNER JOIN  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
          INNER JOIN  Currencys   ON AccCurrency.Curr_id_fk = Currencys.Curr_id 
          where 	
			 AccCurrency.Acc_id_fk like '%1%' 
			or 	 Accounts.Acc_name like '%1%'
			or 	 Currencys.Curr_name like '%1%'
                                order by  AccCurrency.Acc_id_fk

           */
            #endregion

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }
        public string GetIdAccCurr(string AccId,string CurrName)
        {
            string
            query = " SELECT ";
            query += " AccCurrency.AccCurr_id ";
            query += " FROM  AccCurrency INNER JOIN ";
            query += "    Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id ";
            query += " WHERE ";
            query += " (Accounts.Acc_id = "+ AccId + ")";
            query += " AND ";
            query += " (Currencys.Curr_name = "+AddApostropheToString(CurrName) +")";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return (dt.Rows.Count > 0? dt.Rows[0][0].ToString(): null);
        }
        #endregion
        #endregion
    }
}
