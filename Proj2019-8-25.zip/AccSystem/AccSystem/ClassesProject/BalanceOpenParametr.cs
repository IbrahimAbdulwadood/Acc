﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccSystem.ClassesProject
{
   public class BalanceOpenParametr
    {
        public string Serial_number_balance { set; get; }
        public string AccCurr_id_fk { set; get; }
        public string Debt_local { set; get; }
        public string Credit_local { set; get; }
        public string Debt_foreign { set; get; }
        public string Credit_foreign { set; get; }
        public string CurrExching { set; get; }
        public string Note { set; get; }



    }
}
