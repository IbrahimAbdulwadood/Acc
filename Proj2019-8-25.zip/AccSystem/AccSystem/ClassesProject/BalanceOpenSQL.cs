﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccSystem.ClassesProject
{
    class BalanceOpenSQL
    {
        #region المتغيرات 
        DataTable dt;
        ConnectionDB con = new ConnectionDB();
        #endregion

      public  string GetMaxBlaneOpen()
        {
            string
        query = " SELECT  ";
            query += "   isnull(max(Serial_number_balance)+1,1) ";
            query += "  FROM  BalanceOpen  ";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString();
            else return string.Empty;
            /*
            SELECT      
            isnull(max(Serial_number_balance)+1,1)
            FROM  BalanceOpen
            */
        }

      public  DataTable GetAllBlan()
        {
            string
            query  = "  SELECT  ";
            query += "     BalanceOpen.Serial_number_balance    ";
            query += "  ,  Accounts.Acc_id  ";
            query += "  ,  Accounts.Acc_name   ";
            query += "  ,  BalanceOpen.Debt_local   ";
            query += "  ,  BalanceOpen.Credit_local  ";
            query += "  ,  BalanceOpen.Debt_foreign  ";
            query += "  ,  BalanceOpen.Credit_foreign  ";
            query += "  ,  BalanceOpen.CurrExching  ";
            query += "  ,  Currencys.Curr_sumbol_eng ";
            query += "  ,  BalanceOpen.Note   ";
            query += "  ,  BalanceOpen.AccCurr_id_fk   ";
            query += "  ,  BalanceOpen.Date_Balance_open   ";
            query += "  ,  BalanceOpen.Posting   ";

            query += "  FROM    AccCurrency INNER JOIN  ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "   BalanceOpen ON AccCurrency.AccCurr_id = BalanceOpen.AccCurr_id_fk INNER JOIN  ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id  ";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region
            /*
          SELECT        
         BalanceOpen.Serial_number_balance
        , Accounts.Acc_id
        , Accounts.Acc_name
        , BalanceOpen.Debt_local
        , BalanceOpen.Credit_local
        , BalanceOpen.Debt_foreign
        , BalanceOpen.Credit_foreign
        , BalanceOpen.CurrExching
        , Currencys.Curr_sumbol_eng
        ,BalanceOpen.Note
        , BalanceOpen.AccCurr_id_fk
        , BalanceOpen.Date_Balance_open
         ,  BalanceOpen.Posting
        FROM            AccCurrency INNER JOIN
                                 Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                                 BalanceOpen ON AccCurrency.AccCurr_id = BalanceOpen.AccCurr_id_fk INNER JOIN
                                 Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
            */
            #endregion

        }
        public void DeletBalanceOpen(string Serial_number_balance)
        {

            string
            query = "    DELETE FROM [dbo].[BalanceOpen]     ";
            query += "   WHERE Serial_number_balance=   "+ Serial_number_balance;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
            DELETE FROM [dbo].[BalanceOpen]
      WHERE Serial_number_balance=1
            */
            #endregion
        }
        public void UpdateBalanceOpen(
     string Serial_number_balance
     ,string AccCurr_id_fk
     ,string Debt_local
     ,string Credit_local
     ,string Debt_foreign
     ,string Credit_foreign
     ,string Date_Balance_open
     ,string User_id_fk
     ,string CurrExching
     ,string Note
     )
        {

            string
            query = "    UPDATE [dbo].[BalanceOpen]    ";
            query += "   SET  ";
            query += "     [AccCurr_id_fk]=   "+ AccCurr_id_fk;
            query += "    ,[Debt_local]=   "+ Debt_local;
            query += "    ,[Credit_local]=   "+ Credit_local;
            query += "    ,[Debt_foreign]=  "+ Debt_foreign;
            query += "    ,[Credit_foreign]=   "+ Credit_foreign;
            query += "    ,[Date_Balance_open]=  "+con.AddApostropheToString(Date_Balance_open);
            query += "    ,[User_id_fk]=   "+ User_id_fk;
            query += "    ,[CurrExching]=   "+ CurrExching;
            query += "    ,[Note]= "+ con.AddApostropheToString(Note);
            query += "   WHERE Serial_number_balance =    "+ Serial_number_balance;

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region  
            /*
            UPDATE [dbo].[BalanceOpen]
               SET 
                   [AccCurr_id_fk] = 15
                  ,[Debt_local] =  0
                  ,[Credit_local] = 1
                  ,[Debt_foreign] =  0
                  ,[Credit_foreign] = 0
                  ,[Date_Balance_open] = '2019-4-4'
                  ,[User_id_fk] = 1
                  ,[CurrExching] = 1
    
             WHERE Serial_number_balance =1
            */
            #endregion

        }
        public void InsertNewBalanceOpen(
       string AccCurr_id_fk
      ,string Debt_local 
      ,string Credit_local
      ,string Debt_foreign
      ,string Credit_foreign
      ,string Date_Balance_open
      ,string User_id_fk
      ,string CurrExching
      ,string Note
      )
        {
            string
             query = "    INSERT INTO [dbo].[BalanceOpen]   ";
            query += "   (   ";
            query += "     [Serial_number_balance]   ";
            query += "    ,[AccCurr_id_fk]   ";
            query += "    ,[Debt_local]   ";
            query += "    ,[Credit_local]   ";
            query += "    ,[Debt_foreign]  ";
            query += "    ,[Credit_foreign]   ";
            query += "    ,[Date_Balance_open]  ";
            query += "    ,[User_id_fk]   ";
            query += "    ,[CurrExching]   ";
            query += "    ,[Posting]  ";
            query += "    ,[Note]  ";
            query += "   )   ";
            query += "    VALUES   ";
            query += "    (  ";
            query += GetMaxBlaneOpen();
            query += "   ,  "+ AccCurr_id_fk;
            query += "   ,  "+ Debt_local;
            query += "   ,  "+ Credit_local;
            query += "   ,  "+ Debt_foreign;
            query += "   ,  "+ Credit_foreign;
            query += "   ,  "+con.AddApostropheToString(Date_Balance_open);
            query += "   ,  "+ User_id_fk;
            query += "   ,  "+ CurrExching;
            query += "   , 0 ";
            query += "   , "+con.AddApostropheToString(Note);
            query += " ) ";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
            INSERT INTO [dbo].[BalanceOpen]
           (
		   [Serial_number_balance]
           ,[AccCurr_id_fk]
           ,[Debt_local]
           ,[Credit_local]
           ,[Debt_foreign]
           ,[Credit_foreign]
           ,[Date_Balance_open]
           ,[User_id_fk]
           ,[CurrExching]
           ,[Posting]
		   )
     VALUES
           (
		   1
           ,18
           ,0
           ,0
           ,0
           ,0
           ,'2019-8-8'
           ,1
           ,1
           ,0
		   )
            */
            #endregion

        }


    }
}
