﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccSystem.ClassesProject
{
    public class BillParametr
    {
        public string idItemUnit { get; set; }
        public string barc { get; set; }
        public string Item_name { get; set; }
        public string Unit_name { get; set; }
        public string Selling_price { get; set; } // سعر الوحدة
        public string price_part { get; set; }  // سعر الجزء
        public string Unit_part { get; set; } // عدد اجزاء الوحدة
        public string Quantity { get; set; } //الكمية وحدة
        public string Part { get; set; }  // الكمية جزء
        public string Bill_body_id { get; set; }
        public string Total { get; set; }

        /*
          ItemUnit.idItemUnit,
    Items.barc,
    Items.Item_name, 
    Units.Unit_name,
    ItemUnit.Selling_price, 
      
                                                       
                                   idItemUnit, 0
                                   Items.barc, 1
                                   Item_name,  2
                                   Unit_name,  3
                                   Selling_price,  4   سعر الوحدة
                                   price_part ,  5   سعر الجزء
                                   Items.State, 6    حالة الصنف
                                   ItemUnit.State, 7     حالة وحدة الصنف
                                   Units.Unit_part 8  عدد اجزاء الوحدة
 
                                    */



    }
}
