﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.ClassesProject
{
    class BillSalesSQL
    {
        #region المتغيرات
        DataTable dt;
        ConnectionDB con = new ConnectionDB();

        #endregion
public string InsertNewSalesHaed(string Type_id_fk
                            ,string Date_salesbill
                            ,string Cust_id_fk
                            ,string BoxUser_id_fk
                            ,string Sum
                            ,string Total
                            ,string Discount
                            ,string Note
                            , string Exching
    )
        {

            string Bill_id = GetMaxIdBillHaed("Bill_id", "SalesBillHead");
            string
            query = "  INSERT INTO [dbo].[SalesBillHead] ";
            query += "  ([Bill_id] ";
            query += "  ,[Type_id_fk]  ";
            query += "  ,[Date_salesbill] ";
            query += "  ,[Cust_id_fk]  ";
            query += "  ,[BoxUser_id_fk]  ";
            query += "  ,[Sum]  ";
            query += "  ,[Total] ";
            query += "  ,[Discount]  ";
            query += "  ,[Note]  ";
            query += "  ,[posting]  ";
            query += "  ,[Exching] ";
            query += "   ) ";
            query += "  VALUES  ";
            query += "  ( "+ Bill_id;
            query += "   ,"+ Type_id_fk;
            query += "   ,"+con.AddApostropheToString(Date_salesbill);
            query += "   ,"+ Cust_id_fk;
            query += "   ,"+ BoxUser_id_fk;
            query += "   ,"+ Sum;
            query += "   ,"+ Total;
            query += "   ,"+ Discount;
            query += "   ,"+con.AddApostropheToString(Note);
            query += "   ,0";
            query += "   ,"+ Exching;
            query += "    )  ";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            return Bill_id;
            #region اضافة راس
            /*
            INSERT INTO [dbo].[SalesBillHead]
               ([Bill_id]
               ,[Type_id_fk]
               ,[Date_salesbill]
               ,[Cust_id_fk]
               ,[BoxUser_id_fk]
               ,[Sum]
               ,[Total]
               ,[Discount]
               ,[Note]
               ,[posting])
         VALUES
               (1
               ,1
               ,'2019-9-9'
               ,1
               ,5
               ,12000
               ,11000
               ,1000
               ,''
               ,0
               )
            */
            #endregion

        }

        public void Delet(string Bill_id = "-1")
        {
            string
          query = "      DELETE FROM [dbo].[SalesBillHead]    WHERE Bill_id= " + Bill_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            /*
            DELETE FROM [dbo].[SalesBillHead]
      WHERE Bill_id=1
            */
        }
        public void InsertNewSalesBody(string Bill_id_fk, string idItemUnit_fk
                              , string Quantity, string Part
                              , string Selling_price, string Selling_part, string Total
                             
    )
        {

            
            string
            query = "  INSERT INTO [dbo].[SalesBillBody] ";
            query += "  ([Bill_id_fk] ";
            query += "  ,[Bill_body_id]  ";
            query += "  ,[idItemUnit_fk] ";
            query += "  ,[Quantity]  ";
            query += "  ,[Part]  ";
            query += "  ,[Selling_price]  ";
            query += "  ,[Selling_part] ";
            query += "  ,[Total]  ";
           
            query += "   ) ";
            query += "  VALUES  ";
            query += "  ( " + Bill_id_fk;
            query += "   ," + GetMaxIdBillSalesBody(Bill_id_fk);
            query += "   ," + idItemUnit_fk;
            query += "   ," + Quantity;
            query += "   ," + Part;
            query += "   ," + Selling_price;
            query += "   ," + Selling_part;
            query += "   ," + Total;
           
            query += "    )  ";
          //  MessageBox.Show(query);
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();


            #region اضافة جسم
            /*
            INSERT INTO [dbo].[SalesBillBody]
               ([Bill_id_fk]
               ,[Bill_body_id]
               ,[idItemUnit_fk]
               ,[Quantity]
               ,[Part]
               ,[Selling_price]
               ,[Selling_part]
               ,[Total])
         VALUES
               (1
               ,2
               ,1
               ,12
               ,1
               ,100
               ,1200
               )
            */
            #endregion

        }




        public string GetMaxIdBillHaed(string nameColumn,string nameTable)
        {
            //^^
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string 
            query = " SELECT isnull(max("+ nameColumn;
            query += " ),0)+1 From ["+ nameTable;
            query += "]";
            con.OpenConnetion();
            dt = con.Query(query, true);
          //  MessageBox.Show(query);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();

            return id;

        }

        public string GetMaxIdBillSalesBody(string Bill_id_fk)
        {
            //^^
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query =
                "SELECT   isnull(max([Bill_body_id])+1,1)  FROM [dbo].[SalesBillBody] where  [Bill_id_fk]= "+ Bill_id_fk;
            /*
            SELECT 
      isnull(max([Bill_body_id])+1,1)
      
  FROM [dbo].[SalesBillBody]
   where 
  [Bill_id_fk]=1
            */
       //     MessageBox.Show(query);
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;

        }

        #region تفاصيل الفاتورة
        public    DataTable GetSalesBody(string Bill_id_fk)
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
           

            string
            query = " SELECT ";
            query += "   SalesBillBody.Bill_body_id ";
            query += "  ,ItemUnit.idItemUnit ";
            query += "  ,Items.barc  ";
            query += "  ,Items.Item_name ";
            query += "  ,Units.Unit_name ";
            query += "  ,SalesBillBody.Quantity ";
            query += "  ,SalesBillBody.Part ";
            query += "  ,SalesBillBody.Selling_price as PriceQuantity ";
            query += "  ,SalesBillBody.Selling_part as PricePart ";
            query += "  ,(SalesBillBody.Quantity * SalesBillBody.Selling_price) as TotaQuan ";
            query += "  ,(SalesBillBody.Part * SalesBillBody.Selling_part) as TotaPart ";
            query += "  ,SalesBillBody.Total ";
            query += "  ,Units.Unit_part ";
           
            query += " FROM  ";
            query += "   SalesBillBody INNER JOIN ";
            query += "    ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN ";
            query += "    Items ON ItemUnit.Item_id_fk = Items.Item_id INNER JOIN ";
            query += "   Units ON ItemUnit.Unit_id_fk = Units.Unit_id  ";
            query += "  WHERE ";
            query += "   (SalesBillBody.Bill_id_fk = "+ Bill_id_fk + ") ";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }
        public void UpdateSalesBody(
            string Bill_id_fk,string Bill_body_id
            ,string idItemUnit_fk,string Quantity
            ,string Part,string Selling_price
            ,string Selling_part,string Total)
        {
            string
            query = " UPDATE [dbo].[SalesBillBody] ";
            query += " SET  ";
            query += "  [idItemUnit_fk] =  "+ idItemUnit_fk;
            query += " ,[Quantity] = "+ Quantity;
            query += " ,[Part] =  "+ Part;
            query += " ,[Selling_price] =  "+ Selling_price;
            query += " ,[Selling_part] = "+ Selling_part;
            query += " ,[Total] = "+ Total;
            query += "   WHERE   ";//
            query += "      [Bill_id_fk] =  "+ Bill_id_fk;//
            query += "  and [Bill_body_id] = "+ Bill_body_id;//
            MessageBox.Show(query);
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            #region
            /*
            UPDATE [dbo].[SalesBillBody]
       SET  
           [idItemUnit_fk] = 3
          ,[Quantity] = 66
          ,[Part] = 77
          ,[Selling_price] = 98
          ,[Selling_part] = 99
          ,[Total] = 97
     WHERE [Bill_id_fk] = 1 and [Bill_body_id] =1
            */
            #endregion
        }
        public void UpdateSalesHaed(
           string Bill_id, string Type_id_fk
           , string Date_salesbill, string Cust_id_fk
           , string BoxUser_id_fk, string Sum
           , string Total, string Discount
           , string Note,string Exching)
        {
            string
            query = " UPDATE [dbo].[SalesBillHead] ";
            query += " SET  ";
            query += "  [Type_id_fk] =  " + Type_id_fk;
            query += " ,[Date_salesbill] = " + con.AddApostropheToString(Date_salesbill);
            query += " ,[Cust_id_fk] =  " + Cust_id_fk;
            query += " ,[BoxUser_id_fk] =  " + BoxUser_id_fk;
            query += " ,[Sum] = " + Sum;
            query += " ,[Total] = " + Total;
            query += " ,[Discount] = " + Discount;
            query += " ,[Note] = " + con.AddApostropheToString(Note);
            query += " ,[posting] = 0";
            query += " ,[Exching] ="+ Exching;
            query += "   WHERE   ";//
            query += "      [Bill_id] =  " + Bill_id;//
         

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            #region
            /*
            UPDATE [dbo].[SalesBillHead]
           SET 
               [Type_id_fk] = 2
              ,[Date_salesbill] = ''
              ,[Cust_id_fk] = 1
              ,[BoxUser_id_fk] = 8
              ,[Sum] = 1200
              ,[Total] = 1000
              ,[Discount] = 99898
              ,[Note] = 'Note'
              ,[posting] = 0
         WHERE [Bill_id] = 1
            */
            #endregion
        }
        public void DeletSalesBody(string Bill_id_fk,string Bill_body_id)
        {
            string
            query = "  DELETE   ";
            query += " FROM [dbo].[SalesBillBody]  ";
            query += "  WHERE ";
            query += "  Bill_body_id= "+ Bill_body_id;
            query += " and Bill_id_fk=  "+ Bill_id_fk;//
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
            DELETE FROM [dbo].[SalesBillBody]
      WHERE Bill_body_id=1and Bill_id_fk=2
            */
            #endregion
        }

        #region الاستعلام
        /*
            SELECT
       SalesBillBody.Bill_body_id
    , ItemUnit.idItemUnit
    , Items.barc
    , Items.Item_name
    , Units.Unit_name
    , SalesBillBody.Quantity
    , SalesBillBody.Part
    , SalesBillBody.Selling_price as PriceQuantity
    ,SalesBillBody.Selling_part as PricePart
    ,(SalesBillBody.Quantity * SalesBillBody.Selling_price) as TotaQuan
    ,(SalesBillBody.Part*SalesBillBody.Selling_part) as TotaPart
    ,SalesBillBody.Total
    ,Units.Unit_part

    FROM            SalesBillBody INNER JOIN
                             ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id INNER JOIN
                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id
    WHERE        (SalesBillBody.Bill_id_fk = 1)
        
        */
        #endregion
        #endregion
        public DataTable GetAllSalesHaed()
        {

            if (dt != null)
                dt = null;
            dt = new DataTable();


            string
            query = " SELECT ";
            query += " SalesBillHead.Bill_id,  ";
            query += " TypeBill.Type_neme, ";
            query += " SalesBillHead.Date_salesbill, ";
            query += " SalesBillHead.Cust_id_fk,   ";
            query += " Customers.Cust_name, ";
            query += " BoxUser.Box_id_fk,  ";
            query += " Boxes.Box_name,  ";
            
            query += " BoxUser.BoxUser_id,  ";
            query += " Users.User_id,   ";
            query += " Users.User_name,   ";
            query += " SalesBillHead.Sum, ";
            query += " SalesBillHead.Total,  ";
            query += " SalesBillHead.Discount,  ";
            query += " SalesBillHead.Note,  ";
            query += " SalesBillHead.posting  ";
            query += "  FROM            SalesBillHead INNER JOIN  ";
            query += "  TypeBill ON SalesBillHead.Type_id_fk = TypeBill.Type_id INNER JOIN  ";
            query += "  Customers ON SalesBillHead.Cust_id_fk = Customers.Cust_id INNER JOIN   ";
            query += "  BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN  ";
            query += "  Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN  ";
            query += "  Boxes ON BoxUser.Box_id_fk = Boxes.Box_id ";
        
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;


            #region بيانات جميع الفواتير
            /*
            SELECT    
            SalesBillHead.Bill_id,
            TypeBill.Type_neme,
            SalesBillHead.Date_salesbill,
            SalesBillHead.Cust_id_fk, 
            Customers.Cust_name,
            BoxUser.Box_id_fk, 
            Boxes.Box_name, 
            BoxUser.BoxUser_id,
            Users.User_id, 
          	Users.User_name, 
            SalesBillHead.Sum,
            SalesBillHead.Total,
            SalesBillHead.Discount,
            SalesBillHead.Note,
            SalesBillHead.posting
    FROM            SalesBillHead INNER JOIN
                             TypeBill ON SalesBillHead.Type_id_fk = TypeBill.Type_id INNER JOIN
                             Customers ON SalesBillHead.Cust_id_fk = Customers.Cust_id INNER JOIN
                             BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
                             Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN
                             Boxes ON BoxUser.Box_id_fk = Boxes.Box_id
            */
            #endregion
        }
        public DataTable SaerchSalesHaed(string TxT)
        {

            if (dt != null)
                dt = null;
            dt = new DataTable();


            string
            query = " SELECT ";
            query += " SalesBillHead.Bill_id,  ";
            query += " TypeBill.Type_neme, ";
            query += " SalesBillHead.Date_salesbill, ";
            query += " SalesBillHead.Cust_id_fk,   ";
            query += " Customers.Cust_name, ";
            query += " BoxUser.Box_id_fk,  ";
            query += " Boxes.Box_name,  ";
            query += " BoxUser.BoxUser_id,  ";
            query += " Users.User_id,   ";
            query += " Users.User_name,   ";
            query += " SalesBillHead.Sum, ";
            query += " SalesBillHead.Total,  ";
            query += " SalesBillHead.Discount,  ";
            query += " SalesBillHead.Note,  ";
            query += " SalesBillHead.posting  ";
            query += "  FROM            SalesBillHead INNER JOIN  ";
            query += "  TypeBill ON SalesBillHead.Type_id_fk = TypeBill.Type_id INNER JOIN  ";
            query += "  Customers ON SalesBillHead.Cust_id_fk = Customers.Cust_id INNER JOIN   ";
            query += "  BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN  ";
            query += "  Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN  ";
            query += "  Boxes ON BoxUser.Box_id_fk = Boxes.Box_id ";
            
            query += "  where  ";
            query += "   SalesBillHead.Bill_id like'%"+ TxT + "%'  ";
            query += "   or  TypeBill.Type_neme like '%" + TxT + "%'  ";
            query += "   or  SalesBillHead.Cust_id_fk like '%" + TxT + "%'  ";
            query += "   or  Customers.Cust_name like '%" + TxT + "%'    ";
            query += "   or  BoxUser.Box_id_fk like '%" + TxT + "%'   ";
            query += "   or  Boxes.Box_name like '%" + TxT + "%'    ";
            query += "   or  SalesBillHead.Sum like '%" + TxT + "%'  ";
            query += "   or  SalesBillHead.Total like '%" + TxT + "%'   ";
            query += "   or  SalesBillHead.Note like '%" + TxT + "%'  ";
            query += "   or  SalesBillHead.Discount like '%" + TxT + "%'  ";
        

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;


            #region بيانات جميع الفواتير
            /*
            SELECT    
            SalesBillHead.Bill_id,
            TypeBill.Type_neme,
            SalesBillHead.Date_salesbill,
            SalesBillHead.Cust_id_fk, 
            Customers.Cust_name,
            BoxUser.Box_id_fk, 
            Boxes.Box_name, 
            BoxUser.BoxUser_id,
            Users.User_id, 
          	Users.User_name,  
            SalesBillHead.Sum,
            SalesBillHead.Total,
            SalesBillHead.Discount,
            SalesBillHead.Note,
            SalesBillHead.posting
    FROM            SalesBillHead INNER JOIN
                             TypeBill ON SalesBillHead.Type_id_fk = TypeBill.Type_id INNER JOIN
                             Customers ON SalesBillHead.Cust_id_fk = Customers.Cust_id INNER JOIN
                             BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
                             Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN
                             Boxes ON BoxUser.Box_id_fk = Boxes.Box_id
                              where 
							      SalesBillHead.Bill_id like'%%'
							  or  TypeBill.Type_neme like '%%'
							  or  SalesBillHead.Date_salesbill like '%%' 
							  or  SalesBillHead.Cust_id_fk like '%%'
							  or  Customers.Cust_name like '%%'  
							  or  BoxUser.Box_id_fk like '%%' 
							  or  Boxes.Box_name like '%%'  
							  or  SalesBillHead.Sum like '%%'
							  or  SalesBillHead.Total like '%%' 
							  or  SalesBillHead.Note like '%%'
							  or  SalesBillHead.Discount like '%%'
            */
            #endregion
        }
        #region  لسته عرض الاصناف
       
        public DataTable GetIteamAll(string Group_id="-1")
        {
            if (dt != null)
                dt = null;
                dt = new DataTable();
           

            string
            query = "    SELECT ";
            query += "   ItemUnit.idItemUnit, ";
            query += "   Items.barc, ";
            query += "   Items.Item_name,   ";
            query += "   Units.Unit_name,   ";//
            query += "   ItemUnit.Selling_price,  ";
         query += " iif(ItemUnit.Selling_price>=0,ROUND((ItemUnit.Selling_price / Units.Unit_part), -1),0) as price_part ,    ";
            query += "   Items.State,   ";
            query += "   ItemUnit.State AS Expr1, ";
            query += "   Units.Unit_part ";//
            query += "   FROM      ";
            query += "  GroupStored INNER JOIN  ";
            query += "  ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN  ";
            query += "  Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN  ";
            query += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN  ";
            query += "  Units ON ItemUnit.Unit_id_fk = Units.Unit_id  ";
            if(Group_id != "-1")
            {
                query += " WHERE   ";
             
                query += "  (GroupStored.Group_id = "+ Group_id + ")  ";
            }
            query += "  order by Items.barc  ";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            //System.Windows.Forms.MessageBox.Show(query);
            return dt;

        }
       public DataTable GetIteamSerch(string Group_id = "-1",string TxT="-1")
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();


            string
            query = "    SELECT ";
            query += "   ItemUnit.idItemUnit, ";
            query += "   Items.barc, ";
            query += "   Items.Item_name,   ";
            query += "   Units.Unit_name,   ";//
            query += "   ItemUnit.Selling_price,  ";//
                                                   
         query += " iif(ItemUnit.Selling_price>=0,ROUND((ItemUnit.Selling_price / Units.Unit_part), -1),0) as price_part ,    ";
            query += "   Items.State,   ";
            query += "   ItemUnit.State AS Expr1, ";
            query += "   Units.Unit_part ";//
            query += "   FROM      ";
            query += "  GroupStored INNER JOIN  ";
            query += "  ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN  ";
            query += "  Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN  ";
            query += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN  ";
            query += "  Units ON ItemUnit.Unit_id_fk = Units.Unit_id  ";
           
             if ( Group_id != "-1")
            {
                query += " WHERE   ";
                query += " (GroupStored.Group_id = " + Group_id + ")  ";
                query += "   AND (      ";
                query += "        Items.barc like '%" + TxT + "%'";
                query += "     or Items.Item_name like '%" + TxT + "%'";
                query += "     or  Units.Unit_name like '%" + TxT + "%'";
                query += "     or ItemUnit.Selling_price like '%" + TxT + "%'";
                query += "   )      ";

            }
            else if ( Group_id == "-1")
            {
                query += " WHERE   ";
            
                query += "    (      ";
                query += "        Items.barc like '%" + TxT + "%'";
                query += "     or Items.Item_name like '%" + TxT + "%'";
                query += "     or  Units.Unit_name like '%" + TxT + "%'";
                query += "     or ItemUnit.Selling_price like '%" + TxT + "%'";
                query += "   )      ";
            }
            query += "  order by Items.barc  ";
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
          //  System.Windows.Forms.MessageBox.Show(query, dt.Rows.Count.ToString());
            return dt;

        }

        public Dictionary<string,string> GetQuantetyUiteAndPart4UiteItemIdNow(string idItemUnit)
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            Dictionary<string, string> QuntityItemUnit = new Dictionary<string, string>();
            QuntityItemUnit.Clear();

            string
           query = "    SELECT ";
          
            query += "  ( ISNULL(Sum( Quantity),0)    ";

            query += "   +(SELECT  ISNULL(Sum( Quantity),0)";
            query += "   FROM PurchBillBody";
            query += "  where idItemUnit_fk = "+ idItemUnit + ")";

            query += "   +(SELECT  ISNULL(Sum( Quantity),0)";
            query += "   FROM ReturnSalesBillBody";
            query += "    WHERE idItemUnit_fk = "+ idItemUnit + ")";

            query += "  -(SELECT   ISNULL(Sum( Quantity),0)";
            query += "    FROM SalesBillBody";
            query += "    WHERE idItemUnit_fk = "+ idItemUnit + ")";


            query += "  -(SELECT   ISNULL(Sum( Quantity),0)";
            query += "      FROM ReturnPurchBillBody";
            query += "      WHERE idItemUnit_fk = "+ idItemUnit + ")";

            query += "   	) as Qun   ";


            query += "   , (";
            query += "  ISNULL(SUM(Part), 0)   ";

            query += "  +(SELECT ISNULL(SUM(Part),0)";
            query += "  FROM PurchBillBody";
            query += "    where idItemUnit_fk = "+ idItemUnit + " ) ";

            query += "  +(SELECT  ISNULL(SUM(Part),0)";
            query += "    FROM ReturnSalesBillBody";
            query += "    WHERE idItemUnit_fk = "+ idItemUnit + ")    ";

            query += "   -(SELECT  ISNULL(SUM(Part),0)";
            query += "     FROM SalesBillBody";
            query += "     WHERE idItemUnit_fk = "+ idItemUnit + ") ";

            query += "  -(SELECT  ISNULL(SUM(Part),0)";
            query += "    FROM ReturnPurchBillBody";
            query += "    WHERE idItemUnit_fk = "+ idItemUnit + ") ";

            query += "  ) as part    ";

            query += "  FROM          FirstBalanceBody";
            query += " WHERE(idItemUnite_fk = "+ idItemUnit + ") ";
           

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            if (dt != null && dt.Rows.Count > 0 )
            { QuntityItemUnit.Add("Quantity", dt.Rows[0][0].ToString());
              QuntityItemUnit.Add("Part", dt.Rows[0][1].ToString());
            }
            return QuntityItemUnit;
            #region  الاستعلام النهائي ^^
            /*
            SELECT   
  ( ISNULL(Sum( Quantity),0)

   +(SELECT  ISNULL(Sum( Quantity),0)
     FROM    PurchBillBody 
	where idItemUnit_fk=3)

	 +(SELECT  ISNULL(Sum( Quantity),0)
	FROM    ReturnSalesBillBody
	WHERE   idItemUnit_fk = 3)

	-(SELECT   ISNULL(Sum( Quantity),0)
		FROM            SalesBillBody
		WHERE        idItemUnit_fk = 3)

	-(SELECT      ISNULL(Sum( Quantity),0)
		FROM            ReturnPurchBillBody
		WHERE        idItemUnit_fk = 3)
		) as Qun


	, (
	ISNULL(SUM(Part),0)

	+(SELECT ISNULL(SUM(Part),0)
	FROM     PurchBillBody 
    where idItemUnit_fk=3 )

	+(SELECT  ISNULL(SUM(Part),0)

	FROM   ReturnSalesBillBody
	WHERE    idItemUnit_fk = 3)

	-(SELECT  ISNULL(SUM(Part),0)
		FROM    SalesBillBody
		WHERE  idItemUnit_fk = 3)

		-(SELECT  ISNULL(SUM(Part),0)
		FROM     ReturnPurchBillBody
		WHERE   idItemUnit_fk = 3)
		) as part


FROM            FirstBalanceBody
WHERE        (idItemUnite_fk = 3)







            */
            #endregion
            #region اجمالي الكمياات النهائي صف واحد ^^
            /*
            SELECT     
            ( ISNULL(sum(PurchBillBody.Quantity),0)
             +(  SELECT       ISNULL(sum( ReturnSalesBillBody.Quantity),0)
    FROM            Units INNER JOIN
                             ItemUnit ON Units.Unit_id = ItemUnit.Unit_id_fk INNER JOIN
                             ReturnSalesBillBody ON ItemUnit.idItemUnit = ReturnSalesBillBody.idItemUnit_fk INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=3 
                )
                -(SELECT       ISNULL( Sum( SalesBillBody.Quantity),0)
    FROM            SalesBillBody INNER JOIN
                             ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=3
                )
                -(SELECT     ISNULL(sum(ReturnPurchBillBody.Quantity),0)
    FROM            ReturnPurchBillBody INNER JOIN
                             ItemUnit ON ReturnPurchBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=3
                )
                )  as Qun



            ,( isnull(sum(PurchBillBody.Part),0)
            +( SELECT     ISNULL(sum( ReturnSalesBillBody.Part),0)
    FROM            Units INNER JOIN
                             ItemUnit ON Units.Unit_id = ItemUnit.Unit_id_fk INNER JOIN
                             ReturnSalesBillBody ON ItemUnit.idItemUnit = ReturnSalesBillBody.idItemUnit_fk INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=3
                )
                -(SELECT      ISNULL(sum( SalesBillBody.Part),0)
    FROM            SalesBillBody INNER JOIN
                             ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=3
                 )
                 -(SELECT     ISNULL(sum(ReturnPurchBillBody.Part),0)
    FROM            ReturnPurchBillBody INNER JOIN
                             ItemUnit ON ReturnPurchBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=3
                             )

                             ) as par




    FROM            PurchBillBody INNER JOIN
                             ItemUnit ON PurchBillBody.idItemUnit_fk = ItemUnit.idItemUnit 
                             where ItemUnit.idItemUnit=3










            */
            #endregion
            #region  اجمالي  كمية الصنف حسب الوحدة في الجداول الاربعة في اربعه صفوف
            /*

            SELECT       ISNULL( Sum( SalesBillBody.Quantity),0),ISNULL(sum( SalesBillBody.Part),0)
    FROM            SalesBillBody INNER JOIN
                             ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=1
    union all

    SELECT     ISNULL(sum(ReturnPurchBillBody.Quantity),0),ISNULL(sum(ReturnPurchBillBody.Part),0)
    FROM            ReturnPurchBillBody INNER JOIN
                             ItemUnit ON ReturnPurchBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=1
    union all						
    SELECT        ISNULL(sum( PurchBillBody.Quantity),0), ISNULL(sum( PurchBillBody.Part),0)
    FROM            Units INNER JOIN
                             ItemUnit ON Units.Unit_id = ItemUnit.Unit_id_fk INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id INNER JOIN
                             PurchBillBody ON ItemUnit.idItemUnit = PurchBillBody.idItemUnit_fk where  ItemUnit.idItemUnit=1
    union all
    SELECT       ISNULL(sum( ReturnSalesBillBody.Quantity),0), ISNULL(sum( ReturnSalesBillBody.Part),0)
    FROM            Units INNER JOIN
                             ItemUnit ON Units.Unit_id = ItemUnit.Unit_id_fk INNER JOIN
                             ReturnSalesBillBody ON ItemUnit.idItemUnit = ReturnSalesBillBody.idItemUnit_fk INNER JOIN
                             Items ON ItemUnit.Item_id_fk = Items.Item_id where  ItemUnit.idItemUnit=1

            */

            #endregion



        }

        /*
       SELECT        ItemUnit.idItemUnit, Items.barc, Items.Item_name, Units.Unit_name, ItemUnit.Selling_price,iif(ItemUnit.Selling_price>=0,
ROUND((ItemUnit.Selling_price/Units.Unit_part),2)
,
0
) as price_part ,
 Items.State, ItemUnit.State AS Expr1,
Units.Unit_part

FROM            GroupStored INNER JOIN
                         ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                         Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                         ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN
                         Units ON ItemUnit.Unit_id_fk = Units.Unit_id
WHERE       Items.barc like '%%' or Items.Item_name like '%%' or  Units.Unit_name like '%%' or ItemUnit.Selling_price like '%%'
        */
        #endregion



        #region حركة صنف من جدول المبيعات ومردود المبيعات
        /*
        
        SELECT        Items.barc, Items.Item_name, Units.Unit_name, SalesBillBody.Quantity, SalesBillBody.Part,
 SalesBillHead.Date_salesbill,SalesBillBody.Bill_id_fk, TypeBill.Type_neme ,IIF(SalesBillBody.Quantity>0,'فاتورة مبيعات','فاتورة مبيعات') as OpraType
FROM            SalesBillHead INNER JOIN
                         TypeBill ON SalesBillHead.Type_id_fk = TypeBill.Type_id INNER JOIN
                         SalesBillBody ON SalesBillHead.Bill_id = SalesBillBody.Bill_id_fk INNER JOIN
                         ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                         Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                         Items ON ItemUnit.Item_id_fk = Items.Item_id where ItemUnit.idItemUnit=1

						 union all
SELECT        Items.barc, Items.Item_name, Units.Unit_name, ReturnPurchBillBody.Quantity, ReturnPurchBillBody.Part, ReturnPurchBillHead.Date_return_pruchbill,
   ReturnPurchBillBody.Return_bill_id_fk, 
                         TypeBill.Type_neme,IIF(ReturnPurchBillBody.Quantity>0,'مردود مشتريات','مردود مشتريات') as OpraType
FROM            ReturnPurchBillHead INNER JOIN
                         TypeBill ON ReturnPurchBillHead.Type_id_fk = TypeBill.Type_id INNER JOIN
                         ReturnPurchBillBody ON ReturnPurchBillHead.Return_bill_id = ReturnPurchBillBody.Return_bill_id_fk INNER JOIN
                         Units INNER JOIN
                         ItemUnit ON Units.Unit_id = ItemUnit.Unit_id_fk INNER JOIN
                         Items ON ItemUnit.Item_id_fk = Items.Item_id ON ReturnPurchBillBody.idItemUnit_fk = ItemUnit.idItemUnit where ItemUnit.idItemUnit=1

        */
        #endregion
        #region يجيب حساب المبيعات حسب رقم وحدات الاصناف

        /*
        قبل عملية الترحيل 
        بيروح يفحص اذا كان جميع الاصناف الموجودة معاهم حسابات ولا لا 
        في حال موش الكل معاهم حسابات يطبع رساله للمستخدم المجموعة المخزنية الفلانية ليست متربطة بحساب مبيعات ..
        */
        /*
       SELECT        GroupStored.Acc_sales_fk, GroupStored.Group_name
FROM            ItemTypes INNER JOIN
                         GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN
                         Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                         ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
WHERE        (ItemUnit.idItemUnit in( 1,2,3))
        
        */
        #endregion
      
  
        #region
        /*
        
        
        */
        #endregion

    }
}
