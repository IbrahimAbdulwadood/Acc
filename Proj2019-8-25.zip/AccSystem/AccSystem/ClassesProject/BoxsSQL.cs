﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AccSystem.ClassesProject
{
    class BoxsSQL : AccDefintionSQL
    {
        ConnectionDB con = new ConnectionDB();
        DataTable dt;

        public void InsertNewBox(string nameBox , string AccCurr_id_fk)
        {
            string query = "INSERT INTO [dbo].[Boxes]  ([Box_id] ,[Box_name]  ,[AccCurr_id_fk])" +
   "  VALUES("+ GetMaxId() + ",'"+ nameBox + "',"+ AccCurr_id_fk + ")";
           
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

        }
        List<string> GetBoxUser4Box(string Box_id_fk="-1")
        {
            List<string> data = new List<string>();
            string query = " SELECT   BoxUser_id FROM   BoxUser  WHERE   Box_id_fk = "+ Box_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            /*
            SELECT        BoxUser_id
                FROM            BoxUser
                WHERE        Box_id_fk = 1
            */
        }
      public  List<string> ChaeckCanDelet(string Box_id_fk = "-1",string AccCurrid="-1")
        {
            List<string> BoxUser_id = GetBoxUser4Box(Box_id_fk);
            List<string> data = new List<string>();
            if (BoxUser_id.Count > 0)
            {
                for(int i=0;i< BoxUser_id.Count;i++)

                {
                    string 
                    query  = "  SELECT  Support_id FROM   SupportExchangHead WHERE  BoxUser_id_fk= "+ BoxUser_id[i];
                    query += "  union all ";
                    query += "   SELECT  Support_id FROM  SupportCatchHead WHERE  BoxUser_id_fk = " + BoxUser_id[i];
                    query += "  union all ";
                    query += "  SELECT Bill_id FROM  SalesBillHead WHERE  BoxUser_id_fk = "+ BoxUser_id[i];
                    query += "  union all ";
                    query += "  SELECT  Return_bill_id FROM  ReturnSalesBillHead WHERE BoxUser_id_fk = " + BoxUser_id[i];
                    query += "  union all ";
                    query += "  SELECT  Dayly_id_fk FROM DaylyBody WHERE AccCurr_id_fk = "+ AccCurrid;
                    query += "  union all ";
                    query += " SELECT Entry_id_fk FROM  EntriesBody WHERE AccCurr_id_fk = "+ AccCurrid;
                    query += "  union all ";
                    query += " SELECT Serial_number_balance FROM  BalanceOpen WHERE AccCurr_id_fk = "+ AccCurrid;
                    con.OpenConnetion();
                    dt = new DataTable();
                    dt = con.Query(query, true);
                    con.CloseConnetion();
                    if (dt != null && dt.Rows.Count > 0)
                       for(int j=0;j< dt.Rows.Count;j++)
                            data.Add(dt.Rows[j][0].ToString());

                }
                #region
                /*
            SELECT  Support_id FROM   SupportExchangHead WHERE  BoxUser_id_fk = 1

                union all

                SELECT  Support_id FROM  SupportCatchHead WHERE  BoxUser_id_fk = 1
                union all
                SELECT Bill_id FROM  SalesBillHead WHERE  BoxUser_id_fk = 1
                union all
                SELECT  Return_bill_id FROM  ReturnSalesBillHead WHERE BoxUser_id_fk = 1
                union all
                SELECT  Dayly_id_fk FROM DaylyBody WHERE AccCurr_id_fk = 1
                union all
                SELECT Entry_id_fk FROM  EntriesBody WHERE AccCurr_id_fk = 1
                union all
                SELECT Serial_number_balance FROM  BalanceOpen WHERE AccCurr_id_fk = 1    
            */
                #endregion

            }

            return data;

        }
        public void Delet(string Box_id="-1")
        {
            string query = "  DELETE FROM [dbo].[Boxes]   WHERE Box_id= "+ Box_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            /*
            DELETE FROM [dbo].[Boxes]
      WHERE Box_id=1
            */
        }
        bool CheckAccBoxDefineExist()
        {
            return false;
        }
        public string GetMaxId()
        {
            string id;

            string query = "SELECT isnull(max([Box_id]),0)+1 From Boxes";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;
        }

        public void UpdateNameBox(string idBox,string Box_name)
        {
            string query = "UPDATE [dbo].[Boxes]  SET    [Box_name] ='"+ Box_name + "' WHERE [Box_id] ="+idBox;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }
        public DataTable Serch(string txtSerch)
        {
            //            string query = "SELECT Boxes.Box_id, Boxes.Box_name, Boxes.Acc_id_fk,(( select  Accounts.Acc_name where Accounts.Acc_id = Boxes.Acc_id_fk )) as AccName "+
            //" FROM Boxes CROSS JOIN   Accounts where Accounts.Acc_id = Boxes.Acc_id_fk and((Boxes.Box_id like '%"+ txtSerch + "%') or(Boxes.Box_name like '%"+ txtSerch + "%') or(Boxes.Acc_id_fk like '%"+ txtSerch + "%')) ";
            //  string query = "SELECT * FROM[dbo].[Boxes] where([Box_name] like '%" + txtSerch + "%') or([Box_id] like '%" + txtSerch + "%') or([Acc_id_fk] like '%" + txtSerch + "%')";
            string
            query = " SELECT ";
            query += " Boxes.Box_id";
            query += ", Boxes.Box_name";
            query += ", Accounts.Acc_id";
            query += ", Accounts.Acc_name";
            query += ", Currencys.Curr_name";
            query += ",AccCurrency.AccCurr_id ";
            query += " FROM  ";
            query += "  Boxes INNER JOIN ";
            query += " AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN ";
            query += " Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += " Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";
            query += "  where ";
            query += " Boxes.Box_id like '%"+ txtSerch + "%' ";
            query += " or Boxes.Box_name like '%" + txtSerch + "%'";
            query += " or Accounts.Acc_id like '%" + txtSerch + "%'";
            query += " or  Accounts.Acc_name like '%" + txtSerch + "%'";
            query += " or  Currencys.Curr_name like '%" + txtSerch + "%'";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region
            /*
            SELECT        Boxes.Box_id, Boxes.Box_name, Accounts.Acc_id, Accounts.Acc_name, Currencys.Curr_name,AccCurrency.AccCurr_id
FROM            Boxes INNER JOIN
                         AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
						 where 
						  Boxes.Box_id like '%be%' 
						 or Boxes.Box_name like '%be%'
						 or Accounts.Acc_id like '%be%'
						 or  Accounts.Acc_name like '%be%'
						 or  Currencys.Curr_name like '%be%'
            
            */
            #endregion
        }
        public DataTable GetAllBox()
        {
           
            string 
            query = " SELECT ";
            query += " Boxes.Box_id";
            query += ", Boxes.Box_name";
            query += ", Accounts.Acc_id";
            query += ", Accounts.Acc_name";
            query += ", Currencys.Curr_name";
            query += ",AccCurrency.AccCurr_id ";
            query += " FROM  ";
            query += "  Boxes INNER JOIN ";
            query += " AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN ";
            query += " Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += " Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region
            /*
            SELECT        Boxes.Box_id, Boxes.Box_name, Accounts.Acc_id, Accounts.Acc_name, Currencys.Curr_name,AccCurrency.AccCurr_id
FROM            Boxes INNER JOIN
                         AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
            */
            #endregion
        }
        /// <summary>
        /// /////////////////////////////////////////////////////////////////////////////////////////
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllUsers()

        { //ترجع جميع المستخدمين من جدول المستخدمين
            string query = "SELECT [User_id],[User_name]  FROM [dbo].[Users]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }

        public DataTable GetUsersBox(string idBox)
        { //يرجع جميع مستخدمين الصندوق الحالي
            string query = " SELECT        BoxUser.User_id_fk, Users.User_name, BoxUser.stateA " +
          " FROM Boxes INNER JOIN " +
                 "      BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN " +
                   "     Users ON BoxUser.User_id_fk = Users.User_id " +
    " WHERE(BoxUser.Box_id_fk = "+ idBox + ") ";
          //  string query = " SELECT      Users.User_id,  Users.User_name FROM    BoxUser INNER JOIN   Users ON BoxUser.User_id_fk = Users.User_id WHERE  (BoxUser.Box_id_fk = "+ idBox + ")";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }

        public void InsertUserBox(string idBox,string idUser)
        { //اضافة مستخدم جديد للصندوق
            string query = "INSERT INTO [dbo].[BoxUser] ([User_id_fk] ,[Box_id_fk],[stateA]) VALUES (" + idUser + " ,"+ idBox + ",1)";
            con.OpenConnetion(); 
          con.Query(query, false);
            con.CloseConnetion();

        }
        
        public void UpdateStateUserBox(string idBox , string idUser, string sate)
        { //يعدل حاله المستخدم لاستخدام الصندوق
            string query = "UPDATE [dbo].[BoxUser]  SET  [stateA] = "+ sate + " WHERE [Box_id_fk] ="+ idBox + " and [User_id_fk] ="+ idUser;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }

        //////////////////////////////////////////////////////////////////////

        public string[] GetAccBoxs()
        { //ترجع في مصفوفة حسابات الصناديق المرتبطة
            string query = "SELECT [AccCurr_id_fk] FROM [dbo].[Boxes]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            string[] accBox = new string[dt.Rows.Count];
            for(int i = 0; i < dt.Rows.Count; i++)
            {
                accBox[i] = dt.Rows[i][0].ToString();
            }

            return accBox;

        }

        public DataTable GetAllAcc()
        {//ترجع جميع حسابات الصناديق الموجودة في الدليل المحاسبي
            //string query = "SELECT [Acc_id] ,[Acc_name] FROM [dbo].[Accounts] where [Acc_id_father]="+GetIdAccFatherBox();
            string
         query = " SELECT ";
            query += "  AccCurrency.AccCurr_id, ";
            query += "  Accounts.Acc_id,   ";
            query += "  Accounts.Acc_name,";
            query += "  Currencys.Curr_sumbol_eng ";
          
            query += "  FROM ";
            query += "  AccCurrency INNER JOIN ";
            query += "    Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id  ";
            query += "  where Accounts.Acc_id_father= "+ GetIdAccFatherBox();
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

            /*
            SELECT    
            Accounts.Acc_id, 
            Accounts.Acc_name,
            Currencys.Curr_sumbol_eng,
            AccCurrency.AccCurr_id
FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id  where Accounts.Acc_id_father=1
            */
        }

        public DataTable GetCoustInfo()
        {
          
			   
            string
          query = " SELECT ";
            query += "  Customers.Cust_id,  ";
            query += "  Customers.Cust_name, ";
            query += "  Accounts.Acc_id, ";
            query += "  Accounts.Acc_name,  ";
            query += "  Currencys.Curr_sumbol_eng,   ";
            query += "  AccCurrency.State,  ";
            query += "  Currencys.Curr_echange,  ";
            query += "  Currencys.Curr_id,  ";
            query += "  AccCurrency.AccCurr_id   ";
            query += "  FROM AccCurrency INNER JOIN  ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN   ";
            query += "   Customers ON AccCurrency.AccCurr_id = Customers.AccCurr_id_fk ";
         
          
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region
            /*
            SELECT     
              Customers.Cust_id,
              Customers.Cust_name,
			  Accounts.Acc_id,
			   Accounts.Acc_name, 
			   Currencys.Curr_sumbol_eng, 
			   AccCurrency.State,
			   Currencys.Curr_echange,
			   Currencys.Curr_id,
			   AccCurrency.AccCurr_id


FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                         Customers ON AccCurrency.AccCurr_id = Customers.AccCurr_id_fk
            
            */
            #endregion

        }
        public DataTable GetBoxesUser(string User_id_fk="-1",string BoxUser_id="-1")
        {
            string
          query = " SELECT ";
            query += "  BoxUser.Box_id_fk,  ";
            query += "  Boxes.Box_name,";
            query += "  Accounts.Acc_id,";
            query += "  Accounts.Acc_name,";
            query += "  Currencys.Curr_sumbol, ";
            query += "  BoxUser.stateA, ";
            query += "  BoxUser.BoxUser_id, ";
            query += "  Currencys.Curr_echange ,";
            query += "  Currencys.Curr_id ";
            query += " FROM  ";
            query += " AccCurrency INNER JOIN ";
            query += " Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += " Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN ";
            query += " BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN ";
            query += " Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN ";
            query += " Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";
            query += " WHERE   ";
            query += "    (BoxUser.User_id_fk = "+ User_id_fk;
            query += " and  BoxUser.BoxUser_id !="+ BoxUser_id + " )";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region
            /*
            SELECT   
            BoxUser.Box_id_fk, 
            Boxes.Box_name,
            Accounts.Acc_id,
            Accounts.Acc_name,
            Currencys.Curr_sumbol, 
            BoxUser.stateA, 
            BoxUser.BoxUser_id,
            Currencys.Curr_echange
FROM    
AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                         BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN
                         Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
WHERE        (BoxUser.User_id_fk = 1 and  BoxUser.BoxUser_id !=3)
            
            */
            #endregion

        }

    }
}
