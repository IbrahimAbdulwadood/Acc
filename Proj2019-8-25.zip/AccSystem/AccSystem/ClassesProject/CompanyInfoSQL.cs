﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AccSystem.ClassesProject
{
    class CompanyInfoSQL
    {
        DataTable dt;
        ConnectionDB con = new ConnectionDB();
        public void UpdateCompany
            (
                    string Com_name_ar, string Com_name_en, string Com_phone,
            string Com_fax, string Com_address_ar, string Com_address_en, string Com_email
            )
        { //[Com_name_ar]  ,[Com_name_en]  ,[Com_phone]   ,[Com_fax],[Com_address_ar] ,[Com_address_en]   ,[Com_email]
            string q = null;
          
               
            if (CheckIfExistRowInCompanyInfoTable())
            {
                q = " UPDATE[dbo].[Company]";
                q += " SET[Com_name_ar] =" + Com_name_ar;
                q += "  ,[Com_name_en] = " + Com_name_en;
                q += "  ,[Com_phone] = " + Com_phone;
                q += "  ,[Com_fax] = " + Com_fax;
                q += "  ,[Com_address_ar] = " + Com_address_ar;
                q += "  ,[Com_address_en] = " + Com_address_en;
                q += "  ,[Com_email] = " + Com_email;
                  
            }
            else
            {

                q = "INSERT INTO [dbo].[Company]";
                q += "([Com_name_ar]";
                q += ",[Com_name_en] ";
                q += " ,[Com_phone] ";
                q += ",[Com_fax]";
                q += ",[Com_address_ar]";
                q += ",[Com_address_en]";
                q += ",[Com_email]";
                q += " )";
                q += "  VALUES ";
                q += "(" + Com_name_ar;
                q += "," + Com_name_en;
                q += "," + Com_phone;
                q += "," + Com_fax;
                q += "," + Com_address_ar;
                q += "," + Com_address_en;
                q += "," + Com_email;
                q += ")";
                //  string a = "'"+"Ahmed"+"'";
            }
            con.OpenConnetion();
            con.Query(q, false);
            con.CloseConnetion();
        }
        public DataTable GetDataCompany()
        {
            string
            query = "  SELECT ";
            query += " [Com_name_ar]";
            query += ",[Com_name_en] ";
            query += ",[Com_phone] ";
            query += ",[Com_fax] ";
            query += ",[Com_address_ar]";
            query += ",[Com_address_en] ";
            query += ",[Com_email]";
            query += ",[Com_logo]";
            query +=" FROM[dbo].[Company]";
            con.OpenConnetion();   
            dt=  con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
        public bool CheckIfExistRowInCompanyInfoTable()
        { //هل يوجد سجل ام لا
            //في حال كان موش موجد يعمل اضافة لسجل واحد فقط ويكون فارغ
            //في حال كان موجود يستخدم دوال التعديل فقط
            string query = "SELECT * FROM [dbo].[Company]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt.Rows.Count > 0)
            {
                //MessageBox.Show("يوجد صفوف في جدول تعريف الحسابات" + "  " + dt.Rows.Count.ToString());
                return true;
            }
            else
            {
               // MessageBox.Show("لا يوجد صفوف في جدول تعريف الحسابات" + "  " + dt.Rows.Count.ToString());
                return false;
            }
        }

    }
}
