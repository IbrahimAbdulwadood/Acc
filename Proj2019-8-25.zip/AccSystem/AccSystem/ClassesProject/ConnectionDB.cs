﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace AccSystem.ClassesProject
{
    class ConnectionDB
    {
        public  SqlConnection conn;

        //كونستراكت عشان يعرف الاتصال عند انشاء اوبجكت من هذا الكلاس
        public ConnectionDB()
        {
            conn = new SqlConnection("Data Source=.;Initial Catalog=AccSysDB1;Integrated Security=True");

        }
        public string AddApostropheToString(string txt)
        {
            //اضافة نص احادي للكلمات
            if (txt != "NULL")
            {
                txt = "'" + txt + "'";
            }

            return txt;
        }

        //داله فتح الاتصال مع قاعدة البيانات
        public void OpenConnetion()
        {
            if (conn.State != System.Data.ConnectionState.Open)
            {
                conn.Open();
            }

        }


        //داله اغلاق الاتصال مع قاعدة البيانات
        public void CloseConnetion()
        {
            if (conn.State != System.Data.ConnectionState.Closed)
            {
                conn.Close();
            }

        }


        //داله تنفيذ جميع الاستعلامات
        public DataTable Query(string str,bool state)
        {
            try
            {
                DataTable DT = new DataTable();
                //عشان يحفظ نص الاستعلام في  القاعده
                SqlCommand comnd = new SqlCommand(str, conn);
               // System.Windows.Forms.MessageBox.Show(str);
                
                //اذا كان الاستعلام يرجع قيمه من القاعدة
                if (state)
                {
                    //  عشان يرجع بيانات الكومند التي تم كتابتها من القاعده وتخزينها في جدول خارج القاعده

                    try {
                        SqlDataAdapter adb = new SqlDataAdapter(comnd);
                        try { adb.Fill(DT); }
                        catch (Exception e)
                        { //System.Windows.Forms.MessageBox.Show(e.ToString(), "2لم يتم جلب البيانات");
                        }
                    }
                    catch (Exception e)
                    { //System.Windows.Forms.MessageBox.Show(e.ToString(), "لم يتم جلب البيانات1");
                        }
                   
                    

                }
                else
                {
                    //تنفيذ الاستعلام 
                    try
                    {
                        comnd.ExecuteNonQuery();
                        System.Windows.Forms.MessageBox.Show(" تمت العملية بنجاح","", System.Windows.Forms.MessageBoxButtons.OK);
                    }
                    catch (Exception e) { System.Windows.Forms.MessageBox.Show(e.ToString(),"لم تتم العملية بنجاح",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error); }

                    }
                //يرجع جدول سوا كان مليان ولا فاضي
                return DT;


            }
            catch { return null; }

          
        }

       
    }
}
