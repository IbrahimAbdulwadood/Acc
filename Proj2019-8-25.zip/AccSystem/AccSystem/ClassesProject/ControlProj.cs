﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using AccSystem.FormsProject.Accounts;
using AccSystem.FormsProject.Sys;
using AccSystem.FormsProject.Stores;
using AccSystem.FormsProject.Sales;
using AccSystem.FormsProject.Purchs;

namespace AccSystem.ClassesProject
{
    class ControlProj
    {
        DataTable DTpr;
        ConnectionDB con = new ConnectionDB();
        PermissionsSQL pre = new PermissionsSQL();

        Dictionary<string, bool> ButtnPre;
        Dictionary<string, string> OprationIdName;
        bool existOpra = false;
        public ControlProj()
        {
            OprationIdName = new Dictionary<string, string>();
            OprationIdName.Clear();
            OprationIdName = GetAllOprtion();
            if (OprationIdName.Count > 0)
            {
               // MessageBox.Show("يوجد عمليات في قاعده البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Information);
                existOpra=true;
            }
            else MessageBox.Show("لا يوجد عمليات في قاعدة البيانات","تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        #region جميع الشاشات

        #region شاشات النظام

        #endregion

        #region شاشات الحسابات
        Currency currency; //العملات
        Account account; //الدليل المحاسبي
        AccDefinition accDefinition; //تعريف الحسابات
        AccPeriod accPeriod; //الفترات الماليه
        BalanceOpen_ balanceOpen; //الارصدة الافتتاحية
        Boxs boxs; //الصناديق
        Entries entries; // سندات القيد اليدوي
        SupportCatch supportCatch; // سند القبض
      //  SupportExchang22 supportExchang; //سند صرف
        SupportExchang supportExchang;
        FrmAllSelection FrmAllSelection;
        FrmAllSelectAcc FrmAllSelectAcc;

        #region الشاشات المتبقية
        /*
        
       
        */
        #endregion
        /*
        عند تشغيل النظام تظهر له شاشة مكتوب عليها فوق تهئية النظام 
        فيها فقط بوتنات توديه للشاشات 
        تكون كل البوتنات مخفية ماعدا اول واحد 
        الي هو العملات وعند ادخال العملات
        يقفل هذي الشاشه ويفتح له الشاشه حق التهئية ويعرض له 
        بوتن الدليل المحاسبي في حال ما كان معانا فترات
        بس قبل ما يطلب منه يدخل الدليل المحاسبي يطلب منه الحاسابات الفرعيه كم 
        بتكون رتبتها
        وبعدين يظهر له شاشه الدليل المحاسبي 
        بعد ما يدخل الحسابات 
        يعرض له شاشه تعريف الحسابات
        وبعدين يفتح له شاشه الصناديق

      اولا يدخل العملات
      ثانيا يدخل الدليل المحاسبي
      ثالثا يعرف الحسابات
       */
        #endregion

        #region شاشات المبيعات
        Unit unit; //
        GroupStored groupStored; //
        GroupType groupType; //
        Items items; //
        Customers Customers;
        Suplliers suplliers;
        FrmNonPosting FrmNonPosting;
        Pricing Pricing;
        // purchBill  المشتريات
        //firstBalanceBodge firstBalanceBodge; //مخزون اول المدة
        //Pricing Pricing; //عرض سعر
        CompanyInfo companyInfo;
        MyAccount MyAccount;
        Useres Useres;
        SaleBill SaleBill;
        SaleBill_Return SaleBill_Return;
        FrmRepBill4Item FrmRepBill4Item;
        FrmRepCustAnalytical FrmRepCustAnalytical;//حركة عميل
        FrmRepBoxAnalytical FrmRepBoxAnalytical;
        #endregion

        #endregion


        Dictionary<string, string> GetAllOprtion()
        {
          
                if (DTpr != null)
                    DTpr = null;
            DTpr = new DataTable();
            DTpr = pre.GetAllOpra();
            Dictionary<string, string> Opration =new Dictionary<string, string>();
            Opration.Clear();

            #region الاستعلام
            /*
            SELECT 
    Oper_id,
    Oper_name, 
    Stored_move,
    Source_entry
    FROM      
    Operations
            */
            #endregion


            if (DTpr != null && DTpr.Rows.Count > 0)
               for (int i = 0; i < DTpr.Rows.Count; i++)
                    Opration.Add
                        (
                        DTpr.Rows[i][1].ToString(), //اسم العمليه
                        DTpr.Rows[i][0].ToString() //رقم العمليه
                        );

            return Opration;


        }
        List<string> GetIdNameOpra(string nameOpre)
        {
            string idOpra;
            List<string> idName = new List<string>();
            if (OprationIdName.TryGetValue(nameOpre, out idOpra))
            {
               
              //  MessageBox.Show(nameOpre,idOpra);
                idName.Add(idOpra);
                idName.Add(nameOpre);
            }
            else
             MessageBox.Show("لم نستطع العثور على عملية هذه الشاشة");
            return idName;


        }
       Dictionary<string, bool> CheckScreen(string idUser,string idScreen)
        {
            if (DTpr != null)
                DTpr = null;
            DTpr = new DataTable();
         Dictionary<string, bool> ButtnPreCheck = new Dictionary<string, bool>();
            ButtnPreCheck.Clear();
            DTpr =pre.GetAllPermissionsFromOneScreen(idUser, idScreen);
            if(DTpr.Rows.Count>0&& DTpr != null)
            {

                ButtnPreCheck.Add("Showed", Convert.ToBoolean(DTpr.Rows[0][2].ToString()));
                ButtnPreCheck.Add("Inserted", Convert.ToBoolean(DTpr.Rows[0][3].ToString()));
                ButtnPreCheck.Add("EditeDate", Convert.ToBoolean(DTpr.Rows[0][4].ToString()));
                ButtnPreCheck.Add("Posting", Convert.ToBoolean(DTpr.Rows[0][5].ToString()));
                ButtnPreCheck.Add("Saerch", Convert.ToBoolean(DTpr.Rows[0][6].ToString()));
                ButtnPreCheck.Add("Printed", Convert.ToBoolean(DTpr.Rows[0][7].ToString()));
                ButtnPreCheck.Add("Updated", Convert.ToBoolean(DTpr.Rows[0][8].ToString()));
                ButtnPreCheck.Add("Deleted", Convert.ToBoolean(DTpr.Rows[0][9].ToString()));

            }
            return ButtnPreCheck;
            #region الاستعلام
            /*
            SELECT    
 Permissions.Screen_id_fk, 0
 Screens.Screen_Name,      1
 Permissions.Showed,  2
 Permissions.Inserted, 3
 Permissions.EditeDate, 4
 Permissions.Posting, 5
 Permissions.Saerch, 6
 Permissions.Printed, 7
 Permissions.Updated, 8
 Permissions.Deleted 9
  FROM            Permissions INNER JOIN Screens ON Permissions.Screen_id_fk = Screens.Screen_id where Permissions.User_id_fk =1
            */
            #endregion

        }
        public void PlayForm( string idScreenPlay,string nameScreenPlay ,string idUserPlay)
        {
            try
            {
                ButtnPre = new Dictionary<string, bool>();
                ButtnPre.Clear();
                switch (nameScreenPlay)
                {
                    
                    case "Currency":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                        currency = new Currency(ButtnPre); currency.ShowDialog(); 
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Customers":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                      
                        Customers = new Customers(ButtnPre); Customers.ShowDialog(); 
                       
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "FrmRepBoxAnalytical":
                        FrmRepBoxAnalytical = new FrmRepBoxAnalytical(idUserPlay);
                        FrmRepBoxAnalytical.ShowDialog();
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "FrmNonPosting":
                        FrmNonPosting = new FrmNonPosting();
                        FrmNonPosting.ShowDialog();
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "FrmAllSelectAcc":
                        FrmAllSelectAcc = new FrmAllSelectAcc();
                        FrmAllSelectAcc.ShowDialog();
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Account":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                      
                         account = new Account(ButtnPre); account.ShowDialog(); 
                       
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "SupportCatch":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                      
                         if (existOpra)
                            {
                                supportCatch = new SupportCatch(
                                    idUserPlay,
                                    ButtnPre,
                                    GetIdNameOpra("سند قبض")
                                    );
                                supportCatch.ShowDialog();
                            }
                            else MessageBox.Show("يرجى تعريف العمليات في قاعدة البيانات", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        
                       
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Entries":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                        if (existOpra)
                        {
                            entries = new Entries(
                                    idUserPlay,
                                    ButtnPre,
                                    GetIdNameOpra("قيد يدوي")
                                    );
                            entries.ShowDialog();
                        }
                        else MessageBox.Show("يرجى تعريف العمليات في قاعدة البيانات", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Boxs":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                       
                         boxs = new Boxs(); boxs.ShowDialog(); 
                        
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "AccDefinition":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                          accDefinition = new AccDefinition(); accDefinition.ShowDialog(); 
                       
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "BalanceOpen":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                        if (existOpra)
                        {
                            balanceOpen = new BalanceOpen_(
                                    idUserPlay,
                                    ButtnPre,
                                    GetIdNameOpra("قيد افتتاحي")); balanceOpen.ShowDialog();
                        }
                        else MessageBox.Show("يرجى تعريف العمليات في قاعدة البيانات", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Suplliers":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                      
                         suplliers = new Suplliers(); suplliers.ShowDialog(); 
                        
                        break;
                    //////////////////////////////////////////////////////////////////
                    
                    case "SaleBill":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                        if (existOpra)
                        {
                            SaleBill = new SaleBill(idUserPlay,
                                    ButtnPre,
                                    GetIdNameOpra("فاتورة مبيعات")); SaleBill.ShowDialog();
                        }
                        else MessageBox.Show("يرجى تعريف العمليات في قاعدة البيانات", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "SaleBill_Return":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                        if (existOpra)
                        {
                            SaleBill_Return = new SaleBill_Return(idUserPlay,
                                      ButtnPre,
                                      GetIdNameOpra("فاتورة مردود مبيعات")); SaleBill_Return.ShowDialog();
                        }
                        else MessageBox.Show("يرجى تعريف العمليات في قاعدة البيانات", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        break;
                    //////////////////////////////////////////////////////////////////
                    //case "purchBill":
                    //    ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                    //    if (ButtnPre["Showed"] == true)
                    //    { purchBill = new purchBill(); purchBill.ShowDialog(); }
                    //    else
                    //        MessageBox.Show("لا تمتلك صلاحة دخول هذه الشاشة", "فاتورة مشتريات", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //    break;
                    //////////////////////////////////////////////////////////////////
                    case "GroupType":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                      
                         groupType = new GroupType(); groupType.ShowDialog(); 
                      
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "GroupStored":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                         groupStored = new GroupStored(); groupStored.ShowDialog(); 
                      
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Items":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                     
                         items = new Items(); items.ShowDialog(); 
                       
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Unit":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                        
                         unit = new Unit(); unit.ShowDialog(); 
                       
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Pricing":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);

                        Pricing = new Pricing(); Pricing.ShowDialog(); 
                       
                        break;
                    //////////////////////////////////////////////////////////////////
                    //case "firstBalanceBodge":

                    //    ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                    //    if (existOpra)
                    //    {
                    //        firstBalanceBodge = new firstBalanceBodge(); firstBalanceBodge.ShowDialog();
                    //    }
                    //    else MessageBox.Show("يرجى تعريف العمليات في قاعدة البيانات", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    //    break;
                    //////////////////////////////////////////////////////////////////
                    case "CompanyInfo":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                     
                         companyInfo = new CompanyInfo(); companyInfo.ShowDialog(); 
                        
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "MyAccount":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                       
                         MyAccount = new MyAccount(); MyAccount.ShowDialog(); 
                        
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "Useres":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                       
                         Useres = new Useres(ButtnPre); Useres.ShowDialog(); 
                      
                        break;
                    //////////////////////////////////////////////////////////////////
                    //case "Posting":
                    //    ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                    //    if (ButtnPre["Showed"] == true)
                    //    { Posting = new Posting(); Posting.ShowDialog(); }
                    //    else
                    //        MessageBox.Show("لا تمتلك صلاحة دخول هذه الشاشة", "الترحيل", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //    break;
                    //////////////////////////////////////////////////////////////////
                    //case "NonPosting":
                    //    ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                    //    if (ButtnPre["Showed"] == true)
                    //    { NonPosting = new NonPosting(); NonPosting.ShowDialog(); }
                    //    else
                    //        MessageBox.Show("لا تمتلك صلاحة دخول هذه الشاشة", "الغاء الترحيل", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    //    break;
                    //////////////////////////////////////////////////////////////////
                  
                    case "SupportExchang":
                        ButtnPre = CheckScreen(idUserPlay, idScreenPlay);
                        
                            if (existOpra)
                            {
                                supportExchang = new SupportExchang(
                                    idUserPlay,
                                    ButtnPre,
                                    GetIdNameOpra("سند صرف")
                                    );
                                supportExchang.ShowDialog();
                            }
                            else MessageBox.Show("يرجى تعريف العمليات في قاعدة البيانات", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        
                       
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "FrmRepBill4Item":
                        FrmRepBill4Item = new FrmRepBill4Item();
                        FrmRepBill4Item.Show();
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "FrmRepCustAnalytical":
                        FrmRepCustAnalytical = new FrmRepCustAnalytical();
                        FrmRepCustAnalytical.ShowDialog();
                        break;
                    //////////////////////////////////////////////////////////////////
                    case "FrmAllSelection":
                        FrmAllSelection = new FrmAllSelection();
                        FrmAllSelection.ShowDialog();
                        break;
                    //////////////////////////////////////////////////////////////////
                    default: MessageBox.Show("لم يتم برمجة  صلاحية الشاشة","",MessageBoxButtons.OK,MessageBoxIcon.Error); break;
                }

            }
            catch
            {
            }
        }

    }
}
