﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
    

namespace AccSystem.ClassesProject
{
    class CurrSQL
    {

        ConnectionDB con = new ConnectionDB();
        DataTable dt;


        public DataTable GetAllCurr()
        {
            string query = "SELECT * FROM[dbo].[Currencys]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query,true);
            con.CloseConnetion();
            return dt;
        }
        public void DeletCurr(string Curr_id="-1")
        {
            string
             query = "   DELETE FROM [dbo].[Currencys] ";
            query += "   WHERE Curr_id= "+ Curr_id;

            con.OpenConnetion();
          con.Query(query, false);
            con.CloseConnetion();
            /*
            DELETE FROM [dbo].[Currencys]
      WHERE Curr_id=1
            */
        }
        public DataTable GetAccRelation4Curr(string Curr_id_fk)
        {
            string
              query = "  SELECT        AccCurrency.Acc_id_fk, Accounts.Acc_name ";

            query += "   FROM            AccCurrency INNER JOIN ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id ";
            query += "   WHERE        AccCurrency.Curr_id_fk = "+ Curr_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

            /*
            SELECT        AccCurrency.Acc_id_fk, Accounts.Acc_name
            FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
                WHERE        AccCurrency.Curr_id_fk = 5
            */

        }

        //
        public void InsertNewCurr(
              string Curr_name
            , string Curr_sumbol
            , string Curr_sumbol_eng
            , string Curr_fakah
            , string Curr_echange
            , string Curr_is_local
            , string Curr_is_stock
            , string Curr_maximum
            , string Curr_minimum
            , string Arabic1CurrencyName
            , string Arabic2CurrencyName
            , string Arabic310CurrencyName
            , string Arabic1199CurrencyName
            , string Arabic1CurrencyPartName
            , string Arabic2CurrencyPartName
            , string Arabic310CurrencyPartName
            , string Arabic1199CurrencyPartName
            , string PartPrecision
            , string IsCurrencyNameFeminine
            , string IsCurrencyPartNameFeminine
            )
        {
            string
              query = " INSERT INTO[dbo].[Currencys] ";
          
            query += " (  ";
            query += "  [Curr_id] ";
            query += " ,[Curr_name] ";
            query += " ,[Curr_sumbol] ";
            query += " ,[Curr_sumbol_eng] ";
            query += " ,[Curr_fakah] ";
            query += " ,[Curr_echange] ";
            query += " ,[Curr_is_local] ";
            query += " ,[Curr_is_stock] ";
            query += " ,[Curr_maximum] ";
            query += " ,[Curr_minimum] ";
            query += " ,[Arabic1CurrencyName] ";
            query += " ,[Arabic2CurrencyName] ";
            query += " ,[Arabic310CurrencyName] ";
            query += " ,[Arabic1199CurrencyName] ";
            query += " ,[Arabic1CurrencyPartName] ";
            query += " ,[Arabic2CurrencyPartName] ";
            query += " ,[Arabic310CurrencyPartName] ";
            query += " ,[Arabic1199CurrencyPartName] ";
            query += " ,[PartPrecision] ";
            query += " ,[IsCurrencyNameFeminine] ";
            query += " ,[IsCurrencyPartNameFeminine] ";
            query += "   ) ";
            query += "     VALUES ";
            query += "   ( ";
            query += GetMaxId();
            query += "  ,"+con.AddApostropheToString(Curr_name);
            query += "  , "+con.AddApostropheToString(Curr_sumbol);
            query += "  , "+con.AddApostropheToString(Curr_sumbol_eng);
            query += "  , "+con.AddApostropheToString(Curr_fakah);
            query += "  ,"+Curr_echange;
            query += "  ,"+Curr_is_local;
            query += "  , "+Curr_is_stock;
            query += "  ,"+ Curr_maximum;
            query += "  ,"+ Curr_minimum;
            query += "  , "+con.AddApostropheToString(Arabic1CurrencyName);
            query += "  , "+con.AddApostropheToString(Arabic2CurrencyName);
            query += "  ,"+con.AddApostropheToString(Arabic310CurrencyName);
            query += "  ,"+con.AddApostropheToString(Arabic1199CurrencyName);
            query += "  ,"+con.AddApostropheToString(Arabic1CurrencyPartName);
            query += "  ,"+con.AddApostropheToString(Arabic2CurrencyPartName);
            query += "  ,"+con.AddApostropheToString(Arabic310CurrencyPartName);
            query += "  ,"+con.AddApostropheToString(Arabic1199CurrencyPartName);
            query += "  , "+PartPrecision;
            query += "  ,"+IsCurrencyNameFeminine;
            query += "  ,"+IsCurrencyPartNameFeminine;
            query += "   ) ";


            /*
            INSERT INTO [dbo].[Currencys]
           (
            [Curr_id]
           ,[Curr_name]
           ,[Curr_sumbol]
           ,[Curr_sumbol_eng]
           ,[Curr_fakah]
           ,[Curr_echange]
           ,[Curr_is_local]
           ,[Curr_is_stock]
           ,[Curr_maximum]
           ,[Curr_minimum]
           ,[Arabic1CurrencyName]
           ,[Arabic2CurrencyName]
           ,[Arabic310CurrencyName]
           ,[Arabic1199CurrencyName]
           ,[Arabic1CurrencyPartName]
           ,[Arabic2CurrencyPartName]
           ,[Arabic310CurrencyPartName]
           ,[Arabic1199CurrencyPartName]
           ,[PartPrecision]
           ,[IsCurrencyNameFeminine]
           ,[IsCurrencyPartNameFeminine]
           )
     VALUES
           (1
           ,''
           ,''
           ,''
           ,''
           ,12.1
           ,1
           ,0
           ,12
           ,12
           ,''
           ,''
           ,''
           ,''
           ,''
           ,''
           ,''
           ,''
           ,2
           ,0
           ,0
		   )
            */
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            // GetMaxId() 

        }


        //
        public string GetMaxId()
        {
            string id;

            string query = "SELECT isnull(max([Curr_id]),0)+1 From Currencys";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;
        }
        public void UpdateCur(
            string Curr_id 
            , string Curr_name
            ,string Curr_sumbol
            ,string Curr_sumbol_eng
            ,string Curr_fakah
            ,string Curr_echange
            ,string Curr_is_local
            ,string Curr_is_stock
            ,string Curr_maximum
            ,string Curr_minimum
            , string Arabic1CurrencyName
            , string Arabic2CurrencyName
            , string Arabic310CurrencyName
            , string Arabic1199CurrencyName
            , string Arabic1CurrencyPartName
            , string Arabic2CurrencyPartName
            , string Arabic310CurrencyPartName
            , string Arabic1199CurrencyPartName
            , string PartPrecision
            , string IsCurrencyNameFeminine
            , string IsCurrencyPartNameFeminine

            )
        {
            con.OpenConnetion();
            string
            query  = " UPDATE [dbo].[Currencys]  SET  ";
            query += "   [Curr_name] =  "+con.AddApostropheToString(Curr_name);
            query += "  ,[Curr_sumbol] =   " + con.AddApostropheToString(Curr_sumbol);
            query += "  ,[Curr_sumbol_eng] = " + con.AddApostropheToString(Curr_sumbol_eng);
            query += "  ,[Curr_fakah] =   " + con.AddApostropheToString(Curr_fakah);
            query += "  ,[Curr_echange] = "+ Curr_echange;
            query += "  ,[Curr_is_local] =   "+ Curr_is_local;
            query += "  ,[Curr_is_stock] =  "+ Curr_is_stock;
            query += "  ,[Curr_maximum] =   "+ Curr_maximum;
            query += "  ,[Curr_minimum] =   " + Curr_minimum;
            query += "  ,[Arabic1CurrencyName] = " + con.AddApostropheToString(Arabic1CurrencyName);
            query += "  ,[Arabic2CurrencyName] = " + con.AddApostropheToString(Arabic2CurrencyName);
            query += "  ,[Arabic310CurrencyName] = " + con.AddApostropheToString(Arabic310CurrencyName);
            query += "  ,[Arabic1199CurrencyName] =  " + con.AddApostropheToString(Arabic1199CurrencyName);
            query += "  ,[Arabic1CurrencyPartName] = " + con.AddApostropheToString(Arabic1CurrencyPartName);
            query += "  ,[Arabic2CurrencyPartName] = " + con.AddApostropheToString(Arabic2CurrencyPartName);
            query += "  ,[Arabic310CurrencyPartName] =" + con.AddApostropheToString(Arabic310CurrencyPartName);
            query += " ,[Arabic1199CurrencyPartName] =" + con.AddApostropheToString(Arabic1199CurrencyPartName);
            query += "  ,[PartPrecision] =  " + PartPrecision; ;
            query += "  ,[IsCurrencyNameFeminine] = "+ IsCurrencyNameFeminine;
            query += "  ,[IsCurrencyPartNameFeminine] = "+ IsCurrencyPartNameFeminine;
            query += "  WHERE [Curr_id] = "+ Curr_id;
           

            /*
            UPDATE [dbo].[Currencys]
   SET 
       [Curr_name] = ''
      ,[Curr_sumbol] = ''
      ,[Curr_sumbol_eng] =''
      ,[Curr_fakah] = ''
      ,[Curr_echange] = 12.1
      ,[Curr_is_local] = 0
      ,[Curr_is_stock] =0
      ,[Curr_maximum] = 0
      ,[Curr_minimum] = 0
      ,[Arabic1CurrencyName] = ''
      ,[Arabic2CurrencyName] = ''
      ,[Arabic310CurrencyName] = ''
      ,[Arabic1199CurrencyName] = ''
      ,[Arabic1CurrencyPartName] = ''
      ,[Arabic2CurrencyPartName] = ''
      ,[Arabic310CurrencyPartName] = ''
      ,[Arabic1199CurrencyPartName] = ''
      ,[PartPrecision] = 555
      ,[IsCurrencyNameFeminine] = 0
      ,[IsCurrencyPartNameFeminine] = 0
 WHERE [Curr_id] = 5
            
            */
       
            con.Query(query, false);
            con.CloseConnetion();
          //  MessageBox.Show("تم التعديل");
        }

        public DataTable Serch(string txtSerch)
        {
            string query = "SELECT * FROM[dbo].[Currencys] where([Curr_id] like '%"+ txtSerch + "%') or([Curr_name] like '%"+ txtSerch + "%') or([Curr_sumbol] like '%"+ txtSerch + "%')  or([Curr_sumbol_eng] like '%"+ txtSerch + "%') or([Curr_fakah] like '%"+ txtSerch + "%') or([Curr_echange] like '%"+ txtSerch + "%')";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
        string AddApostropheToString(string txt)
        {
            //اضافة نص احادي للكلمات
            if (txt != "NULL")
            {
                txt = "'" + txt + "'";
            }

            return txt;
        }
        #region يرجع سعر الصرف للعمله مع الحد الاعلى والادنى تستخدم في شاشة القيود اليدوية
        public string[] GetCurrEchange(string AccCurr_id)
        {
             
            string 
               query = "SELECT";
            query += "  Currencys.Curr_echange ";
            query += "  , Currencys.Curr_maximum ";
            query += " , Currencys.Curr_minimum ";
            query += " FROM ";
            query += " AccCurrency ";
            query += " INNER JOIN  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";
            query += " WHERE ";
            query += " (AccCurrency.AccCurr_id = "+ AccCurr_id + ") ";
            #region
            /*
        SELECT 
   Currencys.Curr_echange, 
   Currencys.Curr_maximum, 
   Currencys.Curr_minimum
FROM        
AccCurrency 
INNER JOIN  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
WHERE      
(AccCurrency.AccCurr_id = 2)
        */
            #endregion
            string[] data = new string[3];
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if(dt.Rows.Count > 0)
            {
                data[0] = dt.Rows[0][0].ToString();
                data[1] = dt.Rows[0][1].ToString();
                data[2] = dt.Rows[0][2].ToString();
                return data;
            }
            return null;

           
            //if return -1 = thes Curr not found
        }
        #endregion

        #region يرجع هل العمله محليه ام لا
        public string CurrIsLockal(string AccCurr_id)
        {
            string
            query = "SELECT";
            query += " Currencys.Curr_is_local ";
            query += "  FROM ";
            query += " AccCurrency  ";
            query += " INNER JOIN Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id  ";
            query += "  WHERE ";
            query += "  (AccCurrency.AccCurr_id = "+ AccCurr_id + ") ";
            /*
            SELECT     
  Currencys.Curr_is_local
FROM      
  AccCurrency 
INNER JOIN Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
WHERE   
  (AccCurrency.AccCurr_id = 1)
            */
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
           // MessageBox.Show(dt.Rows[0][0].ToString());
            return (dt.Rows.Count > 0 ?(dt.Rows[0][0].ToString()=="True"?"1":"0") : "-1");
            //return 1 isLocal , 0 isNotLocal , -1 NotFoundCurr

        }

        public string CurrIsLockalWithBoxUser(string BoxUser_id)
        {

            string
                       query = "SELECT";
                       query += " Currencys.Curr_is_local";
                       query += " FROM";
                       query += " BoxUser INNER JOIN";
                       query += " Boxes ON BoxUser.Box_id_fk = Boxes.Box_id INNER JOIN ";
                       query += "  AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN ";
                       query += " Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";
                       query += " WHERE  ";
                       query += "  (BoxUser.BoxUser_id =  "+ BoxUser_id;
                       query += " ) ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return (dt.Rows.Count > 0 ? (dt.Rows[0][0].ToString() == "True" ? "1" : "0") : "-1");

            #region
            /*
            SELECT    
            Currencys.Curr_is_local
FROM          
BoxUser INNER JOIN
                         Boxes ON BoxUser.Box_id_fk = Boxes.Box_id INNER JOIN
                         AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
WHERE        (BoxUser.BoxUser_id = 1)
            */
            #endregion

        }
        public DataTable CurrInfo(string CurrId)
        {
            string
            query = " SELECT ";
            query += "  Arabic1CurrencyName ";
            query += " , Arabic2CurrencyName ";
            query += " , Arabic310CurrencyName ";
            query += " , Arabic1199CurrencyName ";
            query += " , Arabic1CurrencyPartName ";
            query += " , Arabic2CurrencyPartName  ";
            query += " , Arabic310CurrencyPartName ";
            query += " , Arabic1199CurrencyPartName   ";
            query += " , PartPrecision  ";
            query += " , IsCurrencyNameFeminine  ";
            query += " , IsCurrencyPartNameFeminine  ";
            query += "   FROM     Currencys  ";
            query += "   WHERE    Curr_id =   "+ CurrId;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

            #region
            /*
            SELECT   
            Arabic1CurrencyName
            , Arabic2CurrencyName
            , Arabic310CurrencyName
            , Arabic1199CurrencyName
            , Arabic1CurrencyPartName
            , Arabic2CurrencyPartName
            , Arabic310CurrencyPartName
            , Arabic1199CurrencyPartName
            , PartPrecision
            , IsCurrencyNameFeminine
            , IsCurrencyPartNameFeminine
                FROM            Currencys
                WHERE        (Curr_id = 1)
            */
            #endregion
        }
        public bool CurrBoxUserIsLocal(string BoxUser_id)
        {
            string
           query = " SELECT ";
            query += "   Currencys.Curr_is_local  ";
            query += "   FROM  ";
            query += "   AccCurrency INNER JOIN  ";
            query += "   Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN  ";
            query += "   BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN   ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id  ";
            query += "   WHERE  ";
            query += "   BoxUser.BoxUser_id =   "+ BoxUser_id;
           
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            try { return (bool)dt.Rows[0][0]; } catch { MessageBox.Show("لا يوجد حساب لهذا الصندوق ", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }

            /*
            SELECT        Currencys.Curr_is_local
FROM            AccCurrency INNER JOIN
                         Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                         BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
WHERE        (BoxUser.BoxUser_id = 6)
            */

        }
        public bool CurrCustomersIsLocal(string Cust_id)
        {
            string
           query = " SELECT ";
            query += "   Currencys.Curr_is_local  ";
            query += "   FROM  ";
            query += "   Customers INNER JOIN  ";
            query += "   AccCurrency ON Customers.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN  ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id   ";
            query += "   WHERE  ";
            query += "   Customers.Cust_id =   " + Cust_id;

            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            try { return (bool)dt.Rows[0][0]; } catch(Exception e) { MessageBox.Show(e.ToString()); MessageBox.Show("لا يوجد حساب لهذا العميل ", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }

            /*
            SELECT        Currencys.Curr_is_local
FROM            Customers INNER JOIN
                         AccCurrency ON Customers.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
WHERE        (Customers.Cust_id = 1)
            */

        }

        public List<string> GetCurrNameAndExching4idUserBox(string BoxUser_id)
        {
            List<string> data = new List<string>();
            data.Clear();
            string
          query = " SELECT ";
            query += "    Currencys.Curr_sumbol_eng,  ";
            query += "    Currencys.Curr_echange  ";
            query += "   FROM  ";
            query += "   BoxUser INNER JOIN   ";
            query += "   Boxes ON BoxUser.Box_id_fk = Boxes.Box_id INNER JOIN  ";
            query += "   AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN  ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id  ";
            query += "   WHERE  ";
            query += "  BoxUser.BoxUser_id =   " + BoxUser_id;

            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
            {
                data.Clear();
                data.Add(dt.Rows[0][0].ToString());
                data.Add(dt.Rows[0][1].ToString());
            }
            return data;
            /*
            SELECT        Currencys.Curr_sumbol_eng, Currencys.Curr_echange
FROM            BoxUser INNER JOIN
                         Boxes ON BoxUser.Box_id_fk = Boxes.Box_id INNER JOIN
                         AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
WHERE        (BoxUser.BoxUser_id = 7)
            */
        }
        public List<string> GetCurrNameAndExching4Customers(string Cust_id)
        {
            List<string> data = new List<string>();
            data.Clear();
            string
          query = " SELECT ";
            query += "  Currencys.Curr_sumbol_eng,  ";
            query += "  Currencys.Curr_echange  ";
            query += "  FROM  ";
            query += "  AccCurrency INNER JOIN    ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN  ";
            query += "  Customers ON AccCurrency.AccCurr_id = Customers.AccCurr_id_fk  ";
            query += "   WHERE  ";
            query += " Customers.Cust_id =   " + Cust_id;

            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
            {
                data.Clear();
                data.Add(dt.Rows[0][0].ToString());
                data.Add(dt.Rows[0][1].ToString());
            }
            return data;
            /*
           SELECT        Currencys.Curr_sumbol_eng, Currencys.Curr_echange
FROM            AccCurrency INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                         Customers ON AccCurrency.AccCurr_id = Customers.AccCurr_id_fk
WHERE        (Customers.Cust_id = 1)
            */
        }

        public string GetExchingPawCurr(string Exching,string Total)
        {
            dt = new DataTable();
          
           
            string
                query = "SELECT CEILING(convert(decimal,(CONVERT(decimal,"; 
               query += Total + ")/CONVERT(decimal,"+ Exching + "))))";

            dt = con.Query(query, true);
            //SELECT CEILING(convert(decimal,(CONVERT(decimal, 2620)/CONVERT(decimal,140))))
            con.CloseConnetion();
            MessageBox.Show(dt.Rows[0][0].ToString());
            return dt.Rows[0][0].ToString();
            /*
            select Round(12500/140,-1)
            */

        }
        public string GetIdCurrStock()
        {
            string
            query = " SELECT ";
            query += " Curr_id ";
            query += " FROM";
            query += " Currencys ";
            query += " WHERE ";
            query += " (Curr_is_stock = 1) ";
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            try { return dt.Rows[0][0].ToString(); } catch { MessageBox.Show("لم يتم تحدد عملة المخزون","تنبية",MessageBoxButtons.OK,MessageBoxIcon.Warning); return ""; }


            #region
            /*
            SELECT  
            Curr_id
            FROM      
            Currencys
            WHERE    
            (Curr_is_stock = 1)
            */
            #endregion

        }
        #endregion


    }
}
