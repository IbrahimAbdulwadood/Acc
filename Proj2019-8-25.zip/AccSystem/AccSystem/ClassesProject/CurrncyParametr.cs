﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccSystem.ClassesProject
{
  public  class CurrncyParametr
    {
        public string Curr_name { set; get; }
        public string Curr_id { set; get; }
        public string Curr_sumbol { set; get; }
        public string Curr_sumbol_eng { set; get; }
        public string Curr_fakah { set; get; }
        public string Curr_echange { set; get; }
        public string Curr_is_local { set; get; }
        public string Curr_is_stock { set; get; }
        public string Curr_maximum { set; get; }
        public string Curr_minimum { set; get; }
        public string Arabic1CurrencyName { set; get; }
        public string Arabic2CurrencyName { set; get; }
        public string Arabic310CurrencyName { set; get; }
        public string Arabic1199CurrencyName { set; get; }
        public string Arabic1CurrencyPartName { set; get; }
        public string Arabic2CurrencyPartName { set; get; }
        public string Arabic310CurrencyPartName { set; get; }
        public string Arabic1199CurrencyPartName { set; get; }
        public string PartPrecision { set; get; }
        public string IsCurrencyNameFeminine { set; get; }
        public string IsCurrencyPartNameFeminine { set; get; }



    }
}
