﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace AccSystem.ClassesProject
{
    class CustomersSql: AccDefintionSQL
    {
        ConnectionDB con = new ConnectionDB();
        
        DataTable dt;
        public DataTable GetAllCustomers()
        {
            string 
             query = "  SELECT      ";
            query += "    Customers.Cust_id ";
            query += "  , Customers.Cust_name ";
            query += "  , Customers.Cust_address ";
            query += "  , Customers.Cust_phone ";
            query += "  , Customers.Cust_email ";
            query += "  , Customers.Note ";
            query += "  , AccCurrency.AccCurr_id ";
            query += "  , Accounts.Acc_id ";
            query += "  , Accounts.Acc_name ";
            query += "  , AccCurrency.Maximum ";
            query += "  , Currencys.Curr_sumbol_eng ";

            query += "   ,( SELECT  ";
            query += "   ISNULL( ";
            query += "   iif(Currencys.Curr_is_local=1, ";
            query += "   iif(Accounts.Acc_nature_fk=1, ";
            query += "   (sum(DaylyBody.Debt_local)- sum(DaylyBody.Credit_local)), ";
            query += "   (sum (DaylyBody.Credit_local)-sum(DaylyBody.Debt_local))), ";
            query += "   iif(Accounts.Acc_nature_fk=1, ";
            query += "   (sum(DaylyBody.Debt_foreign)- sum(DaylyBody.Credit_foreign)), ";
            query += "   (sum (DaylyBody.Credit_foreign)-sum(DaylyBody.Debt_foreign)))),0) ";
            query += "   FROM       AccCurrency INNER JOIN ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "   DaylyBody ON AccCurrency.AccCurr_id = DaylyBody.AccCurr_id_fk INNER JOIN  ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id ";
            query += "   WHERE ";
            query += "   (DaylyBody.AccCurr_id_fk = Customers.AccCurr_id_fk)   ";
            query += "   group by Currencys.Curr_is_local,Accounts.Acc_nature_fk)  as Account  ";
          
            query += "  FROM   Customers INNER JOIN  ";
            query += "  AccCurrency ON Customers.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";

            #region       
            /*
              SELECT      
    Customers.Cust_id
  , Customers.Cust_name
  , Customers.Cust_address
  , Customers.Cust_phone
  , Customers.Cust_email
  , Customers.Note
  , AccCurrency.AccCurr_id
  , Accounts.Acc_id
  , Accounts.Acc_name
  , AccCurrency.Maximum
  , Currencys.Curr_sumbol_eng
  ,( SELECT       
   ISNULL(
                           iif(Currencys.Curr_is_local=1,
                           iif(Accounts.Acc_nature_fk=1,
                           (sum(DaylyBody.Debt_local)- sum(DaylyBody.Credit_local)),
                           (sum (DaylyBody.Credit_local)-sum(DaylyBody.Debt_local))),
                           iif(Accounts.Acc_nature_fk=1,
                           (sum(DaylyBody.Debt_foreign)- sum(DaylyBody.Credit_foreign)),
                           (sum (DaylyBody.Credit_foreign)-sum(DaylyBody.Debt_foreign)))),0) as Account
  FROM            AccCurrency INNER JOIN
                           Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                           DaylyBody ON AccCurrency.AccCurr_id = DaylyBody.AccCurr_id_fk INNER JOIN
                           Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
  WHERE 
         (DaylyBody.AccCurr_id_fk = Customers.AccCurr_id_fk) 
         group by Currencys.Curr_is_local,Accounts.Acc_nature_fk)

  FROM            Customers INNER JOIN
                           AccCurrency ON Customers.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                           Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                           Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id



      */
            #endregion

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
      public  void Delet(string Cust_id="-1")
        {
            string
           query = "  DELETE FROM [dbo].[Customers]   ";
            query += "   WHERE Cust_id= " + Cust_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            /*
            DELETE FROM [dbo].[Customers]
      WHERE Cust_id=1
            */
        }
        public List<string> ChaeckCanDelet(string Cust_id_fk, string AccCurr_id_fk)
        {
            List<string> Data = new List<string>();
            string
            query = "  SELECT   Dayly_id_fk   ";
            query += "   FROM   DaylyBody  WHERE    AccCurr_id_fk =  "+ AccCurr_id_fk;
            query += "   union all  ";
            query += "    SELECT   Bill_id   FROM    SalesBillHead  WHERE  Cust_id_fk = "+ Cust_id_fk;
            query += "   union all  ";
            query += "  SELECT   Return_bill_id  FROM  ReturnSalesBillHead   WHERE   Cust_id_fk = "+ Cust_id_fk;
            query += "   union all  ";
            query += "  SELECT   Entry_id_fk  FROM   EntriesBody  WHERE   AccCurr_id_fk = "+ AccCurr_id_fk;
            query += "   union all  ";
            query += "  SELECT  Support_id_fk   FROM   SupportExchangBody  WHERE   AccCurr_id_fk = "+ AccCurr_id_fk;
            query += "   union all  ";
            query += "  SELECT  Support_id_fk   FROM   SupportCatchBody   WHERE  AccCurr_id_fk = "+ AccCurr_id_fk;
            query += "   union all  ";
            query += "   SELECT  Serial_number_balance  FROM  BalanceOpen  WHERE  AccCurr_id_fk = "+ AccCurr_id_fk;
          
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    Data.Add(dt.Rows[i][0].ToString());
            return Data;
            #region
            /*
            SELECT        Dayly_id_fk
                FROM            DaylyBody
                WHERE        AccCurr_id_fk = 17
                union all
                SELECT        Bill_id
                FROM            SalesBillHead
                WHERE        Cust_id_fk = 1
                union all
                SELECT        Return_bill_id
                FROM            ReturnSalesBillHead
                WHERE        Cust_id_fk = 1
                union all
                SELECT        Entry_id_fk
                FROM            EntriesBody
                WHERE        AccCurr_id_fk = 17
                union all
                SELECT        Support_id_fk
                FROM            SupportExchangBody
                WHERE        AccCurr_id_fk = 17
                union all
                SELECT        Support_id_fk
                FROM            SupportCatchBody
                WHERE        AccCurr_id_fk = 17
                union all
                SELECT        Serial_number_balance
                FROM            BalanceOpen
                WHERE        AccCurr_id_fk = 1
            */
            #endregion
        }

        public void InsertCustomers(string Acc_id_fk , string Cust_name ,string Cust_address,string Cust_phone , string Note ,string Cust_email)
        {

            string 
            query = "   INSERT INTO [dbo].[Customers]    ";
            query += "  (    ";
            query += "   [Cust_id]   ";
            query += "  ,[AccCurr_id_fk]   ";
            query += "  ,[Cust_name]    ";
            query += "  ,[Cust_address]   ";
            query += "  ,[Cust_phone]     ";
            query += "  ,[Cust_email]    ";
            query += "  ,[Note]    ";
            query += "   )   ";
            query += "  VALUES   ";
            query += "   (   ";
            query +=   GetMaxId();
            query += "  ,"+ Acc_id_fk;
            query += "  ,"+con.AddApostropheToString(Cust_name);
            query += "  ,"+con.AddApostropheToString(Cust_address);
            query += "  ,"+ Cust_phone;
            query += "  ,"+con.AddApostropheToString(Cust_email);
            query += "  ,"+con.AddApostropheToString(Note);
            query += "  ) ";
            #region
            /*
            INSERT INTO [dbo].[Customers]
           (
            [Cust_id]
           ,[AccCurr_id_fk]
           ,[Cust_name]
           ,[Cust_address]
           ,[Cust_phone]
           ,[Cust_email]
           ,[Note]
           )
     VALUES
           (
		   2
           ,8
           ,''
           ,''
           ,967
           ,''
           ,''
		   )
            
            */
         #endregion
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

        }
        public string GetMaxId()
        {
            string id;

            string query = "SELECT isnull(max([Cust_id]),0)+1 From Customers";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;
        }

        public void Updatecustom(string Cust_id, string Cust_name, string Cust_address, string Cust_phone, string Note, string Cust_email)
        {
            con.OpenConnetion();
            //string query = " UPDATE Customers SET Cust_name = @Cust_name ,Cust_address = @Cust_address , Note = @Note, Cust_email=@Cust_email  WHERE Cust_id = @Cust_id ";
            string 
            query = "  UPDATE [dbo].[Customers] ";
            query += " SET ";
            query += "  [Cust_name] = "+con.AddApostropheToString(Cust_name);
            query += " ,[Cust_address] = " + con.AddApostropheToString(Cust_address);
            query += " ,[Cust_phone] = "+ Cust_phone;
            query += " ,[Cust_email] = " + con.AddApostropheToString(Cust_email);
            query += " ,[Note] = " + con.AddApostropheToString(Note);
            query += "  WHERE [Cust_id] = "+ Cust_id;
           

           // SqlCommand com = new SqlCommand(query, con.conn);
           // com.Parameters.AddWithValue("@cust_id", Cust_id);
           //// com.Parameters.AddWithValue("@Acc_id_fk", Acc_id_fk);
           // com.Parameters.AddWithValue("@Cust_name", Cust_name);
           // com.Parameters.AddWithValue("@Cust_address", Cust_address);
           // com.Parameters.AddWithValue("@Cust_phone", Cust_phone);
           // com.Parameters.AddWithValue("@Note", Note);
           // com.Parameters.AddWithValue("@Cust_email", Cust_email);


            //com.ExecuteNonQuery();
             con.Query(query, false);
            con.CloseConnetion();
            MessageBox.Show("تم التعديل");
            #region
            /*
            UPDATE [dbo].[Customers]
   SET 
      
       [Cust_name] = ''
      ,[Cust_address] ='' 
      ,[Cust_phone] = 99
      ,[Cust_email] = ''
      ,[Note] = ''
 WHERE [Cust_id] =1 
            */
            #endregion
        }

        public DataTable Serch(string txtSerch)
        {

            string
             query = "SELECT   ";
            query += "     Customers.Cust_id  ";
            query += "   , Customers.Cust_name  ";
            query += "   , Customers.Cust_address   ";
            query += "   , Customers.Cust_phone  ";
            query += "   , Customers.Cust_email  ";
            query += "   , Customers.Note  ";
            query += "   , AccCurrency.AccCurr_id  ";
            query += "   , Accounts.Acc_id  ";
            query += "   , Accounts.Acc_name  ";
            query += "   , AccCurrency.Maximum   ";
            query += "   , Currencys.Curr_sumbol_eng  ";

            
            query += "   ,(	 SELECT      ";
            query += "   ISNULL(  ";
            query += "   iif(Currencys.Curr_is_local=1,  ";
            query += "   iif(Accounts.Acc_nature_fk=1,  ";
            query += "  (sum(DaylyBody.Debt_local)- sum(DaylyBody.Credit_local)),  ";
            query += "  (sum (DaylyBody.Credit_local)-sum(DaylyBody.Debt_local))),  ";
            query += "  iif(Accounts.Acc_nature_fk=1,  ";
            query += "  (sum(DaylyBody.Debt_foreign)- sum(DaylyBody.Credit_foreign)),  ";
            query += "  (sum (DaylyBody.Credit_foreign)-sum(DaylyBody.Debt_foreign)))),0)  ";
            query += "    FROM            AccCurrency INNER JOIN  ";
            query += "     Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN  ";
            query += "  DaylyBody ON AccCurrency.AccCurr_id = DaylyBody.AccCurr_id_fk INNER JOIN  ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  ";
            query += "  WHERE  ";
            query += "  (DaylyBody.AccCurr_id_fk = Customers.AccCurr_id_fk)   ";
            query += "   group by Currencys.Curr_is_local,Accounts.Acc_nature_fk) as Account  ";
 
            query += " FROM    Customers INNER JOIN   ";
            query += "   AccCurrency ON Customers.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN  ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id  ";
            query += "   where   ";
            query += "      Customers.Cust_id like'%"+ txtSerch + "%'  ";
            query += "   or Customers.Cust_name like'%" + txtSerch + "%'  ";
            query += "   or Customers.Cust_phone like '%" + txtSerch + "%'  ";
            query += "   or Customers.Cust_address like '%" + txtSerch + "%'  ";
            query += "   or Customers.Note like '%" + txtSerch + "%'  ";
            query += "   or Accounts.Acc_id like '%" + txtSerch + "%'  ";
            query += "   or Accounts.Acc_name like '%" + txtSerch + "%'  ";
            query += "   or AccCurrency.Maximum like '%" + txtSerch + "%'  ";
            query += "   or Currencys.Curr_sumbol_eng like '%" + txtSerch + "%'  ";
           
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

            #region
            /*
                    SELECT      
          Customers.Cust_id
        , Customers.Cust_name
        , Customers.Cust_address
        , Customers.Cust_phone
        , Customers.Cust_email
        , Customers.Note
        , AccCurrency.AccCurr_id
        , Accounts.Acc_id
        , Accounts.Acc_name
        , AccCurrency.Maximum
        , Currencys.Curr_sumbol_eng
        ,(	 SELECT       
         ISNULL(
						         iif(Currencys.Curr_is_local=1,
						         iif(Accounts.Acc_nature_fk=1,
						         (sum(DaylyBody.Debt_local)- sum(DaylyBody.Credit_local)),
						         (sum (DaylyBody.Credit_local)-sum(DaylyBody.Debt_local))),
						         iif(Accounts.Acc_nature_fk=1,
						         (sum(DaylyBody.Debt_foreign)- sum(DaylyBody.Credit_foreign)),
						         (sum (DaylyBody.Credit_foreign)-sum(DaylyBody.Debt_foreign)))),0) 
        FROM            AccCurrency INNER JOIN
                                 Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                                 DaylyBody ON AccCurrency.AccCurr_id = DaylyBody.AccCurr_id_fk INNER JOIN
                                 Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
        WHERE 
               (DaylyBody.AccCurr_id_fk = Customers.AccCurr_id_fk) 
	           group by Currencys.Curr_is_local,Accounts.Acc_nature_fk) as Account

        FROM            Customers INNER JOIN
                                 AccCurrency ON Customers.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                                 Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                                 Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
						         
                                 where  
						             Customers.Cust_id like'%%'
						         or  Customers.Cust_name like'%%'
						         or  Customers.Cust_phone like '%%'
						         or  Customers.Cust_address like '%%'
						         or  Customers.Note like '%%'
						         or Accounts.Acc_id like '%%'
						         or Accounts.Acc_name like '%%'
						         or AccCurrency.Maximum like '%%'
						         or Currencys.Curr_sumbol_eng like '%%'
            
            */
            #endregion

        }

        public List<string> GetAccCustomers()
        { //ترجع في مصفوفة حسابات  العملاء المرتبطة
            string query = "SELECT [AccCurr_id_fk] FROM [dbo].[Customers]";
            List<string> accsupllier = new List<string>();

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);

            con.CloseConnetion();
            for (int i = 0; i < dt.Rows.Count; i++)
              accsupllier.Add(dt.Rows[i][0].ToString());
            return accsupllier;

        }

        public DataTable GetAllAcc()
        {
            //ترجع جميع حسابات العملاء الموجودة في الدليل المحاسبي
            string query = "SELECT ";
           
            query += "  AccCurrency.AccCurr_id ";
            query += " ,Accounts.Acc_id ";
            query += " ,Accounts.Acc_name ";
            query += " ,Currencys.Curr_sumbol_eng ";
            query += "  FROM ";
            query += "  AccCurrency INNER JOIN ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";
            query += "  WHERE ";
            query += "  Accounts.Acc_id_father = "+ GetIdAccCustomerFather();

            /*
           SELECT     
           AccCurrency.AccCurr_id
           , Accounts.Acc_id
           , Accounts.Acc_name
           , Currencys.Curr_sumbol_eng
            FROM  
            AccCurrency INNER JOIN
            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
            Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
            WHERE 
            Accounts.Acc_id_father = 1121
            
            */
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }
        //////////////////////////////////////////////////////////////
        public string[] GetListCustomers()
        { //ترجع في مصفوفة حسابات  العملاء المرتبطة
            string query = "SELECT [Cust_id_fk] FROM [dbo].[SalesBillHead]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            string[] accsupllier = new string[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                accsupllier[i] = dt.Rows[i][0].ToString();
            }

            return accsupllier;

        }

        public DataTable GetAllListCustomers()
        {
            string query = "SELECT  [dbo].[Customers].[Cust_id],  [dbo].[Customers].[Cust_name],[dbo].[Accounts].[Acc_name],";
            query += "[dbo].[AccCurrency].[Maximum],[dbo].[Currencys].[Curr_name]";
            query += " FROM[dbo].[Customers]";
            query += "INNER JOIN";
            query += "[dbo].[AccCurrency]";
            query += "ON[dbo].[Customers].[AccCurr_id_fk] = [dbo].[AccCurrency].[AccCurr_id]";
            query += "INNER JOIN";
            query += "[dbo].[Accounts]";
            query += "ON[dbo].[AccCurrency].[Acc_id_fk] = [dbo].[Accounts].[Acc_id]";
            query += "INNER JOIN";
            query += "[dbo].[Currencys]";
            query += "ON[dbo].[AccCurrency].[Curr_id_fk] = [dbo].[Currencys].[Curr_id]";

        con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

         

        }

    }
}
