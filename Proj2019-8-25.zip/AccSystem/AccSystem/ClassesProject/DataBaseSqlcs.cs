﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AccSystem.ClassesProject
{
    class DataBaseSqlcs
    {


        SqlConnection con = new SqlConnection("Data Source=.;DataBase=AccSysDB1;Integrated Security=True");
        
        SqlCommand cmd;
        public void addBase()
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.Filter = "Backup Files (*.Bak)|*.bak";
            if (sf.ShowDialog() == DialogResult.OK)
            {
                cmd = new SqlCommand("Backup Database AccSysDB1 To Disk='" + sf.FileName + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
       
    }
}
