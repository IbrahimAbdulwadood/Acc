﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccSystem.ClassesProject
{
   public class EntriesParametr
    {
        /*
            
         
        SELECT       
         AccCurrency.AccCurr_id
         , AccCurrency.Acc_id_fk
         , Accounts.Acc_name
         , Currencys.Curr_name
         , Currencys.Curr_is_local
         ,  Currencys.Curr_echange
         , Currencys.Curr_maximum
         , Currencys.Curr_minimum
         , Accounts.Acc_state
         , AccCurrency.State
        FROM   
           AccCurrency 
           INNER JOIN  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
           INNER JOIN  Currencys   ON AccCurrency.Curr_id_fk = Currencys.Curr_id 
						 
						         order by  AccCurrency.Acc_id_fk
            
            */
        //    EntriesParametr
        //    (
        //   string AccCurr_id, string Acc_id_fk,
        //   string Acc_name,string Curr_name,
        //   string Curr_is_local,  string Curr_echange,
        //   string Curr_maximum, string Curr_minimum
        //    )
        //{
        //     AccCurr_id;
        //     Acc_id_fk;
        //     Acc_name;
        //     Curr_name;
        //     Curr_is_local;
        //     Curr_echange;
        //     Curr_maximum;
        //     Curr_minimum;
        /*
          EntriesBody_id 
          Debt_local 
          Credit_local 
          Debt_foreign 
          Credit_foreign 
          Note 
          AccCurr_id;
          Acc_id_fk;
          Acc_name;
          Curr_name;
          Curr_is_local;
          Curr_echange;
          Curr_maximum;
          Curr_minimum;
            */
        //}

        public string Acc_id_fk { set; get; }
        public string Acc_name { set; get; }
        public string Curr_name { set; get; }
        public string Curr_is_local { set; get; }
        public string Curr_maximum { set; get; }
        public string Curr_minimum { set; get; }
        public string bemoo { get; set; }

        public string AccCurr_id { set; get; }
        public string Curr_echange { set; get; }


        public string EntriesBody_id { set; get; }
        public string Debt_local { set; get; }
        public string Credit_local { set; get; }
        public string Debt_foreign { set; get; }
        public string Credit_foreign { set; get; }
        public string Note { set; get; }

       
       
      

    }
}
