﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;


namespace AccSystem.ClassesProject
{
    class EntriesSQL
    {
        #region المتغيرات
        DataTable dt;
        ConnectionDB con = new ConnectionDB();

        #endregion
        #region الدوال
        #region الدوال المساعدة
        public void Delet(string Entry_id="-1")
        {
            string
          query = "      DELETE FROM [dbo].[EntriesHead]    WHERE Entry_id= "+ Entry_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            /*
            DELETE FROM [dbo].[EntriesHead]
      WHERE Entry_id=1
            */
        }
        string AddApostropheToString(string txt)
        {
            //اضافة نص احادي للكلمات
            if (txt != "NULL")
            {
                txt = "'" + txt + "'";
            }

            return txt;
        }


        #endregion

        #region الدوال الاساسية

        public DataTable SerchEntreiesHaed(string txt)
        {
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string
            query = "    SELECT ";
            query += "   EntriesHead.Entry_id ";
            query += "  ,EntriesHead.Date_entry ";
            query += "  ,EntriesHead.Entry_sum ";
            query += "  ,EntriesHead.Refr_id ";
            query += "  ,EntriesHead.User_id_fk ";
            query += "  ,Users.User_name ";
            query += "  ,EntriesHead.Note ";
            query += "  ,EntriesHead.Posting ";
            query += "   FROM EntriesHead INNER JOIN ";
            query += "   Users ON EntriesHead.User_id_fk = Users.User_id ";
            query += "   where ";
            query += "   EntriesHead.Entry_id like '%"+ txt + "%' or ";
            query += "   EntriesHead.Entry_sum like '%"+ txt + "%' or  ";
            query += "   EntriesHead.Refr_id like '%"+ txt + "%'  or  ";
            query += "   EntriesHead.Note like '%"+ txt + "%' ";

            #region
            /*
            SELECT
     EntriesHead.Entry_id, 
     EntriesHead.Date_entry, 
	 EntriesHead.Entry_sum, 
	 EntriesHead.Refr_id,
	  EntriesHead.User_id_fk, 
	  EntriesHead.Note,
	   Users.User_name
FROM     
EntriesHead INNER JOIN
                         Users ON EntriesHead.User_id_fk = Users.User_id
                          where
						  EntriesHead.Entry_id like '%%' or
						    EntriesHead.Entry_sum like '%%' or 
							 EntriesHead.Refr_id like '%%'  or 
							   EntriesHead.Note like '%%'
            
            */
            #endregion

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
        }
        public DataTable GetAllEntries()
        {
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string
            query = "     SELECT ";
            query += "    EntriesHead.Entry_id "; 
            query += "  , EntriesHead.Date_entry ";
            query += "  , EntriesHead.Entry_sum ";
            query += "  , EntriesHead.Refr_id ";
            query += "  , EntriesHead.User_id_fk ";
            query += "  , Users.User_name ";
            query += "  , EntriesHead.Note ";
            query += "  , EntriesHead.Posting ";
            query += "   FROM EntriesHead INNER JOIN ";
            query += "   Users ON EntriesHead.User_id_fk = Users.User_id ";


            #region
            /*
            SELECT
     EntriesHead.Entry_id, 
     EntriesHead.Date_entry, 
	 EntriesHead.Entry_sum, 
	 EntriesHead.Refr_id,
	  EntriesHead.User_id_fk, 
	  EntriesHead.Note,
	   Users.User_name
FROM     
EntriesHead INNER JOIN
                         Users ON EntriesHead.User_id_fk = Users.User_id
                          where
						  EntriesHead.Entry_id like '%%' or
						    EntriesHead.Entry_sum like '%%' or 
							 EntriesHead.Refr_id like '%%'  or 
							   EntriesHead.Note like '%%'
            
            */
            #endregion
            try {
                con.OpenConnetion();
                dt = con.Query(query, true);
                con.CloseConnetion();

                return dt; }
            catch(Exception e) { System.Windows.Forms.MessageBox.Show(e.ToString()); return null; }
        }

        public DataTable GetAllEntriesBody(string Entry_id_fk)
        {
           
                dt = new DataTable();
            
            #region
            /*
            SELECT        EntriesBody.EntriesBody_id, AccCurrency.Acc_id_fk, Accounts.Acc_name, 
            Currencys.Curr_name, EntriesBody.CurrExching, EntriesBody.Debt_local, EntriesBody.Credit_local, 
            EntriesBody.Debt_foreign, EntriesBody.Credit_foreign, EntriesBody.Note, EntriesBody.Date_entry_body,
            AccCurrency.AccCurr_id
            FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                         EntriesBody ON AccCurrency.AccCurr_id = EntriesBody.AccCurr_id_fk
            WHERE        (EntriesBody.Entry_id_fk = 1)
            */
            #endregion
            string
            query = "   SELECT ";
            query += "  EntriesBody.EntriesBody_id , ";
            query += " AccCurrency.Acc_id_fk , ";
            query += "  Accounts.Acc_name , ";
            query += "  Currencys.Curr_name , ";
            query += " EntriesBody.CurrExching , ";
            query += " EntriesBody.Debt_local , ";
            query += " EntriesBody.Credit_local , ";
            query += "  EntriesBody.Debt_foreign , ";
            query += " EntriesBody.Credit_foreign , ";
            query += " EntriesBody.Note , ";
            query += " EntriesBody.Date_entry_body , ";
            query += "   AccCurrency.AccCurr_id ";
        
            query += "  FROM    AccCurrency INNER JOIN ";
            query += " Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "   EntriesBody ON AccCurrency.AccCurr_id = EntriesBody.AccCurr_id_fk ";

            query += "  WHERE  (EntriesBody.Entry_id_fk  =" + Entry_id_fk+")";
           
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
        }

        public string InsertNewEntriesHaed
            (string Date_entry, string Entry_sum , string Refr_id,
            string Note, string User_id_fk
            )
        {

            #region
            /*
            
            INSERT INTO [dbo].[EntriesHead]
           ([Entry_id]
           ,[Date_entry]
           ,[Entry_sum]
           ,[Refr_id]
           ,[Note]
           ,[User_id_fk])
     VALUES
           (<Entry_id, int,> || 9
           ,<Date_entry, date,> || '2019/5/10'
           ,<Entry_sum, float,>  || 1200
           ,<Refr_id, int,> ||  NULL
           ,<Note, nvarchar(max),> || 'eee'
           ,<User_id_fk, int,> || 1
           )
           
            */
            #endregion
            string idEntry = GetMaxIdEntriseHaed();
            string
            query = "   INSERT INTO [dbo].[EntriesHead] ";
            query += " ([Entry_id] ";
            query += "  ,[Date_entry] ";
            query += "  ,[Entry_sum] ";
            query += "  ,[Refr_id] ";
            query += "  ,[Note] ";
            query += "  ,[Posting] ";//Posting
            query += "  ,[User_id_fk]) ";
            query += "   VALUES ( ";
            query +=    idEntry;
            query += "  ,"+AddApostropheToString(Date_entry);
            query += "  ,"+ Entry_sum;
            query += "  , "+ Refr_id;
            query += " ,"+AddApostropheToString(Note);
            query += " ,0";//Posting
            query += " ,"+ User_id_fk;
            query += "  ) ";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            // System.Windows.Forms.MessageBox.Show(idEntry, "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(AddApostropheToString(Date_entry), "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(Entry_sum, "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(Refr_id, "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(AddApostropheToString(Note), "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(User_id_fk, "InsertNewEntriesHaed");
           
            return idEntry;
        }
        public void InsertNewEntriesBody
           (string Entry_id_fk, string AccCurr_id_fk, string Debt_local,
           string Credit_local, string Debt_foreign, string Credit_foreign
            , string Note, string Date_entry_body,string CurrExching
           )
        {
            string
            query = "   INSERT INTO[dbo].[EntriesBody] ";
            query += "  ([Entry_id_fk] ";
            query += "  ,[EntriesBody_id] ";
            query += "  ,[AccCurr_id_fk] ";
            query += "  ,[Debt_local] ";
            query += " ,[Credit_local] ";
            query += "   ,[Debt_foreign] ";
            query += "    ,[Credit_foreign] ";
            query += "  ,[Note] ";
            query += "  ,[Date_entry_body] ";
            query += "  ,[CurrExching]) ";
            query += "  VALUES ";
            query += "   (  "+ Entry_id_fk;
            query += "    , "+GetMaxIdEntriseBody(Entry_id_fk);
            query += " , "+ AccCurr_id_fk;
            query += " , "+ Debt_local;
            query += "  , "+ Credit_local;
            query += "  , "+ Debt_foreign;
            query += "  ,"+ Credit_foreign;
            query += " ,"+AddApostropheToString(Note);
            query += "   ,"+AddApostropheToString(Date_entry_body);
            query += "  ," + CurrExching+")";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

        }

        public void UpdateEntriesBody
            (
            string Entry_id_fk,string EntriesBody_id,
            string AccCurr_id_fk, string Debt_local,
            string Credit_local,string Debt_foreign,
            string Credit_foreign,string Note,
            string Date_entry_body, string CurrExching
            )
        {
            string
            query = "   UPDATE[dbo].[EntriesBody] ";
            query += "  SET ";
            query += "   [AccCurr_id_fk] ="+ AccCurr_id_fk;
            query += "  ,[Debt_local] ="+ Debt_local;
            query += "  ,[Credit_local] ="+ Credit_local;
            query += "  ,[Debt_foreign] ="+ Debt_foreign;
            query += "  ,[Credit_foreign] ="+ Credit_foreign;
            query += "  ,[Note] ="+AddApostropheToString(Note);
            query += "  ,[Date_entry_body] ="+AddApostropheToString(Date_entry_body);
            query += "  ,[CurrExching] =" + CurrExching;
            query += "  WHERE [Entry_id_fk] = "+ Entry_id_fk;
            query += "  and[EntriesBody_id] = "+ EntriesBody_id;

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
         }
        public void UpdateEntriesHaed
           (
         string Entry_id,string Date_entry,
         string Entry_sum, string Refr_id,
         string Note, string User_id_fk
           )
        {
            string
            query = "   UPDATE [dbo].[EntriesHead] ";
            query += "  SET ";
            query += "  [Date_entry] ="+AddApostropheToString(Date_entry);
            query += " ,[Entry_sum] = "+ Entry_sum;
            query += " ,[Refr_id] ="+Refr_id; //Can Null
            query += " ,[Note] ="+AddApostropheToString(Note);
            query += " ,[User_id_fk] ="+ User_id_fk;
            query += "  WHERE[Entry_id] = "+ Entry_id;
 
    
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }

        public string GetMaxIdEntriseHaed()
        {
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query = "SELECT isnull(max(Entry_id),0)+1 From EntriesHead";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
         
                id = dt.Rows[0][0].ToString();
        
            return id;

        }
        public void DeleteEntryBody(string EntriesBody_id,string Entry_id_fk)
        {

            string 
            query = "DELETE FROM [dbo].[EntriesBody]";
            query += " WHERE[EntriesBody].EntriesBody_id = "+ EntriesBody_id;
            query += " and[EntriesBody].Entry_id_fk = "+ Entry_id_fk;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }

        public string GetMaxIdEntriseBody(string Entry_id_fk)
        {
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query = "SELECT isnull(max(EntriesBody_id),0)+1 From EntriesBody where Entry_id_fk="+ Entry_id_fk;

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;

        }

        #endregion

        #region استعلامات التقارير
       public DataTable ReportEnrty(string Entry_id_fk)
        {
            if (dt != null)
                dt = null;
                dt = new DataTable();
            string 
            query = "  SELECT    ";
            query += " AccCurrency.Acc_id_fk ,  ";
            query += " Iif(EntriesBody.Debt_local=0,null,Accounts.Acc_name) as AccNameDeb ,  ";
            query += " Iif(EntriesBody.Credit_local=0,null,Accounts.Acc_name) as AccNameCredit , ";
            query += "  Currencys.Curr_sumbol,  ";
            query += "  EntriesBody.CurrExching,  ";
            query += " EntriesBody.Debt_local, ";
            query += "  EntriesBody.Credit_local, ";
            query += " EntriesBody.Debt_foreign,  ";
            query += "  EntriesBody.Credit_foreign, ";
   query += " CONCAT(  EntriesBody.Note ,' || بتاريخ ',FORMAT (EntriesBody.Date_entry_body, 'yyyy-MM-dd')) ";
            query += " FROM  ";
            query += "   Accounts INNER JOIN ";
            query += "   AccCurrency ON Accounts.Acc_id = AccCurrency.Acc_id_fk INNER JOIN ";
            query += "  EntriesBody ON AccCurrency.AccCurr_id = EntriesBody.AccCurr_id_fk INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";
            query += " where (EntriesBody.Entry_id_fk = ";
            query += Entry_id_fk;
            query += " )  order by EntriesBody.Credit_local ";

      
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
            #region الاستعلام
            /*
            SELECT   
  AccCurrency.Acc_id_fk ,  
  Iif(EntriesBody.Debt_local=0,null,Accounts.Acc_name) as AccNameDeb , 
  Iif(EntriesBody.Credit_local=0,null,Accounts.Acc_name) as AccNameCredit ,
   Currencys.Curr_sumbol, 
   EntriesBody.CurrExching, 
  EntriesBody.Debt_local,
   EntriesBody.Credit_local, 
   EntriesBody.Debt_foreign, 
   EntriesBody.Credit_foreign,
 CONCAT(  EntriesBody.Note ,' || بتاريخ ',FORMAT (EntriesBody.Date_entry_body, 'yyyy-MM-dd'))

  
FROM            Accounts INNER JOIN
                         AccCurrency ON Accounts.Acc_id = AccCurrency.Acc_id_fk INNER JOIN
                         EntriesBody ON AccCurrency.AccCurr_id = EntriesBody.AccCurr_id_fk INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id where (EntriesBody.Entry_id_fk = 2)  order by EntriesBody.Credit_local
            */
            #endregion

        }
       public DataTable ReportAllEnrty()
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "  SELECT    ";
            query += " AccCurrency.Acc_id_fk ,  ";
            query += " Iif(EntriesBody.Debt_local=0,null,Accounts.Acc_name) as AccNameDeb ,  ";
            query += " Iif(EntriesBody.Credit_local=0,null,Accounts.Acc_name) as AccNameCredit , ";
            query += "  Currencys.Curr_sumbol,  ";
            query += "  EntriesBody.CurrExching,  ";
            query += " EntriesBody.Debt_local, ";
            query += "  EntriesBody.Credit_local, ";
            query += " EntriesBody.Debt_foreign,  ";
            query += "  EntriesBody.Credit_foreign, ";
            query += " CONCAT(  EntriesBody.Note ,' || بتاريخ ',FORMAT (EntriesBody.Date_entry_body, 'yyyy-MM-dd')) ";
            query += " FROM  ";
            query += "   Accounts INNER JOIN ";
            query += "   AccCurrency ON Accounts.Acc_id = AccCurrency.Acc_id_fk INNER JOIN ";
            query += "  EntriesBody ON AccCurrency.AccCurr_id = EntriesBody.AccCurr_id_fk INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id ";
            query += "   order by EntriesBody.Entry_id_fk, EntriesBody.Credit_local  ";


            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
            #region الاستعلام
            /*
          
SELECT   
  
  AccCurrency.Acc_id_fk ,  
  Iif(EntriesBody.Debt_local=0,null,Accounts.Acc_name) as AccNameDeb , 
  Iif(EntriesBody.Credit_local=0,null,Accounts.Acc_name) as AccNameCredit ,
   Currencys.Curr_sumbol, 
   EntriesBody.CurrExching, 
  EntriesBody.Debt_local,
   EntriesBody.Credit_local, 
   EntriesBody.Debt_foreign, 
   EntriesBody.Credit_foreign,
 CONCAT(  EntriesBody.Note ,' || بتاريخ ',FORMAT (EntriesBody.Date_entry_body, 'yyyy-MM-dd')),
 
 EntriesBody.Entry_id_fk
 ,EntriesBody.EntriesBody_id

  
FROM            Accounts INNER JOIN
                         AccCurrency ON Accounts.Acc_id = AccCurrency.Acc_id_fk INNER JOIN
                         EntriesBody ON AccCurrency.AccCurr_id = EntriesBody.AccCurr_id_fk INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
						
						    order by EntriesBody.Entry_id_fk, EntriesBody.Credit_local 
            */
            #endregion

        }

        #endregion
        #endregion



    }
}
