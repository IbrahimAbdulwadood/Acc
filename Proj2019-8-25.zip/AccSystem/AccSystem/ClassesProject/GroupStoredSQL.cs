﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AccSystem.ClassesProject
{
    class GroupStoredSQL
    {
        DataTable dt;
        ConnectionDB con = new ConnectionDB();
        string AddApostropheToString(string txt)
        {
            //اضافة نص احادي للكلمات
            if (txt != "NULL")
            {
                txt = "'" + txt + "'";
            }
            
            return txt;
        }
        public DataTable Serch(string txtSerch)
        {
            string
          query = "SELECT [Group_id]";
            query += "  ,[Group_name] ";
            query += "  ,[Acc_sales_fk]";
            query += "  ,[Acc_cost_fk]";
            query += "  ,[Acc_return_sales_fk]";
            query += "  ,[Acc_return_purchases_fk]";
            query += "  ,[Acc_discount_allow_fk]";
            query += "  ,[Acc_discount_gained_fk]";
            query += "  ,[Acc_stored_fk]";
            query += "  ,[Acc_quantity_free_fk]";
            query += " FROM[dbo].[GroupStored]";
            query += "  where ([Group_id] like '%"+ txtSerch + "%' or";
            query += " [Group_name] like '%"+ txtSerch + "%' or";
            query += " [Acc_sales_fk] like '%"+ txtSerch + "%' or";
            query += " [Acc_cost_fk] like '%" + txtSerch + "%' or";
            query += " [Acc_return_sales_fk] like '%"+ txtSerch + "%' or";
            query += " [Acc_return_purchases_fk] like '%"+ txtSerch + "%' or";
            query += " [Acc_discount_allow_fk] like '%"+ txtSerch + "%' or";
            query += " [Acc_discount_gained_fk] like '%"+ txtSerch + "%' or";
            query += " [Acc_stored_fk] like '%"+ txtSerch + "%' or";
            query += " [Acc_quantity_free_fk] like '%"+ txtSerch + "%')";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
            #region
            /*
                        select 
            a.Group_id
            ,a.Group_name
            ,a.Acc_sales_fk 
            ,a.Acc_sales_id
            ,a.Acc_sales_name
            ,a.Acc_cost_fk
            ,a.Acc_cost_id
            ,a.Acc_cost_name
            ,a.Acc_return_sales_fk
            ,a.Acc_return_sales_id
            ,a.Acc_return_sales_name
            ,a.Acc_stored_fk
            ,a.Acc_stored_id
            ,a.Acc_stored_name

            from(
             SELECT        
             Group_id
             , Group_name
             , Acc_sales_fk
             ,(SELECT        Accounts.Acc_id
				            FROM   AccCurrency INNER JOIN
                            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
				            WHERE        AccCurrency.AccCurr_id = Acc_sales_fk) as Acc_sales_id
            ,(SELECT        Accounts.Acc_name
				            FROM   AccCurrency INNER JOIN
                            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
				            WHERE        AccCurrency.AccCurr_id = Acc_sales_fk)  as Acc_sales_name
             , Acc_cost_fk
             ,(SELECT        Accounts.Acc_id
				            FROM   AccCurrency INNER JOIN
                            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
				            WHERE        AccCurrency.AccCurr_id = Acc_cost_fk)  as Acc_cost_id
            ,(SELECT        Accounts.Acc_name
				            FROM   AccCurrency INNER JOIN
                            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
				            WHERE        AccCurrency.AccCurr_id = Acc_cost_fk)  as Acc_cost_name
             , Acc_return_sales_fk
             ,(SELECT        Accounts.Acc_id
				            FROM   AccCurrency INNER JOIN
                            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
				            WHERE        AccCurrency.AccCurr_id = Acc_return_sales_fk)  as Acc_return_sales_id
            ,(SELECT        Accounts.Acc_name
				            FROM   AccCurrency INNER JOIN
                            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
				            WHERE        AccCurrency.AccCurr_id = Acc_return_sales_fk)  as Acc_return_sales_name
 
             , Acc_stored_fk
             ,(SELECT        Accounts.Acc_id
				            FROM   AccCurrency INNER JOIN
                            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
				            WHERE        AccCurrency.AccCurr_id = Acc_stored_fk)  as Acc_stored_id
            ,(SELECT        Accounts.Acc_name
				            FROM   AccCurrency INNER JOIN
                            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
				            WHERE        AccCurrency.AccCurr_id = Acc_stored_fk)  as Acc_stored_name
 
 
 
            FROM            GroupStored
            ) a 

            where 
            a.Group_id like '%%'
            or  a.Group_name like '%%'

            or a.Acc_sales_id like '%%'
            or a.Acc_sales_name like '%%'

            or a.Acc_cost_id like '%%'
            or a.Acc_cost_name like '%%'

             or a.Acc_return_sales_id like '%%'
             or a.Acc_return_sales_name  like '%%'

            or a.Acc_stored_id like '%%'
            or a.Acc_stored_name like '%%'



            */
            #endregion

        }
        #region الحذف
        public List<string> ChaeckCanDelet(string Item_id_fk = "-1")
        {
            List<string> UnitItem_id = GetTypeItem4GroupStored(Item_id_fk);
            return UnitItem_id;

        }
        List<string> GetTypeItem4GroupStored(string Group_id_fk = "-1")
        {
            List<string> data = new List<string>();
            string query = " SELECT ItemType_id FROM ItemTypes WHERE Group_id_fk = " + Group_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            /*
        SELECT ItemType_id FROM ItemTypes WHERE Group_id_fk = 1
            */
        }
        public void Delet(string Group_id = "-1")
        {
            string
                    query = "   DELETE FROM [dbo].[GroupStored]  WHERE Group_id= " + Group_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            /*
       DELETE FROM [dbo].[GroupStored] WHERE Group_id=1
            */
        }
        #endregion
        public DataTable GetAllGroup ()
        {  
            /*
            [Group_id] ,[Group_name],[Acc_sales_fk] ,[Acc_purchases_cost_fk],
            [Acc_return_sales_fk] ,[Acc_return_purchases_fk] ,[Acc_discount_allow_fk] 
            ,[Acc_discount_gained_fk] ,[Acc_stored_fk] ,[Acc_quantity_free_fk]
            */
            string
            query = "SELECT [Group_id]";
            query += "  ,[Group_name] ";
            query += "  ,[Acc_sales_fk]";
            query += "  ,[Acc_cost_fk]";
            query += "  ,[Acc_return_sales_fk]";
            query += "  ,[Acc_return_purchases_fk]";
            query += "  ,[Acc_discount_allow_fk]";
            query += "  ,[Acc_discount_gained_fk]";
            query += "  ,[Acc_stored_fk]";
            query += "  ,[Acc_quantity_free_fk]";
            query += " FROM[dbo].[GroupStored]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
           
            return dt;
        }
        public DataTable GaetGroupAll()
        {
            string
           query = " SELECT  ";
            query += " Group_id   ";
            query += "  , Group_name  ";
            query += "    , Acc_sales_fk   ";
            query += "   ,(SELECT        Accounts.Acc_id    ";
            query += "   FROM   AccCurrency INNER JOIN   ";
            query += "    Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  ";
            query += "    WHERE  AccCurrency.AccCurr_id = Acc_sales_fk) as Acc_sales_fk  ";

            query += "   ,(SELECT        Accounts.Acc_name    ";
            query += "   FROM   AccCurrency INNER JOIN   ";
            query += "    Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  ";
            query += "    WHERE  AccCurrency.AccCurr_id = Acc_sales_fk) as Acc_sales_fk  ";

            query += "    , Acc_cost_fk   ";
            query += "    ,(SELECT  Accounts.Acc_id  FROM   AccCurrency INNER JOIN  ";
            query += "    Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id    WHERE   AccCurrency.AccCurr_id = Acc_cost_fk)  as Acc_cost_fk   ";
            query += "    ,(SELECT  Accounts.Acc_name FROM   AccCurrency INNER JOIN   ";
            query += "     Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id   WHERE   AccCurrency.AccCurr_id = Acc_cost_fk)  as Acc_cost_fk  ";

            query += "   , Acc_return_sales_fk   ";
            query += "    ,(SELECT  Accounts.Acc_id  FROM   AccCurrency INNER JOIN   ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE   AccCurrency.AccCurr_id = Acc_return_sales_fk)  as Acc_return_sales_fk    ";
            query += "    ,(SELECT   Accounts.Acc_name  FROM   AccCurrency INNER JOIN   ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE  AccCurrency.AccCurr_id = Acc_return_sales_fk)  as Acc_return_sales_fk   ";

            query += "  , Acc_stored_fk   ";
            query += "   ,(SELECT  Accounts.Acc_id   FROM   AccCurrency INNER JOIN  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id   ";
            query += "    WHERE        AccCurrency.AccCurr_id = Acc_stored_fk)  as Acc_stored_fk   ";
            query += "    ,(SELECT   Accounts.Acc_name   FROM   AccCurrency INNER JOIN   ";
            query += "    Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE   AccCurrency.AccCurr_id = Acc_stored_fk)  as Acc_stored_fk  ";
            query += "   FROM            GroupStored   ";
           
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;

            /*
           SELECT        
            Group_id
            , Group_name
            , Acc_sales_fk
            ,(SELECT        Accounts.Acc_id
                           FROM   AccCurrency INNER JOIN
                           Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
                           WHERE        AccCurrency.AccCurr_id = Acc_sales_fk) as Acc_sales_fk
           ,(SELECT        Accounts.Acc_name
                           FROM   AccCurrency INNER JOIN
                           Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
                           WHERE        AccCurrency.AccCurr_id = Acc_sales_fk)  as Acc_sales_fk
            , Acc_cost_fk
            ,(SELECT  Accounts.Acc_id  FROM   AccCurrency INNER JOIN
            Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id    WHERE        AccCurrency.AccCurr_id = Acc_cost_fk)  as Acc_cost_fk
           ,(SELECT  Accounts.Acc_name FROM   AccCurrency INNER JOIN
               Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id   WHERE        AccCurrency.AccCurr_id = Acc_cost_fk)  as Acc_cost_fk
            , Acc_return_sales_fk
            ,(SELECT  Accounts.Acc_id  FROM   AccCurrency INNER JOIN
              Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE        AccCurrency.AccCurr_id = Acc_return_sales_fk)  as Acc_return_sales_fk
           ,(SELECT   Accounts.Acc_name  FROM   AccCurrency INNER JOIN
              Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE        AccCurrency.AccCurr_id = Acc_return_sales_fk)  as Acc_return_sales_fk

            , Acc_stored_fk
            ,(SELECT  Accounts.Acc_id   FROM   AccCurrency INNER JOIN  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id
                           WHERE        AccCurrency.AccCurr_id = Acc_stored_fk)  as Acc_stored_fk
           ,(SELECT   Accounts.Acc_name   FROM   AccCurrency INNER JOIN
                           Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id  WHERE   AccCurrency.AccCurr_id = Acc_stored_fk)  as Acc_stored_fk



           FROM            GroupStored
           */
        }
        public void InsertNewGroupStored
            (
            string Group_name, string Acc_sales_fk, string Acc_cost_fk,
            string Acc_return_sales_fk, string Acc_return_purchases_fk, string Acc_discount_allow_fk,
            string Acc_discount_gained_fk, string Acc_stored_fk, string Acc_quantity_free_fk
            )
        {
            string
            query = "INSERT INTO [dbo].[GroupStored] ";
            query += "([Group_id],";
            query += " [Group_name] ,";
            query += "[Acc_sales_fk]  ,";
            query += "[Acc_cost_fk],";
            query += "[Acc_return_sales_fk],";
            query += "[Acc_return_purchases_fk] ";
            query += ",[Acc_discount_allow_fk]";
            query += ",[Acc_discount_gained_fk]";
            query += ",[Acc_stored_fk] ";
            query += ",[Acc_quantity_free_fk]) ";
            query += "VALUES ";
            query += "("+ GetMaxIdGroup ();  //Group_id
            query += ","+ AddApostropheToString(Group_name);  //Group_name
            query += ","+ Acc_sales_fk; //Acc_sales_fk
            query += ","+ Acc_cost_fk; //Acc_purchases_cost_fk
            query += ","+ Acc_return_sales_fk; //Acc_return_sales_fk
            query += ","+ Acc_return_purchases_fk; //Acc_return_purchases_fk
            query += ","+ Acc_discount_allow_fk; //Acc_discount_allow_fk
            query += ","+ Acc_discount_gained_fk; //Acc_discount_gained_fk
            query += ","+ Acc_stored_fk; //Acc_stored_fk
            query += ","+ Acc_quantity_free_fk + ")"; //Acc_quantity_free_fk

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }

        public string GetMaxIdGroup()
        {
            string id;

            string query = "SELECT isnull(max([Group_id]),0)+1 From GroupStored";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;

        }
        public void UpdateGroupStore
            (
             string Group_id
            , string Group_name
            //, string Acc_sales_fk
            //, string Acc_cost_fk
            //,
            //string Acc_return_sales_fk
            //, string Acc_return_purchases_fk
            //, string Acc_discount_allow_fk
            //,
            //string Acc_discount_gained_fk
            //, string Acc_stored_fk
            //, string Acc_quantity_free_fk
            )
        {
            string query = "UPDATE [dbo].[GroupStored]";
            query += "   SET ";
            query += "  [Group_name] =" + AddApostropheToString(Group_name);
            //query += "  ,[Acc_sales_fk] ="+ Acc_sales_fk;
            //query += "  ,[Acc_cost_fk] =" + Acc_cost_fk;
            //query += "  ,[Acc_return_sales_fk] ="+ Acc_return_sales_fk;
            //query += "  ,[Acc_return_purchases_fk] ="+ Acc_return_purchases_fk;
            //query += "  ,[Acc_discount_allow_fk] ="+ Acc_discount_allow_fk;
            //query += "  ,[Acc_discount_gained_fk] ="+ Acc_discount_gained_fk;
            //query += "  ,[Acc_stored_fk] ="+ Acc_stored_fk;
            //query += "  ,[Acc_quantity_free_fk] ="+ Acc_quantity_free_fk;
            query += "  WHERE[Group_id] ="+ Group_id;

            con.OpenConnetion();  
           con.Query(query, false);
            con.CloseConnetion();
        }

    }
}
