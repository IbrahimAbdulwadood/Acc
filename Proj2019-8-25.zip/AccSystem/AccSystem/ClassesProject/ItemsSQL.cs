﻿using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
namespace AccSystem.ClassesProject
{
    class ItemsSQL
    {
        /*

        ------------------------------------------
                      Table Items
        ------------------------------------------
        Item_id	//int//	Unchecked
        Item_name //	nvarchar(50) //	Unchecked
        Group_id_fk //	int //	Unchecked
        -------------------------------------------
     


        ------------------------------------------
                       ItemUnit
        ------------------------------------------
        idItemUnit      //	int //	Unchecked
        Item_id_fk      //	int	// Unchecked
        Unit_id_fk	    // int //	Unchecked
        Store_id_fk	    // int //	Checked null
        QuantityUnitNow	// int //	Unchecked
        QuantityPartNow	// int //	Unchecked
        Selling_price	// float //	Unchecked
        Prime_cost	    // float //	Unchecked
        Minimum     	// int	// Checked null
        Maxmum          //	int //	Checked null
        ------------------------------------------


        ------------------------------------------
                       Unit
        ------------------------------------------
        Unit_part       //	int            //	Unchecked
        Unit_refill     //	int            //	Unchecked
        Unit_name       //	nvarchar(50)   //	Unchecked
        Unit_id         //	int            //	Unchecked
         ------------------------------------------


        */

        ConnectionDB con = new ConnectionDB();
        DataTable dt;

        string AddApostropheToString(string txt)
        {
            //اضافة نص احادي للكلمات
            if (txt != "NULL")
            {
                txt = "'" + txt + "'";
            }

            return txt;
        }

        #region FunCtions Items Table

        ///////////////////دوال الاصناف///////////////////////////////

        public DataTable GetAllItems()
        {
            //Item_id,Item_name,Group_id_fk,Group_name
           //Done
            string
            query = "   SELECT ";
            query += "  Items.Item_id, ";
            query += "  Items.Item_name,";
            query += "  Items.ItemType_id_fk, ";
            query += "  ItemTypes.ItemType_name,";
            query += "  Items.Item_Serall,";
            query += "  Items.Item_No_From_Type,";
            query += " Items.barc ";
            query += "  FROM Items INNER JOIN";
            query += "   ItemTypes ON Items.ItemType_id_fk = ItemTypes.ItemType_id "; 
            query += "  order by Items.Item_id";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
        }
        #region  دوال الكميات
        public DataTable GetItemInfo(string Item_id)
        {
            string
           query = "   SELECT ";
            query += "  ItemUnit.idItemUnit ";
            query += "   , Items.barc ";
            query += "  , Items.Item_name ";
            query += "  , Units.Unit_name ";
            query += " FROM   Items INNER JOIN ";
            query += " ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN  ";
            query += "   Units ON ItemUnit.Unit_id_fk = Units.Unit_id where Items.Item_id= "+ Item_id;
           
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
            /*
       SELECT       
       ItemUnit.idItemUnit
       , Items.barc
       , Items.Item_name
       , Units.Unit_name
           FROM            Items INNER JOIN
                        ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN
                        Units ON ItemUnit.Unit_id_fk = Units.Unit_id where Items.Item_id=1
           */
        }

        string GetMaxidFromFristBalanc()
        {
            string
            query = "   select isnull(max(id)+1,1) from FirstBalanceBody ";
           

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt.Rows[0][0].ToString();

        }
        public void InsertNewFirstBalance(string idItemUnite_fk, string Quantity, string Part)
        {
            string
            query = "     INSERT INTO [dbo].[FirstBalanceBody] ";
            query += "    ([id] ";
            query += " ,[idItemUnite_fk]  ";
            query += " ,[Quantity]  ";
            query += "    ,[Part]  ";
            query += "    ) ";
            query += "    VALUES  ";
            query += " (  " + GetMaxidFromFristBalanc();
            query += "  ,  "+ idItemUnite_fk;
            query += "  ,  "+ Quantity;
            query += "  ,  "+ Part;
            query += "  )  ";
           
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            /*
            INSERT INTO [dbo].[FirstBalanceBody]
           ([id]
           ,[idItemUnite_fk]
           ,[Quantity]
           ,[Part]
            )
     VALUES
           (9
           ,4
           ,4
           ,0
           
		   )
            */
        }
        #endregion
        List<string> GetUnitItem4Item(string Item_id_fk = "-1")
        {
            List<string> data = new List<string>();
            string query = "   SELECT  idItemUnit FROM  ItemUnit WHERE    Item_id_fk = " + Item_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            /*
           SELECT  idItemUnit FROM  ItemUnit WHERE    Item_id_fk = 1
            */
        }
        public void Delet(string Item_id="-1")
        {
            string
                    query = "   DELETE FROM [dbo].[Items]  WHERE Item_id= " + Item_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            /*
            DELETE FROM [dbo].[Items]  WHERE Item_id=1
            */
        }
        public List<string> ChaeckCanDelet(string Item_id_fk = "-1")
        {
            List<string> UnitItem_id = GetUnitItem4Item(Item_id_fk);
            List<string> data = new List<string>();
            if (UnitItem_id.Count > 0)
            {
                for (int i = 0; i < UnitItem_id.Count; i++)

                {
                    string
                    query = "    SELECT  Bill_id_fk FROM SalesBillBody WHERE idItemUnit_fk = " + UnitItem_id[i];
                    query += "  union all ";
                    query += "    SELECT Return_bill_id_fk FROM  ReturnSalesBillBody WHERE idItemUnit_fk = " + UnitItem_id[i];
                   
                    con.OpenConnetion();
                    dt = new DataTable();
                    dt = con.Query(query, true);
                    con.CloseConnetion();
                    if (dt != null && dt.Rows.Count > 0)
                        for (int j = 0; j < dt.Rows.Count; j++)
                            data.Add(dt.Rows[j][0].ToString());

                }
                #region
                /*
           SELECT  Bill_id_fk FROM SalesBillBody WHERE idItemUnit_fk = 1
            union all
            SELECT Return_bill_id_fk FROM  ReturnSalesBillBody WHERE idItemUnit_fk = 1 
            */
                #endregion

            }

            return data;

        }
        public DataTable Serch(string txtSerch)
        {
            //Done
            string
            query = "   SELECT ";
            query += "  Items.Item_id, ";
            query += "  Items.Item_name,";
            query += "  Items.ItemType_id_fk, ";
            query += "  ItemTypes.ItemType_name,";
            query += "  Items.Item_Serall,";
            query += "  Items.Item_No_From_Type,";
            query += "  Items.barc ";
            query += "  FROM Items INNER JOIN";
            query += "  ItemTypes ON Items.ItemType_id_fk = ItemTypes.ItemType_id ";
            query += "  where ( Items.Item_id like '%" + txtSerch + "%' or";
            query += "  Items.Item_name like '%" + txtSerch + "%' or";
            query += "  Items.ItemType_id_fk like '%" + txtSerch + "%' or";
            query += "  Items.barc like '%" + txtSerch + "%' or";
            query += "  ItemTypes.ItemType_name like '%" + txtSerch + "%' )";
            query += "  order by Items.Item_id";
          
           
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;

        }

        public void InsertNewItem ( string Item_name, string ItemType_id_fk)
        {
        //Done
            string
            query = "INSERT INTO[dbo].[Items] ";
            query += "([Item_id]";
            query += ",[Item_name]";
            query += ",[ItemType_id_fk]";
            query += " ,[Item_Serall]";
            query += " ,[Item_No_From_Type]";
            query += " ,[State]";//,[]
            query += " ,[barc])";
            query += "VALUES";
            query += " ("+GetMaxIdItem();
            query += " ,"+AddApostropheToString(Item_name);
            query += "   ,"+ ItemType_id_fk;
            query += "   ," + GetMaxItemSerall(ItemType_id_fk);
            query += "   ," + GetMaxItemNoFromType(ItemType_id_fk);
            query += "   ,1" ;
            query += "   ,CONCAT(" + ItemType_id_fk + ",CONCAT('-', SUBSTRING( CAST( " + GetMaxItemSerall(ItemType_id_fk) + " as nvarchar), 2,3)))" ;
            query += ")";

          
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }
        public string GetMaxIdItem()
        {
            string id;

            string query = "SELECT isnull(max(Item_id),0)+1 From Items";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;

        }
       
        public string GetMaxItemNoFromType(string ItemType_id_fk)
        {
            string id;

            string query = "SELECT isnull(max(Item_No_From_Type),0)+1 From Items  where[ItemType_id_fk] ="+ItemType_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            MessageBox.Show(id);
            return id;
    
        }
        public string GetMaxItemSerall(string ItemType_id_fk)
        {
            
            string 
              query = " SELECT isnull(max(Item_Serall), (" + ItemType_id_fk + "*1000))+1";
              query+=" FROM[dbo].Items where[ItemType_id_fk] = "+ ItemType_id_fk;
              con.OpenConnetion();
              dt = new DataTable();
              dt = con.Query(query, true);
              con.CloseConnetion();
            if (dt.Rows.Count > 0&&dt!=null)
            {
                query = dt.Rows[0][0].ToString();
                MessageBox.Show(query,"قبل القص");
               if(query.Length==6)
                    query= query.Substring(2);
                MessageBox.Show(query,"بعد القص");
                return query;
            }
            return null;

        }
        /*
        ,[Item_Serall]";
            query += " ,[Item_No_From_Type]
            */
        public void UpdateItemAll
      (string Item_id, string Item_name, string ItemType_id_fk)
        {
            //Done  
            string
            query = " UPDATE[dbo].[Items]";
            query += "   SET ";
            query += "  [Item_name] =" + AddApostropheToString(Item_name);
            query += "  ,[ItemType_id_fk] =" + ItemType_id_fk;
            query += "  ,[Item_Serall] =" + GetMaxItemSerall(ItemType_id_fk);
            query += "  ,[Item_No_From_Type] =" + GetMaxItemNoFromType(ItemType_id_fk);
            query += "  , [barc] = CONCAT("+ItemType_id_fk+",CONCAT('-', SUBSTRING( CAST( "+ GetMaxItemSerall(ItemType_id_fk) + " as nvarchar), 2,3)))";
            query += "  WHERE[Item_id] =" + Item_id;

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }
        public void UpdateItem 
            (string Item_id, string Item_name)
        {
         //Done  
            string
            query = " UPDATE[dbo].[Items]";
            query += "   SET ";
            query += "  [Item_name] =" + AddApostropheToString(Item_name);         
            query += "  WHERE[Item_id] =" + Item_id;

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }
         
        public bool CanEditeIdGroup( string idItem)
        {
            /*
            وظيفة الداله تروح تفحص في جميع الفواتير والسندات اذا الصنف المحدد موجود ترجع 1
            اذا موش موجود ترجع صفر
            */


            /*
            
            SELECT   top 1      PurchBillBody.Bill_id_fk as PurchBillBody ,
            (SELECT   top 1      ReturnPurchBillBody.Return_bill_id_fk FROM  Items INNER JOIN  ReturnPurchBillBody  ON Items.Item_id = ReturnPurchBillBody.Item_id_fk WHERE (ReturnPurchBillBody.Item_id_fk = 1)) as ReturnPurchBillBody
           ,(SELECT    top 1     ReturnSalesBillBody.Return_bill_id_fk FROM  Items INNER JOIN  ReturnSalesBillBody  ON Items.Item_id = ReturnSalesBillBody.Item_id_fk WHERE (ReturnSalesBillBody.Item_id_fk = 1)) as ReturnSalesBillBody
           ,(SELECT     top 1    SalesBillBody.Bill_id_fk FROM  Items INNER JOIN  SalesBillBody  ON Items.Item_id = SalesBillBody.Item_id_fk WHERE (SalesBillBody.Item_id_fk = 1)) as SalesBillBody
           ,(SELECT    top 1     StockingBody.Stock_id_fk FROM  Items INNER JOIN  StockingBody  ON Items.Item_id = StockingBody.Item_id_fk WHERE (StockingBody.Item_id_fk = 1)) as StockingBody
           ,(SELECT    top 1     SupplyStoreBody.Supply_id_fk FROM  Items INNER JOIN  SupplyStoreBody  ON Items.Item_id = SupplyStoreBody.Item_id_fk WHERE (SupplyStoreBody.Item_id_fk = 1)) as SupplyStoreBody
           ,(SELECT    top 1     FirstBalanceBodge.Serial_number_first_balance_bodge FROM  Items INNER JOIN  FirstBalanceBodge  ON Items.Item_id = FirstBalanceBodge.Item_id_fk WHERE (FirstBalanceBodge.Item_id_fk = 1)) as FirstBalanceBodge
           ,(SELECT    top 1     ExchangeStoreBody.Exch_id_fk FROM  Items INNER JOIN  ExchangeStoreBody  ON Items.Item_id = ExchangeStoreBody.Item_id_fk WHERE (ExchangeStoreBody.Item_id_fk = 1)) as ExchangeStoreBody
          FROM            Items INNER JOIN  PurchBillBody ON Items.Item_id = PurchBillBody.Item_id_fk
                                      WHERE        (PurchBillBody.Item_id_fk = 1)
            */

            string
            query = " SELECT   top 1      PurchBillBody.Bill_id_fk as PurchBillBody , ";

            query += "  (SELECT   top 1      ReturnPurchBillBody.Return_bill_id_fk FROM  Items INNER JOIN ";
            query += "  ReturnPurchBillBody  ON Items.Item_id = ReturnPurchBillBody.Item_id_fk ";
            query += "   WHERE (ReturnPurchBillBody.Item_id_fk = "+ idItem + ")) as ReturnPurchBillBody ";

            query += "  ,(SELECT    top 1     ReturnSalesBillBody.Return_bill_id_fk FROM  Items INNER JOIN ";
            query += "  ReturnSalesBillBody  ON Items.Item_id = ReturnSalesBillBody.Item_id_fk ";
            query += "  WHERE (ReturnSalesBillBody.Item_id_fk = " + idItem + ")) as ReturnSalesBillBody ";

            query += "   ,(SELECT     top 1    SalesBillBody.Bill_id_fk FROM  Items INNER JOIN ";
            query += "    SalesBillBody  ON Items.Item_id = SalesBillBody.Item_id_fk ";
            query += "   WHERE (SalesBillBody.Item_id_fk = " + idItem + ")) as SalesBillBody ";

            query += "  ,(SELECT    top 1     StockingBody.Stock_id_fk FROM  Items INNER JOIN ";
            query += "    StockingBody  ON Items.Item_id = StockingBody.Item_id_fk WHERE ";
            query += "    (StockingBody.Item_id_fk = " + idItem + ")) as StockingBody ";

            query += "  ,(SELECT    top 1     SupplyStoreBody.Supply_id_fk FROM  Items INNER JOIN ";
            query += "  SupplyStoreBody  ON Items.Item_id = SupplyStoreBody.Item_id_fk WHERE ";
            query += "  (SupplyStoreBody.Item_id_fk = " + idItem + ")) as SupplyStoreBody ";

            query += " ,(SELECT    top 1     FirstBalanceBodge.Serial_number_first_balance_bodge FROM  Items INNER JOIN ";
            query += "  FirstBalanceBodge  ON Items.Item_id = FirstBalanceBodge.Item_id_fk WHERE ";
            query += "   (FirstBalanceBodge.Item_id_fk = " + idItem + ")) as FirstBalanceBodge ";

            query += " ,(SELECT    top 1     ExchangeStoreBody.Exch_id_fk FROM  Items INNER JOIN ";
            query += "  ExchangeStoreBody  ON Items.Item_id = ExchangeStoreBody.Item_id_fk WHERE ";
            query += "  (ExchangeStoreBody.Item_id_fk = " + idItem + ")) as ExchangeStoreBody ";

            query += "  FROM            Items INNER JOIN ";
            query += "  PurchBillBody ON Items.Item_id = PurchBillBody.Item_id_fk ";

            query += "  WHERE        (PurchBillBody.Item_id_fk = " + idItem + ")";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
        }


        ///////////////////نهاية دوال الاصناف////////////////////////
        #endregion

        #region FunCtions Items_Unit Table دوال جدول واحدات الاصناف
       
        public DataTable GetAllUnit()
        {
            //عرض جميع الوحدات من جدول الوحدات

            string
            query = "SELECT [Unit_id]";
            query += " ,[Unit_name] ";
            query += " ,[Unit_refill] ";
            query += " ,[Unit_part] ";
            query += " FROM[dbo].[Units]";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;

            
        }

        #region استعلام عرض وحدات الصنف
        /*

         SELECT ItemUnit.idItemUnit, ItemUnit.Unit_id_fk ,Units.Unit_name, 
            ItemUnit.Selling_price, ItemUnit.Prime_cost, 
            ItemUnit.Minimum, ItemUnit.Maxmum
           FROM  ItemUnit INNER JOIN
           Units ON ItemUnit.Unit_id_fk = Units.Unit_id
           WHERE        (ItemUnit.Item_id_fk = 2)
           */
        #endregion
        #region فيه مشكله يعرض رقم الصنف واحد بس استعلام عرض وحدات الاصناف مع الكميات
        /*
         SELECT
ItemUnetStoreQuantity.ItemUnit_id_fk as ItemUnit_id , ItemUnit.Unit_id_fk as Unit_id , 
Units.Unit_name ,Items.Item_name, ItemUnit.Prime_cost ,ItemUnit.Selling_price,
sum(ItemUnetStoreQuantity.QuantityUnitNow ) as QuantityUnitNow ,
sum(ItemUnetStoreQuantity.QuantityPartNow ) as QuantityPartNow ,ItemUnit.Minimum,ItemUnit.Maxmum
               FROM  Items INNER JOIN
                        ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk 
                        INNER JOIN
                        ItemUnetStoreQuantity ON ItemUnit.idItemUnit = ItemUnetStoreQuantity.ItemUnit_id_fk 
                        INNER JOIN
                        Units ON Units.Unit_id = ItemUnit.Unit_id_fk

               WHERE        (Items.Item_id = 2)
                group by ItemUnetStoreQuantity.ItemUnit_id_fk,
                ItemUnit.Prime_cost,ItemUnit.Selling_price,
                Items.Item_name,Units.Unit_name,
                ItemUnit.Unit_id_fk,ItemUnit.Maxmum,ItemUnit.Minimum

        */
        #endregion
        public DataTable GetUintsItem(string idItem)
        {


            //idItemUnit , Unit_id_fk , Unit_name , Selling_price , Prime_cost , Minimum , Maxmum
            string
            query = "  SELECT ItemUnit.idItemUnit, ItemUnit.Unit_id_fk ,Units.Unit_name,";
            query += " ItemUnit.Selling_price, ItemUnit.Prime_cost, ";
            query += " ItemUnit.Minimum, ItemUnit.Maxmum ,ItemUnit.State";
            query += " FROM  ItemUnit INNER JOIN ";
            query += " Units ON ItemUnit.Unit_id_fk = Units.Unit_id ";
            query += " WHERE   (ItemUnit.Item_id_fk = "+ idItem + ")";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;

        }
        public void UpdateUintsItem
            (string idItemUnit , string Selling_price , string Minimum, string Maxmum,string State)
        {
           // MessageBox.Show("idItemUnit : " + idItemUnit + "|| Selling_price: " +Selling_price, "From method UpdateUintsItem ");
            //idItemUnit , Unit_id_fk , Unit_name , Selling_price , Prime_cost , Minimum , Maxmum
            string
            query = " UPDATE[dbo].[ItemUnit] ";
            query += "  SET ";
            query += "   [Selling_price] = " + Selling_price;
            query += "    ,[Minimum] = " + Minimum;
            query += " ,[Maxmum] = " + Maxmum;
            query += " ,[State] = " + State;
            
        query += " WHERE [idItemUnit] = " + idItemUnit;

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

           
        }
        public string GetMaxUintsItem()
        {

            string id;

            string query = "SELECT isnull(max(idItemUnit),0)+1 From ItemUnit";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;

        }

        public void InsertUnitToItem(string Unite_id , string Item_id)
        {
            
            string
            query = "  INSERT INTO[dbo].[ItemUnit] ";
        query += "  ([idItemUnit] ";
            query += " ,[Item_id_fk] ";
            query += "   ,[Unit_id_fk] ";
            query += "   ,[Selling_price] ";
            query += "  ,[Prime_cost] ";
            query += " ,[Minimum] ";
            query += "   ,[Maxmum] ";
            query += "   ,[State]) ";
            query += " VALUES";
            query += "  ("+ GetMaxUintsItem();
            query += "  ,"+ Item_id;
            query += "   ,"+ Unite_id;
            query += "  , 0"; // Selling_price
            query += " , 0"; // Prime_cost
            query += " , NULL"; //Minimum
            query += " , NULL"; // Maxmum
            query += " ,1  )";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

        }

        ///////////////////نهاية دوال وحدات الاصناف////////////////////////
        #endregion

        #region دوال الكميات
       

        /*
              INSERT INTO [dbo].[ItemUnetStoreQuantity]
                         ([ItemUnit_id_fk]
                         ,[Store_id_fk]
                         ,[QuantityUnitNow]
                         ,[QuantityPartNow])
                   VALUES
                         (2
                         ,2
                         ,0
                         ,0
                         )
              */

        /*


        UPDATE [dbo].[ItemUnetStoreQuantity]
      SET  

  [QuantityUnitNow] = 3
  ,[QuantityPartNow] = 1
    WHERE [ItemUnit_id_fk] =1 and [Store_id_fk] =1

        */
        public void UpdateItemUnitStoreQuantity(string ItemUnit_id_fk,string Store_id_fk, string QuantityUnitNow, string QuantityPartNow)
        {
            string query = null;

            /*
            يحتاج تعديل للداله يتحقق اولا هل العمليه بتكون 
            زيادة او نقص للصنف عشان يعرف يستخدم الداله المناسبة لتغيير الكميات
            اي نجعل الداله تستقبل بارمتر اضافي يبين
            نوع العمليه الرياضية الي بتتم على الكميات
            */

          if ( CheckItemUnitIdAndStoreFound(ItemUnit_id_fk, Store_id_fk))
            {
                //اذا موجود اعمل تعديل

                query = "   UPDATE[dbo].[ItemUnetStoreQuantity] ";
                query += "  SET ";
                query += "  [QuantityUnitNow] ="+ QuantityUnitNow;
                query += " ,[QuantityPartNow] ="+ QuantityPartNow;
                query += " WHERE ";
                query += " [ItemUnit_id_fk] ="+ ItemUnit_id_fk;
                query += " and ";
                query += " [Store_id_fk] ="+ Store_id_fk;
             
            }
          else
            {
                query = "  INSERT INTO [dbo].[ItemUnetStoreQuantity] ";
                query += " ([ItemUnit_id_fk] ";
                query += " ,[Store_id_fk] ";
                query += "  ,[QuantityUnitNow] ";
                query += " ,[QuantityPartNow]) ";

                query += "   VALUES ";
                query += "("+ ItemUnit_id_fk;
                query += ","+ Store_id_fk;
                query += ","+ QuantityUnitNow;
                query += ","+ QuantityPartNow;
                query += ")";
            }


            con.OpenConnetion();
           con.Query(query, false);
            con.CloseConnetion();

      

        }

        /*

          SELECT [QuantityPartNow]
          FROM [dbo].[ItemUnetStoreQuantity] where
          [ItemUnit_id_fk]=6 
          and 
          [Store_id_fk]=1

          */
        bool CheckItemUnitIdAndStoreFound(string ItemUnit_id_fk, string Store_id_fk)
        {
            //داله تفحص اذا كان رقم وحدات الاصناف ورقم المخزن موجودين في جدول كميات الاصناف يرجع 1
            // اذا موش موجود يرجع صفر
            // عشان اعرف هل استخدم اضافة ولا تعديل
            string
           query = "    SELECT [QuantityPartNow] ";
            query += "  FROM [dbo].[ItemUnetStoreQuantity] where ";
            query += "  [ItemUnit_id_fk]="+ ItemUnit_id_fk;
            query += "  and  ";
            query += "  [Store_id_fk]="+ Store_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt.Rows.Count > 0)
                return true;
            else
                return false;
    
        }
        #region استعلام تفصلي للصنف كم الكمية من كل وحدة في كل مخزن

        /*
       SELECT        Items.Item_name, Stores.Store_name, Units.Unit_name, ItemUnetStoreQuantity.QuantityPartNow, ItemUnetStoreQuantity.QuantityUnitNow
                                FROM            ItemUnetStoreQuantity INNER JOIN
                    Stores ON ItemUnetStoreQuantity.Store_id_fk = Stores.Store_id INNER JOIN
                    ItemUnit ON ItemUnetStoreQuantity.ItemUnit_id_fk = ItemUnit.idItemUnit  INNER JOIN
                    Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                    Items ON ItemUnit.Item_id_fk = Items.Item_id

       where  Items.Item_id=1

       */

        #endregion

        public DataTable GetItemQuntityFromAllStors(string Item_id)
        {

            //داله تستعلم عن كميات الاصناف تحليلي حسب رقم كل مخزن


            string
            query = "   SELECT Items.Item_name, Stores.Store_name, Units.Unit_name, ";
            query += "  ItemUnetStoreQuantity.QuantityPartNow, ItemUnetStoreQuantity.QuantityUnitNow";
            query += "  FROM            ItemUnetStoreQuantity INNER JOIN ";
            query += "  Stores ON ItemUnetStoreQuantity.Store_id_fk = Stores.Store_id INNER JOIN ";
            query += " ItemUnit ON ItemUnetStoreQuantity.ItemUnit_id_fk = ItemUnit.idItemUnit  INNER JOIN ";
            query += "   Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN";
            query += " Items ON ItemUnit.Item_id_fk = Items.Item_id ";
            query += "  where  Items.Item_id= "+ Item_id;

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;


        }
        #region داله ترجع اجمالي الكمية للصنف لوحدة محددة
       
        public string[] GetSumQuntityItemUnitNow(string ItemUnit_id)
        {
            #region استعلامات كميات المخازن
            /*

               SELECT     sum(   ItemUnetStoreQuantity.QuantityUnitNow )
                   FROM            Items INNER JOIN
                            ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN
                            ItemUnetStoreQuantity ON ItemUnit.idItemUnit = ItemUnetStoreQuantity.ItemUnit_id_fk
                   WHERE         (ItemUnetStoreQuantity.ItemUnit_id_fk=2)

               */

            /*

           SELECT     sum(   ItemUnetStoreQuantity.QuantityPartNow )
               FROM            Items INNER JOIN
                        ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN
                        ItemUnetStoreQuantity ON ItemUnit.idItemUnit = ItemUnetStoreQuantity.ItemUnit_id_fk
                   WHERE       (ItemUnetStoreQuantity.ItemUnit_id_fk=2)

           */
            #endregion

            //داله تستعلم عن اجمالي الكميات للصنف المحدد
            string[] QuantityUnitNow =new string[2];
            string
          query = "  SELECT     sum(   ItemUnetStoreQuantity.QuantityUnitNow )";
            query += " FROM            Items INNER JOIN ";
            query += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN ";
            query += "  ItemUnetStoreQuantity ON ItemUnit.idItemUnit = ItemUnetStoreQuantity.ItemUnit_id_fk ";
            query += "  WHERE        (ItemUnetStoreQuantity.ItemUnit_id_fk = " + ItemUnit_id + ") ";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            if (dt.Rows[0][0].ToString() == "NULL" || dt.Rows[0][0].ToString() == "")
            {
                QuantityUnitNow[0] = "0";
               // MessageBox.Show(dt.Rows[0][0].ToString(), "QuantityUnitNow = NULL " + " ItemUnit_id= " + ItemUnit_id);
            }

            else
            {
                QuantityUnitNow[0] = dt.Rows[0][0].ToString();
               // MessageBox.Show(dt.Rows[0][0].ToString(), "QuantityUnitNow " + " ItemUnit_id= " + ItemUnit_id);
            }
                

            dt.Clear();
            dt.Rows.Clear();

            query = "  SELECT     sum(   ItemUnetStoreQuantity.QuantityPartNow )";
            query += " FROM            Items INNER JOIN ";
            query += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN ";
            query += "  ItemUnetStoreQuantity ON ItemUnit.idItemUnit = ItemUnetStoreQuantity.ItemUnit_id_fk ";
            query += "  WHERE        (ItemUnetStoreQuantity.ItemUnit_id_fk = " + ItemUnit_id + ") ";

            dt = con.Query(query, true);
            if (dt.Rows[0][0].ToString() == "NULL"|| dt.Rows[0][0].ToString() == "")
            {
                QuantityUnitNow[1] = "0";
              //  MessageBox.Show(dt.Rows[0][0].ToString(), "QuantityPartNow = NULL"+ " ItemUnit_id= "+ ItemUnit_id);
            }
               
            else
                QuantityUnitNow[1] = dt.Rows[0][0].ToString();
          //  MessageBox.Show(dt.Rows[0][0].ToString(), "QuantityPartNow" + " ItemUnit_id= " + ItemUnit_id);
            //  MessageBox.Show("QuantityPartNow= " + QuantityUnitNow[0] + " || QuantityUnitNow= "+ QuantityUnitNow[1]);

            return QuantityUnitNow;

        }
        #endregion

        ////////////////////////////نهاية دوال الكميات///////////////////////////
        #endregion

        #region دوال الفواتير
        /*
        SELECT        Items.barc, Items.Item_name, Units.Unit_name, ItemUnit.Selling_price,(ItemUnit.Selling_price/Units.Unit_part) as Seling_part ,Units.Unit_refill, Units.Unit_part
FROM            ItemUnit INNER JOIN
                         Units ON ItemUnit.Unit_id_fk = Units.Unit_id INNER JOIN
                         ItemUnetStoreQuantity ON ItemUnit.idItemUnit = ItemUnetStoreQuantity.ItemUnit_id_fk INNER JOIN
                         Items ON ItemUnit.Item_id_fk = Items.Item_id INNER JOIN
                         ItemTypes ON Items.ItemType_id_fk = ItemTypes.ItemType_id order by  Items.barc
        
        */
        #endregion
    }
    //dlk  kl
}
