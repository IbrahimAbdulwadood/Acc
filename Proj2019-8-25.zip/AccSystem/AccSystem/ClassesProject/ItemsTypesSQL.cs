﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace AccSystem.ClassesProject
{
    class ItemsTypesSQL
    {
        DataTable dt;
        ConnectionDB con = new ConnectionDB();

      public  string AddApostropheToString(string txt)
        {
            //اضافة نص احادي للكلمات
            if (txt != "NULL")
            {
                txt = "'" + txt + "'";
            }

            return txt;
        }
        #region الحذف
        public List<string> ChaeckCanDelet(string Item_id_fk = "-1")
        {
            List<string> UnitItem_id = GetItem4TypeItem(Item_id_fk);
            return UnitItem_id;

        }
        List<string> GetItem4TypeItem(string ItemType_id_fk = "-1")
        {
            List<string> data = new List<string>();
            string query = " SELECT Item_id FROM Items WHERE ItemType_id_fk = " + ItemType_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            /*
          SELECT Item_id FROM Items WHERE ItemType_id_fk = 1
            */
        }
        public void Delet(string ItemType_id = "-1")
        {
            string
                    query = "   DELETE FROM [dbo].[ItemTypes]  WHERE ItemType_id= " + ItemType_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            /*
         DELETE FROM [dbo].[ItemTypes] WHERE ItemType_id=1
            */
        }
        #endregion
        public string GetMaxIdItemType(string GroupStore_id)
        {
            string
                q = "SELECT  isnull(max([ItemType_id]),("+ GroupStore_id + "*100))+1";
                q+="  FROM[dbo].[ItemTypes] where[Group_id_fk] ="+ GroupStore_id;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            q = dt.Rows[0][0].ToString();
            dt = null;
           // MessageBox.Show(q, "GetMaxIdItemType");
            return q;

        }
     public   void UpdateItemType(string ItemTypes_name,string ItemType_id)
        {
            string q = " UPDATE [dbo].[ItemTypes]";
            q += " SET ";
            q += "   [ItemType_name] ="+AddApostropheToString(ItemTypes_name);
            q += "WHERE [ItemType_id] ="+ ItemType_id;
            con.OpenConnetion();
            con.Query(q, false);
            con.CloseConnetion();

        }
   public     void InsertNewItemType(string GroupStore_id,string ItemType_name)
        {
            string q = "INSERT INTO [dbo].[ItemTypes]";
            q += "   ([ItemType_id]";
            q += "   ,[ItemType_name]";
            q += "   ,[Group_id_fk])";
            q += "  VALUES";
            q += "    ("+ GetMaxIdItemType(GroupStore_id);
            q += "   ,"+ AddApostropheToString(ItemType_name);
            q += "   , "+ GroupStore_id + ")";

            con.OpenConnetion();
           con.Query(q,false);
            con.CloseConnetion();

        }
        #region الاستعلام عن جميع الفئات
    public DataTable Serch(string txtSerch)
        {
            string
            query = "SELECT     ";
            query += "    ItemTypes.ItemType_id, ItemTypes.ItemType_name, ";
            query += "  ItemTypes.Group_id_fk, GroupStored.Group_name ";
            query += "  FROM ItemTypes INNER JOIN ";
            query += "  GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id";
            query += " where ";
            query += "    ItemTypes.ItemType_id like '%" + txtSerch + "%' ";
            query += " or ItemTypes.ItemType_name like '%" + txtSerch + "%'";
            query += " or ItemTypes.Group_id_fk like '%" + txtSerch + "%'";
            query += " or GroupStored.Group_name like '%" + txtSerch + "%'";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;

        }   
    public    DataTable GetAllItemType()
        {
            string 
            query = "SELECT     ";
            query += "    ItemTypes.ItemType_id, ItemTypes.ItemType_name, ";
            query += "  ItemTypes.Group_id_fk, GroupStored.Group_name ";
            query += "  FROM ItemTypes INNER JOIN ";
            query += "  GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;

        }
        #endregion
        #region الاستعلام عن جميع فئات مجموعة مخزنية محددة

     public   DataTable GetAllItemTypeFromGroup(string Group_id_fk)
        {
            
            string
            query = "SELECT    ";
            query += "  ItemTypes.ItemType_id, ItemTypes.ItemType_name,";
            query += "    ItemTypes.Group_id_fk, GroupStored.Group_name";
            query += " FROM ItemTypes INNER JOIN";
            query += "    GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id";
            query += "  where ItemTypes.Group_id_fk = "+ Group_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;

        }
        #endregion
    }
}
