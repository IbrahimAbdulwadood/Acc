﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AccSystem.ClassesProject
{
    
    class OpreationType
    {
        ConnectionDB con = new ConnectionDB();
        DataTable dt;
        public string[] Getopreationtype()
        { 
            string query = "SELECT [Bill_type] FROM [dbo].[SalesBillHead]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            string[] op = new string[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                op[i] = dt.Rows[i][0].ToString();
            }

            return op;

        }

        public DataTable GetAllopreationtype()
        {
            string query = "SELECT [Opera_type_id], [Opera_type_name] FROM [dbo].[OperaType] ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }
    }
}
