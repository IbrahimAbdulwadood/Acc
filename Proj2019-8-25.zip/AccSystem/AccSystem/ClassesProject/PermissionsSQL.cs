﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AccSystem.ClassesProject
{
    class PermissionsSQL
    {
        /// <summary>
        /// كلاس الصلاحيات
        /// </summary>

        ConnectionDB con = new ConnectionDB();
        DataTable dt;

        public void UpdatePermissions(
          string User_id_fk, string Screen_id_fk, string Showed
         , string Inserted, string Updated, string Deleted
         , string Printed, string Saerch, string Posting
          , string EditeDate
          )
        {

            string
            query = "  UPDATE [dbo].[Permissions] ";
            query += "     SET    ";
            query += "  [Showed]=" + Showed;
            query += " ,[Inserted]= " + Inserted;
            query += " ,[Updated]= " + Updated;
            query += " ,[Deleted]= " + Deleted;
            query += " ,[Printed]= " + Printed;
            query += " ,[Saerch]= " + Saerch;
            query += " ,[Posting]= " + Posting;
            query += " ,[EditeDate]=  " + EditeDate;
            query += " WHERE   ";
            query += "  [User_id_fk] =  " + User_id_fk;
            query += " and   ";
            query += "  [Screen_id_fk] =  " + Screen_id_fk;

       //     System.Windows.Forms.MessageBox.Show(query);

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
            UPDATE [dbo].[Permissions]
   SET 
       [Showed] = 1
      ,[Inserted] = 1
      ,[Updated] = 1
      ,[Deleted] = 1
      ,[Printed] = 1
      ,[Saerch] = 1
      ,[Posting] =1
      ,[EditeDate] = 1
 WHERE [User_id_fk] = 1 and [Screen_id_fk] = 1
            
            */
            #endregion

        }
        public void InsertScreen2User(string User_id_fk, string Screen_id_fk)
        {

            string
            query = "     INSERT INTO [dbo].[Permissions]   ";
            query += "     ([User_id_fk]   ";
            query += "     ,[Screen_id_fk]   ";
            query += "     ,[Showed]   ";
            query += "     ,[Inserted]  ";
            query += "     ,[Updated]   ";
            query += "     ,[Deleted]  ";
            query += "     ,[Printed]   ";
            query += "     ,[Saerch]   ";
            query += "     ,[Posting]  ";
            query += "     ,[EditeDate])  ";
            query += "      VALUES   ";
            query += "   (   " + User_id_fk;
            query += "   ,  " + Screen_id_fk;
            query += "  ,0,0,0,0,0,0,0,0)";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();


            #region
            /*
            INSERT INTO [dbo].[Permissions]
           ([User_id_fk]
           ,[Screen_id_fk]
           ,[Showed]
           ,[Inserted]
           ,[Updated]
           ,[Deleted]
           ,[Printed]
           ,[Saerch]
           ,[Posting]
           ,[EditeDate])
     VALUES
           (1
           ,7
           ,1
           ,1
           ,1
           ,1
           ,1
           ,1
           ,1
           ,1
		   )
            
            */
            #endregion

        }

        public string GetNameScreen(string Screen_id)
        {

            string
         query = " SELECT    ";
            query += "  Description ";
            query += " FROM";
            query += " Screens ";
            query += " WHERE        (Screen_id = "+ Screen_id + ") ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString();
            else return "";

            /*
            
            SELECT        Description
FROM            Screens
WHERE        (Screen_id = 1)
            */

        }

        public DataTable GetAllScreenSerch(string TxT)
        {
            string
           query = " SELECT    ";
            query += "  Screen_id, ";
            query += " Screen_Name, ";
            query += " Description ";
            query += " FROM ";
            query += " Screens ";
            query += " where Screen_id like '%"+ TxT+ "%'";
            query += " or Screen_Name like '%" + TxT + "%'";
            query += " or Description like '%" + TxT + "%'";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

            /*
           SELECT        Screen_id, Screen_Name, Description
FROM            Screens
            where Screen_id like '%%' or Screen_Name like '%%' or Description like '%%'
            */

            
        }

        public DataTable GetAllScreen()
        {
            string
            query = " SELECT    ";
            query += " Screen_id ";
            query += ", Screen_Name  ";
            query += ", Description ";
            query += " FROM ";
            query += " Screens  ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region الاستعلام
            /*
            
            SELECT        Screen_id, Screen_Name, Description
FROM            Screens
            */
            #endregion

        }
        public DataTable GetAllPermissionsAllScreen(string idUser ,string MainOrUserScreen)
        {

          
            /*

             هذا بستخدمه في شاشة المستخدمين وصلاحياتهم
             وعند تسجيل الدخول ياخذ الشاشات المتاحة للمستخدم

           */

            string
             query = " SELECT    ";
            query += " Permissions.Screen_id_fk, "; 
            query += " Screens.Screen_Name,  ";
            query += " Permissions.Showed, ";
            query += " Permissions.Inserted, ";
            query += " Permissions.EditeDate, ";
            query += " Permissions.Posting, ";
            query += " Permissions.Saerch, ";
            query += " Permissions.Printed,  ";
            query += " Permissions.Updated, ";
            query += " Permissions.Deleted,  ";
            query += " Screens.Description   ";//
            query += "  FROM   ";
            query += " Permissions INNER JOIN ";
            query += " Screens ON Permissions.Screen_id_fk = Screens.Screen_id  ";
            query += " where Permissions.User_id_fk = ";
            query += idUser;
            if (MainOrUserScreen == "Main")
               query += " and Permissions.Showed=1 ";
            
           
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region الاستعلام
            /*
             SELECT    
     Permissions.Screen_id_fk
     ,Screens.Description
     ,Permissions.Showed
     , Permissions.Inserted
     ,Permissions.EditeDate
     , Permissions.Posting
     ,Permissions.Saerch
     , Permissions.Printed
     ,Permissions.Updated
     , Permissions.Deleted
     ,Screens.Screen_Name 
      FROM            Permissions INNER JOIN Screens ON Permissions.Screen_id_fk = Screens.Screen_id where Permissions.User_id_fk =1
            */
            #endregion

        }
        public DataTable GetAllPermissionsFromOneScreen(string idUser, string idScreen)
        {
            /*
            بستخدمها قبل دخول اي شاشة
            
            */
            string
              query = " SELECT    ";
            query += " Permissions.Screen_id_fk, ";
            query += " Screens.Screen_Name,  ";
            query += " Permissions.Showed, ";
            query += " Permissions.Inserted, ";
            query += " Permissions.EditeDate, ";
            query += " Permissions.Posting, ";
            query += " Permissions.Saerch, ";
            query += " Permissions.Printed,  ";
            query += " Permissions.Updated, ";
            query += " Permissions.Deleted  ";
            query += "  FROM   ";
            query += " Permissions INNER JOIN ";
            query += " Screens ON Permissions.Screen_id_fk = Screens.Screen_id  ";
            query += " where Permissions.User_id_fk = ";
            query += idUser;
            query += " and Permissions.Screen_id_fk = ";
            query += idScreen;

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }

        public DataTable GetAllOpra()
        {
            string
            query = "   SELECT    ";
            query += "  Oper_id, ";
            query += "  Oper_name,   ";
            query += "  Stored_move,   ";
            query += "  Source_entry ";
            query += "  FROM ";
            query += "  Operations ";


            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

            #region
            /*
            SELECT 
   Oper_id,
 Oper_name, 
 Stored_move,
  Source_entry
FROM      
     Operations
            */
            #endregion

        }

    }
}
