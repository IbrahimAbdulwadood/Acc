﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;

namespace AccSystem.ClassesProject
{
    class PostingSQL
    {
        //كلاس اليومية العامو او الترحيلات
        /*
      
      اولا رقم العمليه وايش اسمها
        0	قيد افتتاحي	
        1	قيد يدوي	
        2	سند قبض	
        3	سند صرف	
        4	فاتورة مشتريات	
        5	فاتورة مردود مشتريات	
        6	فاتورة مبيعات	
        7	فاتورة مردود مبيعات	
        8	صرف مخزني	
        9	توريد مخزني	
        10	جرد	
        11	رصيد مخزون اول المدة

        */


        /*
        SELECT       
         DaylyHaed.Dayly_id,
          Operations.Oper_name,
          Iif(DaylyHaed.Oper_id_fk=1,(SELECT [Entry_sum] FROM [dbo].[EntriesHead] where [Entry_id]= DaylyHaed.Refer_id_fk),

          Iif(DaylyHaed.Oper_id_fk=2,(SELECT   [Debt_local] FROM [dbo].[SupportCatchHead] where [Support_id]=DaylyHaed.Refer_id_fk),1)

          ),
           DaylyHaed.Dayly_sum,

         DaylyHaed.Refer_id_fk,


           DaylyHaed.Date_dayly
        FROM            DaylyHaed INNER JOIN
                                 Operations ON DaylyHaed.Oper_id_fk = Operations.Oper_id 
        */
        #region المتغيرات
        DataTable dt;
        ConnectionDB con = new ConnectionDB();

        #endregion
        #region الدوال
        #region الدوال المساعدة

        string AddApostropheToString(string txt)
        {
            //اضافة نص احادي للكلمات
            if (txt != "NULL")
            {
                txt = "'" + txt + "'";
            }

            return txt;
        }


        #endregion

        #region الدوال الاساسية

        public DataTable SerchEntreiesHaed(string txt)
        {
            //عاده موش جاهز
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string
            query = "    SELECT ";
            query += "   EntriesHead.Entry_id ";
            query += "  ,EntriesHead.Date_entry ";
            query += "  ,EntriesHead.Entry_sum ";
            query += "  ,EntriesHead.Refr_id ";
            query += "  ,EntriesHead.User_id_fk ";
            query += "  ,Users.User_name ";
            query += "  ,EntriesHead.Note ";
            query += "   FROM EntriesHead INNER JOIN ";
            query += "   Users ON EntriesHead.User_id_fk = Users.User_id ";
            query += "   where ";
            query += "   EntriesHead.Entry_id like '%" + txt + "%' or ";
            query += "   EntriesHead.Entry_sum like '%" + txt + "%' or  ";
            query += "   EntriesHead.Refr_id like '%" + txt + "%'  or  ";
            query += "   EntriesHead.Note like '%" + txt + "%' ";

            #region
            /*
            SELECT
     EntriesHead.Entry_id, 
     EntriesHead.Date_entry, 
	 EntriesHead.Entry_sum, 
	 EntriesHead.Refr_id,
	  EntriesHead.User_id_fk, 
	  EntriesHead.Note,
	   Users.User_name
FROM     
EntriesHead INNER JOIN
                         Users ON EntriesHead.User_id_fk = Users.User_id
                          where
						  EntriesHead.Entry_id like '%%' or
						    EntriesHead.Entry_sum like '%%' or 
							 EntriesHead.Refr_id like '%%'  or 
							   EntriesHead.Note like '%%'
            
            */
            #endregion

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
        }
        public DataTable GetAllEntries()
        { //عاده موش جاهز
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string
            query = "     SELECT ";
            query += "    EntriesHead.Entry_id ";
            query += "  , EntriesHead.Date_entry ";
            query += "  , EntriesHead.Entry_sum ";
            query += "  , EntriesHead.Refr_id ";
            query += "  , EntriesHead.User_id_fk ";
            query += "  , Users.User_name ";
            query += "  , EntriesHead.Note ";
            query += "   FROM EntriesHead INNER JOIN ";
            query += "   Users ON EntriesHead.User_id_fk = Users.User_id ";


            #region
            /*
            SELECT
     EntriesHead.Entry_id, 
     EntriesHead.Date_entry, 
	 EntriesHead.Entry_sum, 
	 EntriesHead.Refr_id,
	  EntriesHead.User_id_fk, 
	  EntriesHead.Note,
	   Users.User_name
FROM     
EntriesHead INNER JOIN
                         Users ON EntriesHead.User_id_fk = Users.User_id
                          where
						  EntriesHead.Entry_id like '%%' or
						    EntriesHead.Entry_sum like '%%' or 
							 EntriesHead.Refr_id like '%%'  or 
							   EntriesHead.Note like '%%'
            
            */
            #endregion

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
        }

        public DataTable GetAllEntriesBody(string Entry_id_fk)
        {
            //عاده موش جاهز
            if (dt != null)
                dt = null;
            dt = new DataTable();

          
            string
            query = "   SELECT ";
            query += "  EntriesBody.EntriesBody_id , ";
            query += " AccCurrency.Acc_id_fk , ";
            query += "  Accounts.Acc_name , ";
            query += "  Currencys.Curr_name , ";
            query += " EntriesBody.CurrExching , ";
            query += " EntriesBody.Debt_local , ";
            query += " EntriesBody.Credit_local , ";
            query += "  EntriesBody.Debt_foreign , ";
            query += " EntriesBody.Credit_foreign , ";
            query += " EntriesBody.Note , ";
            query += " EntriesBody.Date_entry_body , ";
            query += "   AccCurrency.AccCurr_id ";

            query += "  FROM    AccCurrency INNER JOIN ";
            query += " Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "   EntriesBody ON AccCurrency.AccCurr_id = EntriesBody.AccCurr_id_fk ";

            query += "  WHERE  (EntriesBody.Entry_id_fk  =" + Entry_id_fk + ")";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
            #region الاستعلام
            /*
            SELECT        EntriesBody.EntriesBody_id, AccCurrency.Acc_id_fk, Accounts.Acc_name, 
            Currencys.Curr_name, EntriesBody.CurrExching, EntriesBody.Debt_local, EntriesBody.Credit_local, 
            EntriesBody.Debt_foreign, EntriesBody.Credit_foreign, EntriesBody.Note, EntriesBody.Date_entry_body,
            AccCurrency.AccCurr_id
            FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                         EntriesBody ON AccCurrency.AccCurr_id = EntriesBody.AccCurr_id_fk
            WHERE        (EntriesBody.Entry_id_fk = 1)
            */
            #endregion
        }

        public string InsertNewPostingHaed
            (string Oper_id_fk, string Dayly_sum, string Date_dayly,
            string Note, string Refer_id_fk,string User_id_fk
            )
        {
            //^^

            #region
            /*
            
           INSERT INTO [dbo].[DaylyHaed]
           ([Dayly_id]
           ,[Oper_id_fk]
           ,[Dayly_sum]
           ,[Date_dayly]
           ,[Note]
           ,[Refer_id_fk])
     VALUES
           (3
           , 1
           , 2000
           , '2019-08-8'
           ,'Note'
           ,1
		   )
            */
            #endregion
            string Dayly_id = GetMaxIdPostingHaed();
            string
            query = " INSERT INTO [dbo].[DaylyHaed] ";
            query += "  ( [Dayly_id] ";
            query += "  ,[Oper_id_fk]  ";
            query += "  ,[Dayly_sum] ";
            query += "  ,[Date_dayly] ";
            query += "  ,[Note]  ";
            query += "  ,[User_id_fk] ";
            query += "  ,[Refer_id_fk]) ";
            query += "  VALUES (  ";
            query += Dayly_id;
            query += "  ," + Oper_id_fk;
            query += "  ," + Dayly_sum;
            query += "  , " + AddApostropheToString(Date_dayly);
            query += " ," + AddApostropheToString(Note);
            query += " ," + User_id_fk;
            query += " ," + Refer_id_fk;
            query += "  ) ";
         //   System.Windows.Forms.MessageBox.Show(query);
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            // System.Windows.Forms.MessageBox.Show(idEntry, "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(AddApostropheToString(Date_entry), "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(Entry_sum, "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(Refr_id, "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(AddApostropheToString(Note), "InsertNewEntriesHaed");
            //System.Windows.Forms.MessageBox.Show(User_id_fk, "InsertNewEntriesHaed");

            return Dayly_id;
        }
        public void InsertNewPostingBody
           (
            string Dayly_id_fk, string AccCurr_id_fk,
            string Debt_local, string Credit_local, 
            string Debt_foreign, string Credit_foreign
            , string Note, string Date_dayly_body, 
                 string CurrExching
           )
        {
            //^^
            #region الاستعلام
            /*
           INSERT INTO [dbo].[DaylyBody]
           ([Dayly_id_fk]
           ,[DaylyBody_id]
           ,[AccCurr_id_fk]
		   ,[CurrExching]
           ,[Debt_local]
           ,[Credit_local]
           ,[Debt_foreign]
           ,[Credit_foreign]
           ,[Date_dayly_body]
           ,[Note])
     VALUES
           (1
           ,2
           ,4
		   ,12
           ,0
           ,0
           ,0
           ,0
           ,'2019-9-9'
           ,'Note'
		   )
            */
            #endregion
            string
            query = "    INSERT INTO [dbo].[DaylyBody]  ";
            query += "   ([Dayly_id_fk]  ";
            query += "   ,[DaylyBody_id] ";
            query += "   ,[AccCurr_id_fk] ";
            query += "  ,[CurrExching] ";
            query += "   ,[Debt_local] ";
            query += "   ,[Credit_local]  ";
            query += "     ,[Debt_foreign]  ";
            query += "   ,[Credit_foreign] ";
            query += "  ,[Date_dayly_body]  ";
            query += "    ,[Note]) ";
            query += "  VALUES ";
            query += "   (  " + Dayly_id_fk;
            query += "    , " + GetMaxIdPostingBody(Dayly_id_fk);
            query += " , " + AccCurr_id_fk;
            query += " , " + CurrExching;
            query += " , " + Debt_local;
            query += "  , " + Credit_local;
            query += "  , " + Debt_foreign;
            query += "  ," + Credit_foreign;
            query += "   ," + AddApostropheToString(Date_dayly_body);
            query += " ," + AddApostropheToString(Note) + ")";
         //   MessageBox.Show(query,"Body");
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

        }

        public void UpdatePostingBody
            (
            string Dayly_id_fk, string AccCurr_id_fk,
            string Debt_local, string Credit_local,
            string Debt_foreign, string Credit_foreign
            , string Note, string Date_dayly_body,
            string CurrExching , string DaylyBody_id
            )
        {
           //^^
            string
            query = "    UPDATE [dbo].[DaylyBody] ";
            query += "  SET ";
            query += "   [AccCurr_id_fk] =" + AccCurr_id_fk;
            query += "  ,[Debt_local] =" + Debt_local;
            query += "  ,[Credit_local] =" + Credit_local;
            query += "  ,[Debt_foreign] =" + Debt_foreign;
            query += "  ,[Credit_foreign] =" + Credit_foreign;
            query += "  ,[Note] =" + AddApostropheToString(Note);
            query += "  ,[Date_dayly_body] =" + AddApostropheToString(Date_dayly_body);
            query += "  ,[CurrExching] =" + CurrExching;
            query += "  WHERE [Dayly_id_fk] = " + Dayly_id_fk;
            query += "  and[DaylyBody_id] = " + DaylyBody_id;

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            #region
            /*
            UPDATE [dbo].[DaylyBody]
   SET 
       [AccCurr_id_fk] = 4
      ,[CurrExching] = 1
      ,[Debt_local] = 0
      ,[Credit_local] = 55
      ,[Debt_foreign] = 0
      ,[Credit_foreign] = 0
      ,[Date_dayly_body] = '2019-9-9'
      ,[Note] = 'Note'
 WHERE 
          [Dayly_id_fk] = 1
      and [DaylyBody_id] = 1
            */
            #endregion
        }
        public void UpdatePostingHaed
           (
         string Dayly_id, string Oper_id_fk,
         string Dayly_sum, string Date_dayly,
         string Note, string Refer_id_fk
           )
        {
            //^^

            #region
            /*
            UPDATE [dbo].[DaylyHaed]
   SET 
      [Oper_id_fk] = 1
      ,[Dayly_sum] = 2500
      ,[Date_dayly] = '2018-7-7'
      ,[Note] = 'Note'
      ,[Refer_id_fk] = 1
 WHERE [Dayly_id] = 1
            */
            #endregion
            string
            query = "     UPDATE [dbo].[DaylyHaed] ";
            query += "  SET ";
            query += "  [Oper_id_fk] =" + Oper_id_fk;
            query += " ,[Dayly_sum] = " + Dayly_sum;
            query += " ,[Date_dayly] =" + AddApostropheToString(Date_dayly);
            query += " ,[Note] =" + AddApostropheToString(Note);
            query += " ,[Refer_id_fk] =" + Refer_id_fk;
            query += "  WHERE[Dayly_id] = " + Dayly_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }

        public string GetMaxIdPostingHaed()
        {
            //^^
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query = " SELECT isnull(max(Dayly_id),0)+1 From [DaylyHaed]";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();

            return id;

        }
        public void DeletePostingBody(string DaylyBody_id, string Dayly_id_fk)
        {
            //^^

            #region
            /*
            DELETE FROM [dbo].[DaylyBody]
      WHERE Dayly_id_fk=1 and DaylyBody_id=1
            */
            #endregion
            string
            query = " DELETE FROM [dbo].[DaylyBody] ";
            query += "  WHERE Dayly_id_fk= " + DaylyBody_id;
            query += " and DaylyBody_id= " + DaylyBody_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }
        public void DeletePotstingHaed(string Dayly_id)
        {
            #region
            /*
            DELETE FROM [dbo].[DaylyHaed]
      WHERE [DaylyHaed].Dayly_id=1 
      and [DaylyHaed].Refer_id_fk=1 
      and [DaylyHaed].Oper_id_fk=1
            */
            #endregion
            string
            query = " DELETE FROM [dbo].[DaylyHaed] ";
            query += "  WHERE [DaylyHaed].Dayly_id= " + Dayly_id;
           // query += "  and [DaylyHaed].Refer_id_fk= " + Refer_id_fk;
         
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
        }
        public string GetMaxIdPostingBody(string Dayly_id_fk)
        { 
            //^^
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query = 
                "SELECT isnull(max(DaylyBody_id),0)+1 From DaylyBody where Dayly_id_fk=" + Dayly_id_fk;
           // MessageBox.Show(query);
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;

        }

        public bool CheckPostingOrNot(string Oper_id_fk,string Refer_id_fk)
        {
            /*
            يروح يفحص السند الحالي من العميلة الحاليه اذا موجود يعني نعم يعني مرحل
            مالم يرجع لا اي غير مرحل
            */
            if (dt != null)
                dt = null;
            dt = new DataTable();

            string
            query = "  SELECT [Dayly_id] ";
            query += " FROM ";
            query += " [dbo].[DaylyHaed] ";
            query += "  where ";
            query += " [Oper_id_fk]=";
            query += Oper_id_fk;
            query += " and [Refer_id_fk]= ";
            query += Refer_id_fk;

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                return true;
                return false;
          //  return dt;

            #region
            /*
            SELECT [Dayly_id]
      
  FROM [dbo].[DaylyHaed] where [Oper_id_fk]=1 and [Refer_id_fk]= 1
            */
            #endregion
        }

        DataTable GetDataPostSupportCatch(string Support_id)
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "  SELECT ";
            query += "  AccCurrency.AccCurr_id ";
            query += " , SupportCatchHead.CurrExching  ";
            query += " , SupportCatchHead.Debt_local  ";
            query += "  , Iif(SupportCatchHead.Debt_local>0,0,0) as Credit_local  ";
            query += " , SupportCatchHead.Debt_foreign  ";
            query += " , Iif(SupportCatchHead.Debt_local>0,0,0) as Credit_foreign   ";
            query += " FROM       Boxes INNER JOIN  ";
            query += "    AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN ";
            query += "   BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN  ";
            query += "  SupportCatchHead ON BoxUser.BoxUser_id = SupportCatchHead.BoxUser_id_fk  ";
            query += " WHERE        (SupportCatchHead.Support_id = " + Support_id + ")  ";

            query += " union All  ";

            query += "  SELECT  ";
            query += "  AccCurr_id_fk  ";
            query += "   , CurrExching  ";
            query += "  , Iif(Credit_local>0,0,0) as Debt_local   ";
            query += " ,  Credit_local  ";
            query += "  , Iif(Credit_local>0,0,0) as Debt_foreign   ";
            query += "  , Credit_foreign  ";
            query += " FROM            SupportCatchBody where Support_id_fk=" + Support_id;

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region استعلام مركب جلب  قيد سند القبض
            /*

SELECT     
   AccCurrency.AccCurr_id
, SupportCatchHead.CurrExching
, SupportCatchHead.Debt_local
 , Iif(SupportCatchHead.Debt_local>0,0,0) as Credit_local 
, SupportCatchHead.Debt_foreign
, Iif(SupportCatchHead.Debt_local>0,0,0) as Credit_foreign 
FROM            Boxes INNER JOIN
                         AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN
                         SupportCatchHead ON BoxUser.BoxUser_id = SupportCatchHead.BoxUser_id_fk
WHERE        (SupportCatchHead.Support_id = 1)
union All
SELECT    
    AccCurr_id_fk
   , CurrExching 
   , Iif(Credit_local>0,0,0) as Debt_local 
   ,  Credit_local
    , Iif(Credit_local>0,0,0) as Debt_foreign 
   , Credit_foreign
FROM            SupportCatchBody where Support_id_fk=1

            */
            #endregion
        }
        DataTable GetDataPostSupportExchang(string Support_id)
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "  SELECT ";
      
            query += "   AccCurr_id_fk ";
            query += "  ,CurrExching ";
            query += "  ,Debt_local ";
            query += "  ,Iif(Debt_local > 0, 0, 0) as Credit_local ";
            query += "  ,Debt_foreign  ";
            query += "  ,Iif(Debt_foreign > 0, 0, 0) as Credit_foreign  ";
            query += "  FROM SupportExchangBody where Support_id_fk = "+ Support_id;
            query += "  union All ";

            query += "   SELECT ";
            query += "   AccCurrency.AccCurr_id   ";
            query += " , SupportExchangHead.CurrExching ";
            query += " , Iif(SupportExchangHead.Credit_local > 0, 0, 0) as Debt_local  ";
            query += " , SupportExchangHead.Credit_local ";
            query += " , Iif(SupportExchangHead.Credit_foreign > 0, 0, 0) as Debt_foreign ";
            query += " , SupportExchangHead.Credit_foreign  ";
            query += "  FROM            Boxes INNER JOIN   ";
            query += "    AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN  ";
            query += "    BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN  ";
            query += "    SupportExchangHead ON BoxUser.BoxUser_id = SupportExchangHead.BoxUser_id_fk  ";
            query += "    WHERE(SupportExchangHead.Support_id = "+ Support_id + ")";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region استعلام مركب جلب  قيد سند القبض
            /*

 SELECT    
    AccCurr_id_fk
   , CurrExching 
   
   ,  Debt_local
   , Iif(Debt_local>0,0,0) as Credit_local 
   
   , Debt_foreign
    , Iif(Debt_foreign>0,0,0) as Credit_foreign 
FROM            SupportExchangBody where Support_id_fk=3
union All

	  SELECT     
   AccCurrency.AccCurr_id
, SupportExchangHead.CurrExching
, Iif(SupportExchangHead.Credit_local>0,0,0) as Debt_local 
, SupportExchangHead.Credit_local
, Iif(SupportExchangHead.Credit_foreign>0,0,0) as Debt_foreign 
, SupportExchangHead.Credit_foreign
FROM            Boxes INNER JOIN
                         AccCurrency ON Boxes.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN
                         SupportExchangHead ON BoxUser.BoxUser_id = SupportExchangHead.BoxUser_id_fk
WHERE        (SupportExchangHead.Support_id = 3)


            */
            #endregion
        }
        Dictionary<string,string> CheckDataPostSales(string Bill_id)
        {

            if (dt != null)
                dt = null;
            dt = new DataTable();
            #region  query
            string
    query = "  SELECT ";
    query += " Sum(A.Debt_local)  AS Debt_local";  
    query += " ,Sum(A.Credit_local) as Credit_local";
    query += " ,iif(Sum(A.Debt_local)=Sum(A.Credit_local),0,(iif(Sum(A.Debt_local)>Sum(A.Credit_local),1,2)))";
    query += " ,iif(Sum(A.Debt_local)=Sum(A.Credit_local),0,(iif(Sum(A.Debt_local)>Sum(A.Credit_local),";
    query += "  (Sum(A.Debt_local)-Sum(A.Credit_local)),";
    query += "  Sum(A.Credit_local)-(Sum(A.Debt_local)))))";
    query += "  ,( select (ISNULL( AccDifferenceExchingCurrForeigner,0))  FROM   AccDefine)  ";
    query += " From";

    query += " (SELECT    ";   
    query += "  iif(";
    query += "    Type_id_fk=1";
    query += "      ,(SELECT AccCurrency.AccCurr_id";
    query += "        FROM      ";
    query += "   AccCurrency INNER JOIN";
    query += "   Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN";
    query += "  BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk";
    query += "    WHERE      ";
    query += "  BoxUser.BoxUser_id = BoxUser_id_fk)";
    query += "     ,(SELECT AccCurr_id_fk";
	query += "        FROM   Customers";
    query += "       WHERE Cust_id = Cust_id_fk)) as AccCurr_id ,";
    query += " Exching,";
    query += "   iif(Exching=1,Total,(Total*Exching)) as Debt_local ,";
    query += "   (select 0) as Credit_local , ";
    query += "    iif(Exching=1,0,Total) as Debt_foreign,";
    query += "    (select 0) as Credit_foreign";
    query += "    FROM        ";
    query += "      SalesBillHead where Bill_id ="+ Bill_id;

            query += "  union all";

    query += "   SELECT   ";  
    query += "   (SELECT        Acc_sales_fk";
    query += "     FROM            GroupStored";
    query += "     WHERE        (Group_id = (SELECT        GroupStored.Group_id";
    query += "    FROM            ItemTypes INNER JOIN";
    query += "    GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN";
    query += "        Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN";
    query += "         ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk";
    query += "     WHERE        (ItemUnit.idItemUnit = idItemUnit_fk)))) as AccCurr_id ,  ";
	query += "       (select 1) as Exching , ";
	query += "        (select 0) as Debt_local , ";
    query += "      Total as Credit_local ,";
    query += "        (select 0) as Debt_foreign ,";
    query += "        (select 0) as Credit_foreign";
    query += "       FROM         ";
    query += "      SalesBillBody";
    query += "      WHERE    ";
    query += "       Bill_id_fk = "+ Bill_id;

    query += "  union all";

    query += "      SELECT       (SELECT     Acc_cost_fk";
    query += "      FROM         GroupStored";
	query += "        WHERE        Group_id = (SELECT   GroupStored.Group_id";
    query += "        FROM         GroupStored INNER JOIN";
    query += "         ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN";
    query += "           Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN";
    query += "         ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk";
	query += "	  WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id";
    query += "	        ,(select 1) as Exching";
    query += "   ,((convert(float, SalesBillBody.Part)/convert(float, Units.Unit_part))+SalesBillBody.Quantity)*ItemUnit.Prime_cost as Debt_local";
    query += "       ,(select 0) as Credit_local";
    query += "      ,(select 0) as Debt_foreign";
    query += "      ,(select 0) as Credit_foreign";
    query += "     FROM            SalesBillBody INNER JOIN";
    query += "      ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN";
    query += "            Units ON ItemUnit.Unit_id_fk = Units.Unit_id";
    query += "   WHERE        SalesBillBody.Bill_id_fk = "+ Bill_id;

    query += "     union all";

	
    query += "     SELECT       (SELECT     Acc_stored_fk";
    query += "       FROM         GroupStored";
	query += "        WHERE        Group_id = (SELECT   GroupStored.Group_id";
	query += "        FROM         GroupStored INNER JOIN";
    query += "          ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN";
    query += "   Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN";
    query += "         ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk";
    query += "	        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id";
    query += "		        ,(select 1) as Exching";
    query += "     ,(select 0) as  Debt_local";
    query += "     ,((convert(float, SalesBillBody.Part)/convert(float, Units.Unit_part))+SalesBillBody.Quantity)*ItemUnit.Prime_cost as Credit_local";
    query += "     ,(select 0) as Debt_foreign";
    query += "      ,(select 0) as Credit_foreign";
    query += "    FROM            SalesBillBody INNER JOIN";
    query += "     ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN";
    query += "                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id";
    query += "   WHERE        SalesBillBody.Bill_id_fk = "+ Bill_id;
	
    query += "       ) A ";
            #endregion
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            Dictionary<string, string> Data = new Dictionary<string, string>();
            if (dt != null && dt.Rows.Count > 0)
            {
                //EqualOrDebtOrCredit
                //Equal 0
                //Debt>Credit 1
                //Credit>Debt 2

                Data.Add("EqualOrDebtOrCredit", dt.Rows[0][2].ToString());
                Data.Add("TotalDefrent", dt.Rows[0][3].ToString());
                Data.Add("AccCurrDef", dt.Rows[0][4].ToString());
            }
            return Data;
            #region الاستعلام
            /*
            select  

          Sum(A.Debt_local)  AS Debt_local
         ,Sum(A.Credit_local) as Credit_local
         ,iif(Sum(A.Debt_local)=Sum(A.Credit_local),0,(iif(Sum(A.Debt_local)>Sum(A.Credit_local),1,2)))
         ,iif(Sum(A.Debt_local)=Sum(A.Credit_local),0,(iif(Sum(A.Debt_local)>Sum(A.Credit_local),
         (Sum(A.Debt_local)-Sum(A.Credit_local)),
         Sum(A.Credit_local)-(Sum(A.Debt_local)))))
         From
        (SELECT       
        iif(
		        Type_id_fk=1
		        ,(SELECT AccCurrency.AccCurr_id
			        FROM      
			        AccCurrency INNER JOIN
                                 Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                                 BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk
			        WHERE      
          BoxUser.BoxUser_id = BoxUser_id_fk)
		        ,(SELECT AccCurr_id_fk
			        FROM   Customers
			        WHERE Cust_id = Cust_id_fk)) as AccCurr_id ,

        Exching,

         iif(Exching=1,Total,(Total*Exching)) as Debt_local ,

         (select 0) as Credit_local , 

         iif(Exching=1,0,Total) as Debt_foreign,

          (select 0) as Credit_foreign


        FROM        
            SalesBillHead where Bill_id =1

        union all


        SELECT     
        (SELECT        Acc_sales_fk
        FROM            GroupStored
        WHERE        (Group_id = (SELECT        GroupStored.Group_id
        FROM            ItemTypes INNER JOIN
                                 GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
        WHERE        (ItemUnit.idItemUnit = idItemUnit_fk)))) as AccCurr_id ,  
	        (select 1) as Exching , 
	        (select 0) as Debt_local , 
	        Total as Credit_local ,
	        (select 0) as Debt_foreign ,
	        (select 0) as Credit_foreign
	        FROM         
           SalesBillBody
	        WHERE    
	        Bill_id_fk = 1

	        union all


	        SELECT       (SELECT     Acc_cost_fk
	        FROM         GroupStored
	        WHERE        Group_id = (SELECT   GroupStored.Group_id
	        FROM         GroupStored INNER JOIN
                                 ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
			        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id
			        ,(select 1) as Exching
        ,((convert(float, SalesBillBody.Part)/convert(float, Units.Unit_part))+SalesBillBody.Quantity)*ItemUnit.Prime_cost as Debt_local
        ,(select 0) as Credit_local
        ,(select 0) as Debt_foreign
        ,(select 0) as Credit_foreign
        FROM            SalesBillBody INNER JOIN
                                 ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                                 Units ON ItemUnit.Unit_id_fk = Units.Unit_id
        WHERE        SalesBillBody.Bill_id_fk = 1

        union all

	
        SELECT       (SELECT     Acc_stored_fk
	        FROM         GroupStored
	        WHERE        Group_id = (SELECT   GroupStored.Group_id
	        FROM         GroupStored INNER JOIN
                                 ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
			        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id
			        ,(select 1) as Exching
        ,(select 0) as  Debt_local
        ,((convert(float, SalesBillBody.Part)/convert(float, Units.Unit_part))+SalesBillBody.Quantity)*ItemUnit.Prime_cost as Credit_local
        ,(select 0) as Debt_foreign
        ,(select 0) as Credit_foreign
        FROM            SalesBillBody INNER JOIN
                                 ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                                 Units ON ItemUnit.Unit_id_fk = Units.Unit_id
        WHERE        SalesBillBody.Bill_id_fk = 1
	
	        ) A 




            
            */
            #endregion

        }
        Dictionary<string, string> CheckDataPostSalesReturn(string Bill_id)
        {

            if (dt != null)
                dt = null;
            dt = new DataTable();
            #region  query
            string
    query = "  SELECT ";
            query += " Sum(A.Debt_local)  AS Debt_local";
            query += " ,Sum(A.Credit_local) as Credit_local";
            query += " ,iif(Sum(A.Debt_local)=Sum(A.Credit_local),0,(iif(Sum(A.Debt_local)>Sum(A.Credit_local),1,2)))";
            query += " ,iif(Sum(A.Debt_local)=Sum(A.Credit_local),0,(iif(Sum(A.Debt_local)>Sum(A.Credit_local),";
            query += "  (Sum(A.Debt_local)-Sum(A.Credit_local)),";
            query += "  Sum(A.Credit_local)-(Sum(A.Debt_local)))))";
            query += "  ,( select (ISNULL( AccDifferenceExchingCurrForeigner,0))  FROM   AccDefine)  ";
            query += " From";

            query += " (SELECT    ";
            query += "  iif(";
            query += "    Type_id_fk=1";
            query += "      ,(SELECT AccCurrency.AccCurr_id";
            query += "        FROM      ";
            query += "   AccCurrency INNER JOIN";
            query += "   Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN";
            query += "  BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk";
            query += "    WHERE      ";
            query += "  BoxUser.BoxUser_id = BoxUser_id_fk)";
            query += "     ,(SELECT AccCurr_id_fk";
            query += "        FROM   Customers";
            query += "       WHERE Cust_id = Cust_id_fk)) as AccCurr_id ,";
            query += " Exching,";
        
            query += "   (select 0) as  Debt_local , ";
            query += "   iif(Exching=1,Total,(Total*Exching)) as Credit_local ,";
            query += "    (select 0) as Debt_foreign, ";
            query += "    iif(Exching=1,0,Total) as Credit_foreign ";
          
            query += "    FROM        ";
            query += "      ReturnSalesBillHead where Return_bill_id =" + Bill_id;
             

            query += "  union all";

            query += "   SELECT   ";
            query += "   (SELECT        Acc_return_sales_fk";
            query += "     FROM            GroupStored";
            query += "     WHERE        (Group_id = (SELECT        GroupStored.Group_id";
            query += "    FROM            ItemTypes INNER JOIN";
            query += "    GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN";
            query += "        Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN";
            query += "         ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk";
            query += "     WHERE        (ItemUnit.idItemUnit = idItemUnit_fk)))) as AccCurr_id ,  ";
            query += "       (select 1) as Exching , ";
            query += "      Total   as Debt_local , ";
            query += "    (select 0)   as Credit_local ,"; //
            query += "        (select 0) as Debt_foreign ,";
            query += "        (select 0) as Credit_foreign";
            query += "       FROM         ";
            query += "      ReturnSalesBillBody";
            query += "      WHERE    ";
            query += "       Return_bill_id_fk = " + Bill_id;  

            query += "  union all";

            query += "      SELECT       (SELECT     Acc_cost_fk";
            query += "      FROM         GroupStored";
            query += "        WHERE        Group_id = (SELECT   GroupStored.Group_id";
            query += "        FROM         GroupStored INNER JOIN";
            query += "         ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN";
            query += "           Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN";
            query += "         ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk";
            query += "	  WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id";
            query += "	        ,(select 1) as Exching";
            query += "       ,(select 0) as Debt_local ";
            query += "   ,((convert(float, ReturnSalesBillBody.Part)/convert(float, Units.Unit_part))+ReturnSalesBillBody.Quantity)*ItemUnit.Prime_cost as Credit_local ";
            query += "      ,(select 0) as Debt_foreign";
            query += "      ,(select 0) as Credit_foreign";
            query += "     FROM            ReturnSalesBillBody INNER JOIN";
            query += "      ItemUnit ON ReturnSalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN";
            query += "            Units ON ItemUnit.Unit_id_fk = Units.Unit_id";
            query += "   WHERE        ReturnSalesBillBody.Return_bill_id_fk = " + Bill_id;

            query += "     union all";


            query += "     SELECT       (SELECT     Acc_stored_fk";
            query += "       FROM         GroupStored";
            query += "        WHERE        Group_id = (SELECT   GroupStored.Group_id";
            query += "        FROM         GroupStored INNER JOIN";
            query += "          ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN";
            query += "   Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN";
            query += "         ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk";
            query += "	        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id";
            query += "		        ,(select 1) as Exching";
          
            query += "     ,((convert(float, ReturnSalesBillBody.Part)/convert(float, Units.Unit_part))+ReturnSalesBillBody.Quantity)*ItemUnit.Prime_cost as Debt_local ";
            query += "     ,(select 0) as Credit_local ";
            query += "     ,(select 0) as Debt_foreign";
            query += "      ,(select 0) as Credit_foreign";
            query += "    FROM            ReturnSalesBillBody INNER JOIN";
            query += "     ItemUnit ON ReturnSalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN";
            query += "                             Units ON ItemUnit.Unit_id_fk = Units.Unit_id";
            query += "   WHERE        ReturnSalesBillBody.Return_bill_id_fk = " + Bill_id;

            query += "       ) A ";
            #endregion
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            Dictionary<string, string> Data = new Dictionary<string, string>();
            if (dt != null && dt.Rows.Count > 0)
            {
                //EqualOrDebtOrCredit
                //Equal 0
                //Debt>Credit 1
                //Credit>Debt 2

                Data.Add("EqualOrDebtOrCredit", dt.Rows[0][2].ToString());
                Data.Add("TotalDefrent", dt.Rows[0][3].ToString());
                Data.Add("AccCurrDef", dt.Rows[0][4].ToString());
            }
            return Data;
            #region الاستعلام
            /*
            
               
     select  

          Sum(A.Debt_local)  AS Debt_local
         ,Sum(A.Credit_local) as Credit_local
         ,iif(Sum(A.Debt_local)=Sum(A.Credit_local),0,(iif(Sum(A.Debt_local)>Sum(A.Credit_local),1,2)))
         ,iif(Sum(A.Debt_local)=Sum(A.Credit_local),0,(iif(Sum(A.Debt_local)>Sum(A.Credit_local),
         (Sum(A.Debt_local)-Sum(A.Credit_local)),
         Sum(A.Credit_local)-(Sum(A.Debt_local)))))
         From
        (	
        
            SELECT     
        (SELECT       Acc_return_sales_fk
        FROM            GroupStored
        WHERE        (Group_id = (SELECT        GroupStored.Group_id
        FROM            ItemTypes INNER JOIN
                                 GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
        WHERE        (ItemUnit.idItemUnit = idItemUnit_fk)))) as AccCurr_id ,  
	        (select 1) as Exching , 
	       Total   as Debt_local , 
	     (select 0)  as Credit_local ,
	     (select 0) as Debt_foreign ,
	     (select 0) as Credit_foreign
	        FROM         
           ReturnSalesBillBody
	        WHERE    
	        Return_bill_id_fk = 1
         
			union all	
		
			SELECT       
        iif(
		        Type_id_fk=1
		        ,(SELECT AccCurrency.AccCurr_id
			        FROM      
			        AccCurrency INNER JOIN
                                 Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                                 BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk
			        WHERE      
          BoxUser.BoxUser_id = BoxUser_id_fk)
		        ,(SELECT AccCurr_id_fk
			        FROM   Customers
			        WHERE Cust_id = Cust_id_fk)) as AccCurr_id ,

        Exching,

        (select 0)  as Debt_local ,

        iif(Exching=1,Total,(Total*Exching))  as Credit_local , 

       (select 0)   as Debt_foreign,

       iif(Exching=1,0,Total)    as Credit_foreign


        FROM        
            ReturnSalesBillHead where Return_bill_id =1

		
		  
        
			
			  union all
			   SELECT       (SELECT     Acc_stored_fk
	        FROM         GroupStored
	        WHERE        Group_id = (SELECT   GroupStored.Group_id
	        FROM         GroupStored INNER JOIN
                                 ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
			        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id
			        ,(select 1) as Exching
      
        ,((convert(float, ReturnSalesBillBody.Part)/convert(float, Units.Unit_part))+ReturnSalesBillBody.Quantity)*ItemUnit.Prime_cost as  Debt_local
          ,(select 0) as  Credit_local
		,(select 0) as Debt_foreign
        ,(select 0) as Credit_foreign
        FROM            ReturnSalesBillBody INNER JOIN
                                 ItemUnit ON ReturnSalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                                 Units ON ItemUnit.Unit_id_fk = Units.Unit_id
        WHERE        ReturnSalesBillBody.Return_bill_id_fk = 1
			
			 union all
			  
	        SELECT       (SELECT     Acc_cost_fk
	        FROM         GroupStored
	        WHERE        Group_id = (SELECT   GroupStored.Group_id
	        FROM         GroupStored INNER JOIN
                                 ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
			        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id
			        ,(select 1) as Exching
					  ,(select 0) as Debt_local
        ,((convert(float, ReturnSalesBillBody.Part)/convert(float, Units.Unit_part))+ReturnSalesBillBody.Quantity)*ItemUnit.Prime_cost as Credit_local
      
        ,(select 0) as Debt_foreign
        ,(select 0) as Credit_foreign
        FROM            ReturnSalesBillBody INNER JOIN
                                 ItemUnit ON ReturnSalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                                 Units ON ItemUnit.Unit_id_fk = Units.Unit_id
        WHERE        ReturnSalesBillBody.Return_bill_id_fk = 1

		
	        ) A 




            
            */
            #endregion




        }
        bool CheckEntryTrue(string Entry_id_fk)
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "  SELECT ";
            query += "  sum(Debt_local)- sum(Credit_local)  ";
            query += "  FROM     EntriesBody  ";
            query += "   WHERE        Entry_id_fk =   "+ Entry_id_fk;
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString() == "0" ? true : false;
            else return false;

            /*
            SELECT    
            sum(Debt_local)- sum(Credit_local)
            FROM            EntriesBody
            WHERE        Entry_id_fk = 1
            */
        }
        DataTable GetDataEntry(string Entry_id_fk = "-1")
        {
            bool State = CheckEntryTrue(Entry_id_fk);
            if (dt != null)
                dt = null;
            dt = new DataTable();
            if (State)
            {
               
                string
                query = "  SELECT ";
                query += "    AccCurr_id_fk  ";
                query += "  , CurrExching  ";
                query += "  , Debt_local  ";
                query += "  , Credit_local ";
                query += "  , Debt_foreign  ";
                query += "  , Credit_foreign  ";
              
                query += "  , Note ";
                query += "  FROM   EntriesBody  ";
                query += "  WHERE        Entry_id_fk =   "+ Entry_id_fk;
                con.OpenConnetion();
                dt = con.Query(query, true);
                con.CloseConnetion();

            }
            else
                MessageBox.Show("اجمالي مدين لا يساوي اجمالي دائن","كلاس الترحيل",MessageBoxButtons.OK,MessageBoxIcon.Error);
            return dt;
            #region
            /*
            SELECT       
            AccCurr_id_fk
            , CurrExching
            , Debt_local
            , Credit_local
            , Debt_foreign
            , Credit_foreign
          
            , Note
                FROM            EntriesBody
                WHERE        Entry_id_fk = 1
            */
            #endregion
        }
        DataTable GetDataPostSales(string Bill_id = "-1")
        {
            Dictionary<string, string> Data = new Dictionary<string, string>();
            Data = CheckDataPostSales(Bill_id);

            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "  SELECT ";

            query += "   A.AccCurr_id  ";
            query += "  ,a.Exching  ";
            query += "  ,Sum(A.Debt_local)  AS Debt_local ";
            query += "  ,Sum(A.Credit_local) as Credit_local ";
            query += "  ,Sum(A.Debt_foreign) as Debt_foreign  ";
            query += "  ,Sum(A.Credit_foreign) as Credit_foreign  ";
            query += "  From  ";
            #region جلب  الجانب المدين للقيد رقم 1
            query += "  (SELECT      ";
            query += "  iif(  ";
            query += "  Type_id_fk=1 ";
            query += "  ,(SELECT AccCurrency.AccCurr_id  ";
            query += "  FROM      ";
            query += "  AccCurrency INNER JOIN ";
            query += "  Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN ";
            query += "  BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk  ";
            query += "  WHERE       ";
            query += "  BoxUser.BoxUser_id = BoxUser_id_fk) ";
            query += "  ,(SELECT AccCurr_id_fk  ";
            query += "  FROM   Customers ";
            query += "  WHERE Cust_id = Cust_id_fk)) as AccCurr_id , ";
            query += "  Exching,  ";
            query += "  iif(Exching=1,Total,(Total*Exching)) as Debt_local ,  ";
            query += "  (select 0) as Credit_local ,   ";
            query += "  iif(Exching=1,0,Total) as Debt_foreign,  ";
            query += "  (select 0) as Credit_foreign ";
            query += "  FROM    ";
            query += "  SalesBillHead where Bill_id =  " + Bill_id;
            #endregion

            query += "  union all  ";
            #region جلب الجانب الدائن للقيد رقم 1
            query += "  SELECT    ";
            query += " (SELECT  Acc_sales_fk ";
            query += "  FROM    GroupStored  ";
            query += "  WHERE  (Group_id = (SELECT  GroupStored.Group_id  ";
            query += "  FROM   ItemTypes INNER JOIN  ";
            query += "  GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN  ";
            query += "  Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN ";
            query += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk ";
            query += "  WHERE  (ItemUnit.idItemUnit = idItemUnit_fk)))) as AccCurr_id ,    ";
            query += "  (select 1) as Exching ,   ";
            query += "  (select 0) as Debt_local ,  ";
            query += "  Total as Credit_local ,  ";
            query += "  (select 0) as Debt_foreign ,  ";
            query += "  (select 0) as Credit_foreign  ";
            query += "  FROM    ";
            query += "  SalesBillBody ";
            query += "  WHERE  ";
            query += "  Bill_id_fk =  " + Bill_id;
            #endregion

            query += "   union all  ";
            #region
            query += "   SELECT (SELECT     Acc_cost_fk  ";
            query += "   FROM   GroupStored ";
            query += "   WHERE  Group_id = (SELECT   GroupStored.Group_id ";
            query += "   FROM   GroupStored INNER JOIN  ";
            query += "   ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN ";
            query += "   Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN ";
            query += "   ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk ";
            query += "   WHERE  ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id  ";
            query += "   ,(select 1) as Exching ";
            query += "   ,((convert(float, SalesBillBody.Part)/convert(float, Units.Unit_part))+SalesBillBody.Quantity) ";
            query += "   *ItemUnit.Prime_cost as Debt_local  ";
            query += "   ,(select 0) as Credit_local ";
            query += "   ,(select 0) as Debt_foreign  ";
            query += "   ,(select 0) as Credit_foreign ";
            query += "  FROM   SalesBillBody INNER JOIN  ";
            query += "  ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN  ";
            query += "  Units ON ItemUnit.Unit_id_fk = Units.Unit_id ";
            query += "  WHERE    SalesBillBody.Bill_id_fk = " + Bill_id;
            #endregion
            query += "   union all  ";
            query += "   SELECT  (SELECT  Acc_stored_fk  ";
            query += "    FROM         GroupStored ";
            query += "    WHERE        Group_id = (SELECT   GroupStored.Group_id ";
            query += "   FROM         GroupStored INNER JOIN  ";
            query += "  ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN  ";
            query += "  Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN ";
            query += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk ";
            query += "   WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id  ";
            query += "   ,(select 1) as Exching  ";
            query += "    ,(select 0) as  Debt_local ";
            query += "    ,((convert(float, SalesBillBody.Part)/convert(float, Units.Unit_part))+SalesBillBody.Quantity) ";
            query += " *ItemUnit.Prime_cost as Credit_local  ";
            query += "    ,(select 0) as Debt_foreign  ";
            query += "    ,(select 0) as Credit_foreign ";
            query += "   FROM            SalesBillBody INNER JOIN ";
            query += "   ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN ";
            query += "   Units ON ItemUnit.Unit_id_fk = Units.Unit_id ";
            query += "   WHERE        SalesBillBody.Bill_id_fk = " + Bill_id;
            if (Data.Count == 3)
            {
                if (Data["EqualOrDebtOrCredit"] != "0"&&Data["AccCurrDef"]!="0")
                {
                    query += " union all  ";
                    query += " SELECT   ";
                    query += " ISNULL( AccDifferenceExchingCurrForeigner,0) as AccCurr_id ";
                    query += "  ,(select 1) as Exching   ";
                    #region جلب رقم حساب فوارق عملات اجنبيه
                    /*
                    union all
            SELECT   
    
            ISNULL( AccDifferenceExchingCurrForeigner,0) as AccCurr_id
             ,(select 1) as Exching
             ,(select 0) as  Debt_local
             ,(select 0)as Credit_local
             ,(select 0)as Debt_foreign
             ,(select 0)as Credit_foreign
            FROM            AccDefine
                    */
                    #endregion

                    if (Data["EqualOrDebtOrCredit"] == "1")
                    {
                        query += "  ,(select 0) as  Debt_local  ";
                        query += "  ,(select "+ Data["TotalDefrent"] + ")as Credit_local  ";
                    }
                    else if(Data["EqualOrDebtOrCredit"] == "2")
                    {
                        query += "  ,(select " + Data["TotalDefrent"] + ") as  Debt_local  ";
                        query += "  ,(select 0)as Credit_local  ";
                    }
                    query += "   ,(select 0) as  Debt_foreign  ";
                    query += "   ,(select 0)as Credit_foreign  ";
                    query += "  FROM     AccDefine ";
                }
            }
            query += "    ) A group by A.AccCurr_id,a.Exching order by A.AccCurr_id ";
         
     
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region
            /*
            select  
         A.AccCurr_id
         ,a.Exching
         ,Sum(A.Debt_local)  AS Debt_local
         ,Sum(A.Credit_local) as Credit_local
         ,Sum(A.Debt_foreign) as Debt_foreign
         ,Sum(A.Credit_foreign) as Credit_foreign
         From
        (SELECT       
        iif(
		        Type_id_fk=1
		        ,(SELECT AccCurrency.AccCurr_id
			        FROM      
			        AccCurrency INNER JOIN
                                 Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                                 BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk
			        WHERE      
          BoxUser.BoxUser_id = BoxUser_id_fk)
		        ,(SELECT AccCurr_id_fk
			        FROM   Customers
			        WHERE Cust_id = Cust_id_fk)) as AccCurr_id ,

        Exching,

         iif(Exching=1,Total,(Total*Exching)) as Debt_local ,

         (select 0) as Credit_local , 

         iif(Exching=1,0,Total) as Debt_foreign,

          (select 0) as Credit_foreign


        FROM        
            SalesBillHead where Bill_id =1

        union all


        SELECT     
        (SELECT        Acc_sales_fk
        FROM            GroupStored
        WHERE        (Group_id = (SELECT        GroupStored.Group_id
        FROM            ItemTypes INNER JOIN
                                 GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
        WHERE        (ItemUnit.idItemUnit = idItemUnit_fk)))) as AccCurr_id ,  
	        (select 1) as Exching , 
	        (select 0) as Debt_local , 
	        Total as Credit_local ,
	        (select 0) as Debt_foreign ,
	        (select 0) as Credit_foreign
	        FROM         
           SalesBillBody
	        WHERE    
	        Bill_id_fk = 1

	        union all


	        SELECT       (SELECT     Acc_cost_fk
	        FROM         GroupStored
	        WHERE        Group_id = (SELECT   GroupStored.Group_id
	        FROM         GroupStored INNER JOIN
                                 ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
			        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id
			        ,(select 1) as Exching
        ,((convert(float, SalesBillBody.Part)/convert(float, Units.Unit_part))+SalesBillBody.Quantity)*ItemUnit.Prime_cost as Debt_local
        ,(select 0) as Credit_local
        ,(select 0) as Debt_foreign
        ,(select 0) as Credit_foreign
        FROM            SalesBillBody INNER JOIN
                                 ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                                 Units ON ItemUnit.Unit_id_fk = Units.Unit_id
        WHERE        SalesBillBody.Bill_id_fk = 1

        union all

	
        SELECT       (SELECT     Acc_stored_fk
	        FROM         GroupStored
	        WHERE        Group_id = (SELECT   GroupStored.Group_id
	        FROM         GroupStored INNER JOIN
                                 ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
			        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id
			        ,(select 1) as Exching
        ,(select 0) as  Debt_local
        ,((convert(float, SalesBillBody.Part)/convert(float, Units.Unit_part))+SalesBillBody.Quantity)*ItemUnit.Prime_cost as Credit_local
        ,(select 0) as Debt_foreign
        ,(select 0) as Credit_foreign
        FROM            SalesBillBody INNER JOIN
                                 ItemUnit ON SalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                                 Units ON ItemUnit.Unit_id_fk = Units.Unit_id
        WHERE        SalesBillBody.Bill_id_fk = 1
	
	        ) A group by A.AccCurr_id,a.Exching order by A.AccCurr_id




            */
            #endregion

        }
        DataTable GetDataPostSalesReturn(string Bill_id = "-1")
        {
            Dictionary<string, string> Data = new Dictionary<string, string>();
            Data = CheckDataPostSalesReturn(Bill_id);

            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "  SELECT ";

            query += "   A.AccCurr_id  ";
            query += "  ,a.Exching  ";
            query += "  ,Sum(A.Debt_local)  AS Debt_local ";
            query += "  ,Sum(A.Credit_local) as Credit_local ";
            query += "  ,Sum(A.Debt_foreign) as Debt_foreign  ";
            query += "  ,Sum(A.Credit_foreign) as Credit_foreign  ";
            query += "  From ( ";
            #region جلب الجانب المدين للقيد رقم 1
            query += "  SELECT    ";
            query += " (SELECT  Acc_return_sales_fk ";
            query += "  FROM    GroupStored  ";
            query += "  WHERE  (Group_id = (SELECT  GroupStored.Group_id  ";
            query += "  FROM   ItemTypes INNER JOIN  ";
            query += "  GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN  ";
            query += "  Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN ";
            query += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk ";
            query += "  WHERE  (ItemUnit.idItemUnit = idItemUnit_fk)))) as AccCurr_id ,    ";
            query += "  (select 1) as Exching ,   ";
            query += " Total  as Debt_local ,  ";
            query += " (select 0)  as Credit_local ,  ";
            query += "  (select 0) as Debt_foreign ,  ";
            query += "  (select 0) as Credit_foreign  ";
            query += "  FROM    ";
            query += "  ReturnSalesBillBody ";
            query += "  WHERE  ";
            query += "  Return_bill_id_fk =  " + Bill_id; //     
            #endregion

            query += "  union all  ";
      
            #region جلب  الجانب الدائن للقيد رقم 1
            query += "  SELECT      ";
            query += "  iif(  ";
            query += "  Type_id_fk=1 ";
            query += "  ,(SELECT AccCurrency.AccCurr_id  ";
            query += "  FROM      ";
            query += "  AccCurrency INNER JOIN ";
            query += "  Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN ";
            query += "  BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk  ";
            query += "  WHERE       ";
            query += "  BoxUser.BoxUser_id = BoxUser_id_fk) ";
            query += "  ,(SELECT AccCurr_id_fk  ";
            query += "  FROM   Customers ";
            query += "  WHERE Cust_id = Cust_id_fk)) as AccCurr_id , ";
            query += "  Exching,  ";
            query += "  (select 0) as Debt_local  ,   ";
            query += "  iif(Exching=1,Total,(Total*Exching)) as Credit_local  ,  ";
            query += "  (select 0) as Debt_foreign , ";
            query += "  iif(Exching=1,0,Total) as Credit_foreign   ";
           
            query += "  FROM    ";
            query += "  ReturnSalesBillHead where Return_bill_id =  " + Bill_id; // 
            #endregion

            query += "   union all  ";
            #region جلب الجانب المدين 2
            query += "   SELECT  (SELECT  Acc_stored_fk  ";
            query += "    FROM         GroupStored ";
            query += "    WHERE        Group_id = (SELECT   GroupStored.Group_id ";
            query += "   FROM         GroupStored INNER JOIN  ";
            query += "  ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN  ";
            query += "  Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN ";
            query += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk ";
            query += "   WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id  ";
            query += "   ,(select 1) as Exching  ";
            query += "    ,((convert(float, ReturnSalesBillBody.Part)/convert(float, Units.Unit_part))+ReturnSalesBillBody.Quantity) ";
            query += " *ItemUnit.Prime_cost as Debt_local   ";
            query += "    ,(select 0) as Credit_local  ";
            query += "    ,(select 0) as Debt_foreign  ";
            query += "    ,(select 0) as Credit_foreign ";
            query += "   FROM            ReturnSalesBillBody INNER JOIN ";
            query += "   ItemUnit ON ReturnSalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN ";
            query += "   Units ON ItemUnit.Unit_id_fk = Units.Unit_id ";
            query += "   WHERE        ReturnSalesBillBody.Return_bill_id_fk = " + Bill_id; // 
            #endregion

            query += "   union all  ";
            #region جلب الجانب الدائن 2
            query += "   SELECT (SELECT     Acc_cost_fk  ";
            query += "   FROM   GroupStored ";
            query += "   WHERE  Group_id = (SELECT   GroupStored.Group_id ";
            query += "   FROM   GroupStored INNER JOIN  ";
            query += "   ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN ";
            query += "   Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN ";
            query += "   ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk ";
            query += "   WHERE  ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id  ";
            query += "   ,(select 1) as Exching ";
            query += "   ,(select 0) as Debt_local ";
            query += "   ,((convert(float, ReturnSalesBillBody.Part)/convert(float, Units.Unit_part))+ReturnSalesBillBody.Quantity) ";
            query += "   *ItemUnit.Prime_cost as Credit_local   ";
          
            query += "   ,(select 0) as Debt_foreign  ";
            query += "   ,(select 0) as Credit_foreign ";
            query += "  FROM   ReturnSalesBillBody INNER JOIN  ";
            query += "  ItemUnit ON ReturnSalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN  ";
            query += "  Units ON ItemUnit.Unit_id_fk = Units.Unit_id ";
            query += "  WHERE    ReturnSalesBillBody.Return_bill_id_fk = " + Bill_id; // 
            #endregion
            if (Data.Count == 3)
            {
                if (Data["EqualOrDebtOrCredit"] != "0" && Data["AccCurrDef"] != "0")
                {
                    query += " union all  ";
                    query += " SELECT   ";
                    query += " ISNULL( AccDifferenceExchingCurrForeigner,0) as AccCurr_id ";
                    query += "  ,(select 1) as Exching   ";
                    #region جلب رقم حساب فوارق عملات اجنبيه
                    /*
                    union all
            SELECT   
    
            ISNULL( AccDifferenceExchingCurrForeigner,0) as AccCurr_id
             ,(select 1) as Exching
             ,(select 0) as  Debt_local
             ,(select 0)as Credit_local
             ,(select 0)as Debt_foreign
             ,(select 0)as Credit_foreign
            FROM            AccDefine
                    */
                    #endregion

                    if (Data["EqualOrDebtOrCredit"] == "1")
                    {
                        query += "  ,(select 0) as  Debt_local  ";
                        query += "  ,(select " + Data["TotalDefrent"] + ")as Credit_local  ";
                    }
                    else if (Data["EqualOrDebtOrCredit"] == "2")
                    {
                        query += "  ,(select " + Data["TotalDefrent"] + ") as  Debt_local  ";
                        query += "  ,(select 0)as Credit_local  ";
                    }
                    query += "   ,(select 0) as  Debt_foreign  ";
                    query += "   ,(select 0)as Credit_foreign  ";
                    query += "  FROM     AccDefine ";
                }
            }
            query += "    ) A group by A.AccCurr_id,a.Exching order by A.AccCurr_id ";


            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region
            /*
            

		 select  
         A.AccCurr_id
         ,a.Exching
         ,Sum(A.Debt_local)  AS Debt_local
         ,Sum(A.Credit_local) as Credit_local
         ,Sum(A.Debt_foreign) as Debt_foreign
         ,Sum(A.Credit_foreign) as Credit_foreign
         From
        (
		SELECT     
        (SELECT       Acc_return_sales_fk
        FROM            GroupStored
        WHERE        (Group_id = (SELECT        GroupStored.Group_id
        FROM            ItemTypes INNER JOIN
                                 GroupStored ON ItemTypes.Group_id_fk = GroupStored.Group_id INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
        WHERE        (ItemUnit.idItemUnit = idItemUnit_fk)))) as AccCurr_id ,  
	        (select 1) as Exching , 
	       Total   as Debt_local , 
	     (select 0)  as Credit_local ,
	     (select 0) as Debt_foreign ,
	     (select 0) as Credit_foreign
	        FROM         
           ReturnSalesBillBody
	        WHERE    
	        Return_bill_id_fk = 1
         
			union all	
		
			SELECT       
        iif(
		        Type_id_fk=1
		        ,(SELECT AccCurrency.AccCurr_id
			        FROM      
			        AccCurrency INNER JOIN
                                 Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                                 BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk
			        WHERE      
          BoxUser.BoxUser_id = BoxUser_id_fk)
		        ,(SELECT AccCurr_id_fk
			        FROM   Customers
			        WHERE Cust_id = Cust_id_fk)) as AccCurr_id ,

        Exching,

        (select 0)  as Debt_local ,

        iif(Exching=1,Total,(Total*Exching))  as Credit_local , 

       (select 0)   as Debt_foreign,

       iif(Exching=1,0,Total)    as Credit_foreign


        FROM        
            ReturnSalesBillHead where Return_bill_id =1 

		
		  
        
			
			  union all
			   SELECT       (SELECT     Acc_stored_fk
	        FROM         GroupStored
	        WHERE        Group_id = (SELECT   GroupStored.Group_id
	        FROM         GroupStored INNER JOIN
                                 ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
			        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id
			        ,(select 1) as Exching
      
        ,((convert(float, ReturnSalesBillBody.Part)/convert(float, Units.Unit_part))+ReturnSalesBillBody.Quantity)*ItemUnit.Prime_cost as  Debt_local
          ,(select 0) as  Credit_local
		,(select 0) as Debt_foreign
        ,(select 0) as Credit_foreign
        FROM            ReturnSalesBillBody INNER JOIN
                                 ItemUnit ON ReturnSalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                                 Units ON ItemUnit.Unit_id_fk = Units.Unit_id
        WHERE        ReturnSalesBillBody.Return_bill_id_fk = 1 
			
			 union all
			  
	        SELECT       (SELECT     Acc_cost_fk
	        FROM         GroupStored
	        WHERE        Group_id = (SELECT   GroupStored.Group_id
	        FROM         GroupStored INNER JOIN
                                 ItemTypes ON GroupStored.Group_id = ItemTypes.Group_id_fk INNER JOIN
                                 Items ON ItemTypes.ItemType_id = Items.ItemType_id_fk INNER JOIN
                                 ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk
			        WHERE        ItemUnit.idItemUnit = idItemUnit_fk)) as AccCurr_id
			        ,(select 1) as Exching
					  ,(select 0) as Debt_local
        ,((convert(float, ReturnSalesBillBody.Part)/convert(float, Units.Unit_part))+ReturnSalesBillBody.Quantity)*ItemUnit.Prime_cost as Credit_local
      
        ,(select 0) as Debt_foreign
        ,(select 0) as Credit_foreign
        FROM            ReturnSalesBillBody INNER JOIN
                                 ItemUnit ON ReturnSalesBillBody.idItemUnit_fk = ItemUnit.idItemUnit INNER JOIN
                                 Units ON ItemUnit.Unit_id_fk = Units.Unit_id
        WHERE        ReturnSalesBillBody.Return_bill_id_fk = 1

		
		 
       
		    ) A group by  A.AccCurr_id,a.Exching order by a.AccCurr_id




            */
            #endregion

        }
        string GetEntryHeadNote(string Entry_id="-1")
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
          query = "  SELECT ";
            query += "  Note   ";
            query += "  FROM            EntriesHead   ";
            query += "   WHERE        Entry_id =   "+ Entry_id;
            if (dt != null && dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString();
            else return string.Empty;

            /*
            SELECT      
          Note
        FROM            EntriesHead
        WHERE        Entry_id = 1
            */
        }
        void EditStatePosting(string Support_id,string idOpra)
        {

            string query = string.Empty;
            if(idOpra=="2")
            query += " UPDATE [dbo].[SupportCatchHead] ";
            else if(idOpra == "3")
            query += " UPDATE [dbo].[SupportExchangHead] ";
            else if (idOpra == "6")
                query += " UPDATE [dbo].[SalesBillHead] ";
            else if (idOpra == "7")
                query += " UPDATE [dbo].[ReturnSalesBillHead] ";
            else if(idOpra=="1")
                query += " UPDATE [dbo].[EntriesHead] ";
            else if (idOpra == "0")
                query += " UPDATE [dbo].[BalanceOpen] ";
            query += "   SET  ";
            query += "  [Posting] = 1 ";
            if (idOpra == "3"|| idOpra == "2")
                query += " WHERE [Support_id] = " + Support_id;
            else if(idOpra == "6")
                query += " WHERE [Bill_id] = " + Support_id;
            else if (idOpra == "7")
                query += " WHERE [Return_bill_id] = " + Support_id;
            else if (idOpra == "1")
                query += " WHERE Entry_id= "+ Support_id;


            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();


            /*
            
            */

        }
     public  void EditStateNonPosting(string Support_id, string idOpra)
        {

            string query = string.Empty;
            if (idOpra == "2")
                query += " UPDATE [dbo].[SupportCatchHead] ";
            else if (idOpra == "3")
                query += " UPDATE [dbo].[SupportExchangHead] ";
            else if (idOpra == "6")
                query += " UPDATE [dbo].[SalesBillHead] ";
            else if (idOpra == "7")
                query += " UPDATE [dbo].[ReturnSalesBillHead] ";
            else if (idOpra == "1")
                query += " UPDATE [dbo].[EntriesHead] ";
            else if (idOpra == "0")
                query += " UPDATE [dbo].[BalanceOpen] ";
            query += "   SET  ";
            query += "  [Posting] = 0 ";
            if (idOpra == "3" || idOpra == "2")
                query += " WHERE [Support_id] = " + Support_id;
            else if (idOpra == "6")
                query += " WHERE [Bill_id] = " + Support_id;
            else if (idOpra == "7")
                query += " WHERE [Return_bill_id] = " + Support_id;
            else if (idOpra == "1")
                query += " WHERE Entry_id= " + Support_id;


            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();


            /*
            
            */

        }
        DataTable GetDataBalanceOpen()
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
            query = "  SELECT ";

            query += "   AccCurr_id_fk  ";
            query += "  ,CurrExching  ";
            query += "  ,Debt_local  ";
            query += "  ,Credit_local  ";
            query += "  ,Debt_foreign  ";
            query += "  ,Credit_foreign  ";
            query += "  FROM  ";
            query += "  BalanceOpen  ";
            con.OpenConnetion();
          dt=  con.Query(query, true);
            con.CloseConnetion();
            return dt;
            #region
            /*
            SELECT      
            AccCurr_id_fk
            , CurrExching
            , Debt_local
            , Credit_local
            , Debt_foreign
            , Credit_foreign
             FROM   
             BalanceOpen
             */
            #endregion

            
        }

        public void PostSupportCatch(string Support_id,string idOpra,string User_id_fk)
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            switch (idOpra)
            {   
                case "1": dt = GetDataEntry(Support_id);break;
                case "2": dt = GetDataPostSupportCatch(Support_id); break;
                case "3": dt = GetDataPostSupportExchang(Support_id); break;
                case "6": dt = GetDataPostSales(Support_id); break;
                case "7": dt = GetDataPostSalesReturn(Support_id); break;
                case "0": dt = GetDataBalanceOpen(); break;
                default: MessageBox.Show("لم نعرف مانوع السند المرسل", "PostSupportCatch(idOpra)");break;
            }
           
           
            if (dt != null && dt.Rows.Count > 0)
            {
                DataTable dtDataPost = new DataTable();
                dtDataPost.Columns.Add("AccCurr_id", typeof(String));
                dtDataPost.Columns.Add("CurrExching", typeof(String));
                dtDataPost.Columns.Add("Debt_local", typeof(String));
                dtDataPost.Columns.Add("Credit_local", typeof(String));
                dtDataPost.Columns.Add("Debt_foreign", typeof(String));
                dtDataPost.Columns.Add("Credit_foreign", typeof(String));
            //    dtDataPost.Columns.Add("Note", typeof(String));
                for (int i=0;i< dt.Rows.Count; i++)
                {
                    dtDataPost.Rows.Add
                        (
                        dt.Rows[i][0].ToString(), //AccCurr_id
                        dt.Rows[i][1].ToString(), //CurrExching
                        dt.Rows[i][2].ToString(), //Debt_local
                        dt.Rows[i][3].ToString(), //Credit_local
                        dt.Rows[i][4].ToString(), //Debt_foreign
                        dt.Rows[i][5].ToString()  //Credit_foreign
                      //  dt.Rows[i][6].ToString()  //Note
                        );
                }

                decimal Debt_local = 0;
                decimal Credit_local = 0;
             
                for (int i = 0; i < dtDataPost.Rows.Count; i++)
                {
                   // MessageBox.Show(dtDataPost.Rows[i][3].ToString(), dtDataPost.Rows[i][2].ToString());
                    try
                    {
                        Debt_local += Convert.ToDecimal(dtDataPost.Rows[i][2].ToString());
                        Credit_local += Convert.ToDecimal(dtDataPost.Rows[i][3].ToString());

                    }
                    catch (Exception ee)
                    {
                        MessageBox.Show(ee.ToString());
                    }
                }
          
                try {  
                if (Debt_local == Credit_local)
                {

                    string
                         note = Support_id;
                        if (idOpra == "2")
                            note += " سند قبض رقم   ";
                        else if (idOpra == "3")
                            note += " سند صرف رقم   ";
                        else if (idOpra == "6")
                            note += " فاتورة مبيعات رقم   ";
                        else if (idOpra == "7")
                            note += " مردود مبيعات رقم   ";
                        else if (idOpra == "1")
                            note += GetEntryHeadNote(note);
                        else if(idOpra == "0") note = " رصيد افتتاحي   ";

                        string idPost = InsertNewPostingHaed
                           (idOpra,
                           Debt_local.ToString(),
                        DateTime.Now.ToString("yyyy/MM/dd").ToString(),
                           note,
                           Support_id,
                           User_id_fk);
                   
                        for (int i = 0; i < dtDataPost.Rows.Count; i++)
                        {
                           
                          //  MessageBox.Show("end rows"+i);

                            InsertNewPostingBody
                            (
                            idPost,
                            dtDataPost.Rows[i][0].ToString(), //AccCurrId
                            dtDataPost.Rows[i][2].ToString(),//Debt_local
                            dtDataPost.Rows[i][3].ToString(),//Credit_local
                            dtDataPost.Rows[i][4].ToString(), //Debt_foreign
                            dtDataPost.Rows[i][5].ToString(),//Credit_foreign
                         note,
                         DateTime.Now.ToString("yyyy/MM/dd").ToString(),
                            dtDataPost.Rows[i][1].ToString() //Exching
                            );
                        
                        }
                        EditStatePosting(Support_id, idOpra);
             
                    MessageBox.Show("تمت عملية الترحيل بنجاح", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }
                else MessageBox.Show("لم يتم الترحيل لان القيد غير متزن\n" + "اجمالي مدين = " + Debt_local + "\n" + " اجمالي دائن=  " + Credit_local, "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
                catch (Exception ee) { MessageBox.Show(ee.ToString()); }
            }
            else MessageBox.Show("لم يتم العثور ع بيانات لترحيلها", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);

         


        }

        #endregion



        #endregion

    }
}
