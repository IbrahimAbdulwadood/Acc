﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AccSystem.ClassesProject
{
    class RecoverDatabasesqlcs
    {
       SqlConnection scon = new SqlConnection(@"Server=.;DataBase=master;Integrated Security=True");
        SqlCommand cmd;
        public void Recoverdatabase()
        {
         

            OpenFileDialog op = new OpenFileDialog();
            op.Filter = "Backup Files (*.Bak)|*.Bak";
            if (op.ShowDialog() == DialogResult.OK)
            {
                cmd = new SqlCommand("Restore Database AccSysDB1 From Disk='" + op.FileName + "'", scon);
                scon.Open();
                cmd.ExecuteNonQuery();
                scon.Close();
               
            }

        }
    }
}
