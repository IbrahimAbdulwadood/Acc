﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace AccSystem.ClassesProject
{
    class SpulliersSql: AccDefintionSQL
    {
        ConnectionDB con = new ConnectionDB();
        AccountSQL Acc = new AccountSQL();
        DataTable dt;


        public DataTable GetAllSuplliers()
        {
            string query = "SELECT dbo.Suplliers.Supllier_id, dbo.Suplliers.Supller_name, dbo.Suplliers.Address, dbo.Suplliers.Phone, dbo.Suplliers.Email, dbo.Accounts.Acc_name, " +
                  " dbo.Suplliers.Acc_id_fk,dbo.Suplliers.Note FROM  dbo.Accounts INNER JOIN" +
                  " dbo.Suplliers ON dbo.Accounts.Acc_id = dbo.Suplliers.Acc_id_fk";

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
        public void UpdateCurrentsuplliers(string Supllier_id, string Supller_name, string Address, string phone, string Email,string Note)
        {
            con.OpenConnetion();
            string query = "UPDATE [dbo].[Suplliers] SET  [Supller_name]=@Supller_name ,[Address]=@Address ,[Phone] =@Phone ,[Email] =@Email ,[Note] =@Note  WHERE [Supllier_id] =@Supllier_id";


            SqlCommand myCommend = new SqlCommand(query, con.conn);
            string[] Query = { "1", Supller_name, "1", "1", "1", "1", "1", "1" };
        //    Acc.InsertSpullie(Query);

            myCommend.Parameters.AddWithValue("@Supllier_id", Supllier_id);
            myCommend.Parameters.AddWithValue("@Supller_name", Supller_name);
            myCommend.Parameters.AddWithValue("@Address", Address);
            myCommend.Parameters.AddWithValue("@Phone", phone);
            myCommend.Parameters.AddWithValue("@Email", Email);
           // myCommend.Parameters.AddWithValue("@Acc_id_fk", @Acc_id_fk);
            myCommend.Parameters.AddWithValue("@Note", Note);
            myCommend.ExecuteNonQuery();
            con.CloseConnetion();
            MessageBox.Show("  تم التعدل ");
        }


        
        public void InsertSpullier(String Supllier_id, String Supller_name, String Acc_id_fk, String Address, String phone, String Email, string Note)
        {
            string query = "INSERT INTO Suplliers(Supllier_id ,Supller_name,Acc_id_fk ,Address ,Phone ,Email ,Note )";
            query += " VALUES("+GetMaxId()+",@Supller_name ,@Acc_id_fk ,@Address ,@Phone ,@Email ,@Note )";
            con.OpenConnetion();

            SqlCommand myCommend = new SqlCommand(query, con.conn);
            string[] QueryAcc = { "1", Supller_name, "1", "1", "1", "1", "1", "1" };
         //   Acc.InsertSpullie(QueryAcc);
            //   myCommend.Parameters.AddWithValue("@Supllier_id", Supllier_id);
            myCommend.Parameters.AddWithValue("@Supller_name", Supller_name);
            myCommend.Parameters.AddWithValue("@Address", Address);
            myCommend.Parameters.AddWithValue("@Phone", phone);
            myCommend.Parameters.AddWithValue("@Email", Email);
            myCommend.Parameters.AddWithValue("@Acc_id_fk", Acc_id_fk);
            myCommend.Parameters.AddWithValue("@Note", Note);

            myCommend.ExecuteNonQuery();
          
            con.CloseConnetion();
            // con.Query(query,false);

        }

        //
        public string GetMaxId()
        {
            string id;

            string query = "SELECT isnull(max([Supllier_id]),0)+1 From Suplliers";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;
        }
        public DataTable Serch(string txtSerch)
        {
            
        string query = "SELECT dbo.Suplliers.Supllier_id, dbo.Suplliers.Supller_name, dbo.Suplliers.Address, dbo.Suplliers.Phone, dbo.Suplliers.Email, dbo.Accounts.Acc_name, " +
                  " dbo.Suplliers.Acc_id_fk,dbo.Suplliers.Note FROM  dbo.Accounts INNER JOIN" +
                  " dbo.Suplliers ON dbo.Accounts.Acc_id = dbo.Suplliers.Acc_id_fk where([Supllier_id] like '%" + txtSerch + "%') or([Supller_name] like '%" + txtSerch + "%')   or([Address] like '%" + txtSerch + "%') or([Phone] like '%" + txtSerch + "%') or([Email] like '%" + txtSerch + "%') or([Acc_name] like '%" + txtSerch + "%')or([Acc_id_fk] like '%" + txtSerch + "%') or([Note] like '%" + txtSerch + "%')";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
        public string[] GetAccsupllier()
        { //ترجع في مصفوفة حسابات  الموردين المرتبطة
            string query = "SELECT [Acc_id_fk] FROM [dbo].[Suplliers]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            string[] accsupllier = new string[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                accsupllier[i] = dt.Rows[i][0].ToString();
            }

            return accsupllier;

        }

        public DataTable GetAllAcc()
        {//ترجع جميع حسابات الموردين الموجودة في الدليل المحاسبي
            string query = "SELECT [Acc_id] ,[Acc_name] FROM [dbo].[Accounts] where [Acc_id_father]=" +GetIdAccSuplliersFather();
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }
        // باقي في واجهة اموردين عند الضغط على f9يظهر list حق حسابات الموردين 


        public string[] Getsupllierslist()
        { //ترجع في مصفوفة   الموردين المرتبطة
            string query = "SELECT  [Supller_id_fk]  FROM [dbo].[SupplyStoreHead]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            string[] supllier = new string[dt.Rows.Count];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                supllier[i] = dt.Rows[i][0].ToString();
            }

            return supllier;

        }
        public DataTable GetAllSupplierlist()
        {//ترجع جميع  الموردين الموجودة 
            string query = "SELECT [Supllier_id] ,[Supller_name] FROM [dbo].[Suplliers]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;

        }

    }
}
