﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AccSystem.ClassesProject
{
    class StoreSql
    {
        ConnectionDB con = new ConnectionDB();
        DataTable dt;


        public DataTable GetAllStores()
        {
            string query = "SELECT * FROM[dbo].[Stores]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
        public void UpdateStore(string Store_id, string Store_name, string Store_address, string Store_phone, string Store_Note)
        {
            con.OpenConnetion();
            string query = " UPDATE Stores SET Store_name = @Store_name ,Store_address = @Store_address ,Store_phone = @Store_phone , Store_Note = @Store_Note  WHERE Store_id = @Store_id ";
            SqlCommand com = new SqlCommand(query, con.conn);
            com.Parameters.AddWithValue("@Store_id", Store_id);
            com.Parameters.AddWithValue("@Store_name", Store_name);
            com.Parameters.AddWithValue("@Store_address", Store_address);
            com.Parameters.AddWithValue("@Store_phone", Store_phone);
            com.Parameters.AddWithValue("@Store_Note", Store_Note);


            com.ExecuteNonQuery();
            //  con.Query(query, false);
            con.CloseConnetion();
            MessageBox.Show("تم التعديل");
        }


        //
        public void InsertNewStores(string Store_id,string Store_name ,string Store_address,string Store_phone,string Store_Note)
        {
            

            string query = " INSERT INTO [dbo].[Stores] ([Store_id] ,[Store_name] ,[Store_address] ,[Store_phone] ,[Store_Note])";
     
   query+=" VALUES   (" + GetMaxId() + ",'" + Store_name + "' ,'" + Store_address + "'  ," + Store_phone + "  ,'" + Store_Note + "'   )";

            con.OpenConnetion();
            con.Query(query, false);

            con.CloseConnetion();


        }


        //
        public string GetMaxId()
        {
            string id;

            string query = "SELECT isnull(max([Store_id]),0)+1 From Stores";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;
        }

        public DataTable Serch(string txtSerch)
        {
            string query = "SELECT * FROM[dbo].[Stores] where([Store_id] like '%" + txtSerch + "%') or([Store_name] like '%" + txtSerch + "%') or([Store_address] like '%" + txtSerch + "%')  or([Store_phone] like '%" + txtSerch + "%')  or([Store_Note] like '%" + txtSerch + "%')";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
    }

        }

