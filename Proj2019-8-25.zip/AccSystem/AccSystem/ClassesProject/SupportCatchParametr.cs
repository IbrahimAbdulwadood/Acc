﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccSystem.ClassesProject
{
  public  class SupportCatchParametr
    {
        public string SupportBody_id { set; get; }
        public string Acc_id_fk { set; get; }
        public string Acc_name { set; get; }
        public string Curr_name { set; get; }
        public string Curr_id { set; get; }
        public string AccCurr_id { set; get; }
        public string Curr_echange { set; get; }
        public string Credit_local { set; get; } //سند القبض
        public string Credit_foreign { set; get; } //سند القبض
        public string Note { set; get; }
        public string Box_id { set; get; }
        public string Box_name { set; get; }
        public string BoxUser_id { set; get; }
       
    }
}
