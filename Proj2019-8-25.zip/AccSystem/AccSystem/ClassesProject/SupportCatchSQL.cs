﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccSystem.ClassesProject
{
    class SupportCatchSQL
    {
        DataTable dt;
        ConnectionDB con = new ConnectionDB();




        ///////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// any Method Done Dawon
        /// </summary>
        /// <returns></returns>
        /// 

        public void Delet(string Support_id = "-1")
        {
            //[]
            string query = " DELETE FROM[dbo].[SupportCatchHead]   WHERE Support_id = " + Support_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            /* DELETE FROM[dbo].[SupportExchangHead]
         WHERE Support_id = 1 
         */
        }
        public string GetMaxIdSupportCatchHead()
        {
            //Done
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query = " SELECT isnull(max([Support_id]),0)+1 From [SupportCatchHead]";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();

            return id;

        }

  
        public string InsertNewSupportCatchHead
          (string Date_support_catch, string BoxUser_id_fk, string Debt_local,
          string Debt_foreign, string CurrExching,string Note,string Refr_id, string payee
            , string TotalWord
          )
        {
            //Doneee
            #region
            
            
                 /*
        
       
INSERT INTO [dbo].[SupportCatchHead]
           ([Support_id]
           ,[Date_support_catch]
           ,[Box_id_fk]
           ,[Debt_local]
           ,[Debt_foreign]
           ,[CurrExching]
           ,[Note]
           ,[payee]
           ,[User_id_fk])
     VALUES
           (2
           ,'2019-05-05'
           ,1
           ,9.9
           ,0
           ,1
           ,'Note'
           ,'moha'
           ,1)
        */

           
            #endregion
            string Support_id = GetMaxIdSupportCatchHead();
           
          
            string
            query = "   INSERT INTO[dbo].[SupportCatchHead]";
            query += "   ([Support_id] ";
            query += "    ,[Date_support_catch] ";
            query += "     ,[BoxUser_id_fk] ";
            query += "  ,[Debt_local]  ";
            query += "    ,[Debt_foreign] ";
            query += "  ,[CurrExching] ";
            query += "       ,[Note] ";
            query += "       ,[Refr_id]";//
            query += "   ,[Posting] ";
            query += "   ,[TotalWord] ";
            query += "   ,[payee]) ";
            query += "   VALUES ( ";
            query += Support_id;
            query += "  ," + con.AddApostropheToString(Date_support_catch);
            query += "  ," + BoxUser_id_fk;
            query += "  , " + Debt_local;
            query += "  , " + Debt_foreign;
            query += "  , " + CurrExching;
            query += " ," + con.AddApostropheToString(Note);
            query += "  , " + Refr_id;
            query += "  , 0";
            query += " ," + con.AddApostropheToString(TotalWord);
            query += " ," + con.AddApostropheToString(payee);
        
            query += "  ) ";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            

            return Support_id;
        }
        public DataTable GetAllSupportCatchHead()
        { //Done
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string
            query = " SELECT   ";
      
            query += "   SupportCatchHead.Support_id, ";
            query += "   SupportCatchHead.Date_support_catch, ";
            query += "   Boxes.Box_id,  ";
            query += "   Boxes.Box_name,  ";
            query += "   Accounts.Acc_id, ";
            query += "   Accounts.Acc_name, ";
            query += "   Currencys.Curr_sumbol_eng,  ";
            query += "   SupportCatchHead.Debt_local,  ";
            query += "   SupportCatchHead.Debt_foreign, ";
            query += "   SupportCatchHead.CurrExching, ";
            query += "   SupportCatchHead.Note, ";
         
            query += "   SupportCatchHead.payee, ";
            query += "   Users.User_id, ";
            query += "   Users.User_name, ";
            query += "   SupportCatchHead.BoxUser_id_fk ,  ";
            query += "   SupportCatchHead.Refr_id ,     ";
            query += "   SupportCatchHead.Posting  ,  "; 
            query += "   SupportCatchHead.TotalWord ,   ";
            query += "   Currencys.Curr_id as a  ";
            query += "   FROM AccCurrency INNER JOIN ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "   Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN";
            query += "   BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "   Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN ";
            query += "   SupportCatchHead ON BoxUser.BoxUser_id = SupportCatchHead.BoxUser_id_fk  ";
            query += "   order by  SupportCatchHead.Support_id  ";
            //

            #region
            /*
           
                 SELECT  
      
        SupportCatchHead.Support_id, 
        SupportCatchHead.Date_support_catch, 
        Boxes.Box_id,  
        Boxes.Box_name,  
        Accounts.Acc_id, 
        Accounts.Acc_name, 
        Currencys.Curr_sumbol_eng, 
        SupportCatchHead.Debt_local,  
        SupportCatchHead.Debt_foreign, 
        SupportCatchHead.CurrExching, 
        SupportCatchHead.Note, 
        SupportCatchHead.payee, 
        Users.User_id, 
        Users.User_name, 
        SupportCatchHead.BoxUser_id_fk , 
        SupportCatchHead.Refr_id ,  
        SupportCatchHead.Posting  ,
	    SupportCatchHead.TotalWord ,
	    Currencys.Curr_id
        FROM AccCurrency INNER JOIN 
                Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  
                Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN 
                Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN 
                Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN 
                SupportCatchHead ON BoxUser.BoxUser_id = SupportCatchHead.BoxUser_id_fk  
            /////////////////////////////////
          
            */
            #endregion

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
        }

        public string GetMaxIdSupportCatchBody(string Support_id_fk)
        {
            //Donee
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query = "SELECT isnull(max(SupportBody_id),0)+1 From SupportCatchBody where Support_id_fk=" + Support_id_fk;

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;

        }

        public void InsertNewSupportCatchBody
          (string Support_id_fk, string AccCurr_id_fk, 
          string Credit_local, string Credit_foreign 
            , string Note, string CurrExching
          )
        {
           
            string
            query = "  INSERT INTO[dbo].[SupportCatchBody]  ";
            query += "      ([Support_id_fk] ";
            query += "    ,[SupportBody_id] ";
            query += "  ,[AccCurr_id_fk] ";
            query += "     ,[Credit_local]  ";
            query += "   ,[Credit_foreign] ";
            query += "     ,[CurrExching] ";
          
            query += "  ,[Note]) ";
            query += "   VALUES ";
            query += "    ( "+ Support_id_fk;
            query += "   ,   "+GetMaxIdSupportCatchBody(Support_id_fk);
            query += "  ,  "+ AccCurr_id_fk;
            query += " ,  "+ Credit_local;
            query += " ,  "+ Credit_foreign;
            query += "  , "+ CurrExching;
      
            query += "  ,"+ con.AddApostropheToString(Note) + ") ";
          //  System.Windows.Forms.MessageBox.Show(query);
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
           INSERT INTO [dbo].[SupportCatchBody]
          ([Support_id_fk]
          ,[SupportBody_id]
          ,[AccCurr_id_fk]
          ,[Credit_local]
          ,[Credit_foreign]
          ,[CurrExching]
       
          ,[Note])
    VALUES
          (1
          ,2
          ,3
          ,1
          ,1
          ,1
      
          ,'ss')
           */
            #endregion

        }

        public DataTable GetAllSupportCatchBody(string Support_id_fk)
        {
            //Doneee
            dt = new DataTable();
            
            string
            query = "   SELECT ";
            query += "    SupportCatchBody.SupportBody_id, ";
            query += "   Accounts.Acc_id, ";
            query += "  Accounts.Acc_name,   ";
            query += "   Currencys.Curr_sumbol, ";
            query += "  SupportCatchBody.CurrExching, ";
            query += "   SupportCatchBody.Credit_local,  ";
            query += "     SupportCatchBody.Credit_foreign, ";
            query += "    SupportCatchBody.Note, ";
            query += "   SupportCatchBody.AccCurr_id_fk ";
            query += "    FROM AccCurrency INNER JOIN ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";
            query += "   SupportCatchBody ON AccCurrency.AccCurr_id = SupportCatchBody.AccCurr_id_fk INNER JOIN ";
            query += "      Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "   SupportCatchHead ON SupportCatchBody.Support_id_fk = SupportCatchHead.Support_id ";
            query += " WHERE(SupportCatchHead.Support_id = "+ Support_id_fk + ") ";
          
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
            #region
            /*

  SELECT        SupportCatchBody.SupportBody_id, Accounts.Acc_id, Accounts.Acc_name, Currencys.Curr_name, SupportCatchBody.CurrExching, SupportCatchBody.Credit_local, 
                   SupportCatchBody.Credit_foreign, SupportCatchBody.Note, SupportCatchBody.AccCurr_id_fk
FROM            AccCurrency INNER JOIN
                   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                   SupportCatchBody ON AccCurrency.AccCurr_id = SupportCatchBody.AccCurr_id_fk INNER JOIN
                   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                   SupportCatchHead ON SupportCatchBody.Support_id_fk = SupportCatchHead.Support_id
WHERE        (SupportCatchHead.Support_id = 1)


  */
            #endregion
        }
        public DataTable SerchSupportCatchHead(string txt="")
        { //Done
            if (dt != null)
                dt = null;
                dt = new DataTable();


            //string
            //query = "    SELECT ";

            //query += "    SupportCatchHead.Support_id, ";
            //query += "    SupportCatchHead.Date_support_catch, ";
            //query += "   Boxes.Box_id,  ";
            //query += "   Boxes.Box_name,  ";
            //query += "   Accounts.Acc_id, ";
            //query += "   Accounts.Acc_name, ";
            //query += "     Currencys.Curr_sumbol, ";
            //query += "     SupportCatchHead.Debt_local,  ";
            //query += "   SupportCatchHead.Debt_foreign, ";
            //query += "    SupportCatchHead.CurrExching, ";
            //query += "    SupportCatchHead.Note, ";
            //query += "    SupportCatchHead.payee, ";
            //query += "    Users.User_id, ";
            //query += "    Users.User_name ";

            //query += "    FROM AccCurrency INNER JOIN ";
            //query += "      Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            //query += "    Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN";
            //query += "   BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN ";
            //query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            //query += "      Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN ";
            //query += "  SupportCatchHead ON BoxUser.BoxUser_id = SupportCatchHead.BoxUser_id_fk  ";
            string
            query = " SELECT   ";

            query += "   SupportCatchHead.Support_id, ";
            query += "   SupportCatchHead.Date_support_catch, ";
            query += "   Boxes.Box_id,  ";
            query += "   Boxes.Box_name,  ";
            query += "   Accounts.Acc_id, ";
            query += "   Accounts.Acc_name, ";
            query += "   Currencys.Curr_sumbol_eng,  ";
            query += "   SupportCatchHead.Debt_local,  ";
            query += "   SupportCatchHead.Debt_foreign, ";
            query += "   SupportCatchHead.CurrExching, ";
            query += "   SupportCatchHead.Note, ";

            query += "   SupportCatchHead.payee, ";
            query += "   Users.User_id, ";
            query += "   Users.User_name, ";
            query += "   SupportCatchHead.BoxUser_id_fk ,  ";
            query += "   SupportCatchHead.Refr_id ,     ";
            query += "   SupportCatchHead.Posting  ,  ";
            query += "   SupportCatchHead.TotalWord ,   ";
            query += "   Currencys.Curr_id   ";
            query += "   FROM AccCurrency INNER JOIN ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "   Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN";
            query += "   BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "   Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN ";
            query += "   SupportCatchHead ON BoxUser.BoxUser_id = SupportCatchHead.BoxUser_id_fk  ";
            query += "   order by  SupportCatchHead.Support_id  ";

            query += "   where ";
            query += "    SupportCatchHead.Support_id like '%" + txt + "%' or ";
            query += "    SupportCatchHead.Date_support_catch like '%" + txt + "%' or  ";
            query += "    SupportCatchHead.Debt_local like '%" + txt + "%'  or  ";
            query += "    SupportCatchHead.Debt_foreign like '%" + txt + "%'  or  ";
            query += "    SupportCatchHead.payee like '%" + txt + "%'  or  ";
            query += "    SupportCatchHead.Note like '%" + txt + "%' ";

            #region
            /*
            SELECT        SupportCatchHead.Support_id, SupportCatchHead.Date_support_catch, Boxes.Box_id, Boxes.Box_name, Accounts.Acc_id, Accounts.Acc_name, 
                         Currencys.Curr_name, SupportCatchHead.Debt_local, SupportCatchHead.Debt_foreign, SupportCatchHead.CurrExching, SupportCatchHead.Note, 
                         SupportCatchHead.payee, Users.User_id, Users.User_name
FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                         BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                         Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN
                         SupportCatchHead ON BoxUser.BoxUser_id = SupportCatchHead.BoxUser_id_fk
						 where 
						  SupportCatchHead.Support_id like '%%' or 
						  SupportCatchHead.Date_support_catch like '%%' or
						  SupportCatchHead.Debt_local like '%%' or
						  SupportCatchHead.Debt_foreign like '%%' or
						   SupportCatchHead.payee like '%%' or
						   SupportCatchHead.Note like '%%'
            */
            #endregion

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
        }

        public void UpdateSupportCatchBody
           ( 
           string Support_id_fk, string SupportBody_id,
           string AccCurr_id_fk, string Credit_local, 
           string Credit_foreign, string Note,
           string CurrExching
           )
        {
            //Donee
            string
            query = "     UPDATE [dbo].[SupportCatchBody]  ";
            query += "   SET [AccCurr_id_fk] =  "+ AccCurr_id_fk;
            query += "   ,[Credit_local] = "+ Credit_local;
            query += "  ,[Credit_foreign] =  "+ Credit_foreign;
            query += "  ,[CurrExching] = "+ CurrExching;
            query += "    ,[Note] =  "+con.AddApostropheToString(Note);
            query += "  WHERE [Support_id_fk] = "+ Support_id_fk;
            query += " and [SupportBody_id] =  "+ SupportBody_id;
        
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
            
            UPDATE [dbo].[SupportCatchBody]
   SET [AccCurr_id_fk] = 3
      ,[Credit_local] = 0
      ,[Credit_foreign] = 0
      ,[CurrExching] = 0
      ,[Note] = ''
 WHERE [Support_id_fk] =1 and [SupportBody_id] =1
            */
            #endregion
        }
        public string GetAccCurrIdHaed(string BoxUserId)
        {
          //  System.Windows.Forms.MessageBox.Show(BoxUserId, "Error");

            if (dt != null)
                dt = null;
            dt = new DataTable();

            string
            query = "   SELECT    ";
            query += "   AccCurrency.AccCurr_id ";
            query += " FROM ";
            query += "   AccCurrency INNER JOIN ";
            query += "   Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN ";
            query += "  BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk ";
            query += " WHERE        (BoxUser.BoxUser_id =  "+ BoxUserId+")";
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null & dt.Rows.Count > 0)
            {
               // System.Windows.Forms.MessageBox.Show(dt.Rows[0][0].ToString(), "Error2");
                return dt.Rows[0][0].ToString();
            }
            else return "-1";


            #region
            /*
            SELECT        AccCurrency.AccCurr_id
FROM            AccCurrency INNER JOIN
                         Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                         BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk
WHERE        (BoxUser.BoxUser_id = 1)
            */
            #endregion
        }

        public void UpdateSupportCatchHaed
          (
        string Support_id, string Date_support_catch,
        string BoxUser_id_fk, string Debt_local,
        string Debt_foreign, string CurrExching,
        string Note, string payee,string Refr_id,
        string TotalWord
          )
        { //Doneee
            string
            query = "   UPDATE [dbo].[SupportCatchHead] ";
            query += "  SET ";
            query += "  [Date_support_catch] = "+con.AddApostropheToString(Date_support_catch);
            query += " ,[BoxUser_id_fk] = "+ BoxUser_id_fk;
            query += "   ,[Debt_local] = "+ Debt_local;
            query += "   ,[Debt_foreign] = "+ Debt_foreign;
            query += "   ,[CurrExching] ="+ CurrExching;
            query += "    ,[Note] ="+con.AddApostropheToString(Note);
            query += "    ,[Refr_id] =" + Refr_id;
            query += "    ,[payee] ="+con.AddApostropheToString(payee);
            query += "    ,[TotalWord] =" + con.AddApostropheToString(TotalWord);
            query += "  WHERE [Support_id] = "+ Support_id;

            
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            #region
            /*
       UPDATE [dbo].[SupportCatchHead]
  SET 
     [Date_support_catch] = '2019-9-9'
     ,[BoxUser_id_fk] = 1
     ,[Debt_local] = 0
     ,[Debt_foreign] = 0
     ,[CurrExching] = 0
     ,[Note] = ''
     ,[payee] = ''
WHERE [Support_id] = 1

       */
            #endregion

        }

        public void DeleteSupportCatchBody(string Support_id_fk, string SupportBody_id)
        {

            string
            query = "DELETE FROM [dbo].[SupportCatchBody]";
            query += "  WHERE Support_id_fk= " + Support_id_fk;
            query += " and SupportBody_id= " + SupportBody_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            #region
            /*
            DELETE FROM [dbo].[SupportCatchBody]
      WHERE Support_id_fk=1and SupportBody_id=3
            */
            #endregion
        }

    }
}
