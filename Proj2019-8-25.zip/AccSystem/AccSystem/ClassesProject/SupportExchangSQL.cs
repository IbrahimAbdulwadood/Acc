﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.ClassesProject
{
    class SupportExchangSQL
    {
        DataTable dt;
        ConnectionDB con = new ConnectionDB();

        public string GetMaxIdSupportExchangHead()
        {
            //^^
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query = " SELECT isnull(max([Support_id]),0)+1 From [SupportExchangHead]";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();

            return id;

        }
        public void Delet(string Support_id="-1")
        {
            string query = " DELETE FROM[dbo].[SupportExchangHead]   WHERE Support_id = "+ Support_id;
            con.OpenConnetion();
             con.Query(query, false);
            con.CloseConnetion();
            /* DELETE FROM[dbo].[SupportExchangHead]
         WHERE Support_id = 1 
         */
        }

        public string InsertNewSupportExchangHead
          (string Date_support_exchang, string BoxUser_id_fk, string Credit_local,
          string Credit_foreign, string CurrExching, string Note, string Refr_id, string payee
            , string TotalWord
          )
        {
            //^^
            #region


            /*


INSERT INTO [dbo].[SupportExchangHead]
           ([Support_id]
           ,[Date_support_exchang]
           ,[BoxUser_id_fk]
           ,[Credit_local]
           ,[Credit_foreign]
           ,[CurrExching]
           ,[Note]
           ,[payee]
           ,[Refr_id]
           ,[Posting]
           ,[TotalWord])
     VALUES
           (1
           ,''
           ,8
           ,9
           ,0
           ,1
           ,''
           ,''
           ,NULL
           ,0
           ,''
		   )
   */


            #endregion
            string Support_id = GetMaxIdSupportExchangHead();

          
        
            string
            query = "    INSERT INTO[dbo].[SupportExchangHead]";
            query += "   ([Support_id] ";
            query += "   ,[Date_support_exchang] ";
            query += "   ,[BoxUser_id_fk] ";
            query += "   ,[Credit_local]  ";
            query += "   ,[Credit_foreign] ";
            query += "   ,[CurrExching] ";
            query += "   ,[Note] ";
            query += "   ,[Refr_id]";//
            query += "   ,[Posting] ";
            query += "   ,[TotalWord] ";
            query += "   ,[payee]) ";
            query += "   VALUES ( ";
            query += Support_id;
            query += "  ," + con.AddApostropheToString(Date_support_exchang);
            query += "  ," + BoxUser_id_fk;
            query += "  , " + Credit_local;
            query += "  , " + Credit_foreign;
            query += "  , " + CurrExching;
            query += " ," + con.AddApostropheToString(Note);
            query += "  , " + Refr_id;
            query += "  , 0";
            query += " ," + con.AddApostropheToString(TotalWord);
            query += " ," + con.AddApostropheToString(payee);
            query += "  ) ";
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();


            return Support_id;
        }
        public DataTable GetAllSupportExchangHead()
        { //^^
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string
            query = " SELECT   ";
           
       
            query += "   SupportExchangHead.Support_id,  ";//
            query += "   SupportExchangHead.Date_support_exchang,  ";//
            query += "   Boxes.Box_id,  ";
            query += "   Boxes.Box_name,  ";
            query += "   Accounts.Acc_id, ";
            query += "   Accounts.Acc_name, ";
            query += "   Currencys.Curr_sumbol_eng,  ";
            query += "   SupportExchangHead.Credit_local,    ";//
            query += "   SupportExchangHead.Credit_foreign,  ";//
            query += "   SupportExchangHead.CurrExching,  ";
            query += "   SupportExchangHead.Note,  ";
            query += "   SupportExchangHead.payee, ";
            query += "   Users.User_id, ";
            query += "   Users.User_name, ";
            
            query += "  SupportExchangHead.BoxUser_id_fk ,   ";
            query += "  SupportExchangHead.Refr_id ,      ";
            query += "  SupportExchangHead.Posting  , ";
            query += "  SupportExchangHead.TotalWord ,   ";
            query += "  Currencys.Curr_id   ";
            query += "  FROM AccCurrency INNER JOIN ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "  Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN";
            query += "  BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "  Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN ";
            query += "  SupportExchangHead ON BoxUser.BoxUser_id = SupportExchangHead.BoxUser_id_fk    ";
            query += " order by   SupportExchangHead.Support_id ";

            #region
            /*
           
                 
SELECT  
      
        SupportExchangHead.Support_id, 
        SupportExchangHead.Date_support_exchang, 
        Boxes.Box_id,  
        Boxes.Box_name,  
        Accounts.Acc_id, 
        Accounts.Acc_name, 
        Currencys.Curr_sumbol_eng, 
        SupportExchangHead.Credit_local,  
        SupportExchangHead.Credit_foreign, 
        SupportExchangHead.CurrExching, 
        SupportExchangHead.Note, 
        SupportExchangHead.payee, 
        Users.User_id, 
        Users.User_name, 
        SupportExchangHead.BoxUser_id_fk , 
        SupportExchangHead.Refr_id ,  
        SupportExchangHead.Posting  ,
	    SupportExchangHead.TotalWord ,
	    Currencys.Curr_id
        FROM AccCurrency INNER JOIN 
                Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  
                Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN 
                Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN 
                Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN 
                SupportExchangHead ON BoxUser.BoxUser_id = SupportExchangHead.BoxUser_id_fk  
            /////////////////////////////////
          
            */
            #endregion

            con.OpenConnetion();
            dt = con.Query(query, true);
            if(dt.Rows.Count>0)
                //MessageBox.Show(dt.Rows.Count.ToString(), "GetAllSupportExchangHead()");
            con.CloseConnetion();

            return dt;
        }

        public string GetMaxIdSupportExchangBody(string Support_id_fk)
        {
            //^^
            if (dt == null)
                dt = new DataTable();
            else
                dt.Clear();

            string id;

            string query = "SELECT isnull(max(SupportBody_id),0)+1 From SupportExchangBody where Support_id_fk=" + Support_id_fk;

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;

        }

        public void InsertNewSupportExchangBody
          (string Support_id_fk, string AccCurr_id_fk,
          string Debt_local, string Debt_foreign
            , string Note, string CurrExching
          )
        {
            //^^
            string
            query = "  INSERT INTO[dbo].[SupportExchangBody]  ";
            query += "    ([Support_id_fk] ";
            query += "    ,[SupportBody_id] ";
            query += "    ,[AccCurr_id_fk] ";
            query += "    ,[Debt_local]  ";
            query += "    ,[Debt_foreign] ";
            query += "    ,[CurrExching] ";
            query += "    ,[Note]) ";
            query += "   VALUES ";
            query += "    ( " + Support_id_fk;
            query += "   ,   " + GetMaxIdSupportExchangBody(Support_id_fk);
            query += "  ,  " + AccCurr_id_fk;
            query += " ,  " + Debt_local;
            query += " ,  " + Debt_foreign;
            query += "  , " + CurrExching;

            query += "  ," + con.AddApostropheToString(Note) + ") ";
            //  System.Windows.Forms.MessageBox.Show(query);
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
          INSERT INTO [dbo].[SupportExchangBody]
          ([Support_id_fk]
          ,[SupportBody_id]
          ,[AccCurr_id_fk]
          ,[Debt_local]
          ,[Debt_foreign]
          ,[CurrExching]
       
          ,[Note])
    VALUES
          (1
          ,2
          ,8
          ,1
          ,1
          ,1
      
          ,'ss')
           */
            #endregion

        }

        public DataTable GetAllSupportExchangBody(string Support_id_fk)
        {
            //^^
            dt = new DataTable();
            
        
            string
            query = "   SELECT ";
            query += "  SupportExchangBody.SupportBody_id, ";
            query += "  Accounts.Acc_id, ";
            query += "  Accounts.Acc_name,   ";
            query += "  Currencys.Curr_sumbol, ";

            query += "  SupportExchangBody.CurrExching, ";
            query += "  SupportExchangBody.Debt_local,   ";
            query += "  SupportExchangBody.Debt_foreign,  ";
            query += "  SupportExchangBody.Note, ";
            query += "  SupportExchangBody.AccCurr_id_fk ";
            query += "    FROM AccCurrency INNER JOIN ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN ";

       query += " SupportExchangBody ON AccCurrency.AccCurr_id = SupportExchangBody.AccCurr_id_fk INNER JOIN  ";
            query += "      Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "  SupportExchangHead ON SupportExchangBody.Support_id_fk = SupportExchangHead.Support_id ";
            query += " WHERE(SupportExchangHead.Support_id = " + Support_id_fk + ") ";

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
            #region
            /*

   SELECT        SupportExchangBody.SupportBody_id, Accounts.Acc_id, Accounts.Acc_name, Currencys.Curr_name, SupportExchangBody.CurrExching, SupportExchangBody.Debt_local, 
                   SupportExchangBody.Debt_foreign, SupportExchangBody.Note, SupportExchangBody.AccCurr_id_fk
FROM            AccCurrency INNER JOIN
                   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                   SupportExchangBody ON AccCurrency.AccCurr_id = SupportExchangBody.AccCurr_id_fk INNER JOIN
                   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                   SupportExchangHead ON SupportExchangBody.Support_id_fk = SupportExchangHead.Support_id
WHERE        (SupportExchangHead.Support_id = 1)


  */
            #endregion
        }
        public DataTable SerchSupportExchangHead(string txt)
        { //^^
            if (dt != null)
                dt = null;
            dt = new DataTable();



            string
            query = " SELECT   ";


            query += "   SupportExchangHead.Support_id,  ";//
            query += "   SupportExchangHead.Date_support_exchang,  ";//
            query += "   Boxes.Box_id,  ";
            query += "   Boxes.Box_name,  ";
            query += "   Accounts.Acc_id, ";
            query += "   Accounts.Acc_name, ";
            query += "   Currencys.Curr_sumbol_eng,  ";
            query += "   SupportExchangHead.Credit_local,    ";//
            query += "   SupportExchangHead.Credit_foreign,  ";//
            query += "   SupportExchangHead.CurrExching,  ";
            query += "   SupportExchangHead.Note,  ";
            query += "   SupportExchangHead.payee, ";
            query += "   Users.User_id, ";
            query += "   Users.User_name, ";

            query += "  SupportExchangHead.BoxUser_id_fk ,   ";
            query += "  SupportExchangHead.Refr_id ,      ";
            query += "  SupportExchangHead.Posting  , ";
            query += "  SupportExchangHead.TotalWord ,   ";
            query += "  Currencys.Curr_id   ";
            query += "  FROM AccCurrency INNER JOIN ";
            query += "  Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "  Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN";
            query += "  BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "  Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN ";
            query += "  SupportExchangHead ON BoxUser.BoxUser_id = SupportExchangHead.BoxUser_id_fk    ";


            query += "   where ";
            query += "    SupportExchangHead.Support_id like '%" + txt + "%' or ";
            query += "    SupportExchangHead.Date_support_exchang like '%" + txt + "%' or  ";
            query += "    SupportExchangHead.Credit_local like '%" + txt + "%'  or  ";
            query += "    SupportExchangHead.Credit_foreign like '%" + txt + "%'  or  ";
            query += "    SupportExchangHead.payee like '%" + txt + "%'  or  ";
            query += "    SupportExchangHead.Note like '%" + txt + "%' ";

            #region
            /*
          SELECT  
      
        SupportExchangHead.Support_id, 
        SupportExchangHead.Date_support_exchang, 
        Boxes.Box_id,  
        Boxes.Box_name,  
        Accounts.Acc_id, 
        Accounts.Acc_name, 
        Currencys.Curr_sumbol_eng, 
        SupportExchangHead.Credit_local,  
        SupportExchangHead.Credit_foreign, 
        SupportExchangHead.CurrExching, 
        SupportExchangHead.Note, 
        SupportExchangHead.payee, 
        Users.User_id, 
        Users.User_name, 
        SupportExchangHead.BoxUser_id_fk , 
        SupportExchangHead.Refr_id ,  
        SupportExchangHead.Posting  ,
	    SupportExchangHead.TotalWord ,
	    Currencys.Curr_id
        FROM AccCurrency INNER JOIN 
                Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  
                Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN 
                Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN 
                Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN 
                SupportExchangHead ON BoxUser.BoxUser_id = SupportExchangHead.BoxUser_id_fk  
				where     SupportExchangHead.Support_id like '%%' or 
						  SupportExchangHead.Date_support_exchang like '%%' or
						  SupportExchangHead.Credit_local like '%%' or
						  SupportExchangHead.Credit_foreign like '%%' or
						   SupportExchangHead.payee like '%%' or
						   SupportExchangHead.Note like '%%'
            */
            #endregion

            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();

            return dt;
        }

        public void UpdateSupportExchangBody
           (
           string Support_id_fk, string SupportBody_id,
           string AccCurr_id_fk, string Debt_local,
           string Debt_foreign, string Note,
           string CurrExching
           )
        {
            //^^
            string
            query = "     UPDATE [dbo].[SupportExchangBody]  ";
            query += "   SET [AccCurr_id_fk] =  " + AccCurr_id_fk;
            query += "   ,[Debt_local] = " + Debt_local;
            query += "  ,[Debt_foreign] =  " + Debt_foreign;
            query += "  ,[CurrExching] = " + CurrExching;
            query += "    ,[Note] =  " + con.AddApostropheToString(Note);
            query += "  WHERE [Support_id_fk] = " + Support_id_fk;
            query += " and [SupportBody_id] =  " + SupportBody_id;

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
            
            UPDATE [dbo].[SupportExchangBody]
   SET [AccCurr_id_fk] = 9
      ,[Debt_local] = 0
      ,[Debt_foreign] = 0
      ,[CurrExching] = 0
      ,[Note] = ''
 WHERE [Support_id_fk] =1 and [SupportBody_id] =2

            */
            #endregion
        }
        public string GetAccCurrIdHaed(string BoxUserId)
        {
            //  System.Windows.Forms.MessageBox.Show(BoxUserId, "Error");

            if (dt != null)
                dt = null;
            dt = new DataTable();

            string
            query = "   SELECT    ";
            query += "   AccCurrency.AccCurr_id ";
            query += " FROM ";
            query += "   AccCurrency INNER JOIN ";
            query += "   Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN ";
            query += "  BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk ";
            query += " WHERE        (BoxUser.BoxUser_id =  " + BoxUserId + ")";
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null & dt.Rows.Count > 0)
            {
                // System.Windows.Forms.MessageBox.Show(dt.Rows[0][0].ToString(), "Error2");
                return dt.Rows[0][0].ToString();
            }
            else return "-1";


            #region
            /*
            SELECT        AccCurrency.AccCurr_id
FROM            AccCurrency INNER JOIN
                         Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                         BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk
WHERE        (BoxUser.BoxUser_id = 1)
            */
            #endregion
        }

        public void UpdateSupportExchangHead
          (
        string Support_id, string Date_support_exchang,
        string BoxUser_id_fk, string Credit_local,
        string Credit_foreign, string CurrExching,
        string Note, string payee, string Refr_id,
        string TotalWord
          )
        { //^^
            string
            query = "   UPDATE [dbo].[SupportExchangHead] ";
            query += "  SET ";
            query += "  [Date_support_exchang] = " + con.AddApostropheToString(Date_support_exchang);
            query += " ,[BoxUser_id_fk] = " + BoxUser_id_fk;
            query += "   ,[Credit_local] = " + Credit_local;
            query += "   ,[Credit_foreign] = " + Credit_foreign;
            query += "   ,[CurrExching] =" + CurrExching;
            query += "    ,[Note] =" + con.AddApostropheToString(Note);
            query += "    ,[Refr_id] =" + Refr_id;
            query += "    ,[payee] =" + con.AddApostropheToString(payee);
            query += "    ,[TotalWord] =" + con.AddApostropheToString(TotalWord);
            query += "  WHERE [Support_id] = " + Support_id;


            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            #region
            /*
       UPDATE [dbo].[SupportExchangHead]
  SET 
     [Date_support_exchang] = '2019-9-9'
     ,[BoxUser_id_fk] = 8
     ,[Credit_local] = 0
     ,[Credit_foreign] = 0
     ,[CurrExching] = 0
     ,[Note] = ''
     ,[payee] = ''
WHERE [Support_id] = 1

       */
            #endregion

        }

        public void DeleteSupportExchangBody(string Support_id_fk, string SupportBody_id)
        {

            string
            query = "DELETE FROM [dbo].[SupportExchangBody]";
            query += "  WHERE Support_id_fk= " + Support_id_fk;
            query += " and SupportBody_id= " + SupportBody_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            #region
            /*
            DELETE FROM [dbo].[SupportExchangBody]
      WHERE Support_id_fk=1and SupportBody_id=2
            */
            #endregion
        }


    }
}
