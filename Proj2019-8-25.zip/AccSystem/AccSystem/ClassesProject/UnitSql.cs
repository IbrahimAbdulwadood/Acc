﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AccSystem.ClassesProject
{
    class UnitSql
    {
        ConnectionDB con = new ConnectionDB();
        DataTable dt;


        public DataTable GetAllUnit()
        {
            string query = "SELECT [Unit_id] ,[Unit_name]  ,[Unit_refill] ,[Unit_part] FROM [dbo].[Units]";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
        #region الحذف
        public List<string> ChaeckCanDelet(string Item_id_fk = "-1")
        {
            List<string> UnitItem_id = GetItem4Unit(Item_id_fk);
            return UnitItem_id;

        }
        List<string> GetItem4Unit(string Unit_id_fk = "-1")
        {
            List<string> data = new List<string>();
            string query = "SELECT  Item_id_fk FROM  ItemUnit WHERE    Unit_id_fk = " + Unit_id_fk;
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;

            /*
           SELECT  Item_id_fk FROM ItemUnit WHERE   Unit_id_fk = 1
            */
        }
        public void Delet(string Unit_id = "-1")
        {
            string
                    query = "   DELETE FROM [dbo].[Units]  WHERE Unit_id= " + Unit_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();
            /*
           DELETE FROM [dbo].[Units]  WHERE Unit_id=1
            */
        }
        #endregion

        //
        public void InsertNewUnit(String Curr_id, String Curr_name, String Curr_sumbol, String Curr_sumbol_eng)
        {
            string query = " INSERT INTO [dbo].[Units]([Unit_id] ,[Unit_name] ,[Unit_refill],[Unit_part]) " + "";


            query += " VALUES   (" + GetMaxId() + ",'" + Curr_name + "','" + Curr_sumbol + "','" + Curr_sumbol_eng + "')";

            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();


        }


        //
        public string GetMaxId()
        {
            string id;

            string query = "SELECT isnull(max([Unit_id]),0)+1 From Units";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();

            id = dt.Rows[0][0].ToString();
            return id;
        }
        public void UpdateUnit(string Unit_id, string Unit_name, string Unit_refill, string Unit_part)
        {
            con.OpenConnetion();
            string query = "UPDATE [dbo].[Units] SET   [Unit_name] = @Unit_name  ,[Unit_refill] =@Unit_refill  ,[Unit_part] =@Unit_part  WHERE [Unit_id]=@Unit_id";
            SqlCommand com = new SqlCommand(query, con.conn);
            com.Parameters.AddWithValue("@Unit_id", Unit_id);
            com.Parameters.AddWithValue("@Unit_name", Unit_name);
            com.Parameters.AddWithValue("@Unit_refill", Unit_refill);
            com.Parameters.AddWithValue("@Unit_part", Unit_part);
            com.ExecuteNonQuery();
            //  con.Query(query, false);
            con.CloseConnetion();
            //  MessageBox.Show("تم التعديل");
        }

        public DataTable Serch(string txtSerch)
        {
            string query = "SELECT * FROM[dbo].[Units] where([Unit_id] like '%" + txtSerch + "%' or([Unit_name] like '%" + txtSerch + "%') or([Unit_refill] like '%" + txtSerch + "%')  or([Unit_part] like '%" + txtSerch + "%'))";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            return dt;
        }
     

    }
}
