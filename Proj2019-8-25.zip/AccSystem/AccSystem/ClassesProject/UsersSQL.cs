﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace AccSystem.ClassesProject
{
    
    class UsersSQL
    {
        ConnectionDB con = new ConnectionDB();
        DataTable dt;
        #region الحذف
        public DataTable GetBoxUserId4User(string User_id_fk)
        {
            string
            q = "   SELECT   BoxUser_id FROM  BoxUser WHERE User_id_fk =   "+ User_id_fk;
          
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            return dt;

            /*
           SELECT   BoxUser_id FROM  BoxUser WHERE User_id_fk = 1
            */
        }
        public DataTable GetBoxUserOprtion(string BoxUser_id)
        {
            /*
            ترجع لي الصناديق او العملاء اي اي مجموعه مخزنية مرتبطة مع حسابات عملات المحدد
            */

            string
            q = "  SELECT  Bill_id  FROM  SalesBillHead  WHERE   BoxUser_id_fk =  "+ BoxUser_id;
            q += "    union all  ";
            q += " SELECT   Return_bill_id    FROM   ReturnSalesBillHead   WHERE  BoxUser_id_fk = "+ BoxUser_id;
            q += "    union all  ";
            q += " SELECT   Support_id FROM SupportExchangHead   WHERE BoxUser_id_fk =  "+ BoxUser_id;
            q += "    union all  ";
            q += " SELECT Support_id  FROM  SupportCatchHead  WHERE  BoxUser_id_fk = "+ BoxUser_id;


            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            return dt;

            #region
            /*
                SELECT  Bill_id  FROM  SalesBillHead  WHERE   BoxUser_id_fk = 5
                union all
                SELECT   Return_bill_id    FROM   ReturnSalesBillHead   WHERE  BoxUser_id_fk = 5
                union all
                SELECT   Support_id FROM SupportExchangHead   WHERE BoxUser_id_fk = 5
                union all
                SELECT Support_id  FROM  SupportCatchHead  WHERE  BoxUser_id_fk = 5
          */
            #endregion

        }
      public  List<string> GetOprationWithOutBox(string User_id)
        { List<string> data = new List<string>();
            string
           q = "   SELECT Serial_number_balance  FROM   BalanceOpen  WHERE User_id_fk =  " + User_id;
            q += "    union all  ";
            q += "  SELECT  Dayly_id FROM  DaylyHaed   WHERE User_id_fk =    " + User_id;
            q += "    union all  ";
            q += "  SELECT Entry_id  FROM EntriesHead  WHERE User_id_fk =   " + User_id;
            q += "    union all  ";
            q += "  SELECT id FROM  FirstBalanceBody   WHERE  User_id_fk =    " + User_id;

            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(q, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                for (int i = 0; i < dt.Rows.Count; i++)
                    data.Add(dt.Rows[i][0].ToString());
            return data;


            /*
              SELECT Serial_number_balance  FROM   BalanceOpen  WHERE User_id_fk = 1
                union all
                SELECT  Dayly_id FROM  DaylyHaed   WHERE User_id_fk = 1
                union all
                SELECT Entry_id  FROM EntriesHead  WHERE User_id_fk = 1
                union all
                SELECT id FROM  FirstBalanceBody   WHERE  User_id_fk = 1
            */
        }

        public void Delet(string User_id="-1")
        {
            string
           q = "  DELETE FROM [dbo].[Users] WHERE User_id= " + User_id;
            con.OpenConnetion();
            con.Query(q, false);
            con.CloseConnetion();
            /*
            DELETE FROM [dbo].[Users] WHERE User_id=1
            */
        }
        #endregion
        public DataTable GetAllUser()
        {
            try {
                if (dt != null)
                    dt = null;
                dt = new DataTable();

                string
            query = "  SELECT [User_id]   ";
            query += " ,[User_name] ";
            query += " ,[Discount] ";
            query += " ,[Discount_percentage] ";
            query += " ,[State] ";
            query += " ,[SaleLater] ";
            query += " FROM [dbo].[Users] ";
           // query += " FROM [dbo].[Users] ";
               
    
     
     
  
       

        con.OpenConnetion();
          
                dt = con.Query(query, true);
                //System.Windows.Forms.MessageBox.Show(dt.Rows.Count.ToString());
                con.CloseConnetion();
                
                return dt;
            }
            catch (Exception e) {
                System.Windows.Forms.MessageBox.Show(e.ToString());
                return dt;
            }
            #region
            /*
             
SELECT [User_id]
      ,[User_name]
      ,[Discount]
      ,[Discount_percentage]
      ,[State]
  FROM [dbo].[Users]
            */
            #endregion


        }
        public string GetMaxIdUser()
        {
            string
            query = "  SELECT isnull(max([User_id]),0)+1 From [Users]   ";

            if (dt != null)
                dt = null;
            dt = new DataTable();
            con.OpenConnetion();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt.Rows.Count > 0 && dt != null)
            {
                System.Windows.Forms.MessageBox.Show(dt.Rows[0][0].ToString());
                return dt.Rows[0][0].ToString();
            }
                
                return null;
            /*

              SELECT isnull(max([User_id]),0)+1 From [Users]
            */
        }

    

       

        public string InsertNewUser(  string User_name
                                    ,string Discount
                                    ,string Discount_percentage 
                                    , string State
                                   ,string SaleLater
                                   )

        {
            string idUser = GetMaxIdUser();
            string
            query = "  INSERT INTO [dbo].[Users]    ";
            query += "  ([User_id] ";
            query += " ,[User_name] ";
            query += "  ,[password] ";
            query += "  ,[Discount] ";
            query += "    ,[Discount_percentage] ";
            query += "    ,[SaleLater] ";
            query += "   ,[State]) ";
            query += "    VALUES  ";
            query += "  ("+ idUser;
            query += "  ,"+con.AddApostropheToString(User_name);
            query += "  ,"+con.AddApostropheToString("1");
            query += "  ,"+ Discount;
            query += "  ,"+ Discount_percentage;
            query += "  ,"+ SaleLater;
            query += "  ," + State;
            query += "    ) ";
       

            con.OpenConnetion();
           con.Query(query, false);
            con.CloseConnetion();
            return idUser;
            #region
            /*
            INSERT INTO [dbo].[Users]
           ([User_id]
           ,[User_name]
           ,[password]
           ,[Discount]
           ,[Discount_percentage]
           ,[State])
     VALUES
           (4
           ,''
           ,''
           ,0
           ,12
           ,0
		   )
            */
            #endregion

        }

        public string GetNameUser(string idUser)
        {
            string
            query = " SELECT    ";
            query += " [User_name] ";
            query += " FROM [dbo].[Users] ";
            query += " where ";
            query += " [User_id]= ";
            query += idUser;
            if (dt != null)
                dt = null;
            dt = new DataTable();
            con.OpenConnetion();
          dt=con.Query(query, true);
            con.CloseConnetion();

            if (dt != null && dt.Rows.Count > 0)
                return dt.Rows[0][0].ToString();
                #region الاستعلام
                /*
                SELECT [User_name] FROM [dbo].[Users] where [User_id]=1
                */
                #endregion
                return null;
        }
        public Dictionary<string, string> Login(string idUser="-1",string pass="-1")
        {
            #region
            /*
            SELECT        User_id, User_name
FROM            Users
WHERE        (password = '1') AND (User_id = 1)
            */
            #endregion
            if (dt != null)
                dt = null;
                dt = new DataTable();
            Dictionary<string, string> idUserAndName = new Dictionary<string, string>();
            idUserAndName.Clear();
              string
            query = " SELECT    ";
            query += "User_id, User_name ";
            query += " FROM    Users ";
            query += " WHERE ";
            query += "   (password = "+con.AddApostropheToString(pass);
            query += " ) AND (User_id = "+ idUser+")";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            
            if (dt !=null&& dt.Rows.Count > 0)
            idUserAndName.Add(dt.Rows[0][0].ToString(), dt.Rows[0][1].ToString());
            return idUserAndName;

           

        }
        public Dictionary<string,string> GetInfoUser(string User_id="-1")
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            Dictionary<string, string> info = new Dictionary<string, string>();
            info.Clear();

            string
           query = " SELECT  ";
            query += "  SaleLater ";
            query += "  , Discount ";
            query += "  , Discount_percentage ";
            query += " FROM  ";
            query += " Users  ";
            query += " WHERE  ";
            query += "   (User_id ="+ User_id+")";
            con.OpenConnetion();
            dt=con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
            {
                info.Add("SaleLater", dt.Rows[0][0].ToString());
                info.Add("Discount", dt.Rows[0][1].ToString());
                info.Add("Discount_percentage", dt.Rows[0][2].ToString());
            }
            
            return info;

            #region
            /*
            SELECT        SaleLater, Discount, Discount_percentage
FROM            Users
WHERE        (User_id = 1)
            */
            #endregion

        }

        public void UpdateUsers(
                              string User_id="-1" 
                              , string User_name ="-1"
                              , string Discount ="0"
                             , string Discount_percentage ="0"
                              ,string State="0"
                               , string SaleLater = "0"
                              )
        {
            string
            query = " UPDATE [dbo].[Users]   ";
            query += " SET  ";
            query += "  [User_name] = "+con.AddApostropheToString(User_name);
            query += " ,[Discount] = "+ Discount;
            query += " ,[Discount_percentage] = "+ Discount_percentage;
            query += " ,[State] = "+ State;
            query += " ,[SaleLater] = " + SaleLater;
            query += " WHERE ";
            query += "  [User_id] = "+ User_id;
            con.OpenConnetion();
            con.Query(query, false);
            con.CloseConnetion();

            #region
            /*
            UPDATE [dbo].[Users]
   SET 
       [User_name] = 'مدير النظام'
     
      ,[Discount] = 0
      ,[Discount_percentage] = 5
      ,[State] = 1
 WHERE [User_id] = 1
            */
            #endregion


        }
        public bool StateUser(string idUser = "-1")
        {
            if (dt != null)
                dt = null;
            dt = new DataTable();
            string
         query = " SELECT    ";
            query += " State ";
            query += " FROM   Users ";
            query += " WHERE  (User_id = "+ idUser + ") ";
            con.OpenConnetion();
            dt = new DataTable();
            dt = con.Query(query, true);
            con.CloseConnetion();
            if (dt != null && dt.Rows.Count > 0)
                return Convert.ToBoolean(dt.Rows[0][0].ToString());
                return false;
            #region
            /*
            SELECT        User_id, User_name,State
FROM            Users
WHERE        (User_id = 3)

            */
            #endregion

        }
    }
}
