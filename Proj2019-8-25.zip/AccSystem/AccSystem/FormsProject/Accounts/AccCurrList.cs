﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class AccCurrList : Form
    {
        string[] CurrName;
        public AccCurrList(string[] CurrName)
        {
            InitializeComponent();
            this.CurrName = CurrName;
         
        }

       
        int i;
      static  public int indeex;
        DataTable datatable;
        ClassesProject.CurrSQL curr = new ClassesProject.CurrSQL();
        private void ListCurrencyNamesForm_Load(object sender, EventArgs e)
        {
           datatable = curr.GetAllCurr();
            bool b;
            if (datatable.Rows.Count > 0)
            {
                if (CurrName != null)
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        b = true;
                        for (int j = 0; j < CurrName.Length; j++)
                        {





                            if (CurrName[j] == datatable.Rows[i][1].ToString())
                            {


                                b = false;
                            }



                        }
                        if (b)
                        {
                            dataGridView1.Rows.Add(datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString());
                        }

                    }

                     if (dataGridView1.Rows.Count == 0)

                    {
                       // bunifuThinButton21.ButtonText = "لا يوجد عملات";
                        button52.Visible = false;
                        label1.Visible = true;
                        label1.Text = "لا يوجد عملات";
                    }

                   }
                else
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString());
                    }

                }
            }

            


        }

       

       
        public bool stateSelect = true;
       

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());
            indeex = dataGridView1.CurrentCell.RowIndex;
            Close();
            //setIndex();

        }

        private void button52_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());
            indeex = dataGridView1.CurrentCell.RowIndex;
            Close();
            //setIndex();
        }
    }
}
