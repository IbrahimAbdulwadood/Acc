﻿namespace AccSystem.FormsProject.Accounts
{
    partial class AccDefinition
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AccDefinition));
            this.panMain = new System.Windows.Forms.Panel();
            this.panFill = new System.Windows.Forms.Panel();
            this.groupBoxData = new System.Windows.Forms.GroupBox();
            this.butSave = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.AccBoxName = new System.Windows.Forms.TextBox();
            this.AccCustomerName = new System.Windows.Forms.TextBox();
            this.AccSuplliersName = new System.Windows.Forms.TextBox();
            this.AccStoredName = new System.Windows.Forms.TextBox();
            this.AccSalesReturnName = new System.Windows.Forms.TextBox();
            this.AccSalesName = new System.Windows.Forms.TextBox();
            this.AccPurchasesCostName = new System.Windows.Forms.TextBox();
            this.AccBox = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.AccCustomer = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.AccSuplliers = new System.Windows.Forms.TextBox();
            this.AccStored = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.AccSalesReturn = new System.Windows.Forms.TextBox();
            this.AccSales = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.AccPurchasesCost = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtAccExching = new System.Windows.Forms.TextBox();
            this.txtAccExchingName = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.button54 = new System.Windows.Forms.Button();
            this.AccLastLevel = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panDown = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panUp = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.panMain.SuspendLayout();
            this.panFill.SuspendLayout();
            this.groupBoxData.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panDown.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panFill);
            this.panMain.Controls.Add(this.panDown);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1140, 659);
            this.panMain.TabIndex = 0;
            // 
            // panFill
            // 
            this.panFill.Controls.Add(this.groupBoxData);
            this.panFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFill.Location = new System.Drawing.Point(0, 37);
            this.panFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFill.Name = "panFill";
            this.panFill.Size = new System.Drawing.Size(1140, 590);
            this.panFill.TabIndex = 2;
            // 
            // groupBoxData
            // 
            this.groupBoxData.Controls.Add(this.butSave);
            this.groupBoxData.Controls.Add(this.buttEdite);
            this.groupBoxData.Controls.Add(this.groupBox3);
            this.groupBoxData.Controls.Add(this.groupBox2);
            this.groupBoxData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxData.ForeColor = System.Drawing.Color.Black;
            this.groupBoxData.Location = new System.Drawing.Point(0, 0);
            this.groupBoxData.Name = "groupBoxData";
            this.groupBoxData.Size = new System.Drawing.Size(1140, 590);
            this.groupBoxData.TabIndex = 34;
            this.groupBoxData.TabStop = false;
            this.groupBoxData.Enter += new System.EventHandler(this.groupBoxData_Enter);
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.butSave.Location = new System.Drawing.Point(553, 538);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(110, 46);
            this.butSave.TabIndex = 218;
            this.butSave.Text = "حفظ";
            this.butSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.butSave.UseVisualStyleBackColor = false;
            this.butSave.Click += new System.EventHandler(this.butSave_Click_1);
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttEdite.Location = new System.Drawing.Point(437, 538);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(110, 46);
            this.buttEdite.TabIndex = 217;
            this.buttEdite.Text = "تعديل";
            this.buttEdite.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttEdite.UseVisualStyleBackColor = false;
            this.buttEdite.Click += new System.EventHandler(this.buttEdite_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(3, 94);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1134, 364);
            this.groupBox3.TabIndex = 85;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "تعريف الحسابات";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.AccBoxName);
            this.groupBox1.Controls.Add(this.AccCustomerName);
            this.groupBox1.Controls.Add(this.AccSuplliersName);
            this.groupBox1.Controls.Add(this.AccStoredName);
            this.groupBox1.Controls.Add(this.AccSalesReturnName);
            this.groupBox1.Controls.Add(this.AccSalesName);
            this.groupBox1.Controls.Add(this.AccPurchasesCostName);
            this.groupBox1.Controls.Add(this.AccBox);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.panel2);
            this.groupBox1.Controls.Add(this.AccCustomer);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.AccSuplliers);
            this.groupBox1.Controls.Add(this.AccStored);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.AccSalesReturn);
            this.groupBox1.Controls.Add(this.AccSales);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.AccPurchasesCost);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Location = new System.Drawing.Point(509, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(622, 342);
            this.groupBox1.TabIndex = 84;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "حسابات نظام المبيعات والمشتريات والمخزون والمحاسبي";
            // 
            // AccBoxName
            // 
            this.AccBoxName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccBoxName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccBoxName.Location = new System.Drawing.Point(81, 210);
            this.AccBoxName.Name = "AccBoxName";
            this.AccBoxName.ReadOnly = true;
            this.AccBoxName.Size = new System.Drawing.Size(221, 23);
            this.AccBoxName.TabIndex = 190;
            this.AccBoxName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AccCustomerName
            // 
            this.AccCustomerName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccCustomerName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccCustomerName.Location = new System.Drawing.Point(81, 179);
            this.AccCustomerName.Name = "AccCustomerName";
            this.AccCustomerName.ReadOnly = true;
            this.AccCustomerName.Size = new System.Drawing.Size(221, 23);
            this.AccCustomerName.TabIndex = 189;
            this.AccCustomerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AccSuplliersName
            // 
            this.AccSuplliersName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccSuplliersName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccSuplliersName.Location = new System.Drawing.Point(81, 237);
            this.AccSuplliersName.Name = "AccSuplliersName";
            this.AccSuplliersName.ReadOnly = true;
            this.AccSuplliersName.Size = new System.Drawing.Size(221, 23);
            this.AccSuplliersName.TabIndex = 188;
            this.AccSuplliersName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AccStoredName
            // 
            this.AccStoredName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccStoredName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccStoredName.Location = new System.Drawing.Point(81, 149);
            this.AccStoredName.Name = "AccStoredName";
            this.AccStoredName.ReadOnly = true;
            this.AccStoredName.Size = new System.Drawing.Size(221, 23);
            this.AccStoredName.TabIndex = 186;
            this.AccStoredName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AccSalesReturnName
            // 
            this.AccSalesReturnName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccSalesReturnName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccSalesReturnName.Location = new System.Drawing.Point(81, 116);
            this.AccSalesReturnName.Name = "AccSalesReturnName";
            this.AccSalesReturnName.ReadOnly = true;
            this.AccSalesReturnName.Size = new System.Drawing.Size(221, 23);
            this.AccSalesReturnName.TabIndex = 185;
            this.AccSalesReturnName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AccSalesName
            // 
            this.AccSalesName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccSalesName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccSalesName.Location = new System.Drawing.Point(81, 87);
            this.AccSalesName.Name = "AccSalesName";
            this.AccSalesName.ReadOnly = true;
            this.AccSalesName.Size = new System.Drawing.Size(221, 23);
            this.AccSalesName.TabIndex = 184;
            this.AccSalesName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AccPurchasesCostName
            // 
            this.AccPurchasesCostName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccPurchasesCostName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccPurchasesCostName.Location = new System.Drawing.Point(81, 59);
            this.AccPurchasesCostName.Name = "AccPurchasesCostName";
            this.AccPurchasesCostName.ReadOnly = true;
            this.AccPurchasesCostName.Size = new System.Drawing.Size(221, 23);
            this.AccPurchasesCostName.TabIndex = 183;
            this.AccPurchasesCostName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AccBox
            // 
            this.AccBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccBox.Location = new System.Drawing.Point(308, 210);
            this.AccBox.Name = "AccBox";
            this.AccBox.ReadOnly = true;
            this.AccBox.Size = new System.Drawing.Size(150, 23);
            this.AccBox.TabIndex = 181;
            this.AccBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AccBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AccBox_KeyDown);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(464, 213);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 16);
            this.label11.TabIndex = 182;
            this.label11.Text = "حساب الصناديق";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkRed;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(616, 23);
            this.panel2.TabIndex = 171;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label5.Location = new System.Drawing.Point(209, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(271, 16);
            this.label5.TabIndex = 66;
            this.label5.Text = "الحسابات الرئيسية قبل الفرعية برتبة واحدة";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AccCustomer
            // 
            this.AccCustomer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccCustomer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccCustomer.Location = new System.Drawing.Point(308, 181);
            this.AccCustomer.Name = "AccCustomer";
            this.AccCustomer.ReadOnly = true;
            this.AccCustomer.Size = new System.Drawing.Size(150, 23);
            this.AccCustomer.TabIndex = 179;
            this.AccCustomer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AccCustomer.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AccCustomer_KeyDown);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(464, 184);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 16);
            this.label10.TabIndex = 180;
            this.label10.Text = "حساب العملاء";
            // 
            // AccSuplliers
            // 
            this.AccSuplliers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccSuplliers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccSuplliers.Location = new System.Drawing.Point(308, 239);
            this.AccSuplliers.Name = "AccSuplliers";
            this.AccSuplliers.ReadOnly = true;
            this.AccSuplliers.Size = new System.Drawing.Size(150, 23);
            this.AccSuplliers.TabIndex = 177;
            this.AccSuplliers.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AccStored
            // 
            this.AccStored.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccStored.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccStored.Location = new System.Drawing.Point(308, 151);
            this.AccStored.Name = "AccStored";
            this.AccStored.ReadOnly = true;
            this.AccStored.Size = new System.Drawing.Size(150, 23);
            this.AccStored.TabIndex = 168;
            this.AccStored.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AccStored.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AccStored_KeyDown);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(464, 242);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 16);
            this.label9.TabIndex = 178;
            this.label9.Text = "حساب الموردين";
            // 
            // AccSalesReturn
            // 
            this.AccSalesReturn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccSalesReturn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccSalesReturn.Location = new System.Drawing.Point(308, 118);
            this.AccSalesReturn.Name = "AccSalesReturn";
            this.AccSalesReturn.ReadOnly = true;
            this.AccSalesReturn.Size = new System.Drawing.Size(150, 23);
            this.AccSalesReturn.TabIndex = 165;
            this.AccSalesReturn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AccSalesReturn.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AccSalesReturn_KeyDown);
            // 
            // AccSales
            // 
            this.AccSales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccSales.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccSales.Location = new System.Drawing.Point(308, 89);
            this.AccSales.Name = "AccSales";
            this.AccSales.ReadOnly = true;
            this.AccSales.Size = new System.Drawing.Size(150, 23);
            this.AccSales.TabIndex = 163;
            this.AccSales.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AccSales.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AccSales_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(464, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 16);
            this.label6.TabIndex = 162;
            this.label6.Text = "حساب المخزون:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(464, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 16);
            this.label3.TabIndex = 160;
            this.label3.Text = "حساب مردود مبيعات:";
            // 
            // AccPurchasesCost
            // 
            this.AccPurchasesCost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.AccPurchasesCost.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.AccPurchasesCost.Location = new System.Drawing.Point(308, 61);
            this.AccPurchasesCost.Name = "AccPurchasesCost";
            this.AccPurchasesCost.ReadOnly = true;
            this.AccPurchasesCost.Size = new System.Drawing.Size(150, 23);
            this.AccPurchasesCost.TabIndex = 155;
            this.AccPurchasesCost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AccPurchasesCost.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AccPurchasesCost_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(464, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(146, 16);
            this.label1.TabIndex = 156;
            this.label1.Text = "حساب تكلفة المبيعات:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(464, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 16);
            this.label4.TabIndex = 157;
            this.label4.Text = "حساب المبيعات:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.groupBox5);
            this.groupBox4.Controls.Add(this.panel3);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox4.Location = new System.Drawing.Point(3, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(506, 342);
            this.groupBox4.TabIndex = 156;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "الحسابات الوسيطة";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtAccExching);
            this.groupBox5.Controls.Add(this.txtAccExchingName);
            this.groupBox5.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox5.Location = new System.Drawing.Point(3, 42);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(500, 58);
            this.groupBox5.TabIndex = 187;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "فوارق اسعار عملات اجنبية:";
            // 
            // txtAccExching
            // 
            this.txtAccExching.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtAccExching.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtAccExching.Location = new System.Drawing.Point(308, 19);
            this.txtAccExching.Name = "txtAccExching";
            this.txtAccExching.ReadOnly = true;
            this.txtAccExching.Size = new System.Drawing.Size(150, 23);
            this.txtAccExching.TabIndex = 184;
            this.txtAccExching.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtAccExching.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtAccExching_KeyDown);
            // 
            // txtAccExchingName
            // 
            this.txtAccExchingName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtAccExchingName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtAccExchingName.Location = new System.Drawing.Point(14, 19);
            this.txtAccExchingName.Name = "txtAccExchingName";
            this.txtAccExchingName.ReadOnly = true;
            this.txtAccExchingName.Size = new System.Drawing.Size(288, 23);
            this.txtAccExchingName.TabIndex = 186;
            this.txtAccExchingName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DarkRed;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(500, 23);
            this.panel3.TabIndex = 156;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label7.Location = new System.Drawing.Point(140, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 16);
            this.label7.TabIndex = 66;
            this.label7.Text = "الحسابات الفرعية";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.button54);
            this.groupBox2.Controls.Add(this.AccLastLevel);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(3, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1134, 75);
            this.groupBox2.TabIndex = 85;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "متغيرات النظام";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(274, 34);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(359, 16);
            this.label16.TabIndex = 217;
            this.label16.Text = "اذا مافي اي حساب في الدليل المحاسبي يظهر هذا البوتن";
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button54.FlatAppearance.BorderSize = 0;
            this.button54.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button54.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button54.ForeColor = System.Drawing.Color.White;
            this.button54.Image = ((System.Drawing.Image)(resources.GetObject("button54.Image")));
            this.button54.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button54.Location = new System.Drawing.Point(10, 19);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(259, 46);
            this.button54.TabIndex = 216;
            this.button54.Text = "تنزيل دليل محاسبي افتراضي";
            this.button54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button54.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button54.UseVisualStyleBackColor = false;
            // 
            // AccLastLevel
            // 
            this.AccLastLevel.BackColor = System.Drawing.Color.Gray;
            this.AccLastLevel.ForeColor = System.Drawing.Color.White;
            this.AccLastLevel.Location = new System.Drawing.Point(891, 31);
            this.AccLastLevel.Name = "AccLastLevel";
            this.AccLastLevel.ReadOnly = true;
            this.AccLastLevel.Size = new System.Drawing.Size(76, 23);
            this.AccLastLevel.TabIndex = 135;
            this.AccLastLevel.Text = "4";
            this.AccLastLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AccLastLevel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AccLastLevel_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(973, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(147, 16);
            this.label12.TabIndex = 134;
            this.label12.Text = "رتبة الحسابات الفرعية:";
            // 
            // panDown
            // 
            this.panDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panDown.Controls.Add(this.statusStrip1);
            this.panDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDown.Location = new System.Drawing.Point(0, 627);
            this.panDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDown.Name = "panDown";
            this.panDown.Size = new System.Drawing.Size(1140, 32);
            this.panDown.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1140, 32);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(93, 27);
            this.toolStripStatusLabel1.Text = "F9 لأضافة حساب";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(15, 27);
            this.toolStripStatusLabel2.Text = "||";
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.label13);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(1140, 37);
            this.panUp.TabIndex = 0;
            this.panUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panUp_Paint);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Location = new System.Drawing.Point(895, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(236, 27);
            this.label13.TabIndex = 9;
            this.label13.Text = "         تعريف الحسابات";
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(12, 3);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 27);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 7;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            this.pictureClose.MouseHover += new System.EventHandler(this.pictureClose_MouseHover);
            // 
            // AccDefinition
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1140, 659);
            this.Controls.Add(this.panMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AccDefinition";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "Form4";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.AccDefinition_Load);
            this.panMain.ResumeLayout(false);
            this.panFill.ResumeLayout(false);
            this.groupBoxData.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panDown.ResumeLayout(false);
            this.panDown.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panFill;
        private System.Windows.Forms.Panel panDown;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.GroupBox groupBoxData;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox AccLastLevel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox AccBox;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox AccCustomer;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox AccSuplliers;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox AccStored;
        private System.Windows.Forms.TextBox AccSalesReturn;
        private System.Windows.Forms.TextBox AccSales;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox AccPurchasesCost;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button buttEdite;
        private System.Windows.Forms.TextBox AccBoxName;
        private System.Windows.Forms.TextBox AccCustomerName;
        private System.Windows.Forms.TextBox AccSuplliersName;
        private System.Windows.Forms.TextBox AccStoredName;
        private System.Windows.Forms.TextBox AccSalesReturnName;
        private System.Windows.Forms.TextBox AccSalesName;
        private System.Windows.Forms.TextBox AccPurchasesCostName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox txtAccExching;
        private System.Windows.Forms.TextBox txtAccExchingName;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
    }
}