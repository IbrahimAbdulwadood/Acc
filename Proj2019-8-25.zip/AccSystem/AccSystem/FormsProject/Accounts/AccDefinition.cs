﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class AccDefinition : Form
    {
        ClassesProject.AccDefintionSQL acDef = new ClassesProject.AccDefintionSQL();
        DataTable dt;
        public AccDefinition()
        {
            InitializeComponent();
            
        }
        #region متغيرات تحريك الشاشة
        //////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس
        /// </summary>
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>
        ///////////////////////////////////////////////////////////////////////////////
        #endregion
        /////////////دوال الشاشة////////////////////////
        bool FlageEdite = false;
        void FillData()
        {
            dt = new DataTable();
            dt = acDef.GetDataAccDefintion();
            if (dt.Rows.Count > 0)
            {
                #region
                /*
       AccBox 0
	   AccBox 1
		,AccSales 2
        as AccSales 3
		,AccSalesReturn 4
         AccSalesReturn 5
		 AccCost 6
         AccCost 7
		,AccStored 8
        as AccStored 9
		,AccCustomer 10
        as AccCustomer 11
     as AccDifferenceExchingCurrForeigner 12
        AccDifferenceExchingCurrForeigner 13

		  AccLastLevel 14
     */
                #endregion

                AccBox.Text = dt.Rows[0][0].ToString();
                AccBoxName.Text = dt.Rows[0][1].ToString();

                AccSales.Text = dt.Rows[0][2].ToString();
                AccSalesName.Text = dt.Rows[0][3].ToString();

                AccSalesReturn.Text = dt.Rows[0][4].ToString();
                AccSalesReturnName.Text = dt.Rows[0][5].ToString();

                AccPurchasesCost.Text = dt.Rows[0][6].ToString();
                AccPurchasesCostName.Text = dt.Rows[0][7].ToString();
              
                AccStored.Text = dt.Rows[0][8].ToString();
                AccStoredName.Text = dt.Rows[0][9].ToString();
            
                AccCustomer.Text = dt.Rows[0][10].ToString();
                AccCustomerName.Text = dt.Rows[0][11].ToString();
                txtAccExching.Text = dt.Rows[0][12].ToString();
                txtAccExchingName.Text = dt.Rows[0][13].ToString();
                txtAccExching.Tag= dt.Rows[0][15].ToString();
                AccLastLevel.Text = dt.Rows[0][14].ToString();


            }
            else
            {
                AccSuplliers.Text = string.Empty;
                AccBox.Text = string.Empty;
                AccBoxName.Text = string.Empty;
                AccSales.Text = string.Empty;
                AccSalesName.Text = string.Empty;
                AccSalesReturn.Text = string.Empty;
                AccSalesReturnName.Text = string.Empty;
                AccPurchasesCost.Text = string.Empty;
                AccPurchasesCostName.Text = string.Empty;
                AccStored.Text = string.Empty;
                AccStoredName.Text = string.Empty;
                AccCustomer.Text = string.Empty;
                AccCustomerName.Text = string.Empty;
                txtAccExching.Text = string.Empty;
                txtAccExching.Tag = null;
                txtAccExchingName.Text = string.Empty;
                AccLastLevel.Text = string.Empty;

            }

        }

        AccDefinitionList AccDefinitionList;
        bool CanUpdateAcc(string AccId,string txtName)
        {
            List<string> data = new List<string>();
            if(txtName== "AccBox")
            data= acDef.CanUpdateAccBox();
            else if(txtName == "AccPurchasesCost")
            {
                List<string> Cost = new List<string>();

                 Cost = acDef.GetAcc_cost4GroupStored();
                if (Cost.Count > 0)
                    for (int i = 0; i < Cost.Count; i++)
                        data = acDef.CanUpdateAccGroupStore(Cost[i]);
            }
            else if (txtName == "AccSales")
            {
                List<string> Cost = new List<string>();

                Cost = acDef.GetAcc_sales4GroupStored();
                if (Cost.Count > 0)
                    for (int i = 0; i < Cost.Count; i++)
                        data = acDef.CanUpdateAccGroupStore(Cost[i]);
            }
            else if (txtName == "AccSalesReturn")
            {
                List<string> Cost = new List<string>();

                Cost = acDef.GetAcc_return_sales4GroupStored();
                if (Cost.Count > 0)
                    for (int i = 0; i < Cost.Count; i++)
                        data = acDef.CanUpdateAccGroupStore(Cost[i]);
            }
            else if (txtName == "AccStored")
            {
                List<string> Cost = new List<string>();

                Cost = acDef.GetAcc_stored4GroupStored();
                if (Cost.Count > 0)
                    for (int i = 0; i < Cost.Count; i++)
                        data = acDef.CanUpdateAccGroupStore(Cost[i]);
            }
            else if (txtName == "AccCustomer")
            {
                data = acDef.CanUpdateAccCustomer();
            }
            else if (txtName == "txtAccExching")
            {
                data = acDef.CanUpdateExching(txtAccExching.Tag.ToString());
            }
            if (data.Count > 0)
            for(int i=0;i<data.Count;i++)
                    if(data[i]== AccId)
                     return false;
                     return true;
        }
       
        void FormatingTextBoxAndButt(string EditeOrSaveOrLoad)
        {
            if (EditeOrSaveOrLoad == "Save" || EditeOrSaveOrLoad == "Load")
            {
                AccLastLevel.ReadOnly = true;
                butSave.Enabled = false;
                buttEdite.Enabled = true;
            }
            else if (EditeOrSaveOrLoad == "Edite")
            {
                AccLastLevel.ReadOnly = false;
                butSave.Enabled = true;
                buttEdite.Enabled = false;
            }
        }
        void EnterLikeTap(KeyEventArgs e)
        {
            //Copy Name Fun in Event KeyDown
            if (e.KeyCode == Keys.Enter)
            {

                SendKeys.Send("{TAB}");
            }
        }
        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }


        ///////////////////////////////////////////////
        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }

        private void AccDefinition_Load(object sender, EventArgs e)
        {
            FillData();
            FormatingTextBoxAndButt("Load");
        }

  


        

        private void AccLastLevel_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

      

     

        private void butSave_Click_1(object sender, EventArgs e)
        {
            //butSave
            if (MessageBox.Show("هل تريد تغيير البيانات؟", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                /*
      [AccBox]  ,[AccSales] ,[AccSalesReturn]  ,[AccPurchasesCost]  ,[AccPurchasesReturn]  ,
      [AccDiscountAllow]  ,[AccDiscountGained] ,[AccStored]  ,[AccQuantityFree] ,[AccCustomer]
     ,[AccSuplliers]  ,[AccStoredFristBalance]  ,[AccLastLevel]
    */
                acDef.UpdateIdAccFatherBox(
              (AccBox.Text == string.Empty ? "NULL" : AccBox.Text),
              (AccSales.Text == string.Empty ? "NULL" : AccSales.Text),
              (AccSalesReturn.Text == string.Empty ? "NULL" : AccSalesReturn.Text),
              (AccPurchasesCost.Text == string.Empty ? "NULL" : AccPurchasesCost.Text),
              (AccStored.Text == string.Empty ? "NULL" : AccStored.Text),
              (AccCustomer.Text == string.Empty ? "NULL" : AccCustomer.Text),
              (txtAccExching.Tag == null ? "NULL" : txtAccExching.Tag.ToString()),
              (AccLastLevel.Text == string.Empty ? "NULL" : AccLastLevel.Text));
            }

            FillData();
            FormatingTextBoxAndButt("Save");
            FlageEdite = false;
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            //buttEdite
            FormatingTextBoxAndButt("Edite");
            FlageEdite = true;
        }

       

        private void AccPurchasesCost_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9&& FlageEdite)
            {
                if (CanUpdateAcc(AccPurchasesCost.Text != string.Empty ? AccPurchasesCost.Text : "-1", "AccPurchasesCost"))
                {
                    AccDefinitionList = new AccDefinitionList((Convert.ToInt32(AccLastLevel.Text) - 1).ToString(), "Main");
                    AccDefinitionList.ShowDialog();
                    if (AccDefinitionList.stateSelect && AccDefinitionList.indeex != -1)
                    {
                        int i = AccDefinitionList.indeex;
                        AccPurchasesCost.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[0].Value.ToString();
                        AccPurchasesCostName.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    }
                }
                else MessageBox.Show("لا يمكن تعديل الحساب لوجود عمليات مرتبطة", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }

        private void AccSales_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9 && FlageEdite)
            {
                if (CanUpdateAcc(AccSales.Text != string.Empty ? AccSales.Text : "-1", "AccSales"))
                {
                    AccDefinitionList = new AccDefinitionList((Convert.ToInt32(AccLastLevel.Text) - 1).ToString(), "Main");
                    AccDefinitionList.ShowDialog();
                    if (AccDefinitionList.stateSelect && AccDefinitionList.indeex != -1)
                    {
                        int i = AccDefinitionList.indeex;
                        AccSales.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[0].Value.ToString();
                        AccSalesName.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    }
                }
                else MessageBox.Show("لا يمكن تعديل الحساب لوجود عمليات مرتبطة ", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }

        private void AccSalesReturn_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9 && FlageEdite)
            {
                if (CanUpdateAcc(AccSalesReturn.Text != string.Empty ? AccSalesReturn.Text : "-1", "AccSalesReturn"))
                {
                    AccDefinitionList = new AccDefinitionList((Convert.ToInt32(AccLastLevel.Text) - 1).ToString(), "Main");
                    AccDefinitionList.ShowDialog();
                    if (AccDefinitionList.stateSelect && AccDefinitionList.indeex != -1)
                    {
                        int i = AccDefinitionList.indeex;
                        AccSalesReturn.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[0].Value.ToString();
                        AccSalesReturnName.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    }
                }
                else MessageBox.Show("لا يمكن تعديل الحساب لوجود عمليات مرتبطة", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }

        private void AccStored_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9 && FlageEdite)
            {
                if (CanUpdateAcc(AccStored.Text != string.Empty ? AccStored.Text : "-1", "AccStored"))
                {
                    AccDefinitionList = new AccDefinitionList((Convert.ToInt32(AccLastLevel.Text) - 1).ToString(), "Main");
                    AccDefinitionList.ShowDialog();
                    if (AccDefinitionList.stateSelect && AccDefinitionList.indeex != -1)
                    {
                        int i = AccDefinitionList.indeex;
                        AccStored.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[0].Value.ToString();
                        AccStoredName.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    }
                }
                else MessageBox.Show("لا يمكن تعديل الحساب لوجود عمليات مرتبطة", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }

        private void AccCustomer_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9 && FlageEdite)
            {
                if (CanUpdateAcc(AccCustomer.Text != string.Empty ? AccCustomer.Text : "-1", "AccCustomer"))
                {
                    AccDefinitionList = new AccDefinitionList((Convert.ToInt32(AccLastLevel.Text) - 1).ToString(), "Main");
                    AccDefinitionList.ShowDialog();
                    if (AccDefinitionList.stateSelect && AccDefinitionList.indeex != -1)
                    {
                        int i = AccDefinitionList.indeex;
                        AccCustomer.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[0].Value.ToString();
                        AccCustomerName.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    }
                }
                else MessageBox.Show("لا يمكن تعديل الحساب لوجود عمليات مرتبطة", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }

        private void AccBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9 && FlageEdite)
            {

                if (CanUpdateAcc(AccBox.Text != string.Empty ? AccBox.Text : "-1", "AccBox"))
                {
                    AccDefinitionList = new AccDefinitionList((Convert.ToInt32(AccLastLevel.Text) - 1).ToString(), "Main");
                    AccDefinitionList.ShowDialog();
                    if (AccDefinitionList.stateSelect && AccDefinitionList.indeex != -1)
                    {
                        int i = AccDefinitionList.indeex;
                        AccBox.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[0].Value.ToString();
                        AccBoxName.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    }
                }
                else MessageBox.Show("لا يمكن تعديل الحساب لوجود عمليات مرتبطة", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

            }
        }

        private void txtAccExching_KeyDown(object sender, KeyEventArgs e)
        {  
            if (e.KeyData == Keys.F9 && FlageEdite)
            {
                if (CanUpdateAcc(txtAccExching.Tag != null ? txtAccExching.Tag.ToString() : "-1", "txtAccExching"))
                {
                    AccDefinitionList = new AccDefinitionList((Convert.ToInt32(AccLastLevel.Text) - 1).ToString(), "");
                    AccDefinitionList.ShowDialog();
                    if (AccDefinitionList.stateSelect && AccDefinitionList.indeex != -1)
                    {
                        int i = AccDefinitionList.indeex;
                        txtAccExching.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[0].Value.ToString();
                        txtAccExchingName.Text = AccDefinitionList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                        txtAccExching.Tag = AccDefinitionList.dataGridView1.Rows[i].Cells[2].Value.ToString();
                    }
                }
                else MessageBox.Show("لا يمكن تعديل الحساب لوجود عمليات مرتبطة", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                
            }
        }
    }
}
