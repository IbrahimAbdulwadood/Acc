﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class AccDefinitionList : Form
    {
      
        public AccDefinitionList(string Acc_level,string MainOrFr3i)
        {
            InitializeComponent();
            indeex = -1;
            this.Acc_level = Acc_level;
            this.MainOrFr3i = MainOrFr3i;
            if (MainOrFr3i=="Main")
            lbTitle.Text = "الحسابات الرئيسية قبل الفرعية برتبة واحدة";
            else
            lbTitle.Text = "الحسابات  الفرعية";

        }
        string MainOrFr3i;
        string Acc_level;
        static public int indeex;
        public bool stateSelect = false;
        DataTable datatable;
        ClassesProject.AccountSQL CustSql = new ClassesProject.AccountSQL();

        #region 
    
        #endregion
        void FillData()
        {
         
            datatable = new DataTable();
            if(MainOrFr3i=="Main")
            datatable = CustSql.GetAccDefin(Acc_level);
            else datatable = CustSql.GetAccDefin();
            //  bool Add2DGV;
            if (datatable != null && datatable.Rows.Count > 0)
            {
                #region اذا في عملاء معاهم حسابات ما يدخلها هنا 

                #endregion
                //else
                if (MainOrFr3i == "Main")
                    for (int i = 0; i < datatable.Rows.Count; i++)
                        dataGridView1.Rows.Add(
                                datatable.Rows[i][0].ToString()
                              , datatable.Rows[i][1].ToString()
                              );
                else
                    for (int i = 0; i < datatable.Rows.Count; i++)
                        dataGridView1.Rows.Add(
                                datatable.Rows[i][0].ToString()
                              , datatable.Rows[i][1].ToString()
                              , datatable.Rows[i][2].ToString()
                              );



            }

            if (dataGridView1.Rows.Count == 0)
            {
                btnSelect.Visible = false;
                panel2.Visible = true;
                label1.Visible = true;
            }
            else
            {
                btnSelect.Visible = true;
                panel2.Visible = false;
                label1.Visible = false;
            }


        }

        private void AccListSupllier_Load(object sender, EventArgs e)
        {
            FillData();
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;

        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

     
        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                stateSelect = true;
                indeex = dataGridView1.CurrentCell.RowIndex;
               // MessageBox.Show(indeex.ToString());
                Close();
            }
            else
            {
                stateSelect = false;
                Close();
            }
        }
    }
}
