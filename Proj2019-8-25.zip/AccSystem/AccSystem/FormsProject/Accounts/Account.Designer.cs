﻿namespace AccSystem.FormsProject.Accounts
{
    partial class Account
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Account));
            this.panMain = new System.Windows.Forms.Panel();
            this.panFill = new System.Windows.Forms.Panel();
            this.panFillFill = new System.Windows.Forms.Panel();
            this.panFillLiftDown = new System.Windows.Forms.Panel();
            this.groupBoxOprea = new System.Windows.Forms.GroupBox();
            this.CountAcc = new System.Windows.Forms.TextBox();
            this.buttLast = new System.Windows.Forms.Button();
            this.buttBack = new System.Windows.Forms.Button();
            this.buttNext = new System.Windows.Forms.Button();
            this.buttFrist = new System.Windows.Forms.Button();
            this.buttDelete = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.butSave = new System.Windows.Forms.Button();
            this.buttAdd = new System.Windows.Forms.Button();
            this.panFillLiftUp = new System.Windows.Forms.Panel();
            this.groupBoxData = new System.Windows.Forms.GroupBox();
            this.groupBoxState = new System.Windows.Forms.GroupBox();
            this.StatActive = new System.Windows.Forms.RadioButton();
            this.StatNoActive = new System.Windows.Forms.RadioButton();
            this.groupBoxReport = new System.Windows.Forms.GroupBox();
            this.Report2 = new System.Windows.Forms.RadioButton();
            this.Report1 = new System.Windows.Forms.RadioButton();
            this.groupBoxType = new System.Windows.Forms.GroupBox();
            this.StateFr3e = new System.Windows.Forms.RadioButton();
            this.StateRasi = new System.Windows.Forms.RadioButton();
            this.groupBoxNature = new System.Windows.Forms.GroupBox();
            this.StatMaden = new System.Windows.Forms.RadioButton();
            this.StatDaain = new System.Windows.Forms.RadioButton();
            this.groupBoxCurrncy = new System.Windows.Forms.GroupBox();
            this.dataGridViewCurr = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttAddCurr = new System.Windows.Forms.Button();
            this.AccFather = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.AccName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.AccId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AccLevel = new System.Windows.Forms.TextBox();
            this.panFillRight = new System.Windows.Forms.Panel();
            this.panFillRightDown = new System.Windows.Forms.Panel();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.panFillRightUp = new System.Windows.Forms.Panel();
            this.panFillLift = new System.Windows.Forms.Panel();
            this.panDown = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.panUp = new System.Windows.Forms.Panel();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.labTitle = new System.Windows.Forms.Label();
            this.txtSerch = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.buttPrint = new System.Windows.Forms.Button();
            this.panMain.SuspendLayout();
            this.panFill.SuspendLayout();
            this.panFillFill.SuspendLayout();
            this.panFillLiftDown.SuspendLayout();
            this.groupBoxOprea.SuspendLayout();
            this.panFillLiftUp.SuspendLayout();
            this.groupBoxData.SuspendLayout();
            this.groupBoxState.SuspendLayout();
            this.groupBoxReport.SuspendLayout();
            this.groupBoxType.SuspendLayout();
            this.groupBoxNature.SuspendLayout();
            this.groupBoxCurrncy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCurr)).BeginInit();
            this.panFillRight.SuspendLayout();
            this.panFillRightDown.SuspendLayout();
            this.panDown.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panFill);
            this.panMain.Controls.Add(this.panDown);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1354, 519);
            this.panMain.TabIndex = 0;
            // 
            // panFill
            // 
            this.panFill.Controls.Add(this.panFillFill);
            this.panFill.Controls.Add(this.panFillLift);
            this.panFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFill.Location = new System.Drawing.Point(0, 46);
            this.panFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFill.Name = "panFill";
            this.panFill.Size = new System.Drawing.Size(1354, 434);
            this.panFill.TabIndex = 2;
            // 
            // panFillFill
            // 
            this.panFillFill.Controls.Add(this.panFillLiftDown);
            this.panFillFill.Controls.Add(this.panFillLiftUp);
            this.panFillFill.Controls.Add(this.panFillRight);
            this.panFillFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFillFill.Location = new System.Drawing.Point(0, 0);
            this.panFillFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillFill.Name = "panFillFill";
            this.panFillFill.Size = new System.Drawing.Size(1354, 434);
            this.panFillFill.TabIndex = 2;
            // 
            // panFillLiftDown
            // 
            this.panFillLiftDown.Controls.Add(this.groupBoxOprea);
            this.panFillLiftDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panFillLiftDown.Location = new System.Drawing.Point(0, 301);
            this.panFillLiftDown.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panFillLiftDown.Name = "panFillLiftDown";
            this.panFillLiftDown.Size = new System.Drawing.Size(1002, 133);
            this.panFillLiftDown.TabIndex = 4;
            // 
            // groupBoxOprea
            // 
            this.groupBoxOprea.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxOprea.Controls.Add(this.buttPrint);
            this.groupBoxOprea.Controls.Add(this.CountAcc);
            this.groupBoxOprea.Controls.Add(this.buttLast);
            this.groupBoxOprea.Controls.Add(this.buttBack);
            this.groupBoxOprea.Controls.Add(this.buttNext);
            this.groupBoxOprea.Controls.Add(this.buttFrist);
            this.groupBoxOprea.Controls.Add(this.buttDelete);
            this.groupBoxOprea.Controls.Add(this.buttEdite);
            this.groupBoxOprea.Controls.Add(this.butSave);
            this.groupBoxOprea.Controls.Add(this.buttAdd);
            this.groupBoxOprea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxOprea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxOprea.ForeColor = System.Drawing.Color.Black;
            this.groupBoxOprea.Location = new System.Drawing.Point(0, 0);
            this.groupBoxOprea.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxOprea.Name = "groupBoxOprea";
            this.groupBoxOprea.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxOprea.Size = new System.Drawing.Size(1002, 133);
            this.groupBoxOprea.TabIndex = 45;
            this.groupBoxOprea.TabStop = false;
            this.groupBoxOprea.Text = "العمليات";
            // 
            // CountAcc
            // 
            this.CountAcc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CountAcc.Enabled = false;
            this.CountAcc.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountAcc.Location = new System.Drawing.Point(170, 52);
            this.CountAcc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.CountAcc.Name = "CountAcc";
            this.CountAcc.ReadOnly = true;
            this.CountAcc.Size = new System.Drawing.Size(154, 33);
            this.CountAcc.TabIndex = 130;
            this.CountAcc.Text = "1111-1111";
            this.CountAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttLast
            // 
            this.buttLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttLast.FlatAppearance.BorderSize = 0;
            this.buttLast.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttLast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttLast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttLast.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttLast.ForeColor = System.Drawing.Color.White;
            this.buttLast.Image = ((System.Drawing.Image)(resources.GetObject("buttLast.Image")));
            this.buttLast.Location = new System.Drawing.Point(23, 25);
            this.buttLast.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttLast.MaximumSize = new System.Drawing.Size(66, 101);
            this.buttLast.Name = "buttLast";
            this.buttLast.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.buttLast.Size = new System.Drawing.Size(66, 101);
            this.buttLast.TabIndex = 129;
            this.buttLast.Text = "الاخير";
            this.buttLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttLast.UseVisualStyleBackColor = false;
            this.buttLast.Click += new System.EventHandler(this.buttLast_Click);
            // 
            // buttBack
            // 
            this.buttBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBack.FlatAppearance.BorderSize = 0;
            this.buttBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBack.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttBack.ForeColor = System.Drawing.Color.White;
            this.buttBack.Image = ((System.Drawing.Image)(resources.GetObject("buttBack.Image")));
            this.buttBack.Location = new System.Drawing.Point(97, 25);
            this.buttBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttBack.MaximumSize = new System.Drawing.Size(66, 101);
            this.buttBack.Name = "buttBack";
            this.buttBack.Size = new System.Drawing.Size(66, 101);
            this.buttBack.TabIndex = 128;
            this.buttBack.Text = "السابق";
            this.buttBack.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttBack.UseVisualStyleBackColor = false;
            this.buttBack.Click += new System.EventHandler(this.buttBack_Click);
            // 
            // buttNext
            // 
            this.buttNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttNext.FlatAppearance.BorderSize = 0;
            this.buttNext.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttNext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttNext.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttNext.ForeColor = System.Drawing.Color.White;
            this.buttNext.Image = ((System.Drawing.Image)(resources.GetObject("buttNext.Image")));
            this.buttNext.Location = new System.Drawing.Point(334, 25);
            this.buttNext.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttNext.MaximumSize = new System.Drawing.Size(66, 101);
            this.buttNext.Name = "buttNext";
            this.buttNext.Size = new System.Drawing.Size(66, 101);
            this.buttNext.TabIndex = 127;
            this.buttNext.Text = "التالي";
            this.buttNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttNext.UseVisualStyleBackColor = false;
            this.buttNext.Click += new System.EventHandler(this.buttNext_Click);
            // 
            // buttFrist
            // 
            this.buttFrist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFrist.FlatAppearance.BorderSize = 0;
            this.buttFrist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttFrist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttFrist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttFrist.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttFrist.ForeColor = System.Drawing.Color.White;
            this.buttFrist.Image = ((System.Drawing.Image)(resources.GetObject("buttFrist.Image")));
            this.buttFrist.Location = new System.Drawing.Point(407, 25);
            this.buttFrist.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttFrist.MaximumSize = new System.Drawing.Size(66, 101);
            this.buttFrist.Name = "buttFrist";
            this.buttFrist.Size = new System.Drawing.Size(66, 101);
            this.buttFrist.TabIndex = 126;
            this.buttFrist.Text = "الاول";
            this.buttFrist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttFrist.UseVisualStyleBackColor = false;
            this.buttFrist.Click += new System.EventHandler(this.buttFrist_Click);
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.FlatAppearance.BorderSize = 0;
            this.buttDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.Location = new System.Drawing.Point(692, 25);
            this.buttDelete.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttDelete.MaximumSize = new System.Drawing.Size(66, 101);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(66, 101);
            this.buttDelete.TabIndex = 124;
            this.buttDelete.Text = "حذف";
            this.buttDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttDelete.UseVisualStyleBackColor = false;
            this.buttDelete.Click += new System.EventHandler(this.buttDelete_Click);
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.Location = new System.Drawing.Point(765, 25);
            this.buttEdite.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttEdite.MaximumSize = new System.Drawing.Size(66, 101);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(66, 101);
            this.buttEdite.TabIndex = 123;
            this.buttEdite.Text = "تعديل";
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttEdite.UseVisualStyleBackColor = false;
            this.buttEdite.Click += new System.EventHandler(this.buttEdite_Click);
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.Location = new System.Drawing.Point(839, 25);
            this.butSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.butSave.MaximumSize = new System.Drawing.Size(66, 101);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(66, 101);
            this.butSave.TabIndex = 122;
            this.butSave.Text = "حفظ";
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butSave.UseVisualStyleBackColor = false;
            this.butSave.Click += new System.EventHandler(this.butSave_Click);
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.FlatAppearance.BorderSize = 0;
            this.buttAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.Location = new System.Drawing.Point(911, 25);
            this.buttAdd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttAdd.MaximumSize = new System.Drawing.Size(66, 101);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(66, 101);
            this.buttAdd.TabIndex = 121;
            this.buttAdd.Text = "جديد";
            this.buttAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttAdd.UseVisualStyleBackColor = false;
            this.buttAdd.Click += new System.EventHandler(this.buttAdd_Click);
            // 
            // panFillLiftUp
            // 
            this.panFillLiftUp.Controls.Add(this.groupBoxData);
            this.panFillLiftUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFillLiftUp.Location = new System.Drawing.Point(0, 0);
            this.panFillLiftUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panFillLiftUp.Name = "panFillLiftUp";
            this.panFillLiftUp.Size = new System.Drawing.Size(1002, 434);
            this.panFillLiftUp.TabIndex = 3;
            // 
            // groupBoxData
            // 
            this.groupBoxData.Controls.Add(this.groupBoxState);
            this.groupBoxData.Controls.Add(this.groupBoxReport);
            this.groupBoxData.Controls.Add(this.groupBoxType);
            this.groupBoxData.Controls.Add(this.groupBoxNature);
            this.groupBoxData.Controls.Add(this.groupBoxCurrncy);
            this.groupBoxData.Controls.Add(this.AccFather);
            this.groupBoxData.Controls.Add(this.label4);
            this.groupBoxData.Controls.Add(this.AccName);
            this.groupBoxData.Controls.Add(this.label3);
            this.groupBoxData.Controls.Add(this.AccId);
            this.groupBoxData.Controls.Add(this.label2);
            this.groupBoxData.Controls.Add(this.label1);
            this.groupBoxData.Controls.Add(this.AccLevel);
            this.groupBoxData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxData.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBoxData.Location = new System.Drawing.Point(0, 0);
            this.groupBoxData.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxData.Name = "groupBoxData";
            this.groupBoxData.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxData.Size = new System.Drawing.Size(1002, 434);
            this.groupBoxData.TabIndex = 0;
            this.groupBoxData.TabStop = false;
            this.groupBoxData.Text = "البـيـانـات";
            this.groupBoxData.Enter += new System.EventHandler(this.groupBoxData_Enter);
            // 
            // groupBoxState
            // 
            this.groupBoxState.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxState.Controls.Add(this.StatActive);
            this.groupBoxState.Controls.Add(this.StatNoActive);
            this.groupBoxState.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBoxState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBoxState.Location = new System.Drawing.Point(436, 165);
            this.groupBoxState.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxState.Name = "groupBoxState";
            this.groupBoxState.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxState.Size = new System.Drawing.Size(241, 60);
            this.groupBoxState.TabIndex = 51;
            this.groupBoxState.TabStop = false;
            this.groupBoxState.Text = "حالة الحساب";
            // 
            // StatActive
            // 
            this.StatActive.AutoSize = true;
            this.StatActive.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StatActive.Location = new System.Drawing.Point(31, 26);
            this.StatActive.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.StatActive.Name = "StatActive";
            this.StatActive.Size = new System.Drawing.Size(51, 17);
            this.StatActive.TabIndex = 1;
            this.StatActive.TabStop = true;
            this.StatActive.Text = "نشط";
            this.StatActive.UseVisualStyleBackColor = true;
            // 
            // StatNoActive
            // 
            this.StatNoActive.AutoSize = true;
            this.StatNoActive.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.StatNoActive.Location = new System.Drawing.Point(143, 26);
            this.StatNoActive.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.StatNoActive.Name = "StatNoActive";
            this.StatNoActive.Size = new System.Drawing.Size(56, 17);
            this.StatNoActive.TabIndex = 0;
            this.StatNoActive.TabStop = true;
            this.StatNoActive.Text = "موقف";
            this.StatNoActive.UseVisualStyleBackColor = true;
            // 
            // groupBoxReport
            // 
            this.groupBoxReport.Controls.Add(this.Report2);
            this.groupBoxReport.Controls.Add(this.Report1);
            this.groupBoxReport.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBoxReport.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBoxReport.Location = new System.Drawing.Point(20, 49);
            this.groupBoxReport.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxReport.Name = "groupBoxReport";
            this.groupBoxReport.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxReport.Size = new System.Drawing.Size(387, 63);
            this.groupBoxReport.TabIndex = 55;
            this.groupBoxReport.TabStop = false;
            this.groupBoxReport.Text = "نوع التقرير";
            // 
            // Report2
            // 
            this.Report2.AutoSize = true;
            this.Report2.Location = new System.Drawing.Point(44, 26);
            this.Report2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Report2.Name = "Report2";
            this.Report2.Size = new System.Drawing.Size(94, 17);
            this.Report2.TabIndex = 3;
            this.Report2.TabStop = true;
            this.Report2.Text = "ارباح وخسائر";
            this.Report2.UseVisualStyleBackColor = true;
            // 
            // Report1
            // 
            this.Report1.AutoSize = true;
            this.Report1.Location = new System.Drawing.Point(202, 26);
            this.Report1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Report1.Name = "Report1";
            this.Report1.Size = new System.Drawing.Size(102, 17);
            this.Report1.TabIndex = 2;
            this.Report1.TabStop = true;
            this.Report1.Text = "ميزانية عمومية";
            this.Report1.UseVisualStyleBackColor = true;
            // 
            // groupBoxType
            // 
            this.groupBoxType.Controls.Add(this.StateFr3e);
            this.groupBoxType.Controls.Add(this.StateRasi);
            this.groupBoxType.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBoxType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBoxType.Location = new System.Drawing.Point(436, 233);
            this.groupBoxType.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxType.Name = "groupBoxType";
            this.groupBoxType.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxType.Size = new System.Drawing.Size(241, 63);
            this.groupBoxType.TabIndex = 53;
            this.groupBoxType.TabStop = false;
            this.groupBoxType.Text = "نوع الحساب";
            // 
            // StateFr3e
            // 
            this.StateFr3e.AutoSize = true;
            this.StateFr3e.Location = new System.Drawing.Point(23, 26);
            this.StateFr3e.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.StateFr3e.Name = "StateFr3e";
            this.StateFr3e.Size = new System.Drawing.Size(57, 17);
            this.StateFr3e.TabIndex = 3;
            this.StateFr3e.TabStop = true;
            this.StateFr3e.Text = "فرعي";
            this.StateFr3e.UseVisualStyleBackColor = true;
            // 
            // StateRasi
            // 
            this.StateRasi.AutoSize = true;
            this.StateRasi.Location = new System.Drawing.Point(133, 26);
            this.StateRasi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.StateRasi.Name = "StateRasi";
            this.StateRasi.Size = new System.Drawing.Size(64, 17);
            this.StateRasi.TabIndex = 2;
            this.StateRasi.TabStop = true;
            this.StateRasi.Text = "رئيسي";
            this.StateRasi.UseVisualStyleBackColor = true;
            // 
            // groupBoxNature
            // 
            this.groupBoxNature.Controls.Add(this.StatMaden);
            this.groupBoxNature.Controls.Add(this.StatDaain);
            this.groupBoxNature.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBoxNature.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBoxNature.Location = new System.Drawing.Point(734, 233);
            this.groupBoxNature.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxNature.Name = "groupBoxNature";
            this.groupBoxNature.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxNature.Size = new System.Drawing.Size(241, 63);
            this.groupBoxNature.TabIndex = 52;
            this.groupBoxNature.TabStop = false;
            this.groupBoxNature.Text = "طبيعة الحساب";
            // 
            // StatMaden
            // 
            this.StatMaden.AutoSize = true;
            this.StatMaden.Location = new System.Drawing.Point(23, 26);
            this.StatMaden.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.StatMaden.Name = "StatMaden";
            this.StatMaden.Size = new System.Drawing.Size(51, 17);
            this.StatMaden.TabIndex = 3;
            this.StatMaden.TabStop = true;
            this.StatMaden.Text = "مدين";
            this.StatMaden.UseVisualStyleBackColor = true;
            // 
            // StatDaain
            // 
            this.StatDaain.AutoSize = true;
            this.StatDaain.Location = new System.Drawing.Point(150, 26);
            this.StatDaain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.StatDaain.Name = "StatDaain";
            this.StatDaain.Size = new System.Drawing.Size(48, 17);
            this.StatDaain.TabIndex = 2;
            this.StatDaain.TabStop = true;
            this.StatDaain.Text = "دائن";
            this.StatDaain.UseVisualStyleBackColor = true;
            // 
            // groupBoxCurrncy
            // 
            this.groupBoxCurrncy.Controls.Add(this.dataGridViewCurr);
            this.groupBoxCurrncy.Controls.Add(this.buttAddCurr);
            this.groupBoxCurrncy.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            this.groupBoxCurrncy.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBoxCurrncy.Location = new System.Drawing.Point(20, 130);
            this.groupBoxCurrncy.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxCurrncy.Name = "groupBoxCurrncy";
            this.groupBoxCurrncy.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBoxCurrncy.Size = new System.Drawing.Size(387, 165);
            this.groupBoxCurrncy.TabIndex = 54;
            this.groupBoxCurrncy.TabStop = false;
            this.groupBoxCurrncy.Text = "العملات المتاحة";
            // 
            // dataGridViewCurr
            // 
            this.dataGridViewCurr.AllowUserToAddRows = false;
            this.dataGridViewCurr.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridViewCurr.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewCurr.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewCurr.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewCurr.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridViewCurr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCurr.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewCurr.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCurr.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCurr.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewCurr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewCurr.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dataGridViewCurr.Location = new System.Drawing.Point(67, 17);
            this.dataGridViewCurr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.dataGridViewCurr.Name = "dataGridViewCurr";
            this.dataGridViewCurr.RowHeadersVisible = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Gray;
            this.dataGridViewCurr.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewCurr.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCurr.Size = new System.Drawing.Size(317, 144);
            this.dataGridViewCurr.TabIndex = 31;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "العملة";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "حد الدين";
            this.Column2.Name = "Column2";
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "متاح";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "id";
            this.Column4.Name = "Column4";
            this.Column4.Visible = false;
            // 
            // buttAddCurr
            // 
            this.buttAddCurr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAddCurr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAddCurr.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttAddCurr.FlatAppearance.BorderSize = 0;
            this.buttAddCurr.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAddCurr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAddCurr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAddCurr.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAddCurr.ForeColor = System.Drawing.Color.White;
            this.buttAddCurr.Image = ((System.Drawing.Image)(resources.GetObject("buttAddCurr.Image")));
            this.buttAddCurr.Location = new System.Drawing.Point(3, 17);
            this.buttAddCurr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.buttAddCurr.Name = "buttAddCurr";
            this.buttAddCurr.Size = new System.Drawing.Size(64, 144);
            this.buttAddCurr.TabIndex = 117;
            this.buttAddCurr.Text = "اضافة عملة";
            this.buttAddCurr.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttAddCurr.UseVisualStyleBackColor = false;
            this.buttAddCurr.Click += new System.EventHandler(this.button5_Click);
            // 
            // AccFather
            // 
            this.AccFather.BackColor = System.Drawing.Color.Silver;
            this.AccFather.ForeColor = System.Drawing.Color.Black;
            this.AccFather.Location = new System.Drawing.Point(446, 59);
            this.AccFather.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AccFather.Name = "AccFather";
            this.AccFather.ReadOnly = true;
            this.AccFather.Size = new System.Drawing.Size(136, 23);
            this.AccFather.TabIndex = 50;
            this.AccFather.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.AccFather.TextChanged += new System.EventHandler(this.AccFather_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(874, 186);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 16);
            this.label4.TabIndex = 49;
            this.label4.Text = "رتبة الحساب:";
            // 
            // AccName
            // 
            this.AccName.BackColor = System.Drawing.Color.Silver;
            this.AccName.ForeColor = System.Drawing.Color.Black;
            this.AccName.Location = new System.Drawing.Point(446, 123);
            this.AccName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AccName.Name = "AccName";
            this.AccName.Size = new System.Drawing.Size(422, 23);
            this.AccName.TabIndex = 48;
            this.AccName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(875, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 16);
            this.label3.TabIndex = 47;
            this.label3.Text = "اسم الحساب:";
            // 
            // AccId
            // 
            this.AccId.BackColor = System.Drawing.Color.Gray;
            this.AccId.ForeColor = System.Drawing.Color.White;
            this.AccId.Location = new System.Drawing.Point(722, 59);
            this.AccId.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AccId.Name = "AccId";
            this.AccId.ReadOnly = true;
            this.AccId.Size = new System.Drawing.Size(145, 23);
            this.AccId.TabIndex = 46;
            this.AccId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(875, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 45;
            this.label2.Text = "رقم الحساب:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(582, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 16);
            this.label1.TabIndex = 43;
            this.label1.Text = " رقم حساب الاب:";
            // 
            // AccLevel
            // 
            this.AccLevel.BackColor = System.Drawing.Color.Silver;
            this.AccLevel.ForeColor = System.Drawing.Color.Black;
            this.AccLevel.Location = new System.Drawing.Point(733, 180);
            this.AccLevel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.AccLevel.Name = "AccLevel";
            this.AccLevel.ReadOnly = true;
            this.AccLevel.Size = new System.Drawing.Size(136, 23);
            this.AccLevel.TabIndex = 44;
            this.AccLevel.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panFillRight
            // 
            this.panFillRight.Controls.Add(this.panFillRightDown);
            this.panFillRight.Controls.Add(this.panFillRightUp);
            this.panFillRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panFillRight.Location = new System.Drawing.Point(1002, 0);
            this.panFillRight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillRight.Name = "panFillRight";
            this.panFillRight.Size = new System.Drawing.Size(352, 434);
            this.panFillRight.TabIndex = 2;
            // 
            // panFillRightDown
            // 
            this.panFillRightDown.Controls.Add(this.treeView1);
            this.panFillRightDown.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFillRightDown.Location = new System.Drawing.Point(0, 79);
            this.panFillRightDown.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panFillRightDown.Name = "panFillRightDown";
            this.panFillRightDown.Size = new System.Drawing.Size(352, 355);
            this.panFillRightDown.TabIndex = 1;
            // 
            // treeView1
            // 
            this.treeView1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.ForeColor = System.Drawing.Color.Black;
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(352, 355);
            this.treeView1.TabIndex = 41;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // panFillRightUp
            // 
            this.panFillRightUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFillRightUp.Location = new System.Drawing.Point(0, 0);
            this.panFillRightUp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panFillRightUp.Name = "panFillRightUp";
            this.panFillRightUp.Size = new System.Drawing.Size(352, 79);
            this.panFillRightUp.TabIndex = 0;
            // 
            // panFillLift
            // 
            this.panFillLift.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFillLift.Location = new System.Drawing.Point(0, 0);
            this.panFillLift.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillLift.Name = "panFillLift";
            this.panFillLift.Size = new System.Drawing.Size(1354, 434);
            this.panFillLift.TabIndex = 1;
            // 
            // panDown
            // 
            this.panDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panDown.Controls.Add(this.statusStrip1);
            this.panDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDown.Location = new System.Drawing.Point(0, 480);
            this.panDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDown.Name = "panDown";
            this.panDown.Size = new System.Drawing.Size(1354, 39);
            this.panDown.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1354, 39);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Controls.Add(this.labTitle);
            this.panUp.Controls.Add(this.txtSerch);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(1354, 46);
            this.panUp.TabIndex = 0;
            this.panUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panUp_Paint);
            this.panUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panUp_MouseDown);
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(14, 6);
            this.pictureClose.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(35, 33);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 10;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click_1);
            // 
            // labTitle
            // 
            this.labTitle.AutoSize = true;
            this.labTitle.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labTitle.ForeColor = System.Drawing.Color.White;
            this.labTitle.Image = global::AccSystem.Properties.Resources.Flow_Chart_32px;
            this.labTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labTitle.Location = new System.Drawing.Point(1074, 8);
            this.labTitle.Name = "labTitle";
            this.labTitle.Size = new System.Drawing.Size(242, 27);
            this.labTitle.TabIndex = 9;
            this.labTitle.Text = "        الدليل المحاسبي";
            // 
            // txtSerch
            // 
            this.txtSerch.BackColor = System.Drawing.Color.DimGray;
            this.txtSerch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSerch.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerch.ForeColor = System.Drawing.Color.White;
            this.txtSerch.Location = new System.Drawing.Point(58, 10);
            this.txtSerch.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtSerch.Multiline = true;
            this.txtSerch.Name = "txtSerch";
            this.txtSerch.Size = new System.Drawing.Size(368, 29);
            this.txtSerch.TabIndex = 8;
            this.txtSerch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttPrint
            // 
            this.buttPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttPrint.FlatAppearance.BorderSize = 0;
            this.buttPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttPrint.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttPrint.ForeColor = System.Drawing.Color.White;
            this.buttPrint.Image = ((System.Drawing.Image)(resources.GetObject("buttPrint.Image")));
            this.buttPrint.Location = new System.Drawing.Point(619, 25);
            this.buttPrint.Name = "buttPrint";
            this.buttPrint.Size = new System.Drawing.Size(67, 101);
            this.buttPrint.TabIndex = 176;
            this.buttPrint.Text = "طباعة";
            this.buttPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttPrint.UseVisualStyleBackColor = false;
            this.buttPrint.Click += new System.EventHandler(this.buttPrint_Click);
            // 
            // Account
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1354, 519);
            this.Controls.Add(this.panMain);
            this.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Account";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "Form4";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.AccTree_Load);
            this.panMain.ResumeLayout(false);
            this.panFill.ResumeLayout(false);
            this.panFillFill.ResumeLayout(false);
            this.panFillLiftDown.ResumeLayout(false);
            this.groupBoxOprea.ResumeLayout(false);
            this.groupBoxOprea.PerformLayout();
            this.panFillLiftUp.ResumeLayout(false);
            this.groupBoxData.ResumeLayout(false);
            this.groupBoxData.PerformLayout();
            this.groupBoxState.ResumeLayout(false);
            this.groupBoxState.PerformLayout();
            this.groupBoxReport.ResumeLayout(false);
            this.groupBoxReport.PerformLayout();
            this.groupBoxType.ResumeLayout(false);
            this.groupBoxType.PerformLayout();
            this.groupBoxNature.ResumeLayout(false);
            this.groupBoxNature.PerformLayout();
            this.groupBoxCurrncy.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCurr)).EndInit();
            this.panFillRight.ResumeLayout(false);
            this.panFillRightDown.ResumeLayout(false);
            this.panDown.ResumeLayout(false);
            this.panDown.PerformLayout();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panFill;
        private System.Windows.Forms.Panel panDown;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.Label labTitle;
        private System.Windows.Forms.TextBox txtSerch;
        private System.Windows.Forms.Panel panFillFill;
        private System.Windows.Forms.Panel panFillLift;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Panel panFillRight;
        private System.Windows.Forms.Panel panFillLiftDown;
        private System.Windows.Forms.GroupBox groupBoxOprea;
        private System.Windows.Forms.Panel panFillLiftUp;
        private System.Windows.Forms.GroupBox groupBoxData;
        private System.Windows.Forms.GroupBox groupBoxState;
        private System.Windows.Forms.RadioButton StatActive;
        private System.Windows.Forms.RadioButton StatNoActive;
        private System.Windows.Forms.GroupBox groupBoxReport;
        private System.Windows.Forms.RadioButton Report2;
        private System.Windows.Forms.RadioButton Report1;
        private System.Windows.Forms.GroupBox groupBoxType;
        private System.Windows.Forms.RadioButton StateFr3e;
        private System.Windows.Forms.RadioButton StateRasi;
        private System.Windows.Forms.GroupBox groupBoxNature;
        private System.Windows.Forms.RadioButton StatMaden;
        private System.Windows.Forms.RadioButton StatDaain;
        private System.Windows.Forms.GroupBox groupBoxCurrncy;
        private System.Windows.Forms.DataGridView dataGridViewCurr;
        private System.Windows.Forms.TextBox AccFather;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox AccName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox AccId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox AccLevel;
        private System.Windows.Forms.Panel panFillRightDown;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Panel panFillRightUp;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.Button buttLast;
        private System.Windows.Forms.Button buttBack;
        private System.Windows.Forms.Button buttNext;
        private System.Windows.Forms.Button buttFrist;
        private System.Windows.Forms.Button buttAddCurr;
        private System.Windows.Forms.TextBox CountAcc;
        public System.Windows.Forms.Button buttAdd;
        public System.Windows.Forms.Button buttDelete;
        public System.Windows.Forms.Button buttEdite;
        public System.Windows.Forms.Button butSave;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Button buttPrint;
    }
}