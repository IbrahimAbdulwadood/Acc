﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{

    public partial class Account : Form
    {
        DataTable dtAllAcc = new DataTable(); //
        DataTable tabCurrAcc = new DataTable();
        Dictionary<string, bool> preForm = new Dictionary<string, bool>();
        ClassesProject.AccountSQL AccClass = new ClassesProject.AccountSQL();
    
        public int indexSelectedNode = 0;
        public bool isAddAcct = false;
        public bool isEditAcct = false;
        public int flag = 0;
        AccCurrList addCurr; //واجهة اضافة عملة للحسابات
        /*
        العمل المتبقي في هذه الشاشة
            تعديل حالة الحساب
            نوع التقرير
            */

   

        public Account(Dictionary<string, bool> pre)
        {
           
            InitializeComponent();
            preForm.Clear();
            preForm = pre;
        }

        #region تحريك الواجهة
        //////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس
        /// </summary>
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>
        ///////////////////////////////////////////////////////////////////////////////
        #endregion
       
        void EnterLikeTap(KeyEventArgs e)
        {
            //Copy Name Fun in Event KeyDown
            if (e.KeyCode == Keys.Enter)
            {

                SendKeys.Send("{TAB}");
            }
        }
        void FromtingCountAcc(string indexNode)
        {
            CountAcc.Text = indexNode + " - " + dtAllAcc.Rows.Count;
        }

        void fillAccTo_Nods(string ShowMainAccOrAll)
        { //يستقبل مستغير هل يشتي الحسابات الرئيسية فقط ولا الكل
            dtAllAcc.Clear();
           

            if (ShowMainAccOrAll == "All")
            {
                dtAllAcc = AccClass.ShowAllAcc();
            }
            else if(ShowMainAccOrAll == "Main")
            {
                dtAllAcc = AccClass.ShowAllMainAcc();
            }
           
          else
            {
                MessageBox.Show("fillAccTo_Nods"+" هناك مشكلة في استقبال نوع التعبية من هذه الداله ");
            }

           
            if (dtAllAcc.Rows.Count > 0)
            {
                treeView1.Nodes.Clear();
                treeView1.Select();
                /*
                           تترتب النود حسب رقم الاب 
                           */
                for (int i = 0; i < dtAllAcc.Rows.Count; i++)
                {    // يبحث عن الاباء والابناءحقه
                    TreeNode[] node = treeView1.Nodes.Find(dtAllAcc.Rows[i][2].ToString(), true);

                    if (node.Length >= 1)
                    //اذا في ابناء ضيفهم تحت ابوهم
                    {
                        node[0].Nodes.Add(dtAllAcc.Rows[i][0].ToString(), dtAllAcc.Rows[i][1].ToString() + " - " + dtAllAcc.Rows[i][0].ToString());

                    }
                    else
                    { //لا يوجد ابناء تنضاف قي الشجرة كأب
                        treeView1.Nodes.Add(dtAllAcc.Rows[i][0].ToString(), dtAllAcc.Rows[i][1].ToString() + " - " + dtAllAcc.Rows[i][0].ToString());
                    }
                }//end for


            }


        }
        #region داله صلاحيات العمليات
        void Permissions()
        {

            #region الصلاحيات
            if (preForm.Count > 0)
            {

                #region البيانات المستلمه
                /*
            ButtnPreCheck.Add("Showed", Convert.ToBoolean(DTpr.Rows[0][2].ToString()));
            ButtnPreCheck.Add("Inserted", Convert.ToBoolean(DTpr.Rows[0][3].ToString()));
            ButtnPreCheck.Add("EditeDate", Convert.ToBoolean(DTpr.Rows[0][4].ToString()));
            ButtnPreCheck.Add("Posting", Convert.ToBoolean(DTpr.Rows[0][5].ToString()));
            ButtnPreCheck.Add("Saerch", Convert.ToBoolean(DTpr.Rows[0][6].ToString()));
            ButtnPreCheck.Add("Printed", Convert.ToBoolean(DTpr.Rows[0][7].ToString()));
            ButtnPreCheck.Add("Updated", Convert.ToBoolean(DTpr.Rows[0][8].ToString()));
            ButtnPreCheck.Add("Deleted", Convert.ToBoolean(DTpr.Rows[0][9].ToString()));
                */
                #endregion

                bool result;
               
                    /////////////////////////////////////////////////////////////////
                    if (preForm.TryGetValue("Deleted", out result))
                        buttDelete.Enabled = result;

                    else { buttDelete.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "الحذف"); }
                    ///////////////////////////////////////////////////////////////////
                    if (preForm.TryGetValue("Inserted", out result))
                        buttAdd.Enabled = result;

                    else { buttAdd.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "الاضافة"); }
                    ///////////////////////////////////////////////////////////////////
                    if (preForm.TryGetValue("Updated", out result))
                        buttEdite.Enabled = result;

                    else { buttEdite.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "التعديل"); }
                    ///////////////////////////////////////////////////////////////////
              
                
                //فعل البوتونات
            }
            else
            {
                MessageBox.Show("لم يتم استلام اي صلاحيات", "FormatingTextBoxAndButt()");
            }
            #endregion
        }
        #endregion

        void formatingButt(string AddOrEditeOrSeve)
            {

            if (AddOrEditeOrSeve =="Add" || AddOrEditeOrSeve=="Edite" )
            {
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttDelete.Enabled = false;

                buttAddCurr.Enabled = true;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
                dataGridViewCurr.Columns[1].ReadOnly = false;
                dataGridViewCurr.Columns[2].ReadOnly = false;
            }
            else if (AddOrEditeOrSeve == "Save" || AddOrEditeOrSeve == "Load")
            {
                Permissions();
                buttAddCurr.Enabled = false;

                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;

                dataGridViewCurr.Columns[1].ReadOnly = true;
                dataGridViewCurr.Columns[2].ReadOnly = true;
            }
            
            }   
            
           void fillTextBox_FromNodes(bool isAdd)
        {

            try
            {
                if (!isAdd)
                {
                    AccId.Text = dtAllAcc.Rows[indexSelectedNode][0].ToString();
                    AccName.Text = dtAllAcc.Rows[indexSelectedNode][1].ToString();
                    AccFather.Text = dtAllAcc.Rows[indexSelectedNode][2].ToString();
                    AccLevel.Text = dtAllAcc.Rows[indexSelectedNode][3].ToString();
                    /////////////////////////////////////////
                    if (Convert.ToBoolean(dtAllAcc.Rows[indexSelectedNode][4].ToString()) == true)
                    {
                        StatActive.Checked = true;
                    }
                    else if (Convert.ToBoolean(dtAllAcc.Rows[indexSelectedNode][4].ToString()) == false)
                    {
                        StatNoActive.Checked = true;
                    }
                    /////////////////////////////////////////
                    if (dtAllAcc.Rows[indexSelectedNode][5].ToString() == "2")
                    {
                        StatDaain.Checked = true;
                    }
                    else if (dtAllAcc.Rows[indexSelectedNode][5].ToString() == "1")
                    {
                        StatMaden.Checked = true;
                    }
                    /////////////////////////////////////////////
                    if (dtAllAcc.Rows[indexSelectedNode][6].ToString() =="1")
                    {
                        StateRasi.Checked = true;
                    }
                    else if (dtAllAcc.Rows[indexSelectedNode][6].ToString() == "2")
                    {
                        StateFr3e.Checked = true;
                    }
                    //////////////////////////////////////////////
                    if ((dtAllAcc.Rows[indexSelectedNode][7].ToString()) == "1")
                    {
                        Report1.Checked = true;
                    }
                    else if (dtAllAcc.Rows[indexSelectedNode][7].ToString() == "2")
                    {
                        Report2.Checked = true;
                    }
                    FromtingCountAcc((indexSelectedNode + 1).ToString());

                }
                // if click button add 



                else
                { 

                    AccFather.Text = dtAllAcc.Rows[indexSelectedNode][0].ToString();
                    AccId.Text = AccClass.GetMaxFr3iAcc(AccFather.Text);
                    AccName.Text = "";
                    AccLevel.Text = AccClass.GetMaxLevel(AccFather.Text);

                    if (Convert.ToBoolean(dtAllAcc.Rows[indexSelectedNode][4].ToString()) == true)
                    {
                        StatActive.Checked = true;
                    }
                    else
                    {
                        StatNoActive.Checked = true;
                    }
                    /////////////////////////////////////////
                    /////////////////////////////////////////
                    if (dtAllAcc.Rows[indexSelectedNode][5].ToString() == "2")
                    {
                        StatDaain.Checked = true;
                    }
                    else if (dtAllAcc.Rows[indexSelectedNode][5].ToString() == "1")
                    {
                        StatMaden.Checked = true;
                    }
                    /////////////////////////////////////////////
                    if (dtAllAcc.Rows[indexSelectedNode][6].ToString() == "1")
                    {
                        StateRasi.Checked = true;
                    }
                    else if (dtAllAcc.Rows[indexSelectedNode][6].ToString() == "2")
                    {
                        StateFr3e.Checked = true;
                    }
                    //////////////////////////////////////////////
                    if ((dtAllAcc.Rows[indexSelectedNode][7].ToString()) == "1")
                    {
                        Report1.Checked = true;
                    }
                    else if (dtAllAcc.Rows[indexSelectedNode][7].ToString() == "2")
                    {
                        Report2.Checked = true;
                    }

                   FromtingCountAcc((dtAllAcc.Rows.Count+1).ToString());
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }



        } 
            
                
       void ShowCurrAcc(bool isNotMain)
        {
            if (isNotMain)
            {
                groupBoxCurrncy.Enabled = false;
                dataGridViewCurr.Rows.Clear();
            }
            //اذا كان حساب رئيسي لا تعرض العملات
            else
            {
                groupBoxCurrncy.Enabled = true; //اذا كان حساب فرعي اعرض العملات
                tabCurrAcc = AccClass.GetCurrAcc(AccId.Text);
                dataGridViewCurr.Rows.Clear();
                for (int i = 0; i < tabCurrAcc.Rows.Count; i++)
                {
                    dataGridViewCurr.Rows.Add(tabCurrAcc.Rows[i][0].ToString(), tabCurrAcc.Rows[i][1].ToString(), (bool)tabCurrAcc.Rows[i][2], tabCurrAcc.Rows[i][3].ToString());
                }
                //هنا داله الي تعبي العملات حق المستخدم
            }

        }   
       
        List<string> GetAccCurrIdRelation4Acc(string AccId)
        {
            List<string> AccCurrId = new List<string>();
            DataTable DT = new DataTable();
            DT = AccClass.GetAccCurr4Acc(AccId);
            if (DT != null && DT.Rows.Count > 0)
            {
               // MessageBox.Show(DT.Rows.Count.ToString());
                for (int i = 0; i < DT.Rows.Count; i++)
                    AccCurrId.Add(DT.Rows[i][0].ToString());
            }

            return AccCurrId;
            
        }
        void DeletAcc(string AccId="-1")
        {
            List<string> AccCurr = new List<string>();
            List<string> MessgError = new List<string>();
         
            AccCurr = GetAccCurrIdRelation4Acc(AccId);
          //  MessageBox.Show(AccCurr.Count.ToString());
            if (AccCurr.Count > 0)
            {
                for(int i=0;i< AccCurr.Count; i++)
                {
                    DataTable DT = new DataTable();
                    try
                    {
                        DT = AccClass.GetAccCurrOprtion(AccCurr[i]);
                        if (DT != null && DT.Rows.Count > 0)
                        {
                          //  MessageBox.Show(DT.Rows.Count.ToString());
                            for (int j = 0; j < DT.Rows.Count; j++)
                                MessgError.Add(DT.Rows[j][0].ToString() + " " + DT.Rows[j][1].ToString() + " " + DT.Rows[j][2].ToString());
                        }

                    } catch(Exception e) { MessageBox.Show(e.ToString()); }
                    
                        
                }
                if (MessgError.Count > 0)
                    for (int i = 0; i < MessgError.Count; i++)
                        MessageBox.Show(MessgError[i],"لا يمكن الحذف يوجد علاقه مع ",MessageBoxButtons.OK,MessageBoxIcon.Stop);
                else
                {
                    if (DialogResult.Yes == (MessageBox.Show("تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question)))
                    {
                        try {
                            AccClass.DeletAcc(AccId);
                           // MessageBox.Show("تم عمليه الحذف بنجاح");
                            fillAccTo_Nods("All");
                        } catch { MessageBox.Show("لم يتم الحذف"); }
                        
                    }
                }
            }
            else
            {
                if(DialogResult.Yes==(MessageBox.Show("تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question)))
                {
                    AccClass.DeletAcc(AccId);
                    MessageBox.Show("تم عمليه الحذف بنجاح");
                    fillAccTo_Nods("All");
                }
               

            }

          

        }
        void Savedd(string isNewOrEdite)
        {

            if (isNewOrEdite =="Add")
            {  //الحفظ عند الاضافة
               
                if (AccName.Text != "")
                {
                    if (MessageBox.Show("هل تريد الاضافة ؟", "تنبية", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                    {
                        //string[] dataaa = { AccName.Text, AccFather.Text, AccLevel.Text, (StatActive.Checked ? "1" : "0"), (StatDaain.Checked ? "2" : "1"), (StateRasi.Checked ? "1" : "2"), (Report1.Checked ? "1" : "2") };
                        ////for (int i = 0; i < dataaa.Count(); i++)
                        ////    MessageBox.Show(dataaa[i]);
                        //// AccClass.InsertNewAcc(setValue());
                        AccClass.InsertNewAcc(AccId.Text, AccName.Text, AccFather.Text, AccLevel.Text, (StatActive.Checked ? "1" : "0"), (StatDaain.Checked ? "2" : "1"), (StateRasi.Checked ? "1" : "2"), (Report1.Checked ? "1" : "2"));
                        isAddAcct = false;
                        fillAccTo_Nods("All");
                        fillTextBox_FromNodes(isAddAcct);
                        formatingButt("Save");
                    }
                      
                   
                   
                   
                  //  butt(true);
                   // flag = 0;

                }
                else if (MessageBox.Show("يجب ادخال الاسم , هل تريد التراجع ؟ ", "تنبية", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                {
                    isAddAcct = false;
                   
                    fillAccTo_Nods("All");
                    fillTextBox_FromNodes(isAddAcct);
                    formatingButt("Save");
                    //butt(true);
                    //flag = 0;

                }
                else AccName.Focus();

            }
            else if (isNewOrEdite=="Edite")
            {
                if (AccName.Text != "" && AccId.Text != "")
                    if (MessageBox.Show("هل تريد التعديل ؟", "تنبية", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                    {
                        //اذا حول من فرعي الى رئيسي 
                        //bool raesi = accSelect.isRaesi(AccId.Text);
                        //if (StateRasi.Checked == false && raesi)
                        //{

                        //}
                        AccClass.UpdateNameAcc(
                            AccId.Text
                            , AccName.Text
                            , StatActive.Checked==true?"1":"0"
                            , StatMaden.Checked==true?"1":"2"
                            , Report1.Checked==true?"1":"2"
                            );
                    
                        for (int i = 0; i < dataGridViewCurr.Rows.Count; i++)
                        {
                            AccClass.UpdetCurrAcc(dataGridViewCurr.Rows[i].Cells[3].Value.ToString(), dataGridViewCurr.Rows[i].Cells[1].Value.ToString(),(dataGridViewCurr.Rows[i].Cells[2].Value.ToString())=="True"?"1":"0");
                        }
                        // butt(true);
                        fillAccTo_Nods("All");
                        fillTextBox_FromNodes(isAddAcct);
                        isEditAcct = false;
                        formatingButt("Save");

                    }
                    else
                        MessageBox.Show("ادخل الاسم");

                //flag = 0;
            }
            // else { }
        }

        void afterSelectedNode(TreeViewEventArgs e)
        {
            int i = 0;
            String name = e.Node.Name;
            //  int a=  e.Node.TreeView.GetNodeCount(true);

            for (i = 0; i < dtAllAcc.Rows.Count; i++)
            {
                if (dtAllAcc.Rows[i][0].ToString() == name)
                { indexSelectedNode = i; break; }

            }
            fillTextBox_FromNodes(isAddAcct);
            // FromtingCountAcc((e.Node.Index+1).ToString());
            //  MessageBox.Show("a= "+a.ToString()+" count= "+ (e.Node.Index + 1).ToString());
            ShowCurrAcc(AccClass.IsMainAcc(AccId.Text));
            // treeView1.Select();
        }

      
        ////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

       

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            //داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void pictureClose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

      

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            afterSelectedNode(e);
        }
       
        private void AccFather_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }
       // ClassesProject.ControlProj ctr = new ClassesProject.ControlProj(1);
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
          //  ctr.PlayForm(this, this.Name);
               

        }

        private void AccTree_Load(object sender, EventArgs e)
        {
            fillAccTo_Nods("All");
            fillTextBox_FromNodes(false);
            formatingButt("Load");
            // butSave.Enabled = true;
            //  buttAddCurr.Enabled = false;
            dataGridViewCurr.Columns[1].ReadOnly = true;
            dataGridViewCurr.Columns[2].ReadOnly = true;
            dataGridViewCurr.Columns[0].ReadOnly = true;
            // treeView1.Select();
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            isAddAcct = true;
            formatingButt("Add");
            fillAccTo_Nods("Main");
            treeView1.Select();
            fillTextBox_FromNodes(isAddAcct);
           

        }

        private void butSave_Click(object sender, EventArgs e)
        {
            if (isAddAcct)
            {
                Savedd("Add");
            }
           else if (isEditAcct)
            {
                Savedd("Edite");
            }
            
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            isEditAcct = true;
            formatingButt("Edite");

        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            treeView1.Select();
            SendKeys.Send("{Down}");
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            treeView1.Select();
            SendKeys.Send("{Up}");
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            treeView1.Select();
            SendKeys.Send("{RIGHT}");
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            treeView1.Select();
            SendKeys.Send("{Left}");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            /*

            * عرفنا مصفوفة فارغه لتخزين العملات الموجود للمستخدم
            * اذا كان معاه عملات
            * المصفوفة تاخذ حجم عدد العملات المتاحه للمستخدم
            * ونخزن فيها ارقام العملات مثل ما هو مبين في الفوريه
            * هئنا الابوكجت الخاص بواجه العملات وارسلنا لها العملات الي موجوده مع المسخدم
            * وعرضنا له الواجهه
            * 
       */

            string[] c = null;
            if (dataGridViewCurr.RowCount > 0)
            {
                c = new string[dataGridViewCurr.RowCount];
                for (int i = 0; i < dataGridViewCurr.RowCount; i++)
                {
                    c[i] = dataGridViewCurr.Rows[i].Cells[0].Value.ToString();
                }
            }

            addCurr = new AccCurrList(c);
            addCurr.ShowDialog();

            /*
             * معي متغير داخل الواجهه حق العملات من نوع بولين اذا كان مفعل
             * و عدد الصفوف في الجريد حق العملات اكبر من 1 ادخل الشرط
             * 
        */

            if (addCurr.stateSelect && addCurr.dataGridView1.RowCount > 0)
            {
                int indexCurrInDatGrV = AccCurrList.indeex;
                /*
           *  اندكس العمله حسب الداتا جريت فيو
                 *  عشان نجيب رقمها كما مكتوب قي الاسفل* 
      */
                string idCurrInDB = addCurr.dataGridView1.Rows[indexCurrInDatGrV].Cells[0].Value.ToString();

                //اضافة هذه العملة الى الحساب
                AccClass.InsertNewCurrAcc(AccId.Text, idCurrInDB);// currAcc.(AccId.Text, idCurrInDB);
                ShowCurrAcc(AccClass.IsMainAcc(AccId.Text));
              
            }
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if(AccId.Text!=string.Empty)
            DeletAcc(AccId.Text);
        }

        private void buttPrint_Click(object sender, EventArgs e)
        {
            Reports.Account CS = new Reports.Account();
            CS.SetParameterValue("@id", AccId.Text);
            Reports.frm_Reports f = new Reports.frm_Reports();
            f.crystalReportViewer1.ReportSource = CS;
            f.ShowDialog();
        }
    }
}
