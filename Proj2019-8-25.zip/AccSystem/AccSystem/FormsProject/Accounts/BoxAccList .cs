﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class BoxAccList : Form
    {
        string[] AccBoxExist;
        public BoxAccList()
        {
            InitializeComponent();
            
        }

       
        int i;
      static  public int indeex;
        public bool stateSelect = true;
        DataTable datatable;
        ClassesProject.BoxsSQL boxss = new ClassesProject.BoxsSQL();
      

       
       

        private void pictureClose_Click(object sender, EventArgs e)
        {
                indeex = -1;
               stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());

            indeex = dataGridView1.CurrentCell.RowIndex;
            MessageBox.Show(indeex.ToString());
            Close();
            //setIndex();

        }

        private void BoxAccList_Load(object sender, EventArgs e)
        {
            AccBoxExist = boxss.GetAccBoxs();
            datatable = boxss.GetAllAcc(); //بترجع الحسابات الفرعية الخاصة ب الصناديق
            bool b;
            if (datatable.Rows.Count > 0)
            {
                if (AccBoxExist != null)
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        b = true;
                        for (int j = 0; j < AccBoxExist.Length; j++)
                        {





                            if (AccBoxExist[j] == datatable.Rows[i][0].ToString())
                            {


                                b = false;
                            }



                        }
                        if (b)
                        {
                            dataGridView1.Rows.Add(
                                datatable.Rows[i][0].ToString(),//AccCurr_id
                                datatable.Rows[i][1].ToString(),//Acc_id
                                datatable.Rows[i][2].ToString(),//Acc_name
                                datatable.Rows[i][3].ToString()//Curr_sumbol_eng
                                );
                        }

                    }

                    if (dataGridView1.Rows.Count == 0)

                    {
                        // bunifuThinButton21.ButtonText = "لا يوجد عملات";
                        bunifuThinButton21.Visible = false;
                        label1.Visible = true;
                        label1.Text = "لا يوجد حسابات غير مرتبطة يرجى اضافة حساب من الدليل المحسابي";
                    }

                }
                else
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(
                                 datatable.Rows[i][0].ToString(),//AccCurr_id
                                 datatable.Rows[i][1].ToString(),//Acc_id
                                 datatable.Rows[i][2].ToString(),//Acc_name
                                 datatable.Rows[i][3].ToString()//Curr_sumbol_eng
                                 );
                    }

                }
            }


        }
    }
}
