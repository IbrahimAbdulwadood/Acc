﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class BoxUsersList : Form
    {
        List<string> UsersId=new List<string>();
        public BoxUsersList(List<string> UsersId)
        {
            InitializeComponent();
            this.UsersId = UsersId;
         
        }

       
        int i;
        static  public int indeex;
        public bool stateSelect = true;
        DataTable datatable;
        ClassesProject.BoxsSQL boxss = new ClassesProject.BoxsSQL();
        private void ListCurrencyNamesForm_Load(object sender, EventArgs e)
        {
            datatable = boxss.GetAllUsers();
            bool b;
            if (datatable.Rows.Count > 0)
            {
                if (UsersId != null&& UsersId.Count>0)
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        b = true;
                        for (int j = 0; j < UsersId.Count; j++)
                        {





                            if (UsersId[j] == datatable.Rows[i][0].ToString())
                            {


                                b = false;
                            }



                        }
                        if (b)
                        {
                            dataGridView1.Rows.Add(datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString());
                        }

                    }

                     if (dataGridView1.Rows.Count == 0)

                    {
                       // bunifuThinButton21.ButtonText = "لا يوجد عملات";
                        bunifuThinButton21.Visible = false;
                        label1.Visible = true;
                        label1.Text = "لا يوجد مستخدمين";
                    }

                   }
                else
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString());
                    }

                }
            }

            


        }

       

       
       
       

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());
            if (dataGridView1.RowCount > 0)
                indeex = dataGridView1.CurrentCell.RowIndex;
            else
                indeex = -1;
           Close();
            //setIndex();

        }
    }
}
