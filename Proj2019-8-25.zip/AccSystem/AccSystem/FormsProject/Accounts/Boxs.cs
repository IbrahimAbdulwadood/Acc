﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class Boxs : Form
    {
        public Boxs()
        {
            InitializeComponent();
        }

       


        /// <summary>
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس
        /// </summary>
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>


        ClassesProject.BoxsSQL boxClass = new ClassesProject.BoxsSQL();
        DataTable dataTableBoxs;
        DataTable dataTableUsers;
        BoxUsersList boxUserList;
        BoxAccList boxAccList;

        //////////////////////////////////////////////////////////
        public string flagAddOrEdit = "";
        void FillTextBox()
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                
                int i = dataGridView1.CurrentCell.RowIndex;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */


                Box_id.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                Box_name.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                Acc_id_fk.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                Acc_name_fk.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                Acc_id_fk.Tag= dataGridView1.Rows[i].Cells[5].Value.ToString();
                txtCurrName.Text= dataGridView1.Rows[i].Cells[4].Value.ToString();
                FillTextBoxCountRows((i + 1).ToString());
                ShowUsersBox(Box_id.Text);

            }



        }
        void fillData(string NormalOrSerch)
        {

            dataTableBoxs = new DataTable();
           
            if (NormalOrSerch == "All")
                //يستعلم عن جميع الصناديق 
                dataTableBoxs = boxClass.GetAllBox();
            else if (NormalOrSerch == "Serch")
                dataTableBoxs = boxClass.Serch(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridView1.Rows.Clear();

                for (int i = 0; i < dataTableBoxs.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add(
                         dataTableBoxs.Rows[i][0].ToString(),
                         dataTableBoxs.Rows[i][1].ToString(),
                         dataTableBoxs.Rows[i][2].ToString(),
                         dataTableBoxs.Rows[i][3].ToString(),
                         dataTableBoxs.Rows[i][4].ToString(),
                         dataTableBoxs.Rows[i][5].ToString()
                        );
                }
                if (dataGridView1.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    Box_id.Text = string.Empty;
                    Box_name.Text = string.Empty;
                    Acc_id_fk.Text = string.Empty;
                    Acc_id_fk.Tag = null;
                    Acc_name_fk.Text = string.Empty;
                    txtCurrName.Tag = string.Empty;
                    dataGridViewUsers.Rows.Clear();
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch { }

        }
        void ShowUsersBox(string idBox)
        {
            
            
            {

                dataTableUsers = boxClass.GetUsersBox(Box_id.Text);
                dataGridViewUsers.Rows.Clear();
                for (int i = 0; i < dataTableUsers.Rows.Count; i++)
                {
                    dataGridViewUsers.Rows.Add(dataTableUsers.Rows[i][0].ToString(), dataTableUsers.Rows[i][1].ToString(), (bool)dataTableUsers.Rows[i][2]);
                }
                //هنا داله الي تعبي العملات حق المستخدم
            }

        }
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (Box_name.Text != string.Empty && Acc_id_fk.Text != string.Empty && Acc_name_fk.Text != string.Empty)
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        // string[] data = { CurrName.Text, CurrSumbolAR.Text, CurrSumbolEN.Text, CurrFakah.Text, CurrEchanqe.Text, (CurrIsLocal.Checked ? "1" : "0"), (CurrIsStock.Checked ? "1" : "0"), (CurrMaximum.Text != string.Empty ? CurrMaximum.Text : "0"), (CurrMinimum.Text != string.Empty ? CurrMinimum.Text : "0") };
                        boxClass.InsertNewBox(Box_name.Text, Acc_id_fk.Tag.ToString());

                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }


                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }



            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (Box_name.Text != string.Empty && Acc_id_fk.Text != string.Empty && Acc_name_fk.Text != string.Empty)
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        boxClass.UpdateNameBox(Box_id.Text,Box_name.Text);
                        for(int i = 0; i < dataGridViewUsers.Rows.Count; i++)
                        { //تعديل حاله المستخدمين
                            boxClass.UpdateStateUserBox(Box_id.Text, (dataGridViewUsers.Rows[i].Cells[0].Value).ToString(),( (dataGridViewUsers.Rows[i].Cells[2].Value).ToString()=="True"?"1":"0"));
                        }
                        MessageBox.Show("تم التعديل بنجاح");
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }

                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }

        void ForamtingAdd()
        {
            Box_id.Text = boxClass.GetMaxId();
            Box_name.Text = "";
            Acc_id_fk.Text = "";
            Acc_id_fk.Tag = null;
            txtCurrName.Text = string.Empty;
            Acc_name_fk.Text = "";
            Box_name.Focus();
            dataGridViewUsers.Rows.Clear();
            //   CheckEnableLocalAndStock();



        }
        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                Box_name.ReadOnly = false;
                Acc_id_fk.ReadOnly = true;
                Acc_name_fk.ReadOnly = true;
                txtCurrName.ReadOnly = true;
                /////////////////////
                txtSerch.ReadOnly = true;

                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
                /////////////////مستخدمين الصندوق//////////////////
                bttAddUsers.Enabled = true;
                dataGridViewUsers.Columns[2].ReadOnly = false;
              

                if (flagEditeOrAddOrSave == "Edite")
                {

                    Acc_id_fk.ReadOnly = true;


                }

            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                Box_name.ReadOnly = true;
                Acc_id_fk.ReadOnly = true;
                Acc_name_fk.ReadOnly = true;
                Acc_id_fk.ReadOnly = true;
                Acc_name_fk.ReadOnly = true;
                txtCurrName.ReadOnly = true;
                ///////////////////
                txtSerch.ReadOnly = false;
                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
                /////////////////////////
                bttAddUsers.Enabled = false;
                dataGridViewUsers.Columns[2].ReadOnly = true;
            }


        }
        void Delet()
        {
            List<string> data = new List<string>();
            data= boxClass.ChaeckCanDelet(Box_id.Text, Acc_id_fk.Tag.ToString());
            if (data.Count > 0)
            {
                MessageBox.Show("لا يمكن الحذف يوجد عمليات مرتبطة بهذا الصندوق", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (DialogResult.Yes == MessageBox.Show("؟تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                boxClass.Delet(Box_id.Text);
                fillData("All");

            }

        }
        void FillTextBoxFromButtMove(int i)
        {
            if (i >= 0)
            {
                dataGridView1.ClearSelection();
               
              
                Box_id.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                Box_name.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                Acc_id_fk.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                Acc_name_fk.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                txtCurrName.Text= dataGridView1.Rows[i].Cells[4].Value.ToString();
                Acc_id_fk.Tag= dataGridView1.Rows[i].Cells[5].Value.ToString();
                FillTextBoxCountRows((i + 1).ToString());
                ShowUsersBox(Box_id.Text);
            }

        }

        int indexBoxsButt(string btName, string BoxId)
        {
            /*
            داله لايجاد اندكس العمله حسب رقم العمله
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (BoxId == dataGridView1.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < dataGridView1.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return dataGridView1.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد عملات في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }

        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + dataGridView1.Rows.Count.ToString();
        }

        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }






        ///////////////////////////////////////////////////////////

        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            //داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void CurrMaximum_TextChanged(object sender, EventArgs e)
        {

        }

   

       
     

        private void groupBoxCurrncy_Enter(object sender, EventArgs e)
        {

        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btAddUsers_Click(object sender, EventArgs e)
        {
            /*

            * عرفنا مصفوفة فارغه لتخزين العملات الموجود للمستخدم
            * اذا كان معاه عملات
            * المصفوفة تاخذ حجم عدد العملات المتاحه للمستخدم
            * ونخزن فيها ارقام العملات مثل ما هو مبين في الفوريه
            * هئنا الابوكجت الخاص بواجه العملات وارسلنا لها العملات الي موجوده مع المسخدم
            * وعرضنا له الواجهه
            * 
       */

         
            List<string> userIdFound = new List<string>();
            if (dataGridViewUsers.RowCount > 0)
            {
               
                for (int i = 0; i < dataGridViewUsers.RowCount; i++)
                {
                  
                    userIdFound.Add(dataGridViewUsers.Rows[i].Cells[0].Value.ToString());
                }
            }

            boxUserList = new BoxUsersList(userIdFound);
            boxUserList.ShowDialog();

            /*
             * معي متغير داخل الواجهه حق العملات من نوع بولين اذا كان مفعل
             * و عدد الصفوف في الجريد حق العملات اكبر من 1 ادخل الشرط
             * 
        */

            if (boxUserList.stateSelect && boxUserList.dataGridView1.RowCount > 0&& BoxUsersList.indeex!=-1)
            {
                int indexUserInDatGrV = BoxUsersList.indeex;
                
                string idUserInDB = boxUserList.dataGridView1.Rows[indexUserInDatGrV].Cells[0].Value.ToString();

                //اضافة هذا المستخدم الى الصندوق
                boxClass.InsertUserBox(Box_id.Text, idUserInDB);
                ShowUsersBox(Box_id.Text);

            }
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void Boxs_Load(object sender, EventArgs e)
        {
            fillData("All");
            FormatingTextBoxAndButt("Load");
            dataGridView1.Select();
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SendDataToAddOrEdit(flagAddOrEdit);
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            flagAddOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexBoxsButt("Last", Box_id.Text));
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexBoxsButt("Back", Box_id.Text));
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexBoxsButt("Next", Box_id.Text));
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexBoxsButt("Frist", Box_id.Text));
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Down || e.KeyData == Keys.Up)
            {
                if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                    FillTextBox();
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

        private void Box_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopNumberInTextBox(e);
        }

        private void Acc_id_fk_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

        private void Box_id_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void dataGridView1_SelectionChanged_1(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void Acc_id_fk_KeyDown(object sender, KeyEventArgs e)
        {
            if(Acc_id_fk.Text==string.Empty&&e.KeyData==Keys.F9)
            {
                // MessageBox.Show("Habloooooooo ya leeeed");
                boxAccList = new BoxAccList();
                boxAccList.ShowDialog();

                /*
                 * معي متغير داخل الواجهه حق العملات من نوع بولين اذا كان مفعل
                 * و عدد الصفوف في الجريد حق العملات اكبر من 1 ادخل الشرط
                 * 
            */

                if (boxAccList.stateSelect && boxAccList.dataGridView1.RowCount > 0&& BoxAccList.indeex!=-1)
                {
                    int indexAccInDatGrV = BoxAccList.indeex;
                    /*
               *  اندكس العمله حسب الداتا جريت فيو
                     *  عشان نجيب رقمها كما مكتوب قي الاسفل* 
          */
                    Acc_id_fk.Tag = //احفظ فيه رقم حسابات عملات
                        boxAccList.dataGridView1.Rows[indexAccInDatGrV].Cells[0].Value.ToString();
                    Acc_id_fk.Text = boxAccList.dataGridView1.Rows[indexAccInDatGrV].Cells[1].Value.ToString();
                    Acc_name_fk.Text= boxAccList.dataGridView1.Rows[indexAccInDatGrV].Cells[2].Value.ToString();
                    txtCurrName.Text= boxAccList.dataGridView1.Rows[indexAccInDatGrV].Cells[3].Value.ToString();
                    //اضافة هذا المستخدم الى الصندوق



                }
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {
           
        }

        private void Acc_id_fk_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (Box_id.Text != string.Empty && Acc_id_fk.Tag != null)
                Delet();
        }
    }
}
