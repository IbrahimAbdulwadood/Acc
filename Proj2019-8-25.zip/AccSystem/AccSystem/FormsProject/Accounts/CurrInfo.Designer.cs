﻿namespace AccSystem.FormsProject.Accounts
{
    partial class CurrInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CurrInfo));
            this.pnlFill = new System.Windows.Forms.Panel();
            this.pnlFFill = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCustId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.IsCurrencyNameFeminine = new System.Windows.Forms.CheckBox();
            this.PartPrecision = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Arabic1199CurrencyName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Arabic310CurrencyName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Arabic2CurrencyName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Arabic1CurrencyName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.IsCurrencyPartNameFeminine = new System.Windows.Forms.CheckBox();
            this.Arabic1199CurrencyPartName = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.Arabic310CurrencyPartName = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Arabic2CurrencyPartName = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Arabic1CurrencyPartName = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.pnlFDown = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbHelp = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnEdite = new System.Windows.Forms.Button();
            this.pnlUp = new System.Windows.Forms.Panel();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.pnlDown = new System.Windows.Forms.Panel();
            this.pnlFill.SuspendLayout();
            this.pnlFFill.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.pnlFDown.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlFill
            // 
            this.pnlFill.Controls.Add(this.pnlFFill);
            this.pnlFill.Controls.Add(this.pnlFDown);
            this.pnlFill.Controls.Add(this.pnlUp);
            this.pnlFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFill.Location = new System.Drawing.Point(0, 0);
            this.pnlFill.Name = "pnlFill";
            this.pnlFill.Size = new System.Drawing.Size(801, 321);
            this.pnlFill.TabIndex = 1;
            // 
            // pnlFFill
            // 
            this.pnlFFill.Controls.Add(this.panel1);
            this.pnlFFill.Controls.Add(this.groupBox2);
            this.pnlFFill.Controls.Add(this.groupBox1);
            this.pnlFFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlFFill.Location = new System.Drawing.Point(0, 31);
            this.pnlFFill.Name = "pnlFFill";
            this.pnlFFill.Size = new System.Drawing.Size(801, 211);
            this.pnlFFill.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.txtCustName);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtCustId);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 31);
            this.panel1.TabIndex = 58;
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustName.Dock = System.Windows.Forms.DockStyle.Right;
            this.txtCustName.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.txtCustName.ForeColor = System.Drawing.Color.Black;
            this.txtCustName.Location = new System.Drawing.Point(327, 0);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.ReadOnly = true;
            this.txtCustName.Size = new System.Drawing.Size(180, 23);
            this.txtCustName.TabIndex = 55;
            this.txtCustName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Right;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(507, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 16);
            this.label6.TabIndex = 53;
            this.label6.Text = "اسم العملة:";
            // 
            // txtCustId
            // 
            this.txtCustId.BackColor = System.Drawing.Color.Gray;
            this.txtCustId.Dock = System.Windows.Forms.DockStyle.Right;
            this.txtCustId.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustId.ForeColor = System.Drawing.Color.White;
            this.txtCustId.Location = new System.Drawing.Point(591, 0);
            this.txtCustId.Name = "txtCustId";
            this.txtCustId.ReadOnly = true;
            this.txtCustId.Size = new System.Drawing.Size(131, 26);
            this.txtCustId.TabIndex = 54;
            this.txtCustId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Right;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(722, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 52;
            this.label2.Text = "رقم العملة:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.IsCurrencyNameFeminine);
            this.groupBox2.Controls.Add(this.PartPrecision);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.Arabic1199CurrencyName);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.Arabic310CurrencyName);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.Arabic2CurrencyName);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.Arabic1CurrencyName);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox2.Location = new System.Drawing.Point(0, 42);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(801, 86);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "الارقام الصحيحة";
            // 
            // IsCurrencyNameFeminine
            // 
            this.IsCurrencyNameFeminine.AutoSize = true;
            this.IsCurrencyNameFeminine.Location = new System.Drawing.Point(88, 53);
            this.IsCurrencyNameFeminine.Name = "IsCurrencyNameFeminine";
            this.IsCurrencyNameFeminine.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.IsCurrencyNameFeminine.Size = new System.Drawing.Size(134, 20);
            this.IsCurrencyNameFeminine.TabIndex = 65;
            this.IsCurrencyNameFeminine.Text = "اسم العملة مؤنث";
            this.IsCurrencyNameFeminine.UseVisualStyleBackColor = true;
            // 
            // PartPrecision
            // 
            this.PartPrecision.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.PartPrecision.ForeColor = System.Drawing.Color.Black;
            this.PartPrecision.Location = new System.Drawing.Point(12, 20);
            this.PartPrecision.Name = "PartPrecision";
            this.PartPrecision.ReadOnly = true;
            this.PartPrecision.Size = new System.Drawing.Size(115, 23);
            this.PartPrecision.TabIndex = 64;
            this.PartPrecision.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(133, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 13);
            this.label7.TabIndex = 63;
            this.label7.Text = "عدد خانات الجزء:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Arabic1199CurrencyName
            // 
            this.Arabic1199CurrencyName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Arabic1199CurrencyName.ForeColor = System.Drawing.Color.Black;
            this.Arabic1199CurrencyName.Location = new System.Drawing.Point(228, 50);
            this.Arabic1199CurrencyName.Name = "Arabic1199CurrencyName";
            this.Arabic1199CurrencyName.ReadOnly = true;
            this.Arabic1199CurrencyName.Size = new System.Drawing.Size(180, 23);
            this.Arabic1199CurrencyName.TabIndex = 62;
            this.Arabic1199CurrencyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(414, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 61;
            this.label5.Text = "11- 99:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Arabic310CurrencyName
            // 
            this.Arabic310CurrencyName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Arabic310CurrencyName.ForeColor = System.Drawing.Color.Black;
            this.Arabic310CurrencyName.Location = new System.Drawing.Point(513, 50);
            this.Arabic310CurrencyName.Name = "Arabic310CurrencyName";
            this.Arabic310CurrencyName.ReadOnly = true;
            this.Arabic310CurrencyName.Size = new System.Drawing.Size(180, 23);
            this.Arabic310CurrencyName.TabIndex = 60;
            this.Arabic310CurrencyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(694, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 59;
            this.label4.Text = "3 - 10:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // Arabic2CurrencyName
            // 
            this.Arabic2CurrencyName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Arabic2CurrencyName.ForeColor = System.Drawing.Color.Black;
            this.Arabic2CurrencyName.Location = new System.Drawing.Point(228, 20);
            this.Arabic2CurrencyName.Name = "Arabic2CurrencyName";
            this.Arabic2CurrencyName.ReadOnly = true;
            this.Arabic2CurrencyName.Size = new System.Drawing.Size(180, 23);
            this.Arabic2CurrencyName.TabIndex = 58;
            this.Arabic2CurrencyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(414, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 57;
            this.label3.Text = "2 فقط:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // Arabic1CurrencyName
            // 
            this.Arabic1CurrencyName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Arabic1CurrencyName.ForeColor = System.Drawing.Color.Black;
            this.Arabic1CurrencyName.Location = new System.Drawing.Point(513, 21);
            this.Arabic1CurrencyName.Name = "Arabic1CurrencyName";
            this.Arabic1CurrencyName.ReadOnly = true;
            this.Arabic1CurrencyName.Size = new System.Drawing.Size(180, 23);
            this.Arabic1CurrencyName.TabIndex = 56;
            this.Arabic1CurrencyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(697, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 53;
            this.label1.Text = "1 فقط:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.IsCurrencyPartNameFeminine);
            this.groupBox1.Controls.Add(this.Arabic1199CurrencyPartName);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.Arabic310CurrencyPartName);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.Arabic2CurrencyPartName);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.Arabic1CurrencyPartName);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(0, 128);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(801, 83);
            this.groupBox1.TabIndex = 56;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "اجزاء العملة";
            // 
            // IsCurrencyPartNameFeminine
            // 
            this.IsCurrencyPartNameFeminine.AutoSize = true;
            this.IsCurrencyPartNameFeminine.Location = new System.Drawing.Point(96, 40);
            this.IsCurrencyPartNameFeminine.Name = "IsCurrencyPartNameFeminine";
            this.IsCurrencyPartNameFeminine.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.IsCurrencyPartNameFeminine.Size = new System.Drawing.Size(126, 20);
            this.IsCurrencyPartNameFeminine.TabIndex = 76;
            this.IsCurrencyPartNameFeminine.Text = "اسم الجزء مؤنث";
            this.IsCurrencyPartNameFeminine.UseVisualStyleBackColor = true;
            // 
            // Arabic1199CurrencyPartName
            // 
            this.Arabic1199CurrencyPartName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Arabic1199CurrencyPartName.ForeColor = System.Drawing.Color.Black;
            this.Arabic1199CurrencyPartName.Location = new System.Drawing.Point(227, 42);
            this.Arabic1199CurrencyPartName.Name = "Arabic1199CurrencyPartName";
            this.Arabic1199CurrencyPartName.ReadOnly = true;
            this.Arabic1199CurrencyPartName.Size = new System.Drawing.Size(180, 23);
            this.Arabic1199CurrencyPartName.TabIndex = 73;
            this.Arabic1199CurrencyPartName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(413, 52);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 13);
            this.label9.TabIndex = 72;
            this.label9.Text = "11- 99:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // Arabic310CurrencyPartName
            // 
            this.Arabic310CurrencyPartName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Arabic310CurrencyPartName.ForeColor = System.Drawing.Color.Black;
            this.Arabic310CurrencyPartName.Location = new System.Drawing.Point(512, 42);
            this.Arabic310CurrencyPartName.Name = "Arabic310CurrencyPartName";
            this.Arabic310CurrencyPartName.ReadOnly = true;
            this.Arabic310CurrencyPartName.Size = new System.Drawing.Size(180, 23);
            this.Arabic310CurrencyPartName.TabIndex = 71;
            this.Arabic310CurrencyPartName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(693, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(42, 13);
            this.label10.TabIndex = 70;
            this.label10.Text = "3 - 10:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // Arabic2CurrencyPartName
            // 
            this.Arabic2CurrencyPartName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Arabic2CurrencyPartName.ForeColor = System.Drawing.Color.Black;
            this.Arabic2CurrencyPartName.Location = new System.Drawing.Point(227, 12);
            this.Arabic2CurrencyPartName.Name = "Arabic2CurrencyPartName";
            this.Arabic2CurrencyPartName.ReadOnly = true;
            this.Arabic2CurrencyPartName.Size = new System.Drawing.Size(180, 23);
            this.Arabic2CurrencyPartName.TabIndex = 69;
            this.Arabic2CurrencyPartName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(413, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 68;
            this.label11.Text = "2 فقط:";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // Arabic1CurrencyPartName
            // 
            this.Arabic1CurrencyPartName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Arabic1CurrencyPartName.ForeColor = System.Drawing.Color.Black;
            this.Arabic1CurrencyPartName.Location = new System.Drawing.Point(512, 13);
            this.Arabic1CurrencyPartName.Name = "Arabic1CurrencyPartName";
            this.Arabic1CurrencyPartName.ReadOnly = true;
            this.Arabic1CurrencyPartName.Size = new System.Drawing.Size(180, 23);
            this.Arabic1CurrencyPartName.TabIndex = 67;
            this.Arabic1CurrencyPartName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(696, 17);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 13);
            this.label12.TabIndex = 66;
            this.label12.Text = "1 فقط:";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // pnlFDown
            // 
            this.pnlFDown.Controls.Add(this.panel2);
            this.pnlFDown.Controls.Add(this.btnSave);
            this.pnlFDown.Controls.Add(this.btnEdite);
            this.pnlFDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlFDown.Location = new System.Drawing.Point(0, 242);
            this.pnlFDown.Name = "pnlFDown";
            this.pnlFDown.Size = new System.Drawing.Size(801, 79);
            this.pnlFDown.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Maroon;
            this.panel2.Controls.Add(this.lbHelp);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(801, 21);
            this.panel2.TabIndex = 219;
            // 
            // lbHelp
            // 
            this.lbHelp.AutoSize = true;
            this.lbHelp.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHelp.ForeColor = System.Drawing.Color.White;
            this.lbHelp.Location = new System.Drawing.Point(247, 3);
            this.lbHelp.Name = "lbHelp";
            this.lbHelp.Size = new System.Drawing.Size(308, 13);
            this.lbHelp.TabIndex = 58;
            this.lbHelp.Text = "انقر على اسم التكست بوكس لعرض مثال عن بيانات الخليه";
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(397, 27);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(110, 46);
            this.btnSave.TabIndex = 218;
            this.btnSave.Text = "حفظ";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnEdite
            // 
            this.btnEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEdite.FlatAppearance.BorderSize = 0;
            this.btnEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdite.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.btnEdite.ForeColor = System.Drawing.Color.White;
            this.btnEdite.Image = ((System.Drawing.Image)(resources.GetObject("btnEdite.Image")));
            this.btnEdite.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEdite.Location = new System.Drawing.Point(281, 27);
            this.btnEdite.Name = "btnEdite";
            this.btnEdite.Size = new System.Drawing.Size(110, 46);
            this.btnEdite.TabIndex = 217;
            this.btnEdite.Text = "تعديل";
            this.btnEdite.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnEdite.UseVisualStyleBackColor = false;
            // 
            // pnlUp
            // 
            this.pnlUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlUp.Controls.Add(this.pictureClose);
            this.pnlUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlUp.Location = new System.Drawing.Point(0, 0);
            this.pnlUp.Name = "pnlUp";
            this.pnlUp.Size = new System.Drawing.Size(801, 31);
            this.pnlUp.TabIndex = 60;
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(0, 0);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 31);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 8;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click);
            // 
            // pnlDown
            // 
            this.pnlDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pnlDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlDown.Location = new System.Drawing.Point(0, 321);
            this.pnlDown.Name = "pnlDown";
            this.pnlDown.Size = new System.Drawing.Size(801, 33);
            this.pnlDown.TabIndex = 2;
            // 
            // CurrInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 354);
            this.Controls.Add(this.pnlFill);
            this.Controls.Add(this.pnlDown);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "CurrInfo";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "بيانات تفقيط الارقام";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmCurrInfo_Load);
            this.pnlFill.ResumeLayout(false);
            this.pnlFFill.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.pnlFDown.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlUp.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlFill;
        private System.Windows.Forms.Panel pnlFFill;
        private System.Windows.Forms.Panel pnlFDown;
        private System.Windows.Forms.Panel pnlDown;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnEdite;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.TextBox txtCustId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel pnlUp;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lbHelp;
        public System.Windows.Forms.TextBox Arabic2CurrencyName;
        public System.Windows.Forms.TextBox Arabic1CurrencyName;
        public System.Windows.Forms.TextBox Arabic310CurrencyName;
        public System.Windows.Forms.TextBox Arabic1199CurrencyName;
        public System.Windows.Forms.TextBox PartPrecision;
        public System.Windows.Forms.CheckBox IsCurrencyNameFeminine;
        public System.Windows.Forms.CheckBox IsCurrencyPartNameFeminine;
        public System.Windows.Forms.TextBox Arabic1199CurrencyPartName;
        public System.Windows.Forms.TextBox Arabic310CurrencyPartName;
        public System.Windows.Forms.TextBox Arabic2CurrencyPartName;
        public System.Windows.Forms.TextBox Arabic1CurrencyPartName;
        private System.Windows.Forms.PictureBox pictureClose;
    }
}