﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class CurrInfo : Form
    {
        public CurrInfo(string idCurr,string nameCurr,string Formating)
        {
            InitializeComponent();
            txtCustId.Text = idCurr;
            txtCustName.Text = nameCurr;
            FormatingTxt(Formating);
            Format = Formating;
          //  MessageBox.Show(Format);
        }

        #region المتغيرات
        ClassesProject.CurrSQL CurSql = new ClassesProject.CurrSQL();
      public  ClassesProject.CurrncyParametr currParm = new ClassesProject.CurrncyParametr();

        DataTable DT;
        string Format;
        #endregion
        void GetData()
        {
            DT = new DataTable();
            DT= CurSql.CurrInfo(txtCustId.Text);
            if (DT != null && DT.Rows.Count > 0)
            {
                #region البيانات الي توصل للتيبل
                /*
                Arabic1CurrencyName
            , Arabic2CurrencyName
            , Arabic310CurrencyName
            , Arabic1199CurrencyName
            , Arabic1CurrencyPartName
            , Arabic2CurrencyPartName
            , Arabic310CurrencyPartName
            , Arabic1199CurrencyPartName
            , PartPrecision
            , IsCurrencyNameFeminine
            , IsCurrencyPartNameFeminine 
               */
                #endregion
                Arabic1CurrencyName.Text = DT.Rows[0][0].ToString();
                Arabic2CurrencyName.Text = DT.Rows[0][1].ToString();
                Arabic310CurrencyName.Text = DT.Rows[0][2].ToString();
                Arabic1199CurrencyName.Text = DT.Rows[0][3].ToString();
                Arabic1CurrencyPartName.Text = DT.Rows[0][4].ToString();
                Arabic2CurrencyPartName.Text = DT.Rows[0][5].ToString();
                Arabic310CurrencyPartName.Text = DT.Rows[0][6].ToString();
                Arabic1199CurrencyPartName.Text = DT.Rows[0][7].ToString();
                PartPrecision.Text = DT.Rows[0][8].ToString();
                IsCurrencyNameFeminine.Checked = (bool)DT.Rows[0][9];
                IsCurrencyPartNameFeminine.Checked = (bool)DT.Rows[0][10];

            }
            else
            {
                ClearTxt();
            }

        }
        void ClearTxt()
        {
            Arabic1CurrencyName.Text = string.Empty;
            Arabic2CurrencyName.Text = string.Empty;
            Arabic310CurrencyName.Text = string.Empty;
            Arabic1199CurrencyName.Text = string.Empty;
            Arabic1CurrencyPartName.Text = string.Empty;
            Arabic2CurrencyPartName.Text = string.Empty;
            Arabic310CurrencyPartName.Text = string.Empty;
            Arabic1199CurrencyPartName.Text = string.Empty;
            PartPrecision.Text = string.Empty;
            IsCurrencyNameFeminine.Checked = false;
            IsCurrencyPartNameFeminine.Checked = false;

        }
        void FormatingAddOrEdite()
        {

            Arabic1CurrencyName.ReadOnly = false;
            Arabic2CurrencyName.ReadOnly = false;
            Arabic310CurrencyName.ReadOnly = false;
            Arabic1199CurrencyName.ReadOnly = false;
            Arabic1CurrencyPartName.ReadOnly = false;
            Arabic2CurrencyPartName.ReadOnly = false;
            Arabic310CurrencyPartName.ReadOnly = false;
            Arabic1199CurrencyPartName.ReadOnly = false;
            PartPrecision.ReadOnly = false;
            IsCurrencyNameFeminine.Enabled = true;
            IsCurrencyPartNameFeminine.Enabled = true;
        }
        void FormatingTxt(string ShowOrEdite)
        {
            if (ShowOrEdite == "Load")
            {

                Arabic1CurrencyName.ReadOnly = true;
                Arabic2CurrencyName.ReadOnly = true;
                Arabic310CurrencyName.ReadOnly = true;
                Arabic1199CurrencyName.ReadOnly = true;
                Arabic1CurrencyPartName.ReadOnly = true;
                Arabic2CurrencyPartName.ReadOnly = true;
                Arabic310CurrencyPartName.ReadOnly = true;
                Arabic1199CurrencyPartName.ReadOnly = true;
                PartPrecision.ReadOnly = true;
                IsCurrencyNameFeminine.Enabled = false;
                IsCurrencyPartNameFeminine.Enabled = false;
                GetData();
                btnEdite.Enabled = false;
                btnSave.Enabled = false;

            }
            else if(ShowOrEdite == "Edite")
            {
                FormatingAddOrEdite();
                GetData();
                btnEdite.Enabled = true;
                btnSave.Enabled = true;
            }
            else if (ShowOrEdite=="Add")
            {
                ClearTxt();
                FormatingAddOrEdite();
                btnEdite.Enabled = true;
                btnSave.Enabled = true;
            }

        }

        private void label4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("خمس ليرات سورية || خمسة دراهم إماراتية");
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ليرة سورية || درهم إماراتي");
        }

        private void label3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ليرتان سوريتان||درهمان إماراتيان ");
        }

        private void label5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("خمسة و سبعون درهماً إماراتياً|| خمس و سبعون ليرةً سوريةً");
        }

        private void label7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("(للجنيه السوري: 2 (ليرة سورية = 100 جزء");
            MessageBox.Show("for Tunisian Dinars: 3 ( 1 TND = 1000 parts)");
        }

        private void label12_Click(object sender, EventArgs e)
        {
            MessageBox.Show("قرش||هللة"); 
        }

        private void label11_Click(object sender, EventArgs e)
        {
            MessageBox.Show("قرشان||هللتان"); 
        }

        private void label10_Click(object sender, EventArgs e)
        {
            //
            MessageBox.Show("قروش|| هللات");
        }

        private void label9_Click(object sender, EventArgs e)
        {
            MessageBox.Show("قرشاً||هللةً");
            //MessageBox.Show("");
        }

        private void FrmCurrInfo_Load(object sender, EventArgs e)
        {
           
        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            currParm.Arabic1CurrencyName = 
                Arabic1CurrencyName.Text==string.Empty?"NULL" : Arabic1CurrencyName.Text;

            currParm.Arabic2CurrencyName = 
                Arabic2CurrencyName.Text == string.Empty ? "NULL" : Arabic2CurrencyName.Text;

            currParm.Arabic310CurrencyName =
                Arabic310CurrencyName.Text == string.Empty ? "NULL" : Arabic310CurrencyName.Text;

            currParm.Arabic1199CurrencyName =
                Arabic1199CurrencyName.Text == string.Empty ? "NULL" : Arabic1199CurrencyName.Text;

            currParm.Arabic1CurrencyPartName =
                Arabic1CurrencyPartName.Text == string.Empty ? "NULL" : Arabic1CurrencyPartName.Text;

            currParm.Arabic2CurrencyPartName = 
                Arabic2CurrencyPartName.Text == string.Empty ? "NULL" : Arabic2CurrencyPartName.Text;

            currParm.Arabic310CurrencyPartName = 
                Arabic310CurrencyPartName.Text == string.Empty ? "NULL" : Arabic310CurrencyPartName.Text;

            currParm.Arabic1199CurrencyPartName =
                Arabic1199CurrencyPartName.Text == string.Empty ? "NULL" : Arabic1199CurrencyPartName.Text;

            currParm.PartPrecision = 
                PartPrecision.Text == string.Empty ? "NULL" : PartPrecision.Text;

            currParm.IsCurrencyNameFeminine =
                IsCurrencyNameFeminine.Checked==true?"1":"0";

            currParm.IsCurrencyPartNameFeminine =
                IsCurrencyPartNameFeminine.Checked==true?"1":"0";

            Close();

          

        }
    }
}
