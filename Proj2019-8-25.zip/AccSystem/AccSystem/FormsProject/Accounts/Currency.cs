﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{ 
    public partial class Currency: Form
    {
        ClassesProject.CurrSQL curClass = new ClassesProject.CurrSQL();
        Dictionary<string, bool> preForm = new Dictionary<string, bool>();
        ClassesProject.CurrncyParametr CurrPatrm;
        DataTable dataTable;
        string flagAddOrEdit="";
        string flagLoadOrEdit = "Load";
        CurrInfo frmInfo;
        public Currency(Dictionary<string, bool> pre)
        {
            InitializeComponent();
            preForm.Clear();
            preForm = pre;

        }

        void Delet(string CurrId="-1")
        {
            DataTable DT = new DataTable();
           
            DT = curClass.GetAccRelation4Curr(CurrId);
            if (DT != null && DT.Rows.Count > 0)
            {
                MessageBox.Show("لا يمكن حذف العملة لانها مرتبطة بحسابات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (DialogResult.Yes== MessageBox.Show("تاكيد عملية الحذف","تنبية",MessageBoxButtons.YesNo,MessageBoxIcon.Warning))
            {
                curClass.DeletCurr(CurrId);
                fillData("All");
            }

        }

        #region لغه الادخال

        ////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// داله خارجية تستقبل اسم اللغه و تحولها حسب الطلب و تستدعى عند الحدث انتر وليف
        /// </summary>
        /// <param name="inputName"></param>
        /// <returns></returns>
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }

        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }


        ///
        ///
        ///
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        #endregion

        #region تحريك الواجهة
        /////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>                                                                                  ///
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس                                        ///
        ///                                                                                           ///
        /// </summary>                                                                               ///
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        void MoveForm(MouseEventArgs e)
        {

            ///      نعملها في الحدث ماوووس داون//داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        /// 
        /// 
        /// <param name="e"></param>
        /// 
        /// 
        ///     //داله عشان احرك الفورم 
        /// //ننسخها في الحدث MouseDown
        ///    //if (e.Button == MouseButtons.Left)
        ///    //{
        ///    //    ReleaseCapture();
        ///    //    SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        ///    //}
        ///
        ///
        ///////////////////////////////////////////////////////////////////////////////
        #endregion

       


       
        void FillTextBox()
        { 
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if(dataGridView1.Rows.Count>0)
            {

                int i = dataGridView1.CurrentCell.RowIndex;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */
               

                CurrId.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                CurrName.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                CurrSumbolAR.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                CurrSumbolEN.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                CurrFakah.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
                CurrEchanqe.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
                CurrIsLocal.Checked = Convert.ToBoolean(dataGridView1.Rows[i].Cells[6].Value);
                CurrIsStock.Checked = Convert.ToBoolean(dataGridView1.Rows[i].Cells[7].Value);
                CurrMaximum.Text = dataGridView1.Rows[i].Cells[8].Value.ToString();
                CurrMinimum.Text = dataGridView1.Rows[i].Cells[9].Value.ToString();
                CurrIsLocal.Enabled = false;
                CurrIsStock.Enabled = false;
                FillTextBoxCountRows((i + 1).ToString());

            }
           
           

        }
        


        
        void fillData(string NormalOrSerch)
        {
            flagLoadOrEdit = "Load";
            dataTable = new DataTable();
            if (NormalOrSerch == "All")
                //يستعلم عن جميع العملات
                dataTable = curClass.GetAllCurr();
            else if (NormalOrSerch == "Serch")
                dataTable = curClass.Serch(txtSerch.Text);
            else
                MessageBox.Show("fillData"+"لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridView1.Rows.Clear();

                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString(), dataTable.Rows[i][4].ToString(), dataTable.Rows[i][5].ToString(), Convert.ToBoolean(dataTable.Rows[i][6]), Convert.ToBoolean(dataTable.Rows[i][7]), dataTable.Rows[i][8].ToString(), dataTable.Rows[i][9].ToString());
                }
                if (dataGridView1.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    CurrId.Text = string.Empty;
                    CurrName.Text = string.Empty;
                    CurrSumbolAR.Text = string.Empty;
                    CurrSumbolEN.Text = string.Empty;
                    CurrFakah.Text = string.Empty;
                    CurrEchanqe.Text = string.Empty;
                    CurrIsLocal.Checked = false;
                    CurrIsStock.Checked = false;
                    CurrMaximum.Text = string.Empty;
                    CurrMinimum.Text = string.Empty;
                    CurrIsLocal.Enabled = false;
                    CurrIsStock.Enabled = false;
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch { }

        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="flagAddOrEditLo"></param>
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (CurrName.Text!=string.Empty&& CurrSumbolAR.Text!=string.Empty&& CurrSumbolEN.Text!=string.Empty&& CurrFakah.Text!=string.Empty&& CurrEchanqe.Text!=string.Empty)
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        

                        ShowCurrInfo();

                        curClass.InsertNewCurr(
                              
     CurrName.Text
   , CurrSumbolAR.Text
   , CurrSumbolEN.Text
   , CurrFakah.Text
   , CurrEchanqe.Text
   , (CurrIsLocal.Checked ? "1" : "0")
   , (CurrIsStock.Checked ? "1" : "0")
   , (CurrMaximum.Text != string.Empty ? CurrMaximum.Text : "0")
   , (CurrMinimum.Text != string.Empty ? CurrMinimum.Text : "0")
   , CurrPatrm.Arabic1CurrencyName!=string.Empty? CurrPatrm.Arabic1CurrencyName : CurrName.Text
   , CurrPatrm.Arabic2CurrencyName != string.Empty ? CurrPatrm.Arabic2CurrencyName : CurrName.Text
   , CurrPatrm.Arabic310CurrencyName != string.Empty ? CurrPatrm.Arabic310CurrencyName : CurrName.Text
   , CurrPatrm.Arabic1199CurrencyName != string.Empty ? CurrPatrm.Arabic1199CurrencyName : CurrName.Text
   , CurrPatrm.Arabic1CurrencyPartName != string.Empty ? CurrPatrm.Arabic1CurrencyPartName : CurrName.Text
   , CurrPatrm.Arabic2CurrencyPartName != string.Empty ? CurrPatrm.Arabic2CurrencyPartName : CurrName.Text    
   , CurrPatrm.Arabic310CurrencyPartName != string.Empty ? CurrPatrm.Arabic310CurrencyPartName : CurrName.Text
   , CurrPatrm.Arabic1199CurrencyPartName != string.Empty ? CurrPatrm.Arabic1199CurrencyPartName : CurrName.Text
   , CurrPatrm.PartPrecision != string.Empty ? CurrPatrm.PartPrecision : "2"
   , CurrPatrm.IsCurrencyNameFeminine != string.Empty ? CurrPatrm.IsCurrencyNameFeminine : "0"
   , CurrPatrm.IsCurrencyPartNameFeminine != string.Empty ? CurrPatrm.IsCurrencyPartNameFeminine : "0"
                            );

                        /*
                        
                         CurrPatrm.Arabic1CurrencyName 
                       ;

                    CurrPatrm.Arabic2CurrencyName = 
                        frmInfo.Arabic2CurrencyName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic2CurrencyName.Text;

                    CurrPatrm.Arabic310CurrencyName = 
                        frmInfo.Arabic310CurrencyName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic310CurrencyName.Text;

                    CurrPatrm.Arabic1199CurrencyName = 
                        frmInfo.Arabic1199CurrencyName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic1199CurrencyName.Text;

                    CurrPatrm.Arabic1CurrencyPartName = 
                        frmInfo.Arabic1CurrencyPartName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic1CurrencyPartName.Text;

                    CurrPatrm.Arabic2CurrencyPartName = 
                        frmInfo.Arabic2CurrencyPartName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic2CurrencyPartName.Text;

                    CurrPatrm.Arabic310CurrencyPartName =
                        frmInfo.Arabic310CurrencyPartName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic310CurrencyPartName.Text;

                      CurrPatrm.Arabic1199CurrencyPartName =
                        frmInfo.Arabic1199CurrencyPartName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic1199CurrencyPartName.Text;

                    CurrPatrm.PartPrecision =
                        frmInfo.PartPrecision.Text == string.Empty ?
                       "2" : frmInfo.PartPrecision.Text;

                    CurrPatrm.IsCurrencyNameFeminine =
                        frmInfo.IsCurrencyNameFeminine.Checked==true?"1":"0";

                    CurrPatrm.IsCurrencyPartNameFeminine = frmInfo.IsCurrencyPartNameFeminine.Checked==true?"1":"0";
                        */

                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    

                }
                else if(MessageBox.Show("هل تريد التراجع عن عمليه الاضافة","يوجد حقول فارغه",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }
               
              

            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (CurrName.Text != string.Empty 
                    && CurrSumbolAR.Text != string.Empty 
                    && CurrSumbolEN.Text != string.Empty
                    && CurrFakah.Text != string.Empty 
                    && CurrEchanqe.Text != string.Empty)
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        if (CurrId.Text != string.Empty)
                        {
                            frmInfo = new CurrInfo(CurrId.Text, CurrName.Text, flagLoadOrEdit);
                            frmInfo.ShowDialog();
                           
                                CurrPatrm = new ClassesProject.CurrncyParametr();
                                CurrPatrm.Arabic1CurrencyName =
                                    frmInfo.Arabic1CurrencyName.Text == string.Empty ?
                                    CurrName.Text : frmInfo.Arabic1CurrencyName.Text;

                                CurrPatrm.Arabic2CurrencyName =
                                    frmInfo.Arabic2CurrencyName.Text == string.Empty ?
                                    CurrName.Text : frmInfo.Arabic2CurrencyName.Text;

                                CurrPatrm.Arabic310CurrencyName =
                                    frmInfo.Arabic310CurrencyName.Text == string.Empty ?
                                    CurrName.Text : frmInfo.Arabic310CurrencyName.Text;

                                CurrPatrm.Arabic1199CurrencyName =
                                    frmInfo.Arabic1199CurrencyName.Text == string.Empty ?
                                    CurrName.Text : frmInfo.Arabic1199CurrencyName.Text;

                                CurrPatrm.Arabic1CurrencyPartName =
                                    frmInfo.Arabic1CurrencyPartName.Text == string.Empty ?
                                    CurrName.Text : frmInfo.Arabic1CurrencyPartName.Text;

                                CurrPatrm.Arabic2CurrencyPartName =
                                    frmInfo.Arabic2CurrencyPartName.Text == string.Empty ?
                                    CurrName.Text : frmInfo.Arabic2CurrencyPartName.Text;

                                CurrPatrm.Arabic310CurrencyPartName =
                                    frmInfo.Arabic310CurrencyPartName.Text == string.Empty ?
                                    CurrName.Text : frmInfo.Arabic310CurrencyPartName.Text;

                                CurrPatrm.Arabic1199CurrencyPartName =
                                  frmInfo.Arabic1199CurrencyPartName.Text == string.Empty ?
                                  CurrName.Text : frmInfo.Arabic1199CurrencyPartName.Text;

                                CurrPatrm.PartPrecision =
                                    frmInfo.PartPrecision.Text == string.Empty ?
                                   "2" : frmInfo.PartPrecision.Text;

                                CurrPatrm.IsCurrencyNameFeminine =
                                    frmInfo.IsCurrencyNameFeminine.Checked == true ? "1" : "0";

                                CurrPatrm.IsCurrencyPartNameFeminine = frmInfo.IsCurrencyPartNameFeminine.Checked == true ? "1" : "0";


                              
                           
                        }
                                try {
                            MessageBox.Show(CurrPatrm.Arabic1CurrencyName, "CurrPatrm.Arabic1CurrencyName");
                            curClass.UpdateCur(CurrId.Text
                           , CurrName.Text
                           , CurrSumbolAR.Text
                           , CurrSumbolEN.Text
                           , CurrFakah.Text
                           , CurrEchanqe.Text
                           , (CurrIsLocal.Checked ? "1" : "0")
                           , (CurrIsStock.Checked ? "1" : "0")
                           , (CurrMaximum.Text != string.Empty ? CurrMaximum.Text : "0")
                           , (CurrMinimum.Text != string.Empty ? CurrMinimum.Text : "0")
                           , CurrPatrm.Arabic1CurrencyName != string.Empty ? CurrPatrm.Arabic1CurrencyName : CurrName.Text
  , CurrPatrm.Arabic2CurrencyName != string.Empty ? CurrPatrm.Arabic2CurrencyName : CurrName.Text
  , CurrPatrm.Arabic310CurrencyName != string.Empty ? CurrPatrm.Arabic310CurrencyName : CurrName.Text
  , CurrPatrm.Arabic1199CurrencyName != string.Empty ? CurrPatrm.Arabic1199CurrencyName : CurrName.Text
  , CurrPatrm.Arabic1CurrencyPartName != string.Empty ? CurrPatrm.Arabic1CurrencyPartName : CurrName.Text
  , CurrPatrm.Arabic2CurrencyPartName != string.Empty ? CurrPatrm.Arabic2CurrencyPartName : CurrName.Text
  , CurrPatrm.Arabic310CurrencyPartName != string.Empty ? CurrPatrm.Arabic310CurrencyPartName : CurrName.Text
  , CurrPatrm.Arabic1199CurrencyPartName != string.Empty ? CurrPatrm.Arabic1199CurrencyPartName : CurrName.Text
  , CurrPatrm.PartPrecision != string.Empty ? CurrPatrm.PartPrecision : "2"
  , CurrPatrm.IsCurrencyNameFeminine != string.Empty ? CurrPatrm.IsCurrencyNameFeminine : "0"
  , CurrPatrm.IsCurrencyPartNameFeminine != string.Empty ? CurrPatrm.IsCurrencyPartNameFeminine : "0"
                           );
                            MessageBox.Show("تم التعديل بنجاح");
                        } catch(Exception e) { MessageBox.Show(e.ToString()); }
                        
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                       
                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                   

                } //end else if
            } //end else if

        }



        /// <summary>
        /// 
        /// </summary>
        void CheckEnableLocalAndStock()
        {

            /*
            داله تفحص اذا كان احد العملات محليه تلغي تشيك بوكس حق المحليه
            واذا كان عمله مخزون يلغي التشيك بوكس حق عمله مخزون
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (Convert.ToBoolean(dataGridView1.Rows[i].Cells[6].Value) == true)
                    {
                        CurrIsLocal.Enabled = false; break;
                    }

                    else
                        CurrIsLocal.Enabled = true;
                }

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (Convert.ToBoolean(dataGridView1.Rows[i].Cells[7].Value) == true)
                    {
                        CurrIsStock.Enabled = false; break;
                    }
                    else
                        CurrIsStock.Enabled = true;
                }


            }
        }



        /// <summary>
        /// 
        /// 
        /// 
        /// </summary>
        /// <param name="flagEditeOrAddOrSave"></param>
        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                CurrName.ReadOnly = false;
                CurrSumbolAR.ReadOnly = false;
                CurrSumbolEN.ReadOnly = false;
                CurrFakah.ReadOnly = false;
                CurrEchanqe.ReadOnly = false;
                CurrMaximum.ReadOnly = false;
                CurrMinimum.ReadOnly = false;
                if(flagEditeOrAddOrSave == "Add")
                btnCurrInfo.Enabled = false;
                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;

                if (flagEditeOrAddOrSave == "Edite")
                {

                    CheckEnableLocalAndStock();

                    if (CurrIsLocal.Checked == true)
                        CurrIsLocal.Enabled = true;
                    if (CurrIsStock.Checked == true)
                        CurrIsStock.Enabled = true;
                }

            }

            if (flagEditeOrAddOrSave == "Save"|| flagEditeOrAddOrSave== "Load")
            {
                CurrName.ReadOnly = true;
                CurrSumbolAR.ReadOnly = true;
                CurrSumbolEN.ReadOnly = true;
                CurrFakah.ReadOnly = true;
                CurrEchanqe.ReadOnly = true;
                CurrMaximum.ReadOnly = true;
                CurrMinimum.ReadOnly = true;
                btnCurrInfo.Enabled = true;
                Permissions(); //استدعاء الصلاحيات
                buttNext.Enabled = true;
                    buttBack.Enabled = true;
                    buttFrist.Enabled = true;
                    buttLast.Enabled = true;
                
            }


        }
        #region داله صلاحيات العمليات
        void Permissions()
        {

            #region الصلاحيات
            if (preForm.Count > 0)
            {

                #region البيانات المستلمه
                /*
            ButtnPreCheck.Add("Showed", Convert.ToBoolean(DTpr.Rows[0][2].ToString()));
            ButtnPreCheck.Add("Inserted", Convert.ToBoolean(DTpr.Rows[0][3].ToString()));
            ButtnPreCheck.Add("EditeDate", Convert.ToBoolean(DTpr.Rows[0][4].ToString()));
            ButtnPreCheck.Add("Posting", Convert.ToBoolean(DTpr.Rows[0][5].ToString()));
            ButtnPreCheck.Add("Saerch", Convert.ToBoolean(DTpr.Rows[0][6].ToString()));
            ButtnPreCheck.Add("Printed", Convert.ToBoolean(DTpr.Rows[0][7].ToString()));
            ButtnPreCheck.Add("Updated", Convert.ToBoolean(DTpr.Rows[0][8].ToString()));
            ButtnPreCheck.Add("Deleted", Convert.ToBoolean(DTpr.Rows[0][9].ToString()));
                */
                #endregion

                bool result;
                /////////////////////////////////////////////////////////////////
                if (preForm.TryGetValue("Deleted", out result))
                    buttDelete.Enabled = result;

                else { buttDelete.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "الحذف"); }
                ///////////////////////////////////////////////////////////////////
                if (preForm.TryGetValue("Inserted", out result))
                    buttAdd.Enabled = result;

                else { buttAdd.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "الاضافة"); }
                ///////////////////////////////////////////////////////////////////
                if (preForm.TryGetValue("Updated", out result))
                    buttEdite.Enabled = result;

                else { buttEdite.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "التعديل"); }
                ///////////////////////////////////////////////////////////////////

                //فعل البوتونات
            }
            else
            {
                MessageBox.Show("لم يتم استلام اي صلاحيات", "FormatingTextBoxAndButt()");
            }
            #endregion
        }
        #endregion


        /// <summary>
        /// 
        /// 
        /// 
        /// </summary>

        void ForamtingAdd()
        {
            CurrId.Text = curClass.GetMaxId();
            CurrName.Text = "";
            CurrSumbolAR.Text = "";
            CurrSumbolEN.Text = "";
            CurrFakah.Text = "";
            CurrEchanqe.Text = "";
            CurrIsLocal.Checked = false;
            CurrIsStock.Checked = false;
            CurrMaximum.Text = "";
            CurrMinimum.Text = "";

            CheckEnableLocalAndStock();



        }



        void FillTextBoxFromButtMove(int i)
        {
            if (i >= 0)
            {
                dataGridView1.ClearSelection();
                CurrId.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                CurrName.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                CurrSumbolAR.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                CurrSumbolEN.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                CurrFakah.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
                CurrEchanqe.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
                CurrIsLocal.Checked = Convert.ToBoolean(dataGridView1.Rows[i].Cells[6].Value);
                CurrIsStock.Checked = Convert.ToBoolean(dataGridView1.Rows[i].Cells[7].Value);
                CurrMaximum.Text = dataGridView1.Rows[i].Cells[8].Value.ToString();
                CurrMinimum.Text = dataGridView1.Rows[i].Cells[9].Value.ToString();
                CurrIsLocal.Enabled = false;
                CurrIsStock.Enabled = false;

               

                FillTextBoxCountRows((i+1).ToString());
            }

        }

        int indexCurrButt(string btName, string CurrId)
        {
            /*
            داله لايجاد اندكس العمله حسب رقم العمله
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (CurrId == dataGridView1.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < dataGridView1.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return dataGridView1.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد عملات في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }

        void FillTextBoxCountRows(string index) {

            CountRows.Text = index+" - "+ dataGridView1.Rows.Count.ToString();
        }

        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        ///
        ///
        ///
        ///////////////////////////////////////////////////////////////////////



        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

       

        private void groupBoxOprea_Enter(object sender, EventArgs e)
        {

        }

        private void panFillUpUp_Paint(object sender, PaintEventArgs e)
        {

        }
        
        private void Currency_Load(object sender, EventArgs e)
        {
            fillData("All");
            FormatingTextBoxAndButt("Load");
            dataGridView1.Select();
        }
      

       

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            flagLoadOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

    
       

        private void butSave_Click(object sender, EventArgs e)
        {
            SendDataToAddOrEdit(flagAddOrEdit);
            
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            flagAddOrEdit = "Edite";
            flagLoadOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
            btnCurrInfo.Enabled = false;
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCurrButt("Last", CurrId.Text));
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCurrButt("Back", CurrId.Text));
        }

      
        private void buttNext_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCurrButt("Next", CurrId.Text));
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCurrButt("Frist", CurrId.Text));
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (CurrId.Text != string.Empty)
                Delet(CurrId.Text);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }


        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();

        }

       

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Down || e.KeyData == Keys.Up)
            { if(flagAddOrEdit!="Add"&& flagAddOrEdit!="Edite")
                FillTextBox();
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            //داله تحريك الفوووورم
            MoveForm(e);
        }
      
        private void CurrId_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void CurrName_Enter(object sender, EventArgs e)
        {
           
           //تحويل اللغه عند الضغط ع التكست بوكس الى عربي 
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void CurrEchanqe_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

        private void CurrMinimum_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

        private void CurrMaximum_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

        private void CurrSumbolEN_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("eng"));
        }

        private void CurrSumbolEN_Leave(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

      
        private void CurrFakah_KeyPress(object sender, KeyPressEventArgs e)
        {
            //لا يقبل ارقام
            StopNumberInTextBox(e);

        }

        private void CurrSumbolAR_KeyPress(object sender, KeyPressEventArgs e)
        {
            //لا يقبل ارقام
            StopNumberInTextBox(e);

        }

        private void CurrSumbolEN_KeyPress(object sender, KeyPressEventArgs e)
        {
            //لا يقبل ارقام
            StopNumberInTextBox(e);
        }

        void ShowCurrInfo()
        {
            if (CurrId.Text != string.Empty)
            {
                frmInfo = new CurrInfo(CurrId.Text, CurrName.Text, flagLoadOrEdit);
                frmInfo.ShowDialog();
                if (flagLoadOrEdit == "Edit" || flagLoadOrEdit == "Add")
                {
                    CurrPatrm = new ClassesProject.CurrncyParametr();
                    CurrPatrm.Arabic1CurrencyName =
                        frmInfo.Arabic1CurrencyName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic1CurrencyName.Text;

                    CurrPatrm.Arabic2CurrencyName =
                        frmInfo.Arabic2CurrencyName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic2CurrencyName.Text;

                    CurrPatrm.Arabic310CurrencyName =
                        frmInfo.Arabic310CurrencyName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic310CurrencyName.Text;

                    CurrPatrm.Arabic1199CurrencyName =
                        frmInfo.Arabic1199CurrencyName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic1199CurrencyName.Text;

                    CurrPatrm.Arabic1CurrencyPartName =
                        frmInfo.Arabic1CurrencyPartName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic1CurrencyPartName.Text;

                    CurrPatrm.Arabic2CurrencyPartName =
                        frmInfo.Arabic2CurrencyPartName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic2CurrencyPartName.Text;

                    CurrPatrm.Arabic310CurrencyPartName =
                        frmInfo.Arabic310CurrencyPartName.Text == string.Empty ?
                        CurrName.Text : frmInfo.Arabic310CurrencyPartName.Text;

                    CurrPatrm.Arabic1199CurrencyPartName =
                      frmInfo.Arabic1199CurrencyPartName.Text == string.Empty ?
                      CurrName.Text : frmInfo.Arabic1199CurrencyPartName.Text;

                    CurrPatrm.PartPrecision =
                        frmInfo.PartPrecision.Text == string.Empty ?
                       "2" : frmInfo.PartPrecision.Text;

                    CurrPatrm.IsCurrencyNameFeminine =
                        frmInfo.IsCurrencyNameFeminine.Checked == true ? "1" : "0";

                    CurrPatrm.IsCurrencyPartNameFeminine = frmInfo.IsCurrencyPartNameFeminine.Checked == true ? "1" : "0";


                    MessageBox.Show(frmInfo.Arabic1CurrencyName.Text);
                }
            }


        }

        private void btnCurrInfo_Click(object sender, EventArgs e)
        {
            ShowCurrInfo();
        }
    }
}
