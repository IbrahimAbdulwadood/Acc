﻿namespace AccSystem.FormsProject.Accounts
{
    partial class Entries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Entries));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panMain = new System.Windows.Forms.Panel();
            this.panFill = new System.Windows.Forms.Panel();
            this.panFillUp = new System.Windows.Forms.Panel();
            this.groupBoxAllCurr = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.DGViewEntryBody2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.TotalDifferenceTxt = new System.Windows.Forms.TextBox();
            this.TotalDifferenceLabel = new System.Windows.Forms.Label();
            this.TotalCreditTxt = new System.Windows.Forms.TextBox();
            this.TotalCreditLabl = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.DGViewEntryBody = new System.Windows.Forms.DataGridView();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel3 = new System.Windows.Forms.Panel();
            this.TotalDebitTxt = new System.Windows.Forms.TextBox();
            this.TotalDebitLabel = new System.Windows.Forms.Label();
            this.panRad = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panFillDown = new System.Windows.Forms.Panel();
            this.groupBoxOprea = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttNext = new System.Windows.Forms.Button();
            this.buttFrist = new System.Windows.Forms.Button();
            this.CountRows = new System.Windows.Forms.TextBox();
            this.buttBack = new System.Windows.Forms.Button();
            this.buttLast = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBoxSavePosting = new System.Windows.Forms.CheckBox();
            this.buttPrint = new System.Windows.Forms.Button();
            this.butSave = new System.Windows.Forms.Button();
            this.buttAdd = new System.Windows.Forms.Button();
            this.buttPosting = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.buttDelete = new System.Windows.Forms.Button();
            this.panFillRight = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.DGViewEntryHaed = new System.Windows.Forms.DataGridView();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.panFillRightUp = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.txtSerch = new System.Windows.Forms.TextBox();
            this.panFillRightMain = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.groupBoxData = new System.Windows.Forms.GroupBox();
            this.Note = new System.Windows.Forms.TextBox();
            this.Entry_sum = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.Refr_id = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Entry_id = new System.Windows.Forms.TextBox();
            this.panDown = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserId = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserName = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserIdAdded = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserNameAdded = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.nameOpration = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel9 = new System.Windows.Forms.ToolStripStatusLabel();
            this.idOpration = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel11 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel8 = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatePosting = new System.Windows.Forms.ToolStripStatusLabel();
            this.panUp = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.panMain.SuspendLayout();
            this.panFill.SuspendLayout();
            this.panFillUp.SuspendLayout();
            this.groupBoxAllCurr.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGViewEntryBody2)).BeginInit();
            this.panel4.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGViewEntryBody)).BeginInit();
            this.panel3.SuspendLayout();
            this.panRad.SuspendLayout();
            this.panFillDown.SuspendLayout();
            this.groupBoxOprea.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panFillRight.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGViewEntryHaed)).BeginInit();
            this.panFillRightUp.SuspendLayout();
            this.panFillRightMain.SuspendLayout();
            this.panel5.SuspendLayout();
            this.groupBoxData.SuspendLayout();
            this.panDown.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panFill);
            this.panMain.Controls.Add(this.panFillRight);
            this.panMain.Controls.Add(this.panDown);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1382, 741);
            this.panMain.TabIndex = 0;
            // 
            // panFill
            // 
            this.panFill.Controls.Add(this.panFillUp);
            this.panFill.Controls.Add(this.panFillDown);
            this.panFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFill.Location = new System.Drawing.Point(0, 34);
            this.panFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFill.Name = "panFill";
            this.panFill.Size = new System.Drawing.Size(949, 675);
            this.panFill.TabIndex = 2;
            // 
            // panFillUp
            // 
            this.panFillUp.Controls.Add(this.groupBoxAllCurr);
            this.panFillUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFillUp.Location = new System.Drawing.Point(0, 0);
            this.panFillUp.Name = "panFillUp";
            this.panFillUp.Size = new System.Drawing.Size(949, 547);
            this.panFillUp.TabIndex = 1;
            // 
            // groupBoxAllCurr
            // 
            this.groupBoxAllCurr.Controls.Add(this.groupBox3);
            this.groupBoxAllCurr.Controls.Add(this.groupBox4);
            this.groupBoxAllCurr.Controls.Add(this.panRad);
            this.groupBoxAllCurr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxAllCurr.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxAllCurr.Location = new System.Drawing.Point(0, 0);
            this.groupBoxAllCurr.Name = "groupBoxAllCurr";
            this.groupBoxAllCurr.Size = new System.Drawing.Size(949, 547);
            this.groupBoxAllCurr.TabIndex = 0;
            this.groupBoxAllCurr.TabStop = false;
            this.groupBoxAllCurr.Text = "تفاصيل السند";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.DGViewEntryBody2);
            this.groupBox3.Controls.Add(this.panel4);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox3.Location = new System.Drawing.Point(3, 260);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(943, 266);
            this.groupBox3.TabIndex = 43;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "الجانب الدائن";
            // 
            // DGViewEntryBody2
            // 
            this.DGViewEntryBody2.AllowUserToAddRows = false;
            this.DGViewEntryBody2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DGViewEntryBody2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGViewEntryBody2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGViewEntryBody2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGViewEntryBody2.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DGViewEntryBody2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGViewEntryBody2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DGViewEntryBody2.ColumnHeadersHeight = 30;
            this.DGViewEntryBody2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGViewEntryBody2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGViewEntryBody2.DefaultCellStyle = dataGridViewCellStyle3;
            this.DGViewEntryBody2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGViewEntryBody2.EnableHeadersVisualStyles = false;
            this.DGViewEntryBody2.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DGViewEntryBody2.Location = new System.Drawing.Point(3, 19);
            this.DGViewEntryBody2.Name = "DGViewEntryBody2";
            this.DGViewEntryBody2.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGViewEntryBody2.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DGViewEntryBody2.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Gray;
            this.DGViewEntryBody2.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DGViewEntryBody2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGViewEntryBody2.Size = new System.Drawing.Size(937, 212);
            this.DGViewEntryBody2.TabIndex = 42;
            this.DGViewEntryBody2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGViewEntryBody2_CellClick);
            this.DGViewEntryBody2.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGViewEntryBody2_CellEndEdit);
            this.DGViewEntryBody2.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.DGViewEntryBody2_CellValidating);
            this.DGViewEntryBody2.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGViewEntryBody2_CellValueChanged);
            this.DGViewEntryBody2.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.DGViewEntryBody2_EditingControlShowing);
            this.DGViewEntryBody2.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.DGViewEntryBody2_RowsAdded);
            this.DGViewEntryBody2.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.DGViewEntryBody2_RowsRemoved);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "التسلسل";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn2.FillWeight = 288.8852F;
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "رقم الحساب";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 90;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn3.FillWeight = 525.3807F;
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "اسم الحساب";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 95;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn4.FillWeight = 50.06168F;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "العملة";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 115;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 115;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn5.FillWeight = 20.84476F;
            this.dataGridViewTextBoxColumn5.HeaderText = "سعر الصرف";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 88;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn6.FillWeight = 8.683408F;
            this.dataGridViewTextBoxColumn6.HeaderText = "مدين محلي";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Visible = false;
            this.dataGridViewTextBoxColumn6.Width = 86;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn7.FillWeight = 3.62132F;
            this.dataGridViewTextBoxColumn7.HeaderText = "دائن محلي";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 82;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn8.FillWeight = 1.514259F;
            this.dataGridViewTextBoxColumn8.HeaderText = "مدين اجنبي";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Visible = false;
            this.dataGridViewTextBoxColumn8.Width = 87;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn9.FillWeight = 0.6372076F;
            this.dataGridViewTextBoxColumn9.HeaderText = "دائن اجنبي";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 83;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn10.FillWeight = 0.3715312F;
            this.dataGridViewTextBoxColumn10.HeaderText = "البيان";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 46;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn11.HeaderText = "تاريخ ووقت الاضافة";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Width = 129;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn12.HeaderText = "idAccCurr";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Visible = false;
            this.dataGridViewTextBoxColumn12.Width = 77;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn13.HeaderText = "CurrMax";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Visible = false;
            this.dataGridViewTextBoxColumn13.Width = 68;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn14.HeaderText = "CurMin";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Visible = false;
            this.dataGridViewTextBoxColumn14.Width = 58;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.TotalDifferenceTxt);
            this.panel4.Controls.Add(this.TotalDifferenceLabel);
            this.panel4.Controls.Add(this.TotalCreditTxt);
            this.panel4.Controls.Add(this.TotalCreditLabl);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(3, 231);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(937, 32);
            this.panel4.TabIndex = 43;
            // 
            // TotalDifferenceTxt
            // 
            this.TotalDifferenceTxt.BackColor = System.Drawing.Color.Silver;
            this.TotalDifferenceTxt.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalDifferenceTxt.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalDifferenceTxt.ForeColor = System.Drawing.Color.Red;
            this.TotalDifferenceTxt.Location = new System.Drawing.Point(123, 0);
            this.TotalDifferenceTxt.Name = "TotalDifferenceTxt";
            this.TotalDifferenceTxt.ReadOnly = true;
            this.TotalDifferenceTxt.Size = new System.Drawing.Size(331, 27);
            this.TotalDifferenceTxt.TabIndex = 43;
            this.TotalDifferenceTxt.Text = "0.0";
            this.TotalDifferenceTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TotalDifferenceLabel
            // 
            this.TotalDifferenceLabel.AutoSize = true;
            this.TotalDifferenceLabel.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalDifferenceLabel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.TotalDifferenceLabel.ForeColor = System.Drawing.Color.Black;
            this.TotalDifferenceLabel.Location = new System.Drawing.Point(454, 0);
            this.TotalDifferenceLabel.Name = "TotalDifferenceLabel";
            this.TotalDifferenceLabel.Size = new System.Drawing.Size(61, 19);
            this.TotalDifferenceLabel.TabIndex = 44;
            this.TotalDifferenceLabel.Text = "الفارق:";
            // 
            // TotalCreditTxt
            // 
            this.TotalCreditTxt.BackColor = System.Drawing.Color.Silver;
            this.TotalCreditTxt.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalCreditTxt.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalCreditTxt.ForeColor = System.Drawing.Color.Black;
            this.TotalCreditTxt.Location = new System.Drawing.Point(515, 0);
            this.TotalCreditTxt.Name = "TotalCreditTxt";
            this.TotalCreditTxt.ReadOnly = true;
            this.TotalCreditTxt.Size = new System.Drawing.Size(315, 27);
            this.TotalCreditTxt.TabIndex = 37;
            this.TotalCreditTxt.Text = "0.0";
            this.TotalCreditTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TotalCreditLabl
            // 
            this.TotalCreditLabl.AutoSize = true;
            this.TotalCreditLabl.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalCreditLabl.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.TotalCreditLabl.ForeColor = System.Drawing.Color.Black;
            this.TotalCreditLabl.Location = new System.Drawing.Point(830, 0);
            this.TotalCreditLabl.Name = "TotalCreditLabl";
            this.TotalCreditLabl.Size = new System.Drawing.Size(107, 19);
            this.TotalCreditLabl.TabIndex = 38;
            this.TotalCreditLabl.Text = "اجمالي دائن:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.DGViewEntryBody);
            this.groupBox4.Controls.Add(this.panel3);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(3, 19);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(943, 237);
            this.groupBox4.TabIndex = 44;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "الجانب المدين";
            // 
            // DGViewEntryBody
            // 
            this.DGViewEntryBody.AllowUserToAddRows = false;
            this.DGViewEntryBody.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            this.DGViewEntryBody.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.DGViewEntryBody.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGViewEntryBody.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DGViewEntryBody.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGViewEntryBody.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.DGViewEntryBody.ColumnHeadersHeight = 30;
            this.DGViewEntryBody.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGViewEntryBody.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column17,
            this.Column1,
            this.Column2,
            this.Column4,
            this.Column3,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column18,
            this.Column19,
            this.Column21,
            this.Column22});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGViewEntryBody.DefaultCellStyle = dataGridViewCellStyle8;
            this.DGViewEntryBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGViewEntryBody.EnableHeadersVisualStyles = false;
            this.DGViewEntryBody.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DGViewEntryBody.Location = new System.Drawing.Point(3, 19);
            this.DGViewEntryBody.Name = "DGViewEntryBody";
            this.DGViewEntryBody.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGViewEntryBody.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.DGViewEntryBody.RowHeadersVisible = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.Gray;
            this.DGViewEntryBody.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DGViewEntryBody.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGViewEntryBody.Size = new System.Drawing.Size(937, 187);
            this.DGViewEntryBody.TabIndex = 41;
            this.DGViewEntryBody.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.DGViewEntryBody.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            this.DGViewEntryBody.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGViewEntryBody_CellValueChanged);
            this.DGViewEntryBody.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridView1_DataError);
            this.DGViewEntryBody.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dataGridView1_EditingControlShowing);
            this.DGViewEntryBody.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.DGViewEntryBody_RowsAdded);
            this.DGViewEntryBody.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.DGViewEntryBody_RowsRemoved);
            // 
            // Column17
            // 
            this.Column17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column17.Frozen = true;
            this.Column17.HeaderText = "التسلسل";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column17.Visible = false;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.Column1.FillWeight = 288.8852F;
            this.Column1.Frozen = true;
            this.Column1.HeaderText = "رقم الحساب";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column1.Width = 90;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.Column2.FillWeight = 525.3807F;
            this.Column2.Frozen = true;
            this.Column2.HeaderText = "اسم الحساب";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column2.Width = 95;
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column4.FillWeight = 50.06168F;
            this.Column4.Frozen = true;
            this.Column4.HeaderText = "العملة";
            this.Column4.MinimumWidth = 115;
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column4.Width = 115;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column3.FillWeight = 20.84476F;
            this.Column3.HeaderText = "سعر الصرف";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column3.Width = 88;
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column6.FillWeight = 8.683408F;
            this.Column6.HeaderText = "مدين محلي";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column6.Width = 86;
            // 
            // Column7
            // 
            this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column7.FillWeight = 3.62132F;
            this.Column7.HeaderText = "دائن محلي";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column7.Visible = false;
            this.Column7.Width = 82;
            // 
            // Column8
            // 
            this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column8.FillWeight = 1.514259F;
            this.Column8.HeaderText = "مدين اجنبي";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column8.Width = 87;
            // 
            // Column9
            // 
            this.Column9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column9.FillWeight = 0.6372076F;
            this.Column9.HeaderText = "دائن اجنبي";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column9.Visible = false;
            this.Column9.Width = 83;
            // 
            // Column10
            // 
            this.Column10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column10.FillWeight = 0.3715312F;
            this.Column10.HeaderText = "البيان";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column10.Width = 46;
            // 
            // Column18
            // 
            this.Column18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column18.HeaderText = "تاريخ ووقت الاضافة";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column18.Width = 129;
            // 
            // Column19
            // 
            this.Column19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column19.HeaderText = "idAccCurr";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column19.Visible = false;
            this.Column19.Width = 77;
            // 
            // Column21
            // 
            this.Column21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column21.HeaderText = "CurrMax";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column21.Visible = false;
            this.Column21.Width = 68;
            // 
            // Column22
            // 
            this.Column22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column22.HeaderText = "CurMin";
            this.Column22.Name = "Column22";
            this.Column22.ReadOnly = true;
            this.Column22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column22.Visible = false;
            this.Column22.Width = 58;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.TotalDebitTxt);
            this.panel3.Controls.Add(this.TotalDebitLabel);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(3, 206);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(937, 28);
            this.panel3.TabIndex = 42;
            // 
            // TotalDebitTxt
            // 
            this.TotalDebitTxt.BackColor = System.Drawing.Color.Silver;
            this.TotalDebitTxt.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalDebitTxt.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalDebitTxt.ForeColor = System.Drawing.Color.Black;
            this.TotalDebitTxt.Location = new System.Drawing.Point(513, 0);
            this.TotalDebitTxt.Name = "TotalDebitTxt";
            this.TotalDebitTxt.ReadOnly = true;
            this.TotalDebitTxt.Size = new System.Drawing.Size(311, 27);
            this.TotalDebitTxt.TabIndex = 39;
            this.TotalDebitTxt.Text = "0.0";
            this.TotalDebitTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TotalDebitLabel
            // 
            this.TotalDebitLabel.AutoSize = true;
            this.TotalDebitLabel.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalDebitLabel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalDebitLabel.ForeColor = System.Drawing.Color.Black;
            this.TotalDebitLabel.Location = new System.Drawing.Point(824, 0);
            this.TotalDebitLabel.Name = "TotalDebitLabel";
            this.TotalDebitLabel.Size = new System.Drawing.Size(113, 19);
            this.TotalDebitLabel.TabIndex = 40;
            this.TotalDebitLabel.Text = "اجمالي مدين:";
            // 
            // panRad
            // 
            this.panRad.BackColor = System.Drawing.Color.Maroon;
            this.panRad.Controls.Add(this.label5);
            this.panRad.Controls.Add(this.label4);
            this.panRad.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panRad.Location = new System.Drawing.Point(3, 526);
            this.panRad.Name = "panRad";
            this.panRad.Size = new System.Drawing.Size(943, 18);
            this.panRad.TabIndex = 42;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(827, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "لإضافة حساب";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Right;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(921, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "F9";
            // 
            // panFillDown
            // 
            this.panFillDown.Controls.Add(this.groupBoxOprea);
            this.panFillDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panFillDown.Location = new System.Drawing.Point(0, 547);
            this.panFillDown.Name = "panFillDown";
            this.panFillDown.Size = new System.Drawing.Size(949, 128);
            this.panFillDown.TabIndex = 0;
            // 
            // groupBoxOprea
            // 
            this.groupBoxOprea.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxOprea.Controls.Add(this.panel2);
            this.groupBoxOprea.Controls.Add(this.panel1);
            this.groupBoxOprea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxOprea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxOprea.ForeColor = System.Drawing.Color.Black;
            this.groupBoxOprea.Location = new System.Drawing.Point(0, 0);
            this.groupBoxOprea.Name = "groupBoxOprea";
            this.groupBoxOprea.Size = new System.Drawing.Size(949, 128);
            this.groupBoxOprea.TabIndex = 36;
            this.groupBoxOprea.TabStop = false;
            this.groupBoxOprea.Text = "العمليات";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttNext);
            this.panel2.Controls.Add(this.buttFrist);
            this.panel2.Controls.Add(this.CountRows);
            this.panel2.Controls.Add(this.buttBack);
            this.panel2.Controls.Add(this.buttLast);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(3, 19);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(434, 106);
            this.panel2.TabIndex = 177;
            // 
            // buttNext
            // 
            this.buttNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttNext.FlatAppearance.BorderSize = 0;
            this.buttNext.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttNext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttNext.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttNext.ForeColor = System.Drawing.Color.White;
            this.buttNext.Image = ((System.Drawing.Image)(resources.GetObject("buttNext.Image")));
            this.buttNext.Location = new System.Drawing.Point(282, 14);
            this.buttNext.Name = "buttNext";
            this.buttNext.Size = new System.Drawing.Size(57, 82);
            this.buttNext.TabIndex = 169;
            this.buttNext.Text = "التالي";
            this.buttNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttNext.UseVisualStyleBackColor = false;
            this.buttNext.Click += new System.EventHandler(this.buttNext_Click);
            // 
            // buttFrist
            // 
            this.buttFrist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFrist.FlatAppearance.BorderSize = 0;
            this.buttFrist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttFrist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttFrist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttFrist.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttFrist.ForeColor = System.Drawing.Color.White;
            this.buttFrist.Image = ((System.Drawing.Image)(resources.GetObject("buttFrist.Image")));
            this.buttFrist.Location = new System.Drawing.Point(345, 14);
            this.buttFrist.Name = "buttFrist";
            this.buttFrist.Size = new System.Drawing.Size(57, 82);
            this.buttFrist.TabIndex = 168;
            this.buttFrist.Text = "الاول";
            this.buttFrist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttFrist.UseVisualStyleBackColor = false;
            this.buttFrist.Click += new System.EventHandler(this.buttFrist_Click);
            // 
            // CountRows
            // 
            this.CountRows.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CountRows.Enabled = false;
            this.CountRows.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountRows.Location = new System.Drawing.Point(143, 36);
            this.CountRows.Name = "CountRows";
            this.CountRows.ReadOnly = true;
            this.CountRows.Size = new System.Drawing.Size(133, 33);
            this.CountRows.TabIndex = 172;
            this.CountRows.Text = "1111-1111";
            this.CountRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttBack
            // 
            this.buttBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBack.FlatAppearance.BorderSize = 0;
            this.buttBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBack.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttBack.ForeColor = System.Drawing.Color.White;
            this.buttBack.Image = ((System.Drawing.Image)(resources.GetObject("buttBack.Image")));
            this.buttBack.Location = new System.Drawing.Point(79, 14);
            this.buttBack.Name = "buttBack";
            this.buttBack.Size = new System.Drawing.Size(57, 82);
            this.buttBack.TabIndex = 170;
            this.buttBack.Text = "السابق";
            this.buttBack.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttBack.UseVisualStyleBackColor = false;
            this.buttBack.Click += new System.EventHandler(this.buttBack_Click);
            // 
            // buttLast
            // 
            this.buttLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttLast.FlatAppearance.BorderSize = 0;
            this.buttLast.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttLast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttLast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttLast.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttLast.ForeColor = System.Drawing.Color.White;
            this.buttLast.Image = ((System.Drawing.Image)(resources.GetObject("buttLast.Image")));
            this.buttLast.Location = new System.Drawing.Point(15, 14);
            this.buttLast.Name = "buttLast";
            this.buttLast.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.buttLast.Size = new System.Drawing.Size(57, 82);
            this.buttLast.TabIndex = 171;
            this.buttLast.Text = "الاخير";
            this.buttLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttLast.UseVisualStyleBackColor = false;
            this.buttLast.Click += new System.EventHandler(this.buttLast_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBoxSavePosting);
            this.panel1.Controls.Add(this.buttPrint);
            this.panel1.Controls.Add(this.butSave);
            this.panel1.Controls.Add(this.buttAdd);
            this.panel1.Controls.Add(this.buttPosting);
            this.panel1.Controls.Add(this.buttEdite);
            this.panel1.Controls.Add(this.buttDelete);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(460, 19);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(486, 106);
            this.panel1.TabIndex = 176;
            // 
            // checkBoxSavePosting
            // 
            this.checkBoxSavePosting.AutoSize = true;
            this.checkBoxSavePosting.Location = new System.Drawing.Point(10, 41);
            this.checkBoxSavePosting.Name = "checkBoxSavePosting";
            this.checkBoxSavePosting.Size = new System.Drawing.Size(103, 20);
            this.checkBoxSavePosting.TabIndex = 178;
            this.checkBoxSavePosting.Text = "حفظ وترحيل";
            this.checkBoxSavePosting.UseVisualStyleBackColor = true;
            // 
            // buttPrint
            // 
            this.buttPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttPrint.FlatAppearance.BorderSize = 0;
            this.buttPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttPrint.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttPrint.ForeColor = System.Drawing.Color.White;
            this.buttPrint.Image = ((System.Drawing.Image)(resources.GetObject("buttPrint.Image")));
            this.buttPrint.Location = new System.Drawing.Point(119, 12);
            this.buttPrint.Name = "buttPrint";
            this.buttPrint.Size = new System.Drawing.Size(54, 82);
            this.buttPrint.TabIndex = 175;
            this.buttPrint.Text = "طباعة";
            this.buttPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttPrint.UseVisualStyleBackColor = false;
            this.buttPrint.Click += new System.EventHandler(this.buttPrint_Click);
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.Location = new System.Drawing.Point(358, 12);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(54, 82);
            this.butSave.TabIndex = 165;
            this.butSave.Text = "حفظ";
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butSave.UseVisualStyleBackColor = false;
            this.butSave.Click += new System.EventHandler(this.butSave_Click);
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.FlatAppearance.BorderSize = 0;
            this.buttAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.Location = new System.Drawing.Point(418, 12);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(55, 82);
            this.buttAdd.TabIndex = 164;
            this.buttAdd.Text = "جديد";
            this.buttAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttAdd.UseVisualStyleBackColor = false;
            this.buttAdd.Click += new System.EventHandler(this.buttAdd_Click);
            // 
            // buttPosting
            // 
            this.buttPosting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttPosting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttPosting.FlatAppearance.BorderSize = 0;
            this.buttPosting.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttPosting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttPosting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttPosting.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttPosting.ForeColor = System.Drawing.Color.White;
            this.buttPosting.Image = ((System.Drawing.Image)(resources.GetObject("buttPosting.Image")));
            this.buttPosting.Location = new System.Drawing.Point(179, 12);
            this.buttPosting.Name = "buttPosting";
            this.buttPosting.Size = new System.Drawing.Size(54, 82);
            this.buttPosting.TabIndex = 174;
            this.buttPosting.Text = "ترحيل";
            this.buttPosting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttPosting.UseVisualStyleBackColor = false;
            this.buttPosting.Click += new System.EventHandler(this.buttPosting_Click);
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.Location = new System.Drawing.Point(298, 12);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(54, 82);
            this.buttEdite.TabIndex = 166;
            this.buttEdite.Text = "تعديل";
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttEdite.UseVisualStyleBackColor = false;
            this.buttEdite.Click += new System.EventHandler(this.buttEdite_Click);
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.FlatAppearance.BorderSize = 0;
            this.buttDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.Location = new System.Drawing.Point(238, 12);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(54, 82);
            this.buttDelete.TabIndex = 167;
            this.buttDelete.Text = "حذف";
            this.buttDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttDelete.UseVisualStyleBackColor = false;
            this.buttDelete.Click += new System.EventHandler(this.buttDelete_Click);
            // 
            // panFillRight
            // 
            this.panFillRight.Controls.Add(this.groupBox2);
            this.panFillRight.Controls.Add(this.panFillRightMain);
            this.panFillRight.Controls.Add(this.panel5);
            this.panFillRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panFillRight.Location = new System.Drawing.Point(949, 34);
            this.panFillRight.Name = "panFillRight";
            this.panFillRight.Size = new System.Drawing.Size(433, 675);
            this.panFillRight.TabIndex = 3;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.DGViewEntryHaed);
            this.groupBox2.Controls.Add(this.panFillRightUp);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(0, 155);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(433, 392);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "جميع سندات القيد";
            // 
            // DGViewEntryHaed
            // 
            this.DGViewEntryHaed.AllowUserToAddRows = false;
            this.DGViewEntryHaed.AllowUserToDeleteRows = false;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            this.DGViewEntryHaed.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle11;
            this.DGViewEntryHaed.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGViewEntryHaed.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DGViewEntryHaed.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGViewEntryHaed.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.DGViewEntryHaed.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGViewEntryHaed.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column20,
            this.Column5});
            this.DGViewEntryHaed.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGViewEntryHaed.EnableHeadersVisualStyles = false;
            this.DGViewEntryHaed.GridColor = System.Drawing.Color.Black;
            this.DGViewEntryHaed.Location = new System.Drawing.Point(3, 57);
            this.DGViewEntryHaed.Name = "DGViewEntryHaed";
            this.DGViewEntryHaed.ReadOnly = true;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGViewEntryHaed.RowHeadersDefaultCellStyle = dataGridViewCellStyle20;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle21.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.Color.DimGray;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.Color.White;
            this.DGViewEntryHaed.RowsDefaultCellStyle = dataGridViewCellStyle21;
            this.DGViewEntryHaed.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGViewEntryHaed.Size = new System.Drawing.Size(427, 332);
            this.DGViewEntryHaed.TabIndex = 0;
            this.DGViewEntryHaed.SelectionChanged += new System.EventHandler(this.DGViewEntryHaed_SelectionChanged);
            // 
            // Column11
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column11.DefaultCellStyle = dataGridViewCellStyle13;
            this.Column11.Frozen = true;
            this.Column11.HeaderText = "رقم السند";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column12
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column12.DefaultCellStyle = dataGridViewCellStyle14;
            this.Column12.HeaderText = "رقم المرجع";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column13
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column13.DefaultCellStyle = dataGridViewCellStyle15;
            this.Column13.HeaderText = "التاريخ";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column14
            // 
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column14.DefaultCellStyle = dataGridViewCellStyle16;
            this.Column14.HeaderText = "اجمالي القيد";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            this.Column14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column15
            // 
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column15.DefaultCellStyle = dataGridViewCellStyle17;
            this.Column15.HeaderText = "رقم المستخدم";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            this.Column15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column16
            // 
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column16.DefaultCellStyle = dataGridViewCellStyle18;
            this.Column16.HeaderText = "اسم المستخدم";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column20
            // 
            this.Column20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column20.DefaultCellStyle = dataGridViewCellStyle19;
            this.Column20.HeaderText = "البيان";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column20.Width = 44;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Posting";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // panFillRightUp
            // 
            this.panFillRightUp.BackColor = System.Drawing.SystemColors.Control;
            this.panFillRightUp.Controls.Add(this.label6);
            this.panFillRightUp.Controls.Add(this.txtSerch);
            this.panFillRightUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFillRightUp.Location = new System.Drawing.Point(3, 18);
            this.panFillRightUp.Name = "panFillRightUp";
            this.panFillRightUp.Size = new System.Drawing.Size(427, 39);
            this.panFillRightUp.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(344, 12);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 16);
            this.label6.TabIndex = 3;
            this.label6.Text = "بــحــث:";
            // 
            // txtSerch
            // 
            this.txtSerch.BackColor = System.Drawing.Color.Gray;
            this.txtSerch.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerch.ForeColor = System.Drawing.Color.White;
            this.txtSerch.Location = new System.Drawing.Point(61, 9);
            this.txtSerch.Name = "txtSerch";
            this.txtSerch.Size = new System.Drawing.Size(277, 23);
            this.txtSerch.TabIndex = 2;
            this.txtSerch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSerch.TextChanged += new System.EventHandler(this.txtSerch_TextChanged);
            // 
            // panFillRightMain
            // 
            this.panFillRightMain.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panFillRightMain.Controls.Add(this.groupBox1);
            this.panFillRightMain.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panFillRightMain.Location = new System.Drawing.Point(0, 547);
            this.panFillRightMain.Name = "panFillRightMain";
            this.panFillRightMain.Size = new System.Drawing.Size(433, 128);
            this.panFillRightMain.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(429, 124);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ملاحظات";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.groupBoxData);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(433, 155);
            this.panel5.TabIndex = 3;
            // 
            // groupBoxData
            // 
            this.groupBoxData.Controls.Add(this.Note);
            this.groupBoxData.Controls.Add(this.Entry_sum);
            this.groupBoxData.Controls.Add(this.label3);
            this.groupBoxData.Controls.Add(this.label8);
            this.groupBoxData.Controls.Add(this.dateTimePicker1);
            this.groupBoxData.Controls.Add(this.label10);
            this.groupBoxData.Controls.Add(this.Refr_id);
            this.groupBoxData.Controls.Add(this.label2);
            this.groupBoxData.Controls.Add(this.label1);
            this.groupBoxData.Controls.Add(this.Entry_id);
            this.groupBoxData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxData.Location = new System.Drawing.Point(0, 0);
            this.groupBoxData.Name = "groupBoxData";
            this.groupBoxData.Size = new System.Drawing.Size(433, 155);
            this.groupBoxData.TabIndex = 0;
            this.groupBoxData.TabStop = false;
            this.groupBoxData.Text = "بيانات السند";
            // 
            // Note
            // 
            this.Note.BackColor = System.Drawing.Color.Silver;
            this.Note.ForeColor = System.Drawing.Color.Black;
            this.Note.Location = new System.Drawing.Point(43, 104);
            this.Note.Multiline = true;
            this.Note.Name = "Note";
            this.Note.Size = new System.Drawing.Size(298, 45);
            this.Note.TabIndex = 33;
            this.Note.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Entry_sum
            // 
            this.Entry_sum.BackColor = System.Drawing.Color.Silver;
            this.Entry_sum.ForeColor = System.Drawing.Color.Black;
            this.Entry_sum.Location = new System.Drawing.Point(43, 81);
            this.Entry_sum.Name = "Entry_sum";
            this.Entry_sum.Size = new System.Drawing.Size(298, 23);
            this.Entry_sum.TabIndex = 41;
            this.Entry_sum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Entry_sum.TextChanged += new System.EventHandler(this.Entry_sum_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(347, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 16);
            this.label3.TabIndex = 34;
            this.label3.Text = "البيان:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(347, 81);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 16);
            this.label8.TabIndex = 42;
            this.label8.Text = "مبلغ السند:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy/mm/dd";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(43, 52);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(294, 23);
            this.dateTimePicker1.TabIndex = 48;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(343, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 16);
            this.label10.TabIndex = 47;
            this.label10.Text = "التاريخ:";
            // 
            // Refr_id
            // 
            this.Refr_id.BackColor = System.Drawing.Color.Silver;
            this.Refr_id.ForeColor = System.Drawing.Color.Black;
            this.Refr_id.Location = new System.Drawing.Point(43, 24);
            this.Refr_id.Name = "Refr_id";
            this.Refr_id.Size = new System.Drawing.Size(107, 23);
            this.Refr_id.TabIndex = 14;
            this.Refr_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(150, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "رقم المرجع:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(343, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "رقم الســند:";
            // 
            // Entry_id
            // 
            this.Entry_id.BackColor = System.Drawing.Color.Gray;
            this.Entry_id.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Entry_id.ForeColor = System.Drawing.Color.White;
            this.Entry_id.Location = new System.Drawing.Point(234, 23);
            this.Entry_id.Name = "Entry_id";
            this.Entry_id.ReadOnly = true;
            this.Entry_id.Size = new System.Drawing.Size(107, 23);
            this.Entry_id.TabIndex = 1;
            this.Entry_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panDown
            // 
            this.panDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panDown.Controls.Add(this.statusStrip1);
            this.panDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDown.Location = new System.Drawing.Point(0, 709);
            this.panDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDown.Name = "panDown";
            this.panDown.Size = new System.Drawing.Size(1382, 32);
            this.panDown.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.UserId,
            this.UserName,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel5,
            this.UserIdAdded,
            this.UserNameAdded,
            this.toolStripStatusLabel6,
            this.toolStripStatusLabel7,
            this.nameOpration,
            this.toolStripStatusLabel9,
            this.idOpration,
            this.toolStripStatusLabel11,
            this.toolStripStatusLabel8,
            this.StatePosting});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1382, 32);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(93, 27);
            this.toolStripStatusLabel1.Text = "المستخدم الحالي:";
            // 
            // UserId
            // 
            this.UserId.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserId.ForeColor = System.Drawing.Color.White;
            this.UserId.Name = "UserId";
            this.UserId.Size = new System.Drawing.Size(42, 27);
            this.UserId.Text = "UserId";
            // 
            // UserName
            // 
            this.UserName.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserName.ForeColor = System.Drawing.Color.White;
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(62, 27);
            this.UserName.Text = "UserName";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(21, 27);
            this.toolStripStatusLabel2.Text = "||";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel5.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(95, 27);
            this.toolStripStatusLabel5.Text = "أضافة المستخدم:";
            // 
            // UserIdAdded
            // 
            this.UserIdAdded.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserIdAdded.ForeColor = System.Drawing.Color.White;
            this.UserIdAdded.Name = "UserIdAdded";
            this.UserIdAdded.Size = new System.Drawing.Size(78, 27);
            this.UserIdAdded.Text = "UserIdAdded";
            // 
            // UserNameAdded
            // 
            this.UserNameAdded.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserNameAdded.ForeColor = System.Drawing.Color.White;
            this.UserNameAdded.Name = "UserNameAdded";
            this.UserNameAdded.Size = new System.Drawing.Size(98, 27);
            this.UserNameAdded.Text = "UserNameAdded";
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel6.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            this.toolStripStatusLabel6.Size = new System.Drawing.Size(21, 27);
            this.toolStripStatusLabel6.Text = "||";
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel7.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            this.toolStripStatusLabel7.Size = new System.Drawing.Size(72, 27);
            this.toolStripStatusLabel7.Text = "اسم العملية:";
            // 
            // nameOpration
            // 
            this.nameOpration.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameOpration.ForeColor = System.Drawing.Color.White;
            this.nameOpration.Name = "nameOpration";
            this.nameOpration.Size = new System.Drawing.Size(64, 27);
            this.nameOpration.Text = "NameOpra";
            // 
            // toolStripStatusLabel9
            // 
            this.toolStripStatusLabel9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel9.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel9.Name = "toolStripStatusLabel9";
            this.toolStripStatusLabel9.Size = new System.Drawing.Size(66, 27);
            this.toolStripStatusLabel9.Text = "رقم العملية:";
            // 
            // idOpration
            // 
            this.idOpration.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.idOpration.ForeColor = System.Drawing.Color.White;
            this.idOpration.Name = "idOpration";
            this.idOpration.Size = new System.Drawing.Size(42, 27);
            this.idOpration.Text = "idOpra";
            // 
            // toolStripStatusLabel11
            // 
            this.toolStripStatusLabel11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel11.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel11.Name = "toolStripStatusLabel11";
            this.toolStripStatusLabel11.Size = new System.Drawing.Size(21, 27);
            this.toolStripStatusLabel11.Text = "||";
            // 
            // toolStripStatusLabel8
            // 
            this.toolStripStatusLabel8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel8.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel8.Name = "toolStripStatusLabel8";
            this.toolStripStatusLabel8.Size = new System.Drawing.Size(67, 27);
            this.toolStripStatusLabel8.Text = "حالة السند:";
            // 
            // StatePosting
            // 
            this.StatePosting.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatePosting.ForeColor = System.Drawing.Color.White;
            this.StatePosting.Name = "StatePosting";
            this.StatePosting.Size = new System.Drawing.Size(77, 27);
            this.StatePosting.Text = "StatePosting";
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.label13);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(1382, 34);
            this.panUp.TabIndex = 0;
            this.panUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panUp_Paint);
            this.panUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panUp_MouseDown);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Right;
            this.label13.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Location = new System.Drawing.Point(1222, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(160, 33);
            this.label13.TabIndex = 9;
            this.label13.Text = "     سند قيد";
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(0, 0);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(45, 34);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 7;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            this.pictureClose.MouseHover += new System.EventHandler(this.pictureClose_MouseHover);
            // 
            // Entries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1382, 741);
            this.Controls.Add(this.panMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(1389, 743);
            this.Name = "Entries";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "شاشة القيود اليدويــة";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Entries_Load);
            this.panMain.ResumeLayout(false);
            this.panFill.ResumeLayout(false);
            this.panFillUp.ResumeLayout(false);
            this.groupBoxAllCurr.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGViewEntryBody2)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGViewEntryBody)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panRad.ResumeLayout(false);
            this.panRad.PerformLayout();
            this.panFillDown.ResumeLayout(false);
            this.groupBoxOprea.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panFillRight.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGViewEntryHaed)).EndInit();
            this.panFillRightUp.ResumeLayout(false);
            this.panFillRightUp.PerformLayout();
            this.panFillRightMain.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.groupBoxData.ResumeLayout(false);
            this.groupBoxData.PerformLayout();
            this.panDown.ResumeLayout(false);
            this.panDown.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panFill;
        private System.Windows.Forms.Panel panDown;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.Panel panFillDown;
        private System.Windows.Forms.GroupBox groupBoxOprea;
        private System.Windows.Forms.Panel panFillUp;
        private System.Windows.Forms.TextBox Entry_id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Refr_id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxAllCurr;
        private System.Windows.Forms.DataGridView DGViewEntryBody;
        private System.Windows.Forms.TextBox Entry_sum;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Note;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TotalDifferenceTxt;
        private System.Windows.Forms.Label TotalDifferenceLabel;
        private System.Windows.Forms.TextBox TotalDebitTxt;
        private System.Windows.Forms.Label TotalDebitLabel;
        private System.Windows.Forms.TextBox TotalCreditTxt;
        private System.Windows.Forms.Label TotalCreditLabl;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.TextBox CountRows;
        private System.Windows.Forms.Button buttLast;
        private System.Windows.Forms.Button buttBack;
        private System.Windows.Forms.Button buttNext;
        private System.Windows.Forms.Button buttFrist;
        private System.Windows.Forms.Button buttDelete;
        private System.Windows.Forms.Button buttEdite;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button buttAdd;
        private System.Windows.Forms.Button buttPrint;
        private System.Windows.Forms.Button buttPosting;
        private System.Windows.Forms.Panel panFillRight;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panFillRightUp;
        private System.Windows.Forms.TextBox txtSerch;
        private System.Windows.Forms.Panel panFillRightMain;
        private System.Windows.Forms.Panel panRad;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView DGViewEntryHaed;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView DGViewEntryBody2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.GroupBox groupBoxData;
        private System.Windows.Forms.CheckBox checkBoxSavePosting;
        private System.Windows.Forms.ToolStripStatusLabel UserId;
        private System.Windows.Forms.ToolStripStatusLabel UserName;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel UserIdAdded;
        private System.Windows.Forms.ToolStripStatusLabel UserNameAdded;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        private System.Windows.Forms.ToolStripStatusLabel nameOpration;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel9;
        private System.Windows.Forms.ToolStripStatusLabel idOpration;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel11;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel8;
        private System.Windows.Forms.ToolStripStatusLabel StatePosting;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column5;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}