﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;

namespace AccSystem.FormsProject.Accounts
{
    public partial class Entries : Form
    {


        public Entries(string idUser, Dictionary<string, bool> pre, List<string> idNameOpra)
        {
            InitializeComponent();
            UserId.Text = idUser;
            UserName.Text = userSql.GetNameUser(idUser);
            ButtnPre.Clear();
            ButtnPre = pre;
            if (idNameOpra.Count == 2)
            {
                nameOpration.Text = idNameOpra[1];
                idOpration.Text = idNameOpra[0];
            }
            else MessageBox.Show("لم نستقبل تعريف العمليه");
        }

        #region  دالة خارجية لتحريك الفورم
        /////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>                                                                                  ///
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس                                        ///
        ///                                                                                           ///
        /// </summary>                                                                               ///
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>
        /// 
        /// 
        ///     //داله عشان احرك الفورم 
        /// //ننسخها في الحدث MouseDown
        ///    //if (e.Button == MouseButtons.Left)
        ///    //{
        ///    //    ReleaseCapture();
        ///    //    SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        ///    //}
        ///
        ///
        ///////////////////////////////////////////////////////////////////////////////

        #endregion


        #region المتغيرات
        Dictionary<string, bool> ButtnPre = new Dictionary<string, bool>(); //الصلاحيات

        UsersSQL userSql = new UsersSQL();
        List<DataGridView> DGVBody = new List<DataGridView>();
        PostingSQL postingSql = new PostingSQL();
        ClassesProject.EntriesSQL EntriesClass = new ClassesProject.EntriesSQL();
      //  ClassesProject.AccountSQL AccClass = new ClassesProject.AccountSQL();
        ClassesProject.CurrSQL CurrClass = new ClassesProject.CurrSQL();
        List<ClassesProject.EntriesParametr> ListEntrisBodyBeforEdite = new List<ClassesProject.EntriesParametr>();

        List<ClassesProject.EntriesParametr> ListEntrisBodyAfterEdite = new List<ClassesProject.EntriesParametr>();

        ClassesProject.EntriesParametr EntrisBodyBeforEdite;
        DataTable DTableEntryHaed;
        DataTable DTableEntryBody;
      
        int CountDataGridEnryBodyAfterUpdate = 0;
        string flagAddOrEdit = "";
        static string ExchingOld = "0"; //يخزن اخر سعر صرف عشان اذا غير السعر وطلع خطا لانه الصيغه موش صح يرجع السعر القديم
        string OpenOrClose = ""; //اقفل او فتح الاحرف والارقام في الداتا جريت فيو
        EntriesAccList eal;
        string DGV1Or2 = "";
        /*
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy/MM/dd hh:mm:ss";
            */

        #endregion


        #region الدوال
        #region داله الصلاحيات
        bool stingPosting = false;
        void Permissions(string AddOrLoad)
        {
            if (ButtnPre.Count > 0)
            {
                #region البيانات المستلمه
                /*
            ButtnPreCheck.Add("Showed", Convert.ToBoolean(DTpr.Rows[0][2].ToString()));
            ButtnPreCheck.Add("Inserted", Convert.ToBoolean(DTpr.Rows[0][3].ToString()));
            ButtnPreCheck.Add("EditeDate", Convert.ToBoolean(DTpr.Rows[0][4].ToString()));
            ButtnPreCheck.Add("Posting", Convert.ToBoolean(DTpr.Rows[0][5].ToString()));
            ButtnPreCheck.Add("Saerch", Convert.ToBoolean(DTpr.Rows[0][6].ToString()));
            ButtnPreCheck.Add("Printed", Convert.ToBoolean(DTpr.Rows[0][7].ToString()));
            ButtnPreCheck.Add("Updated", Convert.ToBoolean(DTpr.Rows[0][8].ToString()));
            ButtnPreCheck.Add("Deleted", Convert.ToBoolean(DTpr.Rows[0][9].ToString()));
                */
                #endregion
                bool result;
                if (AddOrLoad == "Load")
                {
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Deleted", out result))
                        buttDelete.Enabled = result;
                    // MessageBox.Show(result.ToString());
                    else MessageBox.Show("لما نستقبل صلاحية الحذف");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Inserted", out result))
                        buttAdd.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية الاضافة");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Updated", out result))
                        buttEdite.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية التعديل");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Posting", out result))
                        buttPosting.Enabled = result;  //اذا قد تم ترحيل هذا السند يكون فولس برجع له
                    else MessageBox.Show("لما نستقبل صلاحية الترحيل");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Printed", out result))
                        buttPrint.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية الطباعة");
                }
                else if (AddOrLoad == "Add")
                {
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("EditeDate", out result))
                        dateTimePicker1.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية تعديل التاريخ");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Posting", out result))
                    {
                        //buttPosting.Enabled = result;  //اذا قد تم ترحيل هذا السند يكون فولس برجع له
                        checkBoxSavePosting.Checked = false;
                        checkBoxSavePosting.Enabled = result;
                    }

                    else MessageBox.Show("لما نستقبل صلاحية الترحيل");
                }
            }

        }

        void IsPosting(bool state)
        {
            if (state)
            {
                StatePosting.Text = "مرحل";
                stingPosting = true;
            }
            else
            {
                StatePosting.Text = "غير مرحل";
                stingPosting = false;
            }
        }

        #endregion
        #region التعامل مع قواعد البيانات
        void fillData(string NormalOrSerch)
        {
            if (DTableEntryHaed != null)
                DTableEntryHaed = null;

            DTableEntryHaed = new DataTable();

            if (NormalOrSerch == "All")

                DTableEntryHaed = EntriesClass.GetAllEntries();

            else if (NormalOrSerch == "Serch")
                DTableEntryHaed = EntriesClass.SerchEntreiesHaed(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                DGViewEntryHaed.Rows.Clear();
                // MessageBox.Show(DTableEntryHaed.Rows.Count.ToString());
                for (int i = 0; i < DTableEntryHaed.Rows.Count; i++)
                {
                    #region
                    /*
                     DTableEntryHaed
    Entry_id [0] , Date_entry [1] , Entry_sum [2], 	Refr_id[3], User_id_fk[4], .User_name[5],  Note[6]
      
                    DGV
 Entry_id [0] , 	Refr_id[1] ,  Date_entry [2] ,  Entry_sum [3] ,  User_id_fk[4] , .User_name[5] , Note[6]
                    */
                    #endregion
                    DGViewEntryHaed.Rows.Add
                     (
                    DTableEntryHaed.Rows[i][0].ToString(), //Entry_id
                    DTableEntryHaed.Rows[i][3].ToString(), //Refr_idv
                    Convert.ToDateTime(DTableEntryHaed.Rows[i][1].ToString()).ToShortDateString(), //Date_entry
                    DTableEntryHaed.Rows[i][2].ToString(), //Entry_sum
                    DTableEntryHaed.Rows[i][4].ToString(), //User_id_fk
                    DTableEntryHaed.Rows[i][5].ToString(), //User_name
                    DTableEntryHaed.Rows[i][6].ToString(),  //Note
                    (bool)DTableEntryHaed.Rows[i][7]
                     );
                }
                if (DGViewEntryHaed.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (DGViewEntryHaed.Rows.Count == 0)
                {
                    Entry_id.Text = string.Empty;
                    Refr_id.Text = string.Empty;
                    Entry_sum.Text = string.Empty;
                   // User_id_fk.Text = string.Empty;
                    UserIdAdded.Text = string.Empty;
                    UserNameAdded.Text = string.Empty;
                    Note.Text = string.Empty;
                    dateTimePicker1.Enabled = false;
                    DGViewEntryBody.Rows.Clear();
                    DGViewEntryBody2.Rows.Clear();
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch (Exception ee) { MessageBox.Show(ee.ToString()); }

        }
        void Delet(string Entry_id = "-1")
        {
            EntriesClass.Delet(Entry_id);
            fillData("All");
            //DELETE FROM [dbo].[SupportCatchHead]
            //  WHERE Support_id = 1
        }
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                #region

                if (Entry_sum.Text != string.Empty && Note.Text != string.Empty)
                {
                    if (
                        TotalDifferenceTxt.Text == "0" && Convert.ToInt32(TotalDebitTxt.Text) > 0 &&
                        TotalDebitTxt.Text == TotalCreditTxt.Text && TotalCreditTxt.Text == Entry_sum.Text
                        )
                    {
                        if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            dateTimePicker1.Format = DateTimePickerFormat.Short;
                            string idEnrty
                                     = EntriesClass.InsertNewEntriesHaed(dateTimePicker1.Value.ToShortDateString(),
                                     Entry_sum.Text, (Refr_id.Text != string.Empty ? Refr_id.Text : "NULL"), Note.Text,
                                     UserId.Text); //اعمل اضافة للراس واحفظ الاي دي حقه

                            //   MessageBox.Show(idEnrty, "السند الذي تم اضافتة الان");
                            for (int j = 0; j < 2; j++)
                                for (int i = 0; i < DGVBody[j].Rows.Count; i++)
                                {
                                    if (
                                        DGVBody[j].Rows[i].Cells[1].Value != null
                                        && DGVBody[j].Rows[i].Cells[3].Value != null
                                        //يحتاج كمان رقم حسابات العملات و يتحقق مره ثاني انه اجمالي المدين يساوي اجمالي الدائن
                                        )
                                    {   //
                                        //string idAccCurr = AccClass.GetIdAccCurr(DGViewEntryBody.Rows[i].Cells[1].Value.ToString(), 
                                        //    DGViewEntryBody.Rows[i].Cells[3].Value.ToString());
                                        string idAccCurr = DGVBody[j].Rows[i].Cells[11].Value.ToString();
                                        // MessageBox.Show(DGViewEntryBody.Rows[i].Cells[3].Value.ToString()+"  اسم العملة"+" "+ idAccCurr +" رقم العمله ");

                                        EntriesClass.InsertNewEntriesBody(
                                        idEnrty,
                                        idAccCurr,
                                        DGVBody[j].Rows[i].Cells[5].Value.ToString(), //DebtLocal
                                        DGVBody[j].Rows[i].Cells[6].Value.ToString(), //CreditLocal
                                        DGVBody[j].Rows[i].Cells[7].Value.ToString(), // DebtFrogen
                                        DGVBody[j].Rows[i].Cells[8].Value.ToString(), // CreditForgen
                                        DGVBody[j].Rows[i].Cells[9].Value.ToString(), // Note
                                        DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss tt"), // Date
                                        DGVBody[j].Rows[i].Cells[4].Value.ToString()   //CurrExching
                                        );
                                    }
                                }
                            MessageBox.Show("تمت الاضافة بنجاح");
                            if (
                                      checkBoxSavePosting.Checked == true
                                      &&
                                      checkBoxSavePosting.Enabled == true
                                      )
                            {
                                posting(idEnrty);
                                // MessageBox.Show("انسخ داله الترحيل عند الاضافة");

                            }
                            //داله تخزن الحسابات الي ما حددها عشان ينبه المستخدم
                            //   SendAccNullToListError();

                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "Save";
                            fillData("All");
                            //عرض رسائل التنبية الخاصه ب الحساب الغير مربوطة
                            //  ShowMesgBoxWarningsAccNull();
                        }
                        else
                        {
                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "";
                            fillData("All");
                        }
                    }
                    else MessageBox.Show("لابد ان يكون اجمالي المدين يساوي اجمالي الدائن وان يكون يساوي اجمالي السند اعلاه");

                }
                else if
                    (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }

                #endregion

            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (Entry_sum.Text != string.Empty && Note.Text != string.Empty)
                {
                    if (
                          TotalDifferenceTxt.Text == "0" && Convert.ToInt32(TotalDebitTxt.Text) > 0 &&
                          TotalDebitTxt.Text == TotalCreditTxt.Text && TotalCreditTxt.Text == Entry_sum.Text
                          )
                    {
                        if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        {
                            // SendAccNullToListError();
                            #region اذا عدد العناصر قبل التعديل يساوي عدد العناصر بعد التعديل
                            if (CountDataGridEnryBodyAfterUpdate == (DGVBody[0].RowCount + DGVBody[1].RowCount - 2)
                                && ListEntrisBodyBeforEdite.Count == (DGVBody[0].RowCount + DGVBody[1].RowCount - 2))
                            {
                                int i = 0;
                                int indexList = 0;
                                int j = 0;
                                //   MessageBox.Show(ListEntrisBodyBeforEdite.Count.ToString());
                                for (j = 0; j < 2; j++)
                                    for (i = 0; i < DGVBody[j].RowCount - 1; i++)
                                    {
                                        /*
                                        //داله نرسلها ب المتغيرات قبل
                                        التعديل وتفحص اذا في اختلاف تغير مالم تخليه مثل ما هو
                                        */


                                        #region
                                        if (DGVBody[j].Rows[i].Cells[1].Value != null
                                        && DGVBody[j].Rows[i].Cells[3].Value != null)
                                        {
                                            //string idAccCurr = AccClass.GetIdAccCurr(DGViewEntryBody.Rows[i].Cells[1].Value.ToString(),
                                            // DGViewEntryBody.Rows[i].Cells[3].Value.ToString());
                                            string idAccCurr = DGVBody[j].Rows[i].Cells[11].Value.ToString();
                                            MessageBox.Show(ListEntrisBodyBeforEdite[indexList].EntriesBody_id, "indexIs" + indexList.ToString());
                                            EntriesClass.UpdateEntriesBody(
                                            Entry_id.Text,
                                            ListEntrisBodyBeforEdite[indexList].EntriesBody_id, //اتاكد منها 
                                            idAccCurr,
                                            DGVBody[j].Rows[i].Cells[5].Value.ToString(), //DebtLocal
                                            DGVBody[j].Rows[i].Cells[6].Value.ToString(), //CreditLocal
                                            DGVBody[j].Rows[i].Cells[7].Value.ToString(), // DebtFrogen
                                            DGVBody[j].Rows[i].Cells[8].Value.ToString(), // CreditForgen
                                            DGVBody[j].Rows[i].Cells[9].Value.ToString(), // Note
                                            DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss tt"), // Date
                                            DGVBody[j].Rows[i].Cells[4].Value.ToString()   //CurrExching
                                            );

                                        }
                                        #endregion


                                        if (indexList < ListEntrisBodyBeforEdite.Count)
                                            indexList++;
                                        else { MessageBox.Show(""); }

                                    }
                                if (
                                     checkBoxSavePosting.Checked == true
                                     &&
                                     checkBoxSavePosting.Enabled == true
                                     )
                                {
                                    posting(Entry_id.Text);
                                    // MessageBox.Show("انسخ داله الترحيل عند الاضافة");

                                }

                                //
                            }
                            #endregion
                            else if
                                ((DGVBody[0].RowCount + DGVBody[1].RowCount - 2) > CountDataGridEnryBodyAfterUpdate
                                )
                            {
                                //يضيف صفوف جديدة في الجدول
                                #region
                                int index = 0;
                              
                                    for(int i = 0; i < ListEntrisBodyAfterEdite.Count; i++)
                                    {
                                        if (ListEntrisBodyBeforEdite.Count > index)
                                        {
                                        EntriesClass.UpdateEntriesBody(
                                       Entry_id.Text
                                       , ListEntrisBodyBeforEdite[i].EntriesBody_id
                                       , ListEntrisBodyAfterEdite[index].AccCurr_id
                                       , ListEntrisBodyAfterEdite[index].Debt_local
                                       , ListEntrisBodyAfterEdite[index].Credit_local
                                       , ListEntrisBodyAfterEdite[index].Debt_foreign
                                       , ListEntrisBodyAfterEdite[index].Credit_foreign
                                       , ListEntrisBodyAfterEdite[index].Note
                                       , DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss tt")
                                       , ListEntrisBodyAfterEdite[index].Curr_echange);
                                        //MessageBox.Show(ListEntrisBodyAfterEdite[index].AccCurr_id,"Update");
                                        index++;
                                            
                                        }
                                        else if (ListEntrisBodyAfterEdite.Count > index)
                                        {

                                        EntriesClass.InsertNewEntriesBody(Entry_id.Text, ListEntrisBodyAfterEdite[index].AccCurr_id, ListEntrisBodyAfterEdite[index].Debt_local, ListEntrisBodyAfterEdite[index].Credit_local, ListEntrisBodyAfterEdite[index].Debt_foreign, ListEntrisBodyAfterEdite[index].Credit_foreign, ListEntrisBodyAfterEdite[index].Note, DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss tt"), ListEntrisBodyAfterEdite[index].Curr_echange);
                                        //MessageBox.Show(ListEntrisBodyAfterEdite[index].AccCurr_id, "Insert");
                                            index++;
                                        }

                                    }

                                //
                                #endregion
                            }


                            else if ((DGVBody[0].RowCount + DGVBody[1].RowCount - 2) < CountDataGridEnryBodyAfterUpdate)
                            {
                                //يحذف جميع الصفوف من الجدول ويرجع يمليهم من جديد
                                int index = 0;

                                for (int i = 0; i < ListEntrisBodyBeforEdite.Count; i++)
                                {
                                    if (ListEntrisBodyAfterEdite.Count > index)
                                    {
                                        EntriesClass.UpdateEntriesBody(
                                       Entry_id.Text, ListEntrisBodyBeforEdite[i].EntriesBody_id, ListEntrisBodyAfterEdite[index].AccCurr_id, ListEntrisBodyAfterEdite[index].Debt_local, ListEntrisBodyAfterEdite[index].Credit_local, ListEntrisBodyAfterEdite[index].Debt_foreign, ListEntrisBodyAfterEdite[index].Credit_foreign, ListEntrisBodyAfterEdite[index].Note, DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss tt"), ListEntrisBodyAfterEdite[index].Curr_echange);
                                        //MessageBox.Show(ListEntrisBodyAfterEdite[index].AccCurr_id,"Update");
                                        index++;

                                    }

                                    
                                    else if (ListEntrisBodyBeforEdite.Count > index)
                                    {
                                        EntriesClass.DeleteEntryBody(ListEntrisBodyBeforEdite[index].EntriesBody_id, Entry_id.Text);
                                        index++;
                                    }
                                }

                                }

                            EntriesClass.UpdateEntriesHaed(Entry_id.Text, dateTimePicker1.Value.ToShortDateString(),
                                  Entry_sum.Text, (Refr_id.Text != string.Empty ? Refr_id.Text : "NULL"), Note.Text,
                                  UserIdAdded.Text);

                            MessageBox.Show("تم التعديل بنجاح");
                            // ShowMesgBoxWarningsAccNull();
                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "";
                            fillData("All");
                        }

                        else
                        {
                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "";
                            fillData("All");
                        }
                    }
                    else MessageBox.Show("لابد ان يكون اجمالي المدين يساوي اجمالي الدائن وان يكون يساوي اجمالي السند اعلاه");
                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }

        #endregion

        #region التحكم في الشاشة
        int indexEntryHaedButt(string btName, string EntryHaedId)
        {
            /*
            داله لايجاد اندكس العمله حسب رقم العمله
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (DGViewEntryHaed.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < DGViewEntryHaed.Rows.Count; i++)
                {
                    if (EntryHaedId == DGViewEntryHaed.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < DGViewEntryHaed.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return DGViewEntryHaed.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد اصناف في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
        void FillTextBox(int indexRows)
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (DGViewEntryHaed.Rows.Count > 0)
            {

                int i = indexRows;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */


                Entry_id.Text = DGViewEntryHaed.Rows[i].Cells[0].Value.ToString();
                Refr_id.Text = DGViewEntryHaed.Rows[i].Cells[1].Value.ToString();

                dateTimePicker1.Value =
               Convert.ToDateTime(DGViewEntryHaed.Rows[i].Cells[2].Value.ToString());

                Entry_sum.Text = DGViewEntryHaed.Rows[i].Cells[3].Value.ToString();
                UserIdAdded.Text = DGViewEntryHaed.Rows[i].Cells[4].Value.ToString();
                UserNameAdded.Text = userSql.GetNameUser(UserIdAdded.Text);
                Note.Text = DGViewEntryHaed.Rows[i].Cells[6].Value.ToString();
                IsPosting(Convert.ToBoolean(DGViewEntryHaed.Rows[i].Cells[7].Value));
             
                   
                ShowBodyEntry(Entry_id.Text);
                FillTextBoxCountRows((i + 1).ToString());

            }



        }
        void ShowBodyEntry(string idEntry)
        {//Done

            // MessageBox.Show(Entry_id.Text);
            //  idEntry = Entry_id.Text;
            if (idEntry != null)
            {
                if (DTableEntryBody != null)
                    DTableEntryBody = null;
                DTableEntryBody = new DataTable();

                //DTableEntryBody.Clear(); 

                DTableEntryBody = EntriesClass.GetAllEntriesBody(idEntry);

            }

            /*

                                          dataTable
        EntriesBody.EntriesBody_id [0] , AccCurrency.Acc_id_fk [1] , Accounts.Acc_name [2] , 
        Currencys.Curr_name [3] , EntriesBody.CurrExching [4] , EntriesBody.Debt_local [5] ,
        EntriesBody.Credit_local [6] ,  EntriesBody.Debt_foreign [7] , EntriesBody.Credit_foreign [8] ,
        EntriesBody.Note [9] , EntriesBody.Date_entry_body [10] , AccCurrency.AccCurr_id [11]

            --------------------------------------------------------------------------------------
                                                      dataGridViwe
             EntriesBody.EntriesBody_id [0] , AccCurrency.Acc_id_fk [1] , Accounts.Acc_name [2] , 
        Currencys.Curr_name [3] , EntriesBody.CurrExching [4] , EntriesBody.Debt_local [5] ,
        EntriesBody.Credit_local [6] ,  EntriesBody.Debt_foreign [7] , EntriesBody.Credit_foreign [8] ,
        EntriesBody.Note [9] , EntriesBody.Date_entry_body [10] , AccCurrency.AccCurr_id [11]

            */
            try {
                DGVBody[0].Rows.Clear();
                DGVBody[1].Rows.Clear();
            }
            catch  { MessageBox.Show("LooL"); }
            //DGViewEntryBody.Rows.Clear();
            //DGViewEntryBody2.Rows.Clear();
            //  MessageBox.Show(DTableEntryBody.Rows.Count.ToString());
            if (DTableEntryBody != null && DTableEntryBody.Rows.Count > 0)
            {
                for (int i = 0; i < DTableEntryBody.Rows.Count; i++)
                {
                    if (DTableEntryBody.Rows[i][6].ToString() == "0") //دائن محلي

                        DGVBody[0].Rows.Add
                        (
                        DTableEntryBody.Rows[i][0].ToString(), //التسلسل
                        DTableEntryBody.Rows[i][1].ToString(), //رقم الحساب
                        DTableEntryBody.Rows[i][2].ToString(), //اسم الحساب
                        DTableEntryBody.Rows[i][3].ToString(), //العملة
                        DTableEntryBody.Rows[i][4].ToString(), //سعر الصرف
                        DTableEntryBody.Rows[i][5].ToString(), //مدين محلي
                        DTableEntryBody.Rows[i][6].ToString(), //دائن محلي
                        DTableEntryBody.Rows[i][7].ToString(), //مدين اجنبي
                        DTableEntryBody.Rows[i][8].ToString(), //دائن اجنبي
                        DTableEntryBody.Rows[i][9].ToString(), //البيان
                        DTableEntryBody.Rows[i][10].ToString(), //تاريخ ووقت الاضافة
                        DTableEntryBody.Rows[i][11].ToString(), //رقم حساب_عملات
                        null, //الحد الاعلى
                        null //الحد الادنى


                        );
                    //داله تجيب الحد الاعلى والادنى لكل عمله
                    else if (DTableEntryBody.Rows[i][5].ToString() == "0")//مدين محلي
                        #region تجربة داتا جريت الجانب الدائن

                        DGVBody[1].Rows.Add
                           (
                           DTableEntryBody.Rows[i][0].ToString(), //التسلسل
                           DTableEntryBody.Rows[i][1].ToString(), //رقم الحساب
                           DTableEntryBody.Rows[i][2].ToString(), //اسم الحساب
                           DTableEntryBody.Rows[i][3].ToString(), //العملة
                           DTableEntryBody.Rows[i][4].ToString(), //سعر الصرف
                           DTableEntryBody.Rows[i][5].ToString(), //مدين محلي
                           DTableEntryBody.Rows[i][6].ToString(), //دائن محلي
                           DTableEntryBody.Rows[i][7].ToString(), //مدين اجنبي
                           DTableEntryBody.Rows[i][8].ToString(), //دائن اجنبي
                           DTableEntryBody.Rows[i][9].ToString(), //البيان
                           DTableEntryBody.Rows[i][10].ToString(), //تاريخ ووقت الاضافة
                           DTableEntryBody.Rows[i][11].ToString(), //رقم حساب_عملات
                           null, //الحد الاعلى
                           null //الحد الادنى


                           );
                    #endregion

                } //endForAddDataEntryBody

                //  dataGridView1 = DGViewEntryBody;



            }
            //  else MessageBox.Show("idEntry is null can't show body","رقم السند = "+ idEntry);
            //TotalCreditAndDebit();

        }
        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + DGViewEntryHaed.Rows.Count.ToString();
        }
        void ForamtingAdd()
        {
            Entry_id.Text = EntriesClass.GetMaxIdEntriseHaed();
            Refr_id.Text = string.Empty;
            dateTimePicker1.Value = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd"));
          //  MessageBox.Show(dateTimePicker1.CustomFormat);
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";
            Entry_sum.Text = string.Empty;
            UserIdAdded.Text = string.Empty; 
            UserNameAdded.Text= string.Empty;
            Note.Text = string.Empty;
            Refr_id.Focus();
            DGVBody[0].Rows.Clear(); //التفاصيل
            DGVBody[1].Rows.Clear();

        }
        void moveScreen(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {
            //Doneeeeee
            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                Refr_id.ReadOnly = false;
                Entry_sum.ReadOnly = false;
                Note.ReadOnly = false;
                //dateTimePicker1.Enabled = true;
                /////////////////////

              
                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
                //buttSerch.Enabled = false;
                buttPosting.Enabled = false;
                buttPrint.Enabled = false;
                Permissions("Add"); //استدعاء الصلاحيات
                ////////////////////////////////////////////
                for (int i = 0; i < 2; i++)
                {
                    DGVBody[i].AllowUserToAddRows = true;
                    DGVBody[i].AllowUserToDeleteRows = true;
                    DGVBody[i].MultiSelect = false;
                    DGVBody[i].ReadOnly = false;
                    
                }

              

                if (flagEditeOrAddOrSave == "Edite")
                {
                    //يروح يتحقق من اليومة العامة اذا كان هذا السند قد تم ترحيله لا يمكن التعديل
                }


            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                Refr_id.ReadOnly = true;
                Entry_sum.ReadOnly = true;
                Note.ReadOnly = true;
                dateTimePicker1.Enabled = false;
                checkBoxSavePosting.Checked = false;
                checkBoxSavePosting.Enabled = false;
                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////

                for (int j = 0; j < DGVBody.Count; j++)
                {
                    for (int i = 0; i < DGViewEntryBody.ColumnCount; i++)
                    { DGVBody[j].Columns[i].ReadOnly = true; }

                    DGVBody[j].SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    DGVBody[j].AllowUserToAddRows = false;
                    DGVBody[j].AllowUserToDeleteRows = false;
                }




                ///////////////////

                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
                //buttSerch.Enabled = true;
                buttPosting.Enabled = true; //اذا قد تم ترحيل هذا السند يكون فولس برجع له
                buttPrint.Enabled = true;
                /////////////////////////
                Permissions("Load"); //استدعاء الصلاحيات



            }


        }
        void posting(string RefPost = "-1")
        {
            /*
            قبل عمليه الترحيل
            اذا كانت حاله السند غير مرحله
            اروح اتاكد من جدول اليومية اذا كان موجود هناك او لا
            في حال كان موجود خليه يطلع 
            رساله خطأ للمستخدم يرجى مراجعة الدعم الفني
            خطأ في عمليه الترحيل
            مالم يرحل طبيعي

             */
            if (
                postingSql.CheckPostingOrNot(idOpration.Text, RefPost) //يفحص من جدول اليومية
                &&
                RefPost != "-1"
                &&
                stingPosting == false //يفحص حاله السند من جدول سندات القبض
                )
            {
                MessageBox.Show("لا يمكن ترحيل هذا السند" + "\n" + "يرجى مراجعة مدير النظام او الدعم الفني", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                MessageBox.Show(RefPost, "حالته موش مرحل وهو مرحل مغالط");
            }
            else if (
                !postingSql.CheckPostingOrNot(idOpration.Text, RefPost)
                &&
                RefPost == "-1")
            {
                MessageBox.Show("خطأ في رقم المرجع عند الترحيل", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else if
                (
                !postingSql.CheckPostingOrNot(idOpration.Text, RefPost)
                &&
                  RefPost != "-1"
                )
            {

                postingSql.PostSupportCatch(RefPost, idOpration.Text, UserId.Text);
                fillData("All");

            }


            /*
            باقي عند تشغيل البرنامج يروح يحفظ جميع السندات الي مشيك عليهم انهم مرحلين
            بعدين يروح يفحص في اليومية العامة اذا مهلوش يحفظه
            عشان يعرض داتا جريت فيو يوجد سندات فيها اخطاء يرجى مراجعة الدعم الفني او مدير النظام
            */

        }
        #region ايقاف الاحراف للداتا جريت
        #region ايقاف الاحرف للمدين
        void StopAlphaFromDataGridView_EditingControlShowing(DataGridViewEditingControlShowingEventArgs e, int IndexColums)
        { //Doneeeeee
            try {
                int CurrentCellColumIndex = -1;
                //used in even dataGridView_EditingControlShowing
                e.Control.KeyPress -= new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
                if (DGV1Or2 == "1")
                {
                    CurrentCellColumIndex = DGVBody[0].CurrentCell.ColumnIndex;
                }
                else if (DGV1Or2 == "2")
                    CurrentCellColumIndex = DGVBody[1].CurrentCell.ColumnIndex;

                if (CurrentCellColumIndex == IndexColums)
                {
                    TextBox tb = e.Control as TextBox;
                    if (tb != null)
                    {
                        tb.KeyPress += new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
                        //  tb.KeyPress+=new KeyPressEventHandler(StopAlphaInTextBox);
                    }
                }
            }
            catch { MessageBox.Show("StopAlphaFromDataGridView_EditingControlShowing Function", "Error"); }



        }
        #endregion

        #endregion
        void StopAlphaInColumn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (OpenOrClose == "CloseAlpha")
            {     //IsPunctuation الفواصل العشرية
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsPunctuation(e.KeyChar))
                {
                    e.Handled = true;
                }

            }
            else if (OpenOrClose == "OpenAll") e.Handled = false;

            else if (OpenOrClose == "CloseAll")
            {
                e.Handled = true;

            }
            // OpenOrClose = string.Empty;
        }

        #endregion
        //نهاية التحكم في الشاشة



        #region دوال العمليات

            void SetDataEntriBodyAfterEdite()
        {
            try
            {
                ListEntrisBodyAfterEdite.Clear();
              

                if ((DGVBody[0].Rows.Count + DGVBody[1].Rows.Count) > 0)
                {
                    for (int j = 0; j < 2; j++)
                        for (int i = 0; i < DGVBody[j].Rows.Count; i++)
                        {
                            #region

                            if (
                            #region

                          
                            DGVBody[j].Rows[i].Cells[11].Value != null && //AccCurrId
                            DGVBody[j].Rows[i].Cells[4].Value != null && //سعر الصرف 
                            DGVBody[j].Rows[i].Cells[5].Value != null && //مدين محلي 
                            DGVBody[j].Rows[i].Cells[6].Value != null && //دائن محلي 
                            DGVBody[j].Rows[i].Cells[7].Value != null && //مدين اجنبي 
                            DGVBody[j].Rows[i].Cells[8].Value != null && // دائن اجنبي
                            DGVBody[j].Rows[i].Cells[9].Value != null && //البيان 
                            Entry_id.Text != string.Empty //رقم السند
                            #endregion
                        )
                            {
                                if (EntrisBodyBeforEdite != null)
                                    EntrisBodyBeforEdite = null;
                                EntrisBodyBeforEdite = new ClassesProject.EntriesParametr();

                                #region

                                EntrisBodyBeforEdite.AccCurr_id =
                                    DGVBody[j].Rows[i].Cells[11].Value.ToString();//AccCurrId

                                EntrisBodyBeforEdite.Curr_echange =
                                    DGVBody[j].Rows[i].Cells[4].Value.ToString(); //سعر الصرف

                            
                                                                                  //MessageBox.Show(DGVBody[j].Rows[i].Cells[0].Value.ToString());
                                EntrisBodyBeforEdite.Debt_local =
                                    DGVBody[j].Rows[i].Cells[5].Value.ToString();//مدين محلي

                                EntrisBodyBeforEdite.Credit_local =
                                    DGVBody[j].Rows[i].Cells[6].Value.ToString(); //دائن محلي

                                EntrisBodyBeforEdite.Debt_foreign =
                                    DGVBody[j].Rows[i].Cells[7].Value.ToString(); //مدين اجنبي

                                EntrisBodyBeforEdite.Credit_foreign =
                                    DGVBody[j].Rows[i].Cells[8].Value.ToString(); //دائن اجنبي

                                EntrisBodyBeforEdite.Note =
                                    DGVBody[j].Rows[i].Cells[9].Value.ToString(); //البيان

                                ListEntrisBodyAfterEdite.Add(EntrisBodyBeforEdite);
                                #endregion




                            }
                            #endregion

                        }

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "Error in Func SetDataEntriBodyABeforEdite()");
            }


        }
        void SetDataEntriBodyABeforEdite()
        {
            try
            {
                ListEntrisBodyBeforEdite.Clear();

                if ((DGVBody[0].Rows.Count+ DGVBody[1].Rows.Count) > 0)
                {   for(int j=0;j<2;j++)
                    for (int i = 0; i < DGVBody[j].Rows.Count; i++)
                    {
                        #region

                        if (
                            #region

                        DGVBody[j].Rows[i].Cells[0].Value != null && //التسلسل
                        DGVBody[j].Rows[i].Cells[11].Value != null && //AccCurrId
                        DGVBody[j].Rows[i].Cells[4].Value != null && //سعر الصرف 
                        DGVBody[j].Rows[i].Cells[5].Value != null && //مدين محلي 
                        DGVBody[j].Rows[i].Cells[6].Value != null && //دائن محلي 
                        DGVBody[j].Rows[i].Cells[7].Value != null && //مدين اجنبي 
                        DGVBody[j].Rows[i].Cells[8].Value != null && // دائن اجنبي
                        DGVBody[j].Rows[i].Cells[9].Value != null && //البيان 
                        Entry_id.Text != string.Empty //رقم السند
                        #endregion
                        )
                        {
                            if (EntrisBodyBeforEdite != null)
                                EntrisBodyBeforEdite = null;
                            EntrisBodyBeforEdite = new ClassesProject.EntriesParametr();

                            #region

                            EntrisBodyBeforEdite.AccCurr_id =
                                DGVBody[j].Rows[i].Cells[11].Value.ToString();//AccCurrId

                            EntrisBodyBeforEdite.Curr_echange =
                                DGVBody[j].Rows[i].Cells[4].Value.ToString(); //سعر الصرف

                            EntrisBodyBeforEdite.EntriesBody_id =
                                DGVBody[j].Rows[i].Cells[0].Value.ToString(); // التسلسل
                                //MessageBox.Show(DGVBody[j].Rows[i].Cells[0].Value.ToString());
                            EntrisBodyBeforEdite.Debt_local =
                                DGVBody[j].Rows[i].Cells[5].Value.ToString();//مدين محلي

                            EntrisBodyBeforEdite.Credit_local =
                                DGVBody[j].Rows[i].Cells[6].Value.ToString(); //دائن محلي

                            EntrisBodyBeforEdite.Debt_foreign =
                                DGVBody[j].Rows[i].Cells[7].Value.ToString(); //مدين اجنبي

                            EntrisBodyBeforEdite.Credit_foreign =
                                DGVBody[j].Rows[i].Cells[8].Value.ToString(); //دائن اجنبي

                            EntrisBodyBeforEdite.Note =
                                DGVBody[j].Rows[i].Cells[9].Value.ToString(); //البيان

                            ListEntrisBodyBeforEdite.Add(EntrisBodyBeforEdite);
                            #endregion




                        }
                        #endregion

                    }

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "Error in Func SetDataEntriBodyABeforEdite()");
            }
        }
        void TotalCreditAndDebit()
        { //Doneeeeeeee
            decimal SumDebit = 0;
            decimal SumCredit = 0;


            #region 

            for (int j = 0; j < 2; j++)
                for (int i = 0; i < DGVBody[j].Rows.Count; i++)
                {
                    if (DGVBody[j].Rows[i].Cells[1].Value != null && DGVBody[j].Rows[i].Cells[j + 5].Value != null)
                    {
                        if (DGVBody[j].Rows[i].Cells[1].Value.ToString() != String.Empty && DGVBody[j].Rows[i].Cells[3].Value != null && DGVBody[j].Rows[i].Cells[4].Value != null
                            )
                        {
                            try
                            { if (j == 1)
                                    SumCredit += Convert.ToDecimal(DGVBody[j].Rows[i].Cells[j + 5].Value.ToString()); //الجانب الدائن
                                else if (j == 0) SumDebit += Convert.ToDecimal(DGVBody[j].Rows[i].Cells[j + 5].Value.ToString()); //الجانب المدين
                            }
                            catch { MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                        }
                    }
                }
            #endregion
            TotalCreditTxt.Text = SumCredit.ToString();
            TotalDebitTxt.Text = SumDebit.ToString();
            TotalDifferenceTxt.Text = (SumDebit - SumCredit).ToString();

        }


        void ShowListAcc(object sender, KeyEventArgs e)
        {

            if (e.KeyData == Keys.F9 || e.KeyData == Keys.Delete)
            {
                if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                {
                    List<string> AccCurrIdEx2 = new List<string>();
                    int DGVBodyIndex = -1;
                    if (DGV1Or2 == "1")
                    { DGVBodyIndex = 0; }
                    else if (DGV1Or2 == "2")
                        DGVBodyIndex = 1;

                    else
                        MessageBox.Show("رقم الداتا جريت فيو غير صحيح");

                    if (e.KeyData == Keys.Delete && OpenOrClose == "CloseAll")
                    {
                        e.Handled = true;
                    }
                    else
                    {
                        //string[] AccCurrIdEx = null;
                        if (DGVBodyIndex != -1 && (DGVBodyIndex == 0 || DGVBodyIndex == 1))
                        {
                            // MessageBox.Show(DGVBodyIndex.ToString(), "DGVBodyIndex");
                            int i = DGVBody[DGVBodyIndex].CurrentCell.RowIndex;
                            int j = DGVBody[DGVBodyIndex].CurrentCell.ColumnIndex;

                            if (j == 1)
                            { 
                            try
                            {

                                try
                                {
                                    for (int ind = 0; ind < 2; ind++)
                                    {
                                        ////MessageBox.Show(DGVBody[0].Rows.Count.ToString(), DGVBody[1].Rows.Count.ToString()
                                        //       );
                                        //MessageBox.Show((1+ind).ToString());
                                        if (DGVBody[ind].Rows.Count > 0)
                                        {

                                            try
                                            {
                                                for (int x = 0; x < DGVBody[ind].Rows.Count; x++)
                                                {
                                                    if (DGVBody[ind].Rows[x].Cells[1].Value != null && DGVBody[ind].Rows[x].Cells[2].Value != null)
                                                    {
                                                        AccCurrIdEx2.Add(DGVBody[ind].Rows[x].Cells[11].Value.ToString());

                                                    }
                                                    //else MessageBox.Show("Loool");
                                                }


                                            }
                                            catch (Exception eee) { MessageBox.Show(eee.ToString()); }
                                        }

                                    }

                                    //for (int ind = 0; ind < 2; ind++)
                                    //{

                                    //    MessageBox.Show((1 + ind).ToString(),"LLLLL");
                                    //}
                                }
                                catch (Exception ee)
                                {
                                    MessageBox.Show(ee.ToString(), "Error in fill AccCurrIdEx {ShowListAcc}  ");
                                }

                                eal = new EntriesAccList(AccCurrIdEx2);
                                eal.ShowDialog();

                                if (EntriesAccList.AccSelection.Count > 0)
                                {

                                    List<ClassesProject.EntriesParametr> AccSelection99 = EntriesAccList.AccSelection;


                                    for (int indx = 0; indx < AccSelection99.Count; indx++)
                                    {

                                        DGVBody[DGVBodyIndex].Rows.Add
                                                        (
                                                         "", //التسلسل
                                                         AccSelection99[indx].Acc_id_fk, //
                                                         AccSelection99[indx].Acc_name, //
                                                         AccSelection99[indx].Curr_name, //
                                                          AccSelection99[indx].Curr_echange, //
                                                          "0", //مدين محلي
                                                          "0", //دائن محلي
                                                          "0", //مدين اجنبي
                                                          "0", //دائن اجنبي
                                                          " سنــد قيد رقم" + Entry_id.Text + "  " + Note.Text,//البيان
                                                          "",//تاريخ الان
                                                           AccSelection99[indx].AccCurr_id, //
                                                          null, //الحد الاعلى
                                                          null //الحد الادنى
                                                        );

                                    }
                                    EntriesAccList.AccSelection.Clear();
                                    AccSelection99.Clear();
                                    //نستدعي داله تفحص جميع  العناصر عشان تعمل الفورمتنج حق العملات الاجنبية
                                    //FormatingDataGridViewCurrExching("Add");





                                }

                                if (eal != null)
                                    eal = null;
                            }

                            catch (Exception ee) { MessageBox.Show(ee.ToString(), "ShowListAcc try"); }
                        }
                        }
                    }
                }
            }
        }

    
        void afterCellEndEditDataGridView()
        { //Doneeeee
            if (DGV1Or2 == "1" || DGV1Or2 == "2")
          {
                int DGVBodyIndex;
                if (DGV1Or2 == "1")
                    DGVBodyIndex = 0;
                else
                    DGVBodyIndex = 1;

            if (DGVBody[DGVBodyIndex].Rows.Count > 0)
            {
                if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                {
                    


                    int i = DGVBody[DGVBodyIndex].CurrentCell.RowIndex;
                    int j = DGVBody[DGVBodyIndex].CurrentCell.ColumnIndex;

                    if (j == 4) // سعر الصرف
                    {
                        #region
                        if (DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value == null //سعر الصرف
                            && DGVBody[DGVBodyIndex].Rows[i].Cells[3].Value != null //العملة
                            && DGVBody[DGVBodyIndex].Rows[i].Cells[2].Value != null //اسم الحساب
                            && DGVBody[DGVBodyIndex].Rows[i].Cells[1].Value != null) //رقم الحساب
                        {
                                DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value = ExchingOld;

                        }

                        //يروح يتحقق من سعر الصرف من القيم الادنى والاعلى للصرف
                        if (DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value != null //سعر الصرف
                            && DGVBody[DGVBodyIndex].Rows[i].Cells[3].Value != null) //العملة
                        {
                            #region
                            try
                            {
                                #region
                                if (
                                   (DGVBody[DGVBodyIndex].Rows[i].Cells[13].Value != null //
                                    && DGVBody[DGVBodyIndex].Rows[i].Cells[13].Value.ToString() != "0" //
                                   )
                                   ||
                                   (DGVBody[DGVBodyIndex].Rows[i].Cells[12].Value != null
                                    && DGVBody[DGVBodyIndex].Rows[i].Cells[12].Value.ToString() != "0"
                                   )
                                   )
                                {
                                    #region

                                    if (Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value.ToString()) < Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[13].Value.ToString()))
                                    {
                                        MessageBox.Show(" \n سعر الصرف اقل من الحد الادنى\n  " + "الحد الادنى = " + DGVBody[DGVBodyIndex].Rows[i].Cells[13].Value.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value = ExchingOld;
                                    }
                                    else if (Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value.ToString()) > Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[12].Value.ToString()))
                                    {
                                        MessageBox.Show(" \n سعر الصرف اكبر من الحد الاعلى\n  " + "الحد الاعلى  = " + DGVBody[DGVBodyIndex].Rows[i].Cells[12].Value.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value = ExchingOld;
                                    }

                                    #endregion
                                }

                                else
                                {
                                    #region

                                    if (Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value.ToString()) <= 1)
                                    {
                                        MessageBox.Show("سعر الصرف المدخل لا يمكن ان يكون اقل من الواحد");
                                        //DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                    }
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value = ExchingOld;
                                    #endregion
                                }
                                ExchingOld = DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value.ToString();
                                #endregion
                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "bemoo", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value = ExchingOld;//سعر الصرف

                            }
                            try
                            {
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value = //مدين محلي
                                        (DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value.ToString() == "0" ? "0" : //اذا كان يساوي صفر خليه صفر مالم انزل تحت
                                                  (Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[7].Value) * //مدين اجنبي
                                                       Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value)).ToString()); //سعر الصرف

                                    DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value = //دائن محلي
                                   (DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value.ToString() == "0" ? "0" : //اذا كان يساوي صفر خليه صفر مالم انزل تحت
                                             (Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[8].Value) * //دائن اجنبي
                                                  Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value)).ToString()); //سعر الصرف

                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value = "0"; //دائن محلي
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value = "0";  //مدين محلي
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[8].Value = "0"; //دائن اجنبي
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[7].Value = "0";  //مدين اجنبي

                            }
                            #endregion

                        }
                        else
                        {
                                // DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                DGVBody[DGVBodyIndex].CurrentRow.Cells[4].ReadOnly = true;
                        }

                        #endregion
                    }
                    if (j == 5) // مدين محلي
                    {
                        #region

                        if (DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value != null //سعر الصرف
                            && DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value != null // مدين محلي
                            )
                        {
                                DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value = "0"; //دائن محلي

                        }
                        else
                        {
                            MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "مدين محلي", MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                                DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value = "0";
                        }
                        #endregion
                    }
                    if (j == 6) // دائن محلي
                    {
                        #region

                        if (DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value != null //سعر الصرف
                            && DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value != null //دائن محلي
                            )
                        {
                                DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value = "0"; //مدين محلي

                        }
                        else
                        {
                            MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "دائن محلي", MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                                DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value = "0";
                        }
                        #endregion
                    }
                    if (j == 7) // مدين اجنبي
                    {
                        #region

                        if (
                            DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value != null //سعر الصرف
                           && DGVBody[DGVBodyIndex].Rows[i].Cells[7].Value != null //مدين اجنبي 
                            )
                        {
                                #region
                                DGVBody[DGVBodyIndex].Rows[i].Cells[8].Value = "0"; //دائن اجنبي
                                DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value = "0"; //دائن محلي
                                DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value = "0"; //مدين محلي
                            try
                            {
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value =  //مدين محلي
                                Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[7].Value) * //مدين اجنبي
                                Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value);  //سعر الصرف
                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "مدين اجنبي", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[7].Value = "0"; //مدين اجنبي
                            }
                            #endregion
                        }
                        else
                        {
                            MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "مدين اجنبي", MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                                DGVBody[DGVBodyIndex].Rows[i].Cells[7].Value = "0";
                        }
                        #endregion
                    }
                    if (j == 8) // دائن اجنبي
                    {
                        #region

                        if (DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value != null //سعر الصرف
                            && DGVBody[DGVBodyIndex].Rows[i].Cells[8].Value != null //دائن اجنبي 
                            )
                        {
                                DGVBody[DGVBodyIndex].Rows[i].Cells[7].Value = "0";
                                DGVBody[DGVBodyIndex].Rows[i].Cells[5].Value = "0";
                                DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value = "0";
                            try
                            {
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[6].Value =
                                Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[8].Value) *
                                Convert.ToDouble(DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value);
                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "دائن اجنبي", MessageBoxButtons.OK,
                                  MessageBoxIcon.Error);
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[8].Value = "0";
                            }

                        }
                        else
                        {
                                DGVBody[DGVBodyIndex].Rows[i].Cells[8].Value = "0";
                            MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "دائن اجنبي", MessageBoxButtons.OK,
                                  MessageBoxIcon.Error);
                        }
                        #endregion
                    }





                }

            }
        }

        }
        void cellClickDataGridView()
        { //عند الضغط على الخليه يستقبل فلاج نوع العمليه عشان يتحكم في الكتابة عليها
            try
            { //Doneeeeeeeee
                #region
                if (DGV1Or2 == "1" || DGV1Or2 == "2")
             {
                    int DGVBodyIndex ;
                    if (DGV1Or2 == "1")
                        DGVBodyIndex = 0;
                    else
                        DGVBodyIndex = 1;
                 //   MessageBox.Show(DGVBodyIndex.ToString(),"DGVInde");
                if (DGVBody[DGVBodyIndex].Rows.Count > 0)
                {
                        //DGV1Or2 = "";
                    int i = DGVBody[DGVBodyIndex].CurrentCell.RowIndex;
                    int j = DGVBody[DGVBodyIndex].CurrentCell.ColumnIndex;

                    if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                    {

                            //DGViewEntryBody.AllowUserToAddRows = true;
                            //DGViewEntryBody.AllowUserToDeleteRows = true;
                            #region


                            DGVBody[DGVBodyIndex].Rows[i].Cells[1].ReadOnly = false;
                            if
                            (
                            DGVBody[DGVBodyIndex].Rows[i].Cells[1].Value != null && // رقم الحساب
                            DGVBody[DGVBodyIndex].Rows[i].Cells[2].Value != null && // اسم الحساب
                            DGVBody[DGVBodyIndex].Rows[i].Cells[3].Value != null &&    // العملة
                            DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value != null &&    // سعر الصرف
                            DGVBody[DGVBodyIndex].Rows[i].Cells[11].Value != null // رقم حسابات عملات
                            )
                        {
                                #region اذا كان رقم واسم الحساب والعملة وسعر الصرف وحساب

                                DGVBody[DGVBodyIndex].Rows[i].Cells[0].ReadOnly = true; //التسلسل
                                DGVBody[DGVBodyIndex].Rows[i].Cells[1].ReadOnly = false;//رقم الحساب
                                DGVBody[DGVBodyIndex].Rows[i].Cells[2].ReadOnly = true; // اسم الحساب
                                DGVBody[DGVBodyIndex].Rows[i].Cells[3].ReadOnly = true;// العملة
                                DGVBody[DGVBodyIndex].Rows[i].Cells[9].ReadOnly = false; // البيان
                                DGVBody[DGVBodyIndex].Rows[i].Cells[10].ReadOnly = true; // التاريخ
                                DGVBody[DGVBodyIndex].Rows[i].Cells[11].ReadOnly = true; // رقم حسابات عملات
                                DGVBody[DGVBodyIndex].Rows[i].Cells[12].ReadOnly = true; // الحد الاعلى
                                DGVBody[DGVBodyIndex].Rows[i].Cells[13].ReadOnly = true; // الحد الادنى


                            string AccCurr_id = (DGVBody[DGVBodyIndex].Rows[i].Cells[11]).Value.ToString();


                            if (AccCurr_id != string.Empty)
                            {
                                #region تحديد اذا كانت العملة محلية ام اجنبية

                                if (CurrClass.CurrIsLockal(AccCurr_id) == "1")
                                {
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[4].ReadOnly = true;  //وقف تغيير سعر الصرف
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[5].ReadOnly = false; //مدين محلي
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[6].ReadOnly = false; //دائن محلي
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[7].ReadOnly = true; // مدين اجنبي وقف التعديل
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[8].ReadOnly = true; // وقف تغيير دائن اجنبي
                                }
                                else if (CurrClass.CurrIsLockal(AccCurr_id) == "0")
                                {
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[4].ReadOnly = false;  //اسمح بتغيير الصرف
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[5].ReadOnly = true;   // اوقف مدين محلي
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[6].ReadOnly = true;   // اوقف دائن محلي
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[7].ReadOnly = false;  // افتح مدين اجنبي
                                        DGVBody[DGVBodyIndex].Rows[i].Cells[8].ReadOnly = false;  // افتح دائن اجنبي
                                }
                                #region يخزن سعر الصرف قبل التعديل

                                if (j == 4 && DGVBody[DGVBodyIndex].Rows[i].Cells[4].ReadOnly == false)
                                    ExchingOld = DGVBody[DGVBodyIndex].Rows[i].Cells[4].Value.ToString(); //اتاكد منه
                                #endregion

                                #endregion
                                #region يجيب الحد الاعلى والادنى وسعر الصرف 

                                string[] currEx = CurrClass.GetCurrEchange(AccCurr_id);
                                    //DGViewEntryBody.Rows[i].Cells[4].Value = currEx[0]; // سعر الصرف
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[12].Value = currEx[1]; // الحد الاعلى
                                    DGVBody[DGVBodyIndex].Rows[i].Cells[13].Value = currEx[2]; // الحد الادنى
                                #endregion

                            }
                            else
                            {
                                MessageBox.Show("AccCurr_id is null", " in function cellClickDataGridView() ");
                            }
                            #endregion

                        }
                        else if(DGVBody[DGVBodyIndex].Rows[i].Cells[1].Value==null&& DGVBody[DGVBodyIndex].Rows.Count==1)
                        {
                             
                                DGVBody[DGVBodyIndex].Rows[0].Cells[1].ReadOnly = false;
                               // MessageBox.Show("");
                            }
                            #endregion

                           // DGVBody[0].Rows[0].Cells[1].ReadOnly = false;
                        }
                    else if (flagAddOrEdit == "Load" || flagAddOrEdit == "Save")
                    {
                            //DGViewEntryBody.AllowUserToAddRows = false;
                            //DGViewEntryBody.AllowUserToDeleteRows = false;

                            #region

                            DGVBody[DGVBodyIndex].Rows[i].Cells[0].ReadOnly = true; //التسلسل
                            DGVBody[DGVBodyIndex].Rows[i].Cells[1].ReadOnly = true;//رقم الحساب
                            DGVBody[DGVBodyIndex].Rows[i].Cells[2].ReadOnly = true; // اسم الحساب
                            DGVBody[DGVBodyIndex].Rows[i].Cells[3].ReadOnly = true;// العملة
                            DGVBody[DGVBodyIndex].Rows[i].Cells[4].ReadOnly = true; // سعر الصرف
                            DGVBody[DGVBodyIndex].Rows[i].Cells[5].ReadOnly = true; // مدين
                            DGVBody[DGVBodyIndex].Rows[i].Cells[6].ReadOnly = true; // دائن حلي
                            DGVBody[DGVBodyIndex].Rows[i].Cells[7].ReadOnly = true; // مدين اجنبي
                            DGVBody[DGVBodyIndex].Rows[i].Cells[8].ReadOnly = true; //دائن اجنبي
                            DGVBody[DGVBodyIndex].Rows[i].Cells[9].ReadOnly = true; // البيان
                            DGVBody[DGVBodyIndex].Rows[i].Cells[10].ReadOnly = true; // التاريخ
                            DGVBody[DGVBodyIndex].Rows[i].Cells[11].ReadOnly = true; // رقم حسابات عملات
                            DGVBody[DGVBodyIndex].Rows[i].Cells[12].ReadOnly = true; // الحد الاعلى
                            DGVBody[DGVBodyIndex].Rows[i].Cells[13].ReadOnly = true; // الحد الادنى
                        #endregion
                    }
                } //endif DGV.Ro>0
            }
                #endregion
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString(), "Error in function cellClickDataGridView() "); }
        }
        void EditingControlShowingDataGridView(object sender, DataGridViewEditingControlShowingEventArgs e)
        { //Doneeeeeeee
            //جعل خصائص الخلايا مثل التكست بوكس
            if (DGV1Or2 == "1" || DGV1Or2 == "2")
            {
                int DGVIndex ;
                if (DGV1Or2 == "1")
                    DGVIndex = 0;
                else
                    DGVIndex = 1;
                if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 1 && e.Control is DataGridViewTextBoxEditingControl)
                {
                    OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 1); //ايقاف الكتابة كاملة
                    //DataGridViewTextBoxEditingControl tb = e.Control as DataGridViewTextBoxEditingControl;
                    DataGridViewTextBoxEditingControl tb = e.Control as DataGridViewTextBoxEditingControl;
                    //e.Control.KeyDown -= ShowListAcc;
                    //e.Control.KeyDown += ShowListAcc;

                    tb.KeyDown -= ShowListAcc;

                    tb.KeyDown += ShowListAcc; //عرض شاشة الحسابات
                   

                }

                /////////////////////////////////////
                else if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 2)
                { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 2); }
                /////////////////////////////////////
                else if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 3)
                { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 3); }

                /////////////////////////////////////
                else if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 4)
                { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 4); } //ايقاف الاحرف فقط
                                                                                                       /////////////////////////////////////
                else if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 5)
                { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 5); }
                /////////////////////////////////////
                else if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 6)
                { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 6); }
                /////////////////////////////////////
                else if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 7)
                { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 7); }
                /////////////////////////////////////
                else if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 8)
                { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 8); }
                /////////////////////////////////////
                else if (DGVBody[DGVIndex].CurrentCell.ColumnIndex == 9)
                { OpenOrClose = "OpenAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 9); }

            }

        }

    

        #endregion

        #endregion



        private void pictureClose_Click(object sender, EventArgs e)
        {
            //Process.GetCurrentProcess().Kill();
            this.Close();
        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

    
        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            moveScreen(e);
        }
    
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

            afterCellEndEditDataGridView();

        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            
            ForamtingAdd();
            flagAddOrEdit = "Add";
         
            FormatingTextBoxAndButt(flagAddOrEdit);
          //  cellClickDataGridView();
           

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DGV1Or2 = "1";
            cellClickDataGridView();
           
           // MessageBox.Show("One");
           // TotalCreditAndDebit();

        }
        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }
     
      
        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            DGV1Or2 = "1";
            EditingControlShowingDataGridView(sender, e);
           
        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
           // MessageBox.Show(e.ToString());
          //  e.Cancel = true;
        }

        private void Entries_Load(object sender, EventArgs e)
        {
            DGVBody.Add(DGViewEntryBody);
            DGVBody.Add(DGViewEntryBody2);
            fillData("All");
            DGViewEntryHaed.Select();
          
            DGVBody[0].ReadOnly = true;
            DGVBody[1].ReadOnly = true;
        
            flagAddOrEdit = "Load";
           
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
           
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            FormatingTextBoxAndButt("Load");
          

        }

        private void Entry_sum_TextChanged(object sender, EventArgs e)
        {
           
        }
    
      
        private void buttEdite_Click(object sender, EventArgs e)
        {
            if (!stingPosting)
            {
                CountDataGridEnryBodyAfterUpdate = DGVBody[0].RowCount + DGVBody[1].RowCount;
                // MessageBox.Show(CountDataGridEnryBodyAfterUpdate.ToString());
                flagAddOrEdit = "Edite";
                SetDataEntriBodyABeforEdite();
                FormatingTextBoxAndButt(flagAddOrEdit);

            }
            else MessageBox.Show("السند مرحل لايمكن تعديله", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Stop);
          
        
 
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            DGViewEntryHaed.ClearSelection();
            FillTextBox(indexEntryHaedButt("Last", Entry_id.Text));
           
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            DGViewEntryHaed.ClearSelection();
            FillTextBox(indexEntryHaedButt("Frist", Entry_id.Text));
         
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            DGViewEntryHaed.ClearSelection();
            FillTextBox(indexEntryHaedButt("Next", Entry_id.Text));
          
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            DGViewEntryHaed.ClearSelection();
            FillTextBox(indexEntryHaedButt("Back", Entry_id.Text));
          
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

       

        private void dataGridViewEntryHaed_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void DGViewEntryHaed_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                // MessageBox.Show(DGViewEntryHaed.Rows.Count.ToString());
            if (DGViewEntryHaed.Rows.Count > 0)
            {
                FillTextBox(DGViewEntryHaed.CurrentCell.RowIndex);
              
            }
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SetDataEntriBodyAfterEdite();
            SendDataToAddOrEdit(flagAddOrEdit);
          
        }

        private void buttPrint_Click(object sender, EventArgs e)
        {
            Reports.Entries item = new Reports.Entries();
            item.Refresh();
            item.SetParameterValue("@ID", this.Entry_id.Text);
            Reports.frm_Reports f = new Reports.frm_Reports();

            f.crystalReportViewer1.ReportSource = item;
            f.Refresh();
            f.ShowDialog();
        }

        private void DGViewEntryBody_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            TotalCreditAndDebit(); //شغال تمام
        }

        private void DGViewEntryBody_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            TotalCreditAndDebit();
        }

        private void DGViewEntryBody_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (DGViewEntryBody.RowCount > 0)
            {
                int j = DGViewEntryBody.CurrentCell.ColumnIndex;
                if(j==4||j==5||j==6||j==7||j==8)
                TotalCreditAndDebit();
            }
           
        }

        private void DGViewEntryBody2_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            TotalCreditAndDebit();
        }

        private void DGViewEntryBody2_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            TotalCreditAndDebit();
        }

        private void DGViewEntryBody2_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (DGViewEntryBody2.RowCount > 0)
            {
                int j = DGViewEntryBody2.CurrentCell.ColumnIndex;
                if (j == 4 || j == 5 || j == 6 || j == 7 || j == 8)
                    TotalCreditAndDebit();
            }
        }

        private void DGViewEntryBody2_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
          //  MessageBox.Show("2");
        }

      

        private void DGViewEntryBody2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // MessageBox.Show("2");
            DGV1Or2 = "2";
            cellClickDataGridView();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //DG[0].Rows[0].Cells[0].Value = "1";
            //DG[1].Rows[0].Cells[0].Value = "2";
           // MessageBox.Show((DGVBody[0].Rows.Count + DGVBody[1].Rows.Count).ToString());
        }

        private void DGViewEntryBody2_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            DGV1Or2 = "2";
            EditingControlShowingDataGridView(sender, e);
        }

        private void DGViewEntryBody2_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            afterCellEndEditDataGridView();
        }

        private void buttPosting_Click(object sender, EventArgs e)
        {
            if (Entry_id.Text != string.Empty && !stingPosting)
            {
                posting(Entry_id.Text);
            }
            else { MessageBox.Show("قد تم ترحيل السند سابقا", "", MessageBoxButtons.OK, MessageBoxIcon.Stop); }
           
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (Entry_id.Text != string.Empty)
            {
                if (!stingPosting && !postingSql.CheckPostingOrNot(idOpration.Text, Entry_id.Text))
                {
                    Delet(Entry_id.Text);
                }
                else MessageBox.Show("السند مرحل لايمكن حذفه", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }

   
}
