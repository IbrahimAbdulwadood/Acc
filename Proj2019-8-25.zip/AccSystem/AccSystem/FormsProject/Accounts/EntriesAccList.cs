﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;

namespace AccSystem.FormsProject.Accounts
{
    public partial class EntriesAccList : Form
    {
       
        #region المتغيرات

      // List<string> AccIdSelected = new List<string>(); //يحفظ ارقام الحسابات الي قد اشر عليهم عشان ما يروحو عند عمليه البحث
      // string[] AccCurrId;
        //تستقبل الحسابات الي قدها موجودة في القيود عشان ما تظهر مره ثاني
        List<string> AccCurrId2 = new List<string>();
        int i;
        static public int indeex;
        public bool stateSelect = false; 
        DataTable datatable;
        ClassesProject.AccountSQL AccClass = new ClassesProject.AccountSQL();

   static   public  List<EntriesParametr> AccSelection = new List<EntriesParametr>();
              EntriesParametr AccIdSelected;
        
        #endregion
        #region الاستعلام الجديد
        /*
        
SELECT        AccCurrency.AccCurr_id, AccCurrency.Acc_id_fk, AccCurrency.Curr_id_fk, Accounts.Acc_name, Currencys.Curr_name, Currencys.Curr_is_local, 
                         Currencys.Curr_echange, Currencys.Curr_maximum, Currencys.Curr_minimum, Accounts.Acc_state, AccCurrency.State
FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id where   AccCurrency.AccCurr_id in(1,2,3,4)
            
            */
        #endregion

        public EntriesAccList(List<string> AccCurrId)
        {
            InitializeComponent();
            this.AccCurrId2 = AccCurrId;
            //if(AccCurrId!=null)
                //foreach (var item in AccCurrId)
                //{
                //    MessageBox.Show(item);
                //}

        }


        private void pictureClose_Click(object sender, EventArgs e)
        {
            
            if (AccSelection.Count > 0)
            {
                if (MessageBox.Show("لن تحفظ الحسابات التي حددتها، هل تأكد الخروج من هذه الشاشة؟", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    AccSelection.Clear();
                    stateSelect = false;
                    this.Close();
                }
            }
            else
            {
                stateSelect = false;
                this.Close();
            }
            //AccIdSelected = new EntriesParametr();
            //AccIdSelected.bemoo = "4";
            // MessageBox.Show(AccIdSelected.bemoo);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
     

        private void button52_Click(object sender, EventArgs e)
        {
            if (AccSelection.Count > 0)
            {
                stateSelect = true;

            }
            else
                stateSelect = false;
           //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());
           // indeex = dataGridView1.CurrentCell.RowIndex;
           Close();
            //setIndex();
        }
        void FormatingDataGrid()
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                { for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        #region منع الكتابة على جميع الحقول
                        for (int x = 0; x < dataGridView1.ColumnCount; x++)
                        {
                            dataGridView1.Rows[i].Cells[x].ReadOnly = true;
                        }
                        #endregion
                        #region السماح باختيار الحسابات النشطة وذات العملة المفعلة
                        dataGridView1.Rows[i].Cells[6].ReadOnly =
                            (dataGridView1.Rows[i].Cells[4].Value.ToString() == "حساب نشط" ?
                            (dataGridView1.Rows[i].Cells[5].Value.ToString() == "عملة مفعلة" ? false : true)
                                                                                                    : true);
                        #endregion
                        #region الحساب الي قد تم عمل تشك عليه يخليه ترو
                        //bool AccFound = false;
                        string AccCurrId = dataGridView1.Rows[i].Cells[0].Value.ToString();
                        for (int x = 0; x < AccSelection.Count; x++)
                        {
                            if (AccCurrId == AccSelection[x].AccCurr_id)
                            {
                                DataGridViewCheckBoxCell chk = dataGridView1.Rows[i].Cells[6] as DataGridViewCheckBoxCell;

                                chk.Value = true;
                                break;
                            }

                        }
                    }
                    #endregion
                }
            }
            catch (Exception e) { MessageBox.Show(e.ToString(), "jjhjh"); }

        }
        void FillData(string NormalOrSerch)
        {
            #region بناء الداتا تيبل
            if (datatable != null)
                datatable = null;

            datatable = new DataTable();

            #endregion

            #region تعبئة البيانات في الداتا تيبل هل الجميع ولا بحث
            if (NormalOrSerch == "All")

                datatable = AccClass.GetAccCurrAll();

            else if (NormalOrSerch == "Serch")
                datatable = AccClass.GetAccCurrSerch(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            #endregion


            try
            {
                dataGridView1.Rows.Clear();
                bool NotAlreadyExists; //غير موجود سابقا
                #region اذا كان يوجد بيانات في الداتا تيبل
              
                if (datatable.Rows.Count > 0)
                {
                    #region اذا شاشة القيود رسلت بحسابات موجودة عندها عشان ما يعرضها هنا
                   
                    if (AccCurrId2.Count>0) //اذا قد في حسابات موجود في شاشة القيود عشان ما يظهرها هنا
                    {   
                        for (i = 0; i < datatable.Rows.Count; i++)
                        {
                            NotAlreadyExists = true;
                            for (int j = 0; j < AccCurrId2.Count; j++)
                            {
                               // MessageBox.Show(AccCurrId[j], datatable.Rows[i][0].ToString());
                                if (AccCurrId2[j] == datatable.Rows[i][0].ToString()&& AccCurrId2[j]!=string.Empty)
                                {
                                    NotAlreadyExists = false;
                                   // MessageBox.Show(AccCurrId[j], datatable.Rows[i][0].ToString(),MessageBoxButtons.YesNo); 
                                   break;
                                }
                            }
                            try
                            {
                                if (NotAlreadyExists)
                                {
                                    #region

                                    /*   AccCurrency.AccCurr_id[0]
                , AccCurrency.Acc_id_fk[1]
                , Accounts.Acc_name[2]
                , Currencys.Curr_name[3]
                , Currencys.Curr_is_local[4]
                , Currencys.Curr_echange[5]
                , Currencys.Curr_maximum[6]
                , Currencys.Curr_minimum[7]
                , Accounts.Acc_state[8]
                , AccCurrency.State[9]
                 */
                                    #endregion

                                    #region اضافة البيانات الى الداتا جريت
                                   
                                    //اذا موش موجود سابفا من خلال الحسابات التي ارسلت عند استدعاء هذه الشاشه ضيفه
                                    dataGridView1.Rows.Add
                                     (datatable.Rows[i][0].ToString(), //AccCurr_id[0],
                                        datatable.Rows[i][1].ToString(),  //Acc_id_fk[1],
                                          datatable.Rows[i][2].ToString(),  //Acc_name[2],
                                            datatable.Rows[i][3].ToString(),  //Curr_name[3],
                                              (Convert.ToBoolean(datatable.Rows[i][8].ToString()) == true ? "حساب نشط" : "حساب غير نشط"),  //Acc_state[8],
                                                (Convert.ToBoolean(datatable.Rows[i][9].ToString()) == true ? "عملة مفعلة" : "عملة غير مفعلة"),  //State[9],
                                                  false,  //Select,
                                                    datatable.Rows[i][5].ToString(),  //Curr_echange[5],
                                                        datatable.Rows[i][4].ToString(),  //Curr_is_local[4],
                                                            datatable.Rows[i][6].ToString(),  //Curr_maximum[6],
                                                                datatable.Rows[i][7].ToString()  //Curr_minimum[7],
                                        );
                                    #endregion
                                   
                                } //endIfNotAlread
                            }
                            catch (Exception ee) { MessageBox.Show(ee.ToString()); }

                        } //endforDTable
                        #region اذا الحاسابات الموجودة في شاشة القيود هي جميع الحسابات المتوفرة عشان ما يكررها
                       
                        if (dataGridView1.Rows.Count == 0)

                        {

                            button52.Visible = false;
                            label1.Visible = true;
                            panel2.Visible = true;
                            label1.Text = "لا يوجد حسابات لعرضها";
                        }
                        else if(dataGridView1.Rows.Count>0)
                        {
                            button52.Visible = true;
                            label1.Visible = false;
                            panel2.Visible = false;
                        }
                        #endregion
                    }
                    #endregion
                    #region اذا ما رسلت شاشو القيود حاسبات يعبي جميع الحسابات

                    else
                    {
                            #region اضافة البيانات الى الداتا جريت
                       
                        for (i = 0; i < datatable.Rows.Count; i++)
                        {
                            dataGridView1.Rows.Add
                                   (
                    datatable.Rows[i][0].ToString(), //AccCurr_id[0],
                        datatable.Rows[i][1].ToString(),  //Acc_id_fk[1],
                            datatable.Rows[i][2].ToString(),  //Acc_name[2],
                                datatable.Rows[i][3].ToString(),  //Curr_name[3],
                                    (Convert.ToBoolean(datatable.Rows[i][8].ToString()) == true ? "حساب نشط" : "حساب غير نشط"),  //Acc_state[8],
                                        (Convert.ToBoolean(datatable.Rows[i][9].ToString()) == true ? "عملة مفعلة" : "عملة غير مفعلة"),  //State[9],
                                           false,  //Select,
                                              datatable.Rows[i][5].ToString(),  //Curr_echange[5],
                                                datatable.Rows[i][4].ToString(),  //Curr_is_local[4],
                                                    datatable.Rows[i][6].ToString(),  //Curr_maximum[6],
                                                        datatable.Rows[i][7].ToString()  //Curr_minimum[7],
                                                              );
                            #endregion

                         

                            if (dataGridView1.Rows.Count == 0)

                            {

                                button52.Visible = false;
                                label1.Visible = true;
                                panel2.Visible = true;
                                label1.Text = "لا يوجد حسابات لعرضها";
                            }
                            else if (dataGridView1.Rows.Count > 0)
                            {
                                button52.Visible = true;
                                label1.Visible = false;
                                panel2.Visible = false;
                            }

                        }


                    }
                    #endregion
                }
                #endregion
                #region لا يوجد بيانات في الداتا تيبل
               
                else
                {
                    if (dataGridView1.Rows.Count == 0&& AccSelection.Count==0)

                    {

                        button52.Visible = false;
                        label1.Visible = true;
                        panel2.Visible = true;
                        label1.Text = "لا يوجد حسابات لعرضها";
                    }
                    else if((dataGridView1.Rows.Count == 0 && AccSelection.Count > 0)|| dataGridView1.Rows.Count>0)
                    {
                        button52.Visible = true;
                        label1.Visible = false;
                        panel2.Visible = false;

                    }
                   
                }
                #endregion
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString(),"Error in Fill Data",MessageBoxButtons.OK,MessageBoxIcon.Error); }

        }
        private void EntriesAccList_Load(object sender, EventArgs e)
        {
            // datatable = AccClass.GetAccCurrAll();
            FillData("All");
            FormatingDataGrid();
            // datatable = AccClass.GetAllAccidFromAccCurr(); //يجيب جميع الحسابات الي معاهم عملات من جدول عملات الحسابات



        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                int i = dataGridView1.CurrentCell.RowIndex;
                int j = dataGridView1.CurrentCell.ColumnIndex;

                if (j == 6)
                {
                    if (dataGridView1.Rows[i].Cells[5].Value.ToString() == "عملة مفعلة" && dataGridView1.Rows[i].Cells[4].Value.ToString() == "حساب نشط")
                    {
                        try {
                            DataGridViewCheckBoxCell chk = dataGridView1.Rows[i].Cells[6] as DataGridViewCheckBoxCell;

                            if (Convert.ToBoolean(chk.Value) == true)
                            {
                                bool AccFound = false;
                                string AccCurrId = dataGridView1.Rows[i].Cells[0].Value.ToString();
                                for (int x = 0; x < AccSelection.Count; x++)
                                {
                                    if (AccCurrId == AccSelection[x].AccCurr_id)
                                    {
                                        AccFound = true; break;
                                    }

                                }
                                if (!AccFound)
                                {
                                    AccIdSelected = new EntriesParametr();
                                    
                                    AccIdSelected.AccCurr_id = dataGridView1.Rows[i].Cells[0].Value.ToString();
                                    AccIdSelected.Acc_id_fk = dataGridView1.Rows[i].Cells[1].Value.ToString();
                                    AccIdSelected.Acc_name = dataGridView1.Rows[i].Cells[2].Value.ToString();
                                    AccIdSelected.Curr_name = dataGridView1.Rows[i].Cells[3].Value.ToString();
                                    AccIdSelected.Curr_echange = dataGridView1.Rows[i].Cells[7].Value.ToString();
                                       
                                    AccSelection.Add(AccIdSelected);
                                }
                            }
                            else
                            {
                                string AccCurrId = dataGridView1.Rows[i].Cells[0].Value.ToString();
                                for (int x = 0; x < AccSelection.Count; x++)
                                {
                                    if (AccCurrId == AccSelection[x].AccCurr_id)
                                    {
                                        AccSelection.RemoveAt(x);
                                        break;
                                    }

                                }


                            }
                        }
                        catch(Exception ee)  { MessageBox.Show(ee.ToString(), "Convert.ToBoolean(dataGridView1.Rows[i].Cells[5].Value) == true"); }

                    }

                }
            } //
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (AccSelection.Count>0)
            {
                int i = 1;
                foreach (var item in AccSelection)
                {
                    MessageBox.Show(item.Acc_id_fk,i.ToString());
                    i++;
                }
            }
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            FillData("Serch");
            FormatingDataGrid();
        }
    }
}
