﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{ 
    public partial class EntriesOld : Form
    {
       

        public EntriesOld()
        {
            InitializeComponent();
        }

        #region  دالة خارجية لتحريك الفورم
        /////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>                                                                                  ///
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس                                        ///
        ///                                                                                           ///
        /// </summary>                                                                               ///
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>
        /// 
        /// 
        ///     //داله عشان احرك الفورم 
        /// //ننسخها في الحدث MouseDown
        ///    //if (e.Button == MouseButtons.Left)
        ///    //{
        ///    //    ReleaseCapture();
        ///    //    SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        ///    //}
        ///
        ///
        ///////////////////////////////////////////////////////////////////////////////

        #endregion


        #region المتغيرات


        ClassesProject.EntriesSQL EntriesClass = new ClassesProject.EntriesSQL();
        ClassesProject.AccountSQL AccClass = new ClassesProject.AccountSQL();
        ClassesProject.CurrSQL CurrClass = new ClassesProject.CurrSQL();
        List<ClassesProject.EntriesParametr> ListEntrisBodyBeforEdite = new List<ClassesProject.EntriesParametr>();
        ClassesProject.EntriesParametr EntrisBodyBeforEdite;
        DataTable DTableEntryHaed;
        DataTable DTableEntryBody;
       // DataTable DTableEntryBody2 = new DataTable();
        int CountDataGridEnryBodyAfterUpdate=0;
        string flagAddOrEdit = "";
        static string ExchingOld = "0"; //يخزن اخر سعر صرف عشان اذا غير السعر وطلع خطا لانه الصيغه موش صح يرجع السعر القديم
        string OpenOrClose = ""; //اقفل او فتح الاحرف والارقام في الداتا جريت فيو
        EntriesAccList eal;

        /*
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "yyyy/MM/dd hh:mm:ss";
            */

        #endregion


        #region الدوال

        #region التعامل مع قواعد البيانات
        void fillData(string NormalOrSerch)
        {
            if (DTableEntryHaed != null)
                DTableEntryHaed = null;

                DTableEntryHaed = new DataTable();

            if (NormalOrSerch == "All")

                DTableEntryHaed = EntriesClass.GetAllEntries();

            else if (NormalOrSerch == "Serch")
                DTableEntryHaed = EntriesClass.SerchEntreiesHaed(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                DGViewEntryHaed.Rows.Clear();
               // MessageBox.Show(DTableEntryHaed.Rows.Count.ToString());
                for (int i = 0; i < DTableEntryHaed.Rows.Count; i++)
                {

                    /*
                     DTableEntryHaed
    Entry_id [0] , Date_entry [1] , Entry_sum [2], 	Refr_id[3], User_id_fk[4], .User_name[5],  Note[6]
      
                    DGV
 Entry_id [0] , 	Refr_id[1] ,  Date_entry [2] ,  Entry_sum [3] ,  User_id_fk[4] , .User_name[5] , Note[6]
                    */
                    DGViewEntryHaed.Rows.Add
                     (
                    DTableEntryHaed.Rows[i][0].ToString(), //Entry_id
                    DTableEntryHaed.Rows[i][3].ToString(), //Refr_idv
                    Convert.ToDateTime( DTableEntryHaed.Rows[i][1].ToString()).ToShortDateString(), //Date_entry
                    DTableEntryHaed.Rows[i][2].ToString(), //Entry_sum
                    DTableEntryHaed.Rows[i][4].ToString(), //User_id_fk
                    DTableEntryHaed.Rows[i][5].ToString(), //User_name
                    DTableEntryHaed.Rows[i][6].ToString()  //Note

                     );
                }
                if (DGViewEntryHaed.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (DGViewEntryHaed.Rows.Count == 0)
                {
                    Entry_id.Text = string.Empty;
                    Refr_id.Text = string.Empty;
                    Entry_sum.Text = string.Empty;
                    User_id_fk.Text = string.Empty;
                    Note.Text = string.Empty;
                    dateTimePicker1.Enabled = false;
                    DGViewEntryBody.Rows.Clear();
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch(Exception ee) { MessageBox.Show(ee.ToString()); }

        }
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                #region
                
                if (Entry_sum.Text != string.Empty && Note.Text != string.Empty)
                {
                    if (
                        TotalDifferenceTxt.Text == "0" && Convert.ToInt32(TotalDebitTxt.Text) > 0 &&
                        TotalDebitTxt.Text == TotalCreditTxt.Text&& TotalCreditTxt.Text== Entry_sum.Text
                        )
                    {
                        if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            dateTimePicker1.Format=DateTimePickerFormat.Short;
                            string idEnrty
                                     = EntriesClass.InsertNewEntriesHaed(dateTimePicker1.Value.ToShortDateString(),
                                     Entry_sum.Text, (Refr_id.Text != string.Empty ? Refr_id.Text : "NULL"), Note.Text,
                                     User_id_fk.Text); //اعمل اضافة للراس واحفظ الاي دي حقه

                         //   MessageBox.Show(idEnrty, "السند الذي تم اضافتة الان");
                            for (int i = 0; i < DGViewEntryBody.Rows.Count; i++)
                            {
                                if (
                                    DGViewEntryBody.Rows[i].Cells[1].Value != null
                                    && DGViewEntryBody.Rows[i].Cells[3].Value != null
                                    //يحتاج كمان رقم حسابات العملات و يتحقق مره ثاني انه اجمالي المدين يساوي اجمالي الدائن
                                    )
                                {   //
                                    //string idAccCurr = AccClass.GetIdAccCurr(DGViewEntryBody.Rows[i].Cells[1].Value.ToString(), 
                                    //    DGViewEntryBody.Rows[i].Cells[3].Value.ToString());
                                    string idAccCurr = DGViewEntryBody.Rows[i].Cells[11].Value.ToString();
                                    // MessageBox.Show(DGViewEntryBody.Rows[i].Cells[3].Value.ToString()+"  اسم العملة"+" "+ idAccCurr +" رقم العمله ");

                                    EntriesClass.InsertNewEntriesBody(
                                    idEnrty,
                                    idAccCurr,
                                    DGViewEntryBody.Rows[i].Cells[5].Value.ToString(), //DebtLocal
                                    DGViewEntryBody.Rows[i].Cells[6].Value.ToString(), //CreditLocal
                                    DGViewEntryBody.Rows[i].Cells[7].Value.ToString(), // DebtFrogen
                                    DGViewEntryBody.Rows[i].Cells[8].Value.ToString(), // CreditForgen
                                    DGViewEntryBody.Rows[i].Cells[9].Value.ToString(), // Note
                                    DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss tt"), // Date
                                    DGViewEntryBody.Rows[i].Cells[4].Value.ToString()   //CurrExching
                                    );
                                }
                            }
                            //داله تخزن الحسابات الي ما حددها عشان ينبه المستخدم
                            //   SendAccNullToListError();

                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "Save";
                            fillData("All");
                            //عرض رسائل التنبية الخاصه ب الحساب الغير مربوطة
                            //  ShowMesgBoxWarningsAccNull();
                        }
                        else
                        {
                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "";
                            fillData("All");
                        }
                    }
                    else MessageBox.Show("لابد ان يكون اجمالي المدين يساوي اجمالي الدائن وان يكون يساوي اجمالي السند اعلاه");

                }
                else if 
                    (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }

                #endregion

            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (Entry_sum.Text != string.Empty && Note.Text != string.Empty)
                {
                    if (
                          TotalDifferenceTxt.Text == "0" && Convert.ToInt32(TotalDebitTxt.Text) > 0 &&
                          TotalDebitTxt.Text == TotalCreditTxt.Text && TotalCreditTxt.Text == Entry_sum.Text
                          )
                    {
                        if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        {
                            // SendAccNullToListError();
                            #region اذا عدد العناصر قبل التعديل يساوي عدد العناصر بعد التعديل
                            if (CountDataGridEnryBodyAfterUpdate == DGViewEntryBody.RowCount
                                && ListEntrisBodyBeforEdite.Count == DGViewEntryBody.RowCount)
                            { 
                                int i = 0;
                          

                                

                                for (i = 0; i < DGViewEntryBody.RowCount; i++)
                                {
                                    /*
                                    //داله نرسلها ب المتغيرات قبل
                                    التعديل وتفحص اذا في اختلاف تغير مالم تخليه مثل ما هو
                                    */
                                   
                                    if (
                                        ListEntrisBodyBeforEdite[i].AccCurr_id !=
                                        DGViewEntryBody.Rows[i].Cells[11].Value.ToString() && // idAccCurr

                                        ListEntrisBodyBeforEdite[i].EntriesBody_id !=
                                        DGViewEntryBody.Rows[i].Cells[0].Value.ToString() && //EntryBodyId

                                        ListEntrisBodyBeforEdite[i].Debt_local !=
                                        DGViewEntryBody.Rows[i].Cells[5].Value.ToString() && //DebtLocal

                                        ListEntrisBodyBeforEdite[i].Credit_local !=
                                        DGViewEntryBody.Rows[i].Cells[6].Value.ToString() &&  //CreditLocal

                                        ListEntrisBodyBeforEdite[i].Debt_foreign !=
                                        DGViewEntryBody.Rows[i].Cells[7].Value.ToString() && // DebtFrogen

                                        ListEntrisBodyBeforEdite[i].Credit_foreign !=
                                        DGViewEntryBody.Rows[i].Cells[8].Value.ToString() && // CreditForgen

                                        ListEntrisBodyBeforEdite[i].Curr_echange !=
                                        DGViewEntryBody.Rows[i].Cells[4].Value.ToString() && //CurrExching

                                        ListEntrisBodyBeforEdite[i].Note !=
                                        DGViewEntryBody.Rows[i].Cells[9].Value.ToString() // Note


                                       )
                                    {
                                        #region
                                        if (DGViewEntryBody.Rows[i].Cells[1].Value != null
                                        && DGViewEntryBody.Rows[i].Cells[3].Value != null)
                                        {
                                            //string idAccCurr = AccClass.GetIdAccCurr(DGViewEntryBody.Rows[i].Cells[1].Value.ToString(),
                                            // DGViewEntryBody.Rows[i].Cells[3].Value.ToString());
                                            string idAccCurr = DGViewEntryBody.Rows[i].Cells[11].Value.ToString();

                                            EntriesClass.UpdateEntriesBody(
                                            Entry_id.Text,
                                            DGViewEntryBody.Rows[i].Cells[0].Value.ToString(),  //EntryBodyId //(i+1).toString()
                                            idAccCurr,
                                            DGViewEntryBody.Rows[i].Cells[5].Value.ToString(), //DebtLocal
                                            DGViewEntryBody.Rows[i].Cells[6].Value.ToString(), //CreditLocal
                                            DGViewEntryBody.Rows[i].Cells[7].Value.ToString(), // DebtFrogen
                                            DGViewEntryBody.Rows[i].Cells[8].Value.ToString(), // CreditForgen
                                            DGViewEntryBody.Rows[i].Cells[9].Value.ToString(), // Note
                                            DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss tt"), // Date
                                            DGViewEntryBody.Rows[i].Cells[4].Value.ToString()   //CurrExching
                                            );
                                        }
                                        #endregion
                                    }

                                }
                            
                            }
                            #endregion
                            else if (DGViewEntryBody.RowCount > CountDataGridEnryBodyAfterUpdate)
                            {
                                //يضيف صفوف جديدة في الجدول
                            }
                            else if(DGViewEntryBody.RowCount < CountDataGridEnryBodyAfterUpdate)
                            {
                                //يحذف جميع الصفوف من الجدول ويرجع يمليهم من جديد
                            }
                            

                            MessageBox.Show("تم التعديل بنجاح");
                           // ShowMesgBoxWarningsAccNull();
                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "";
                            fillData("All");
                        }

                        else
                        {
                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "";
                            fillData("All");
                        }
                    }
                    else MessageBox.Show("لابد ان يكون اجمالي المدين يساوي اجمالي الدائن وان يكون يساوي اجمالي السند اعلاه");
                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }

        #endregion

        #region التحكم في الشاشة
        int indexEntryHaedButt(string btName, string EntryHaedId)
        {
            /*
            داله لايجاد اندكس العمله حسب رقم العمله
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (DGViewEntryHaed.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < DGViewEntryHaed.Rows.Count; i++)
                {
                    if (EntryHaedId == DGViewEntryHaed.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < DGViewEntryHaed.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return DGViewEntryHaed.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد اصناف في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
        void FillTextBox(int indexRows)
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (DGViewEntryHaed.Rows.Count > 0)
            {

                int i = indexRows;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */


                Entry_id.Text = DGViewEntryHaed.Rows[i].Cells[0].Value.ToString();
                Refr_id.Text = DGViewEntryHaed.Rows[i].Cells[1].Value.ToString();

                dateTimePicker1.Value =  
               Convert.ToDateTime(DGViewEntryHaed.Rows[i].Cells[2].Value.ToString());

                Entry_sum.Text = DGViewEntryHaed.Rows[i].Cells[3].Value.ToString();
                User_id_fk.Text = DGViewEntryHaed.Rows[i].Cells[4].Value.ToString();
                Note.Text = DGViewEntryHaed.Rows[i].Cells[6].Value.ToString();
                ShowBodyEntry(Entry_id.Text);
                FillTextBoxCountRows((i + 1).ToString());

            }



        }
        void ShowBodyEntry(string idEntry)
        {

           // MessageBox.Show(Entry_id.Text);
          //  idEntry = Entry_id.Text;
                if (idEntry!=null)
                {
                if (DTableEntryBody!=null)
                    DTableEntryBody = null;
                DTableEntryBody = new DataTable();

                //DTableEntryBody.Clear(); 

                DTableEntryBody = EntriesClass.GetAllEntriesBody(idEntry);

                }

            /*

                                          dataTable
        EntriesBody.EntriesBody_id [0] , AccCurrency.Acc_id_fk [1] , Accounts.Acc_name [2] , 
        Currencys.Curr_name [3] , EntriesBody.CurrExching [4] , EntriesBody.Debt_local [5] ,
        EntriesBody.Credit_local [6] ,  EntriesBody.Debt_foreign [7] , EntriesBody.Credit_foreign [8] ,
        EntriesBody.Note [9] , EntriesBody.Date_entry_body [10] , AccCurrency.AccCurr_id [11]

            --------------------------------------------------------------------------------------
                                                      dataGridViwe
             EntriesBody.EntriesBody_id [0] , AccCurrency.Acc_id_fk [1] , Accounts.Acc_name [2] , 
        Currencys.Curr_name [3] , EntriesBody.CurrExching [4] , EntriesBody.Debt_local [5] ,
        EntriesBody.Credit_local [6] ,  EntriesBody.Debt_foreign [7] , EntriesBody.Credit_foreign [8] ,
        EntriesBody.Note [9] , EntriesBody.Date_entry_body [10] , AccCurrency.AccCurr_id [11]

            */
            DGViewEntryBody.Rows.Clear();
         //  MessageBox.Show(DTableEntryBody.Rows.Count.ToString());
            if (DTableEntryBody != null && DTableEntryBody.Rows.Count > 0)
            {
                for (int i = 0; i < DTableEntryBody.Rows.Count; i++)
                {

                    DGViewEntryBody.Rows.Add
                        (
                        DTableEntryBody.Rows[i][0].ToString(), //التسلسل
                        DTableEntryBody.Rows[i][1].ToString(), //رقم الحساب
                        DTableEntryBody.Rows[i][2].ToString(), //اسم الحساب
                        DTableEntryBody.Rows[i][3].ToString(), //العملة
                        DTableEntryBody.Rows[i][4].ToString(), //سعر الصرف
                        DTableEntryBody.Rows[i][5].ToString(), //مدين محلي
                        DTableEntryBody.Rows[i][6].ToString(), //دائن محلي
                        DTableEntryBody.Rows[i][7].ToString(), //مدين اجنبي
                        DTableEntryBody.Rows[i][8].ToString(), //دائن اجنبي
                        DTableEntryBody.Rows[i][9].ToString(), //البيان
                        DTableEntryBody.Rows[i][10].ToString(), //تاريخ ووقت الاضافة
                        DTableEntryBody.Rows[i][11].ToString(), //رقم حساب_عملات
                        null, //الحد الاعلى
                        null //الحد الادنى


                        );
                   //داله تجيب الحد الاعلى والادنى لكل عمله

                } //endForAddDataEntryBody
            




            }
            //  else MessageBox.Show("idEntry is null can't show body","رقم السند = "+ idEntry);
            //TotalCreditAndDebit();

        }
        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + DGViewEntryHaed.Rows.Count.ToString();
        }
        void ForamtingAdd()
        {
            Entry_id.Text = EntriesClass.GetMaxIdEntriseHaed();
            Refr_id.Text = string.Empty;
            dateTimePicker1.Value = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd"));
          MessageBox.Show(dateTimePicker1.CustomFormat);
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";
            Entry_sum.Text = string.Empty;
            User_id_fk.Text = string.Empty; //خليه ياخذ رقم المستخدم الحالي
            Note.Text = string.Empty;
            Refr_id.Focus();
            DGViewEntryBody.Rows.Clear(); //التفاصيل


        }
        void moveScreen(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
      
        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                Refr_id.ReadOnly = false;
                Entry_sum.ReadOnly = false;
                Note.ReadOnly = false;
                dateTimePicker1.Enabled = true;
                /////////////////////
               

                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
                //buttSerch.Enabled = false;
                buttPosting.Enabled = false;
                buttPrint.Enabled = false;

                ////////////////////////////////////////////
                DGViewEntryBody.AllowUserToAddRows = true;
                DGViewEntryBody.AllowUserToDeleteRows = true;
                DGViewEntryBody.MultiSelect = false;
                DGViewEntryBody.ReadOnly = false;

                
                if (flagEditeOrAddOrSave == "Edite")
                {
                   //يروح يتحقق من اليومة العامة اذا كان هذا السند قد تم ترحيله لا يمكن التعديل
                }


            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                Refr_id.ReadOnly = true;
                Entry_sum.ReadOnly = true;
                Note.ReadOnly = true;
                dateTimePicker1.Enabled = false;

                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
               

                for (int i = 0; i < DGViewEntryBody.ColumnCount; i++)
                {
                    DGViewEntryBody.Columns[i].ReadOnly = true;
                }

                DGViewEntryBody.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                ///////////////////
              
                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
                //buttSerch.Enabled = true;
                buttPosting.Enabled = true; //اذا قد تم ترحيل هذا السند يكون فولس برجع له
                buttPrint.Enabled = true;
                /////////////////////////
                DGViewEntryBody.AllowUserToAddRows = false;
                DGViewEntryBody.AllowUserToDeleteRows = false;


            }


        }
        void StopAlphaFromDataGridView_EditingControlShowing(DataGridViewEditingControlShowingEventArgs e, int IndexColums)
        { 
            //used in even dataGridView_EditingControlShowing
            e.Control.KeyPress -= new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
            if (DGViewEntryBody.CurrentCell.ColumnIndex == IndexColums)
            {
                TextBox tb = e.Control as TextBox;
                if (tb != null)
                {
                    tb.KeyPress += new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
                    //  tb.KeyPress+=new KeyPressEventHandler(StopAlphaInTextBox);
                }
            }


        }
      
       void StopAlphaInColumn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (OpenOrClose == "CloseAlpha")
            {     //IsPunctuation الفواصل العشرية
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsPunctuation(e.KeyChar))
                {
                    e.Handled = true;
                }

            }
            else if (OpenOrClose == "OpenAll") e.Handled = false;

            else if (OpenOrClose == "CloseAll")
            {
                e.Handled = true;
               
            }
           // OpenOrClose = string.Empty;
        }

        #endregion
        //نهاية التحكم في الشاشة
      


        #region دوال العمليات
        void TotalCreditAndDebit()
        {
            decimal SumDebit = 0;
            decimal SumCredit = 0;
            for (int i = 0; i < DGViewEntryBody.Rows.Count; i++)
                if (DGViewEntryBody.Rows[i].Cells[1].Value != null)
                {
                    if (DGViewEntryBody.Rows[i].Cells[1].Value.ToString() != String.Empty && DGViewEntryBody.Rows[i].Cells[3].Value != null && DGViewEntryBody.Rows[i].Cells[4].Value != null&& DGViewEntryBody.Rows[i].Cells[5].Value != null)
                    {
                        try {
                            SumDebit += Convert.ToDecimal(DGViewEntryBody.Rows[i].Cells[5].Value.ToString());
                        }
                        catch { MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                    }
                    if (DGViewEntryBody.Rows[i].Cells[1].Value.ToString() != String.Empty && DGViewEntryBody.Rows[i].Cells[3].Value != null && DGViewEntryBody.Rows[i].Cells[4].Value != null)
                    {
                        try {
                            SumCredit += Convert.ToDecimal(DGViewEntryBody.Rows[i].Cells[6].Value.ToString());
                        }catch { MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة","",MessageBoxButtons.OK,MessageBoxIcon.Error); }
                    }
                }
            TotalCreditTxt.Text = SumCredit.ToString();
            TotalDebitTxt.Text = SumDebit.ToString();
            TotalDifferenceTxt.Text = (SumDebit - SumCredit).ToString();
            //برجع لها
        }
     
      
        void ShowListAcc(object sender, KeyEventArgs e)
        {
          
            if (e.KeyData == Keys.F9|| e.KeyData == Keys.Delete)
            {
                if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                {  
                    int i = DGViewEntryBody.CurrentCell.RowIndex;
                    int j = DGViewEntryBody.CurrentCell.ColumnIndex;
                    if (e.KeyData == Keys.Delete&& OpenOrClose == "CloseAll")
                    {
                       e.Handled = true;
                    }
                    else
                    {
                        string[] AccCurrIdEx = null;
                       try
                        {

                            try
                            {
                                if (DGViewEntryBody.Rows.Count > 0)
                                {
                                    // MessageBox.Show(DGViewEntryBody.Rows.Count.ToString());
                                    AccCurrIdEx = new string[DGViewEntryBody.Rows.Count];

                                    for (int x = 0; x < DGViewEntryBody.Rows.Count; x++)
                                    {
                                        if (DGViewEntryBody.Rows[x].Cells[1].Value.ToString() != string.Empty && DGViewEntryBody.Rows[x].Cells[2].Value.ToString() != string.Empty)
                                            AccCurrIdEx[x] = DGViewEntryBody.Rows[x].Cells[11].Value.ToString();
                                        else AccCurrIdEx[x] = "";
                                    }
                                }
                            }
                            catch (Exception ee) { MessageBox.Show(ee.ToString(), "Error in fill AccCurrIdEx {ShowListAcc}  "); }
                            List<string> abc = new List<string>();
                            if (AccCurrIdEx != null)
                                //   MessageBox.Show("not null");
                               

                                eal = new EntriesAccList(abc);
                            eal.ShowDialog();

                            if (eal.stateSelect = true && eal.dataGridView1.Rows.Count > 0)
                            {

                                List<ClassesProject.EntriesParametr> AccSelection99 = EntriesAccList.AccSelection;
                                if (AccSelection99.Count > 0)
                                {

                                    for (int indx = 0; indx < AccSelection99.Count; indx++)
                                        DGViewEntryBody.Rows.Add
                                            (
                                             "", //التسلسل
                                             AccSelection99[indx].Acc_id_fk, //
                                             AccSelection99[indx].Acc_name, //
                                             AccSelection99[indx].Curr_name, //
                                              AccSelection99[indx].Curr_echange, //
                                              "0", //مدين محلي
                                              "0", //دائن محلي
                                              "0", //مدين اجنبي
                                              "0", //دائن اجنبي
                                              " سنــد قيد رقم" + Entry_id.Text + "  " + Note.Text,//البيان
                                              "",//تاريخ الان
                                               AccSelection99[indx].AccCurr_id, //
                                              null, //الحد الاعلى
                                              null //الحد الادنى
                                            );
                                    EntriesAccList.AccSelection.Clear();
                                    //نستدعي داله تفحص جميع  العناصر عشان تعمل الفورمتنج حق العملات الاجنبية
                                    //FormatingDataGridViewCurrExching("Add");
                                }




                            }

                            if (eal != null)
                                eal = null;
                        }
                        catch (Exception ee) { MessageBox.Show(ee.ToString(), "ShowListAcc try"); }
                    }
                }
            }
            
        }
        void afterCellEndEditDataGridView()
        {
            if (DGViewEntryBody.Rows.Count>0)
            {
                if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                {
                    int i = DGViewEntryBody.CurrentCell.RowIndex;
                    int j = DGViewEntryBody.CurrentCell.ColumnIndex;
                  
                    if (j == 4) // سعر الصرف
                    {
                        #region
                        if (DGViewEntryBody.Rows[i].Cells[4].Value == null //سعر الصرف
                            && DGViewEntryBody.Rows[i].Cells[3].Value != null //العملة
                            && DGViewEntryBody.Rows[i].Cells[2].Value != null //اسم الحساب
                            && DGViewEntryBody.Rows[i].Cells[1].Value != null) //رقم الحساب
                        {
                            DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;

                        }

                        //يروح يتحقق من سعر الصرف من القيم الادنى والاعلى للصرف
                        if (DGViewEntryBody.Rows[i].Cells[4].Value != null //سعر الصرف
                            && DGViewEntryBody.Rows[i].Cells[3].Value != null) //العملة
                        {
                            #region
                            try
                            {
                                #region
                                if (
                                   ( DGViewEntryBody.Rows[i].Cells[13].Value != null //
                                    && DGViewEntryBody.Rows[i].Cells[13].Value.ToString() != "0" //
                                   )
                                   ||
                                   (DGViewEntryBody.Rows[i].Cells[12].Value != null
                                    && DGViewEntryBody.Rows[i].Cells[12].Value.ToString() != "0"
                                   )
                                   )
                                {
                                    #region
                                   
                                    if (Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[4].Value.ToString()) < Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[13].Value.ToString()))
                                    {
                                        MessageBox.Show(" \n سعر الصرف اقل من الحد الادنى\n  " + "الحد الادنى = " + DGViewEntryBody.Rows[i].Cells[13].Value.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                    }
                                    else if (Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[4].Value.ToString()) > Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[12].Value.ToString()))
                                    {
                                        MessageBox.Show(" \n سعر الصرف اكبر من الحد الاعلى\n  " + "الحد الاعلى  = " + DGViewEntryBody.Rows[i].Cells[12].Value.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                    }

                                    #endregion
                                }

                                else
                                {
                                    #region
                                   
                                    if (Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[4].Value.ToString()) <= 1)
                                    {
                                        MessageBox.Show("سعر الصرف المدخل لا يمكن ان يكون اقل من الواحد");
                                        //DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                    }
                                    DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                    #endregion
                                }
                                ExchingOld = DGViewEntryBody.Rows[i].Cells[4].Value.ToString();
                                #endregion
                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "bemoo", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;//سعر الصرف

                            }
                            try
                            {
                                DGViewEntryBody.Rows[i].Cells[5].Value = //مدين محلي
                                        (DGViewEntryBody.Rows[i].Cells[5].Value.ToString() == "0" ? "0" : //اذا كان يساوي صفر خليه صفر مالم انزل تحت
                                                  (Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[7].Value) * //مدين اجنبي
                                                       Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[4].Value)).ToString()); //سعر الصرف

                                DGViewEntryBody.Rows[i].Cells[6].Value = //دائن محلي
                                   (DGViewEntryBody.Rows[i].Cells[6].Value.ToString() == "0" ? "0" : //اذا كان يساوي صفر خليه صفر مالم انزل تحت
                                             (Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[8].Value) * //دائن اجنبي
                                                  Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[4].Value)).ToString()); //سعر الصرف

                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                DGViewEntryBody.Rows[i].Cells[6].Value = "0"; //دائن محلي
                                DGViewEntryBody.Rows[i].Cells[5].Value = "0";  //مدين محلي
                                DGViewEntryBody.Rows[i].Cells[8].Value = "0"; //دائن اجنبي
                                DGViewEntryBody.Rows[i].Cells[7].Value = "0";  //مدين اجنبي

                            }
                            #endregion

                        }
                        else
                        {
                            // DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                            DGViewEntryBody.CurrentRow.Cells[4].ReadOnly = true;
                        }
                            
                        #endregion
                    }
                    if (j == 5) // مدين محلي
                    {
                        #region
                      
                        if (DGViewEntryBody.Rows[i].Cells[4].Value != null //سعر الصرف
                            && DGViewEntryBody.Rows[i].Cells[5].Value != null // مدين محلي
                            ) 
                        {
                            DGViewEntryBody.Rows[i].Cells[6].Value = "0"; //دائن محلي

                        }
                        else
                        {
                            MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "مدين محلي", MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                            DGViewEntryBody.Rows[i].Cells[5].Value = "0";
                        }
                        #endregion
                    }
                    if (j == 6) // دائن محلي
                    {
                        #region
                       
                        if (DGViewEntryBody.Rows[i].Cells[4].Value != null //سعر الصرف
                            && DGViewEntryBody.Rows[i].Cells[6].Value != null //دائن محلي
                            ) 
                        {
                            DGViewEntryBody.Rows[i].Cells[5].Value = "0"; //مدين محلي

                        }
                        else
                        {
                            MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "دائن محلي", MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                            DGViewEntryBody.Rows[i].Cells[6].Value = "0";
                        }
                        #endregion
                    }
                    if (j == 7) // مدين اجنبي
                    {
                        #region

                        if (
                            DGViewEntryBody.Rows[i].Cells[4].Value != null //سعر الصرف
                           && DGViewEntryBody.Rows[i].Cells[7].Value != null //مدين اجنبي 
                            )
                        {
                            #region
                            DGViewEntryBody.Rows[i].Cells[8].Value = "0"; //دائن اجنبي
                            DGViewEntryBody.Rows[i].Cells[6].Value = "0"; //دائن محلي
                            DGViewEntryBody.Rows[i].Cells[5].Value = "0"; //مدين محلي
                            try
                            {
                                DGViewEntryBody.Rows[i].Cells[5].Value =  //مدين محلي
                                Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[7].Value) * //مدين اجنبي
                                Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[4].Value);  //سعر الصرف
                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "مدين اجنبي", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                DGViewEntryBody.Rows[i].Cells[7].Value = "0"; //مدين اجنبي
                            }
                            #endregion
                        }
                        else
                        {
                            MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "مدين اجنبي", MessageBoxButtons.OK,
                                      MessageBoxIcon.Error);
                            DGViewEntryBody.Rows[i].Cells[7].Value = "0";
                        } 
                        #endregion
                    }
                    if (j == 8) // دائن اجنبي
                    {
                        #region

                        if (DGViewEntryBody.Rows[i].Cells[4].Value != null //سعر الصرف
                            && DGViewEntryBody.Rows[i].Cells[8].Value != null //دائن اجنبي 
                            )
                        {
                            DGViewEntryBody.Rows[i].Cells[7].Value = "0";
                            DGViewEntryBody.Rows[i].Cells[5].Value = "0";
                            DGViewEntryBody.Rows[i].Cells[6].Value = "0";
                            try
                            {
                                DGViewEntryBody.Rows[i].Cells[6].Value =
                                Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[8].Value) *
                                Convert.ToDouble(DGViewEntryBody.Rows[i].Cells[4].Value);
                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "دائن اجنبي", MessageBoxButtons.OK,
                                  MessageBoxIcon.Error);
                                DGViewEntryBody.Rows[i].Cells[8].Value = "0";
                            }
                           
                        }
                        else
                        {
                            DGViewEntryBody.Rows[i].Cells[8].Value = "0";
                            MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "دائن اجنبي", MessageBoxButtons.OK,
                                  MessageBoxIcon.Error);
                        }
                        #endregion
                    }
              

                    }

            }
        
        }
        void cellClickDataGridView()
        { //عند الضغط على الخليه يستقبل فلاج نوع العمليه عشان يتحكم في الكتابة عليها
            try
            {
                #region
               
                if (DGViewEntryBody.Rows.Count > 0)
                {
                    
                    int i = DGViewEntryBody.CurrentCell.RowIndex;
                    int j = DGViewEntryBody.CurrentCell.ColumnIndex;

                    if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                    {

                        //DGViewEntryBody.AllowUserToAddRows = true;
                        //DGViewEntryBody.AllowUserToDeleteRows = true;
                        #region

                        #region تفريغ الصف الذي فيه رقم او اسم حساب فارغ او عمله فارغة

                        if (
                            DGViewEntryBody.Rows[i].Cells[1].Value == null || // رقم الحساب
                            DGViewEntryBody.Rows[i].Cells[2].Value == null || // اسم الحساب
                            DGViewEntryBody.Rows[i].Cells[3].Value == null    // العملة
                            )
                        {

                            #region هذي الكود يفرغ
                            /*
                              DGViewEntryBody.Rows[i].Cells[0].ReadOnly = true; //التسلسل
                              DGViewEntryBody.Rows[i].Cells[1].ReadOnly = false;//رقم الحساب
                              DGViewEntryBody.Rows[i].Cells[2].ReadOnly = true; // اسم الحساب
                              DGViewEntryBody.Rows[i].Cells[3].ReadOnly = true;// العملة
                              DGViewEntryBody.Rows[i].Cells[4].ReadOnly = true; // سعر الصرف
                              DGViewEntryBody.Rows[i].Cells[5].ReadOnly = true; // مدين
                              DGViewEntryBody.Rows[i].Cells[6].ReadOnly = true; // دائن حلي
                              DGViewEntryBody.Rows[i].Cells[7].ReadOnly = true; // مدين اجنبي
                              DGViewEntryBody.Rows[i].Cells[8].ReadOnly = true; //دائن اجنبي
                              DGViewEntryBody.Rows[i].Cells[9].ReadOnly = true; // البيان
                              DGViewEntryBody.Rows[i].Cells[10].ReadOnly = true; // التاريخ
                              DGViewEntryBody.Rows[i].Cells[11].ReadOnly = true; // رقم حسابات عملات
                              DGViewEntryBody.Rows[i].Cells[12].ReadOnly = true; // الحد الاعلى
                              DGViewEntryBody.Rows[i].Cells[13].ReadOnly = true; // الحد الادنى
                             for(int indxCol=0; indxCol<=13; indxCol++)
                              {
                                  DGViewEntryBody.Rows[i].Cells[indxCol].Value = null;

                              }
                              */
                            #endregion
                            #region هذا الكود يحذف الصف
                            DGViewEntryBody.Rows.RemoveAt(i);
                            #endregion
                        }
                        #endregion

                        else if
                            (
                            DGViewEntryBody.Rows[i].Cells[1].Value != null && // رقم الحساب
                            DGViewEntryBody.Rows[i].Cells[2].Value != null && // اسم الحساب
                            DGViewEntryBody.Rows[i].Cells[3].Value != null &&    // العملة
                            DGViewEntryBody.Rows[i].Cells[4].Value != null &&    // سعر الصرف
                            DGViewEntryBody.Rows[i].Cells[11].Value !=null // رقم حسابات عملات
                            )
                        {
                            #region اذا كان رقم واسم الحساب والعملة وسعر الصرف وحساب
                          
                            DGViewEntryBody.Rows[i].Cells[0].ReadOnly = true; //التسلسل
                            DGViewEntryBody.Rows[i].Cells[1].ReadOnly = false;//رقم الحساب
                            DGViewEntryBody.Rows[i].Cells[2].ReadOnly = true; // اسم الحساب
                            DGViewEntryBody.Rows[i].Cells[3].ReadOnly = true;// العملة
                            DGViewEntryBody.Rows[i].Cells[9].ReadOnly = false; // البيان
                            DGViewEntryBody.Rows[i].Cells[10].ReadOnly = true; // التاريخ
                            DGViewEntryBody.Rows[i].Cells[11].ReadOnly = true; // رقم حسابات عملات
                            DGViewEntryBody.Rows[i].Cells[12].ReadOnly = true; // الحد الاعلى
                            DGViewEntryBody.Rows[i].Cells[13].ReadOnly = true; // الحد الادنى
                           

                            string AccCurr_id = (DGViewEntryBody.Rows[i].Cells[11]).Value.ToString();


                            if (AccCurr_id != string.Empty)
                            {
                                #region تحديد اذا كانت العملة محلية ام اجنبية
                                
                                if (CurrClass.CurrIsLockal(AccCurr_id) == "1")
                                {
                                    DGViewEntryBody.Rows[i].Cells[4].ReadOnly = true;  //وقف تغيير سعر الصرف
                                    DGViewEntryBody.Rows[i].Cells[5].ReadOnly = false; //مدين محلي
                                    DGViewEntryBody.Rows[i].Cells[6].ReadOnly = false; //دائن محلي
                                    DGViewEntryBody.Rows[i].Cells[7].ReadOnly = true; // مدين اجنبي وقف التعديل
                                    DGViewEntryBody.Rows[i].Cells[8].ReadOnly = true; // وقف تغيير دائن اجنبي
                                }
                                else if (CurrClass.CurrIsLockal(AccCurr_id) == "0")
                                {
                                    DGViewEntryBody.Rows[i].Cells[4].ReadOnly = false;  //اسمح بتغيير الصرف
                                    DGViewEntryBody.Rows[i].Cells[5].ReadOnly = true;   // اوقف مدين محلي
                                    DGViewEntryBody.Rows[i].Cells[6].ReadOnly = true;   // اوقف دائن محلي
                                    DGViewEntryBody.Rows[i].Cells[7].ReadOnly = false;  // افتح مدين اجنبي
                                    DGViewEntryBody.Rows[i].Cells[8].ReadOnly = false;  // افتح دائن اجنبي
                                }
                                #region يخزن سعر الصرف قبل التعديل
                               
                                if (j == 4 && DGViewEntryBody.Rows[i].Cells[4].ReadOnly== false)
                                    ExchingOld = DGViewEntryBody.Rows[i].Cells[4].Value.ToString(); //اتاكد منه
                                #endregion

                                #endregion
                                #region يجيب الحد الاعلى والادنى وسعر الصرف 

                                string[] currEx = CurrClass.GetCurrEchange(AccCurr_id);
                                //DGViewEntryBody.Rows[i].Cells[4].Value = currEx[0]; // سعر الصرف
                                DGViewEntryBody.Rows[i].Cells[12].Value = currEx[1]; // الحد الاعلى
                                DGViewEntryBody.Rows[i].Cells[13].Value = currEx[2]; // الحد الادنى
                                #endregion 
                              
                            }
                            else
                            {
                                MessageBox.Show("AccCurr_id is null", " in function cellClickDataGridView() ");
                            }
                            #endregion

                        }
                        else
                        {
                            MessageBox.Show(" error if ((flagAddOrEdit == Add || flagAddOrEdit == Edite)) ",
                                "in function cellClickDataGridView()");
                        }
                        #endregion

                    }
                    else if (flagAddOrEdit == "Load" || flagAddOrEdit == "Save")
                    {
                        //DGViewEntryBody.AllowUserToAddRows = false;
                        //DGViewEntryBody.AllowUserToDeleteRows = false;

                        #region

                        DGViewEntryBody.Rows[i].Cells[0].ReadOnly = true; //التسلسل
                        DGViewEntryBody.Rows[i].Cells[1].ReadOnly = true;//رقم الحساب
                        DGViewEntryBody.Rows[i].Cells[2].ReadOnly = true; // اسم الحساب
                        DGViewEntryBody.Rows[i].Cells[3].ReadOnly = true;// العملة
                        DGViewEntryBody.Rows[i].Cells[4].ReadOnly = true; // سعر الصرف
                        DGViewEntryBody.Rows[i].Cells[5].ReadOnly = true; // مدين
                        DGViewEntryBody.Rows[i].Cells[6].ReadOnly = true; // دائن حلي
                        DGViewEntryBody.Rows[i].Cells[7].ReadOnly = true; // مدين اجنبي
                        DGViewEntryBody.Rows[i].Cells[8].ReadOnly = true; //دائن اجنبي
                        DGViewEntryBody.Rows[i].Cells[9].ReadOnly = true; // البيان
                        DGViewEntryBody.Rows[i].Cells[10].ReadOnly = true; // التاريخ
                        DGViewEntryBody.Rows[i].Cells[11].ReadOnly = true; // رقم حسابات عملات
                        DGViewEntryBody.Rows[i].Cells[12].ReadOnly = true; // الحد الاعلى
                        DGViewEntryBody.Rows[i].Cells[13].ReadOnly = true; // الحد الادنى
                        #endregion
                    }
                } //endif DGV.Ro>0
                #endregion
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString(), "Error in function cellClickDataGridView() "); }
        }
        void EditingControlShowingDataGridView(object sender ,DataGridViewEditingControlShowingEventArgs e)
        {
            //جعل خصائص الخلايا مثل التكست بوكس

            if (DGViewEntryBody.CurrentCell.ColumnIndex == 1 && e.Control is DataGridViewTextBoxEditingControl)
            {
                OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 1); //ايقاف الكتابة كاملة
                DataGridViewTextBoxEditingControl tb = e.Control as DataGridViewTextBoxEditingControl;
                tb.KeyDown -= ShowListAcc;
                tb.KeyDown += ShowListAcc; //عرض شاشة الحسابات

            }

            /////////////////////////////////////
            else if (DGViewEntryBody.CurrentCell.ColumnIndex == 2)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 2); }
            /////////////////////////////////////
            else if (DGViewEntryBody.CurrentCell.ColumnIndex == 3)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 3); }

            /////////////////////////////////////
            else if (DGViewEntryBody.CurrentCell.ColumnIndex == 4)
            { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 4); } //ايقاف الاحرف فقط
            /////////////////////////////////////
            else if (DGViewEntryBody.CurrentCell.ColumnIndex == 5)
            { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 5); }
            /////////////////////////////////////
            else if (DGViewEntryBody.CurrentCell.ColumnIndex == 6)
            { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 6); }
            /////////////////////////////////////
            else if (DGViewEntryBody.CurrentCell.ColumnIndex == 7)
            { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 7); }
            /////////////////////////////////////
            else if (DGViewEntryBody.CurrentCell.ColumnIndex == 8)
            { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 8); }
            /////////////////////////////////////
            else if (DGViewEntryBody.CurrentCell.ColumnIndex == 9)
            { OpenOrClose = "OpenAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 9); }
           

        }

        #endregion

        #endregion



        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

    
        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            moveScreen(e);
        }
    
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

            afterCellEndEditDataGridView();

        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            
            ForamtingAdd();
            flagAddOrEdit = "Add";
            cellClickDataGridView();
            FormatingTextBoxAndButt(flagAddOrEdit);


        }
    
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cellClickDataGridView();
           // TotalCreditAndDebit();

        }
        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }
     
      
        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            EditingControlShowingDataGridView(sender, e);
           
        }

        private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
           // MessageBox.Show(e.ToString());
          //  e.Cancel = true;
        }

        private void Entries_Load(object sender, EventArgs e)
        {
            fillData("All");
            DGViewEntryHaed.Select();
            DGViewEntryBody.ReadOnly = true;
            flagAddOrEdit = "Load";
            //cellClickDataGridView();
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
           
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            FormatingTextBoxAndButt("Load");
           
        }

        private void Entry_sum_TextChanged(object sender, EventArgs e)
        {

        }
      void SetDataEntriBodyABeforEdite()
        {
            try
            {
                ListEntrisBodyBeforEdite.Clear();

                if (DGViewEntryBody.Rows.Count > 0)
                {
                    for (int i=0;i< DGViewEntryBody.Rows.Count;i++)
                    {
                        #region
                      
                        if (
                        #region
                       
                        DGViewEntryBody.Rows[i].Cells[0].Value != null && //التسلسل
                        DGViewEntryBody.Rows[i].Cells[11].Value != null && //AccCurrId
                        DGViewEntryBody.Rows[i].Cells[4].Value != null && //سعر الصرف 
                        DGViewEntryBody.Rows[i].Cells[5].Value != null && //مدين محلي 
                        DGViewEntryBody.Rows[i].Cells[6].Value != null && //دائن محلي 
                        DGViewEntryBody.Rows[i].Cells[7].Value != null && //مدين اجنبي 
                        DGViewEntryBody.Rows[i].Cells[8].Value != null && // دائن اجنبي
                        DGViewEntryBody.Rows[i].Cells[9].Value != null && //البيان 
                        Entry_id.Text != string.Empty //رقم السند
                        #endregion
                        )
                        {
                            if (EntrisBodyBeforEdite != null)
                                EntrisBodyBeforEdite = null;
                            EntrisBodyBeforEdite = new ClassesProject.EntriesParametr();
                           
                            #region

                            EntrisBodyBeforEdite.AccCurr_id = 
                                DGViewEntryBody.Rows[i].Cells[11].Value.ToString();//AccCurrId

                            EntrisBodyBeforEdite.Curr_echange =
                                DGViewEntryBody.Rows[i].Cells[4].Value.ToString(); //سعر الصرف

                            EntrisBodyBeforEdite.EntriesBody_id =
                                DGViewEntryBody.Rows[i].Cells[0].Value.ToString(); // التسلسل

                            EntrisBodyBeforEdite.Debt_local = 
                                DGViewEntryBody.Rows[i].Cells[5].Value.ToString();//مدين محلي

                            EntrisBodyBeforEdite.Credit_local =
                                DGViewEntryBody.Rows[i].Cells[6].Value.ToString(); //دائن محلي

                            EntrisBodyBeforEdite.Debt_foreign =
                                DGViewEntryBody.Rows[i].Cells[7].Value.ToString(); //مدين اجنبي

                            EntrisBodyBeforEdite.Credit_foreign = 
                                DGViewEntryBody.Rows[i].Cells[8].Value.ToString(); //دائن اجنبي

                            EntrisBodyBeforEdite.Note =
                                DGViewEntryBody.Rows[i].Cells[9].Value.ToString(); //البيان

                            ListEntrisBodyBeforEdite.Add(EntrisBodyBeforEdite);
                            #endregion




                        }
                        #endregion

                    }

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "Error in Func SetDataEntriBodyABeforEdite()");
            }
        }
      
        private void buttEdite_Click(object sender, EventArgs e)
        {
            CountDataGridEnryBodyAfterUpdate = DGViewEntryBody.RowCount;
            flagAddOrEdit = "Edite";
            SetDataEntriBodyABeforEdite();
            FormatingTextBoxAndButt(flagAddOrEdit);
        
 
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            DGViewEntryHaed.ClearSelection();
            FillTextBox(indexEntryHaedButt("Last", Entry_id.Text));
           
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            DGViewEntryHaed.ClearSelection();
            FillTextBox(indexEntryHaedButt("Frist", Entry_id.Text));
         
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            DGViewEntryHaed.ClearSelection();
            FillTextBox(indexEntryHaedButt("Next", Entry_id.Text));
          
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            DGViewEntryHaed.ClearSelection();
            FillTextBox(indexEntryHaedButt("Back", Entry_id.Text));
          
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

       

        private void dataGridViewEntryHaed_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void DGViewEntryHaed_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                // MessageBox.Show(DGViewEntryHaed.Rows.Count.ToString());
            if (DGViewEntryHaed.Rows.Count > 0)
            {
                FillTextBox(DGViewEntryHaed.CurrentCell.RowIndex);
              
            }
        }

        private void butSave_Click(object sender, EventArgs e)
        {
           
            SendDataToAddOrEdit(flagAddOrEdit);
          
        }

        private void buttPrint_Click(object sender, EventArgs e)
        {
           // MessageBox.Show(DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss tt"));
            //MessageBox.Show((dateTimePicker1.Value.ToShortDateString())); // str.Substring(str.Length - length, length);
        }

        private void DGViewEntryBody_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            TotalCreditAndDebit(); //شغال تمام
        }

        private void DGViewEntryBody_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            TotalCreditAndDebit();
        }

        private void DGViewEntryBody_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (DGViewEntryBody.RowCount > 0)
            {
                int j = DGViewEntryBody.CurrentCell.ColumnIndex;
                if(j==4||j==5||j==6||j==7||j==8)
                TotalCreditAndDebit();
            }
           
        }
    }

   
}
