﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.FormsProject.Accounts;
using NumberToWord;

namespace AccSystem.FormsProject.Accounts
{
    public partial class FrmAllSelectAcc : Form
    {
        public FrmAllSelectAcc()
        {
            InitializeComponent();
        }

        #region المتغيرات
        ClassesProject.ConnectionDB con = new ClassesProject.ConnectionDB();
        DataTable DT;
        #endregion
        #region  الدوال
    
        DataTable GetReport(string DateBgin, string DateEnd)
        {
            if (DT != null)
                DT = null;
            DT = new DataTable();

            string
          query = "   select        ";
            query += "   a.Dayly_id_fk  ";
            query += "   ,a.Oper_name  ";
            query += "   ,a.Bill_Type ";
            query += "   ,a.Refer_id_fk  ";
            query += "  ,a.Date_dayly  ";
            query += "   ,a.Acc_id_fk  ";
            query += " ,a.Acc_name  ";
            query += "   ,a.Curr_name  ";
            query += " ,a.Debt_local  ";
            query += "  ,a.Credit_local   ";
            query += "   ,a.Debt_foreign ";
            query += "   ,a.Credit_foreign  ";
            query += "  ,a.Note  ";
            query += "  ,a.Date_Added  ";
            query += "  ,a.UserAdded  ";

            query += "   ,(SELECT    User_name   ";
            query += " FROM     Users   ";
            query += "  WHERE        User_id = a.UserAdded)   ";

            query += "   ,a.UserPosting  ";

            query += "   ,(SELECT        User_name ";
            query += " FROM            Users  ";
            query += " WHERE        User_id =a.UserPosting)  ";

            query += "   ,a.Oper_id_fk  ";

            query += "  from ( ";
            ////////////////////////////////////////

            query += "  SELECT     ";
            query += "    DaylyBody.Dayly_id_fk ";
            query += "  , Operations.Oper_name  ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=6  ";
            query += "  ,(SELECT   TypeBill.Type_neme ";
            query += "  FROM            TypeBill INNER JOIN  ";
            query += "   SalesBillHead ON TypeBill.Type_id = SalesBillHead.Type_id_fk  ";
            query += "   WHERE        SalesBillHead.Bill_id = DaylyHaed.Refer_id_fk) ";

            query += "  ,iif(DaylyHaed.Oper_id_fk=7  ";
            query += " ,(SELECT        TypeBill.Type_neme  ";
            query += "  FROM            TypeBill INNER JOIN  ";
            query += " ReturnSalesBillHead ON TypeBill.Type_id = ReturnSalesBillHead.Type_id_fk  ";
            query += "   WHERE        (ReturnSalesBillHead.Return_bill_id =DaylyHaed.Refer_id_fk ))  ";
            query += "   ,'')) as Bill_Type ";
            ///////////////////////////////////////

            query += "  , DaylyHaed.Refer_id_fk   ";
            query += "  , DaylyHaed.Date_dayly  ";
            query += " , Accounts.Acc_name   ";
            query += " , Currencys.Curr_name  ";
            query += "   , AccCurrency.Acc_id_fk  ";
            query += " , DaylyBody.Debt_local  ";
            query += "   , DaylyBody.Credit_local  ";
            query += "   , DaylyBody.Debt_foreign  ";
            query += "  , DaylyBody.Credit_foreign  ";
            ///////////////////////////////////////////////////
            query += "  ,isnull(iif(DaylyHaed.Oper_id_fk=2   ";
            // query += "  ---اذا كان سند قبض---  ";
            query += "   ,(SELECT   top 1     Note   ";
            query += "  FROM            SupportCatchBody  ";
            query += "  WHERE  ";
            query += "   (Support_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += "  AND (AccCurr_id_fk = (DaylyBody.AccCurr_id_fk)))   ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=3  ";
            // query += "  ---اذا كان سند صرف---  ";
            query += "     ,(SELECT   top 1     Note ";
            query += "   FROM            SupportExchangBody ";
            query += "  WHERE  ";
            query += "   (Support_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += "  AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk))  ";
            query += " ,iif(DaylyHaed.Oper_id_fk=6  ";
            //   query += " ---اذا كان فاتورة مبيعات ---   ";
            query += " ,(SELECT   top 1     Note  ";
            query += "   FROM            SalesBillHead  ";
            query += "   WHERE        (Bill_id = DaylyHaed.Refer_id_fk))  ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=7  ";
            //  query += " ---اذا كان مردود مبيعات ---  ";

            query += "   ,(SELECT   top 1     Note  ";
            query += "   FROM            ReturnSalesBillHead  ";
            query += " WHERE        (Return_bill_id = DaylyHaed.Refer_id_fk))   ";

            query += "  ,iif(DaylyHaed.Oper_id_fk=0  ";
            //  query += "  ---اذا كان قيد افتتاحي ---   ";
            query += "  ,(SELECT   top 1     Note  ";
            query += " FROM            DaylyBody  ";
            query += "  WHERE ";
            query += "  (Dayly_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += " AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk))  ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=1  ";
            query += "    ,(SELECT  top 1      Note  ";
            query += " FROM     EntriesBody  ";
            query += "  WHERE    ";
            query += " (Entry_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += " AND (AccCurr_id_fk =DaylyBody.AccCurr_id_fk ))   ";
            query += " ,'')))))),'') as Note  ";
            /////////////////////////////////////////////////////////

            query += "   ,isnull(iif(DaylyHaed.Oper_id_fk=2 ";
            //  query += "  ---اذا كان سند قبض---  ";
            query += "   ,(SELECT        Date_support_catch  ";
            query += "  FROM            SupportCatchHead  ";
            query += "    WHERE        Support_id = DaylyHaed.Refer_id_fk)   ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=3  ";
            //      query += "   ---اذا كان سند صرف---  ";
            query += "     ,( SELECT        Date_support_exchang  ";
            query += "   FROM            SupportExchangHead ";
            query += "   WHERE        Support_id = DaylyHaed.Refer_id_fk)   ";
            query += "    ,iif(DaylyHaed.Oper_id_fk=6  ";
            //  query += "  ---اذا كان فاتورة مبيعات ---  ";
            query += "     ,(SELECT        Date_salesbill  ";
            query += "   FROM            SalesBillHead  ";
            query += "  WHERE        Bill_id = DaylyHaed.Refer_id_fk)   ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=7  ";
            //  query += "  ---اذا كان مردود مبيعات --- ";
            query += "   ,(SELECT        Date_return_salesBill   ";
            query += "  FROM            ReturnSalesBillHead   ";
            query += "  WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)  ";

            query += "  ,iif(DaylyHaed.Oper_id_fk=0   ";
            //    query += "   ---اذا كان قيد افتتاحي ---  ";
            query += "  ,( SELECT   top 1     Date_Balance_open  ";
            query += "   FROM            BalanceOpen)  ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=1  ";
            query += "  ,( SELECT        Date_entry  ";
            query += "  FROM            EntriesHead   ";
            query += "  WHERE        Entry_id = DaylyHaed.Refer_id_fk)   ";
            query += "  ,'')))))),'') as Date_Added   ";
            //////////////////////////////////////////////
            //  query += "   ---مدخل السجل---   ";
            query += "  ,isnull(iif(DaylyHaed.Oper_id_fk=2  ";
            //    query += "   ---اذا كان سند قبض---  ";
            query += "  ,(SELECT    top 1    BoxUser.User_id_fk   ";
            query += "  FROM            SupportCatchHead INNER JOIN  ";
            query += "   BoxUser ON SupportCatchHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN  ";
            query += "   Users ON BoxUser.User_id_fk = Users.User_id  ";
            query += " 	WHERE       SupportCatchHead.Support_id = DaylyHaed.Refer_id_fk)    ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=3 ";
            //   query += "   ---اذا كان سند صرف---  ";
            query += "   ,( SELECT   top 1   BoxUser.User_id_fk  ";
            query += "  FROM            SupportExchangHead INNER JOIN  ";
            query += "  BoxUser ON SupportExchangHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN  ";
            query += "   Users ON BoxUser.User_id_fk = Users.User_id  ";
            query += "  WHERE        SupportExchangHead.Support_id = DaylyHaed.Refer_id_fk)   ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=6   ";
            //   query += "  ---اذا كان فاتورة مبيعات ---  ";
            query += "  ,(SELECT  top 1     BoxUser.User_id_fk   ";
            query += "    FROM            SalesBillHead INNER JOIN  ";
            query += "  BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN   ";
            query += "   Users ON BoxUser.User_id_fk = Users.User_id  ";
            query += "   WHERE        Bill_id = DaylyHaed.Refer_id_fk)  ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=7   ";
            //    query += "    ---اذا كان مردود مبيعات --- ";
            query += "  ,(SELECT    top 1    BoxUser.User_id_fk  ";
            query += "   FROM            ReturnSalesBillHead INNER JOIN  ";
            query += " BoxUser ON ReturnSalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN   ";
            query += "  Users ON BoxUser.User_id_fk = Users.User_id  ";

            query += "  WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)   ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=0  ";
            //  query += "  ---اذا كان قيد افتتاحي ---  ";
            query += "  ,( SELECT  top 1   BalanceOpen.User_id_fk   ";
            query += "  FROM            BalanceOpen INNER JOIN    ";

            query += "    Users ON BalanceOpen.User_id_fk = Users.User_id)  ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=1  ";
            query += "   ,( SELECT   top 1      DaylyHaed.User_id_fk  ";
            query += "   FROM            DaylyHaed INNER JOIN  ";
            query += "  Users ON DaylyHaed.User_id_fk = Users.User_id  ";
            query += "   where DaylyHaed.Dayly_id= DaylyHaed.Refer_id_fk)   ";
            query += "    ,'')))))),'') as UserAdded  ";
            //////////////////////

            //   query += "  --مرحل السجل-   ";
            query += "   ,(SELECT      User_id  ";
            query += "   FROM            Users   ";
            query += "   WHERE        User_id = DaylyHaed.User_id_fk) as UserPosting   ";
            query += "  ,DaylyHaed.Oper_id_fk   ";
            query += " FROM            DaylyHaed INNER JOIN   ";
            query += "   DaylyBody ON DaylyHaed.Dayly_id = DaylyBody.Dayly_id_fk INNER JOIN  ";
            query += "   AccCurrency ON DaylyBody.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN  ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN  ";
            query += "   Operations ON DaylyHaed.Oper_id_fk = Operations.Oper_id   ";
            query += "   )  ";

            query += "  a  ";
            query += "  where (a.Date_dayly between   " + con.AddApostropheToString(DateBgin);
            query += "  and    " + con.AddApostropheToString(DateEnd);
            query += " or a.Date_Added between " + con.AddApostropheToString(DateBgin);
            query += " and " + con.AddApostropheToString(DateEnd) + " ) ";



            query += "   group by  ";
            query += "   a.Dayly_id_fk ";
            query += "  ,a.Oper_name  ";
            query += "  ,a.Bill_Type  ";
            query += "  ,a.Refer_id_fk  ";
            query += "  ,a.Date_dayly ";
            query += "  ,a.Acc_id_fk  ";
            query += "  ,a.Acc_name  ";
            query += "  ,a.Curr_name  ";
            query += "  ,a.Debt_local ";
            query += "  ,a.Credit_local  ";
            query += "  ,a.Debt_foreign  ";
            query += "  ,a.Credit_foreign  ";
            query += "  ,a.Note  ";
            query += "  ,a.Date_Added  ";
            query += "  ,a.UserAdded  ";
            query += "  ,a.UserPosting  ";
            query += "  ,a.Oper_id_fk  ";


            con.OpenConnetion();
            try { DT = con.Query(query, true); } catch (Exception e) { MessageBox.Show(e.ToString()); }
            
            con.CloseConnetion();

            return DT;
            #region  الاستعلام
            /*
string
          
          query =  " select ";
				  query +="a.Dayly_id_fk";
				query +=",a.Oper_name";
				query +=",a.Bill_Type";
				query +=",a.Refer_id_fk";
				query +=",a.Date_dayly";
				query +=",a.Acc_id_fk";
				query +=",a.Acc_name";
				query +=",a.Curr_name";
				query +=",a.Debt_local";
				query +=",a.Credit_local";
				query +=",a.Debt_foreign";
				query +=",a.Credit_foreign";
				query +=",a.Note";
				query +=",a.Date_Added";
				query +=",a.UserAdded";
				query +=",(SELECT User_name FROM Users";
					query +="WHERE    User_id = a.UserAdded)";
				query +=",a.UserPosting ,(SELECT  User_name  FROM Users";
						query +="WHERE User_id =a.UserPosting)";
				query +=",a.Oper_id_fk";
				query += "from(SELECT  DaylyBody.Dayly_id_fk , Operations.Oper_name";
                query +=",iif(DaylyHaed.Oper_id_fk=6";
                query +=",(SELECT   TypeBill.Type_neme";
                   query +=" FROM   TypeBill INNER JOIN";
                         query +="SalesBillHead ON TypeBill.Type_id = SalesBillHead.Type_id_fk";
                   query +=" WHERE  SalesBillHead.Bill_id = DaylyHaed.Refer_id_fk)";
               query +=" ,iif(DaylyHaed.Oper_id_fk=7";
               query +=" ,(SELECT TypeBill.Type_neme";
                   query += "FROM  TypeBill INNER JOIN";
                   query +=" ReturnSalesBillHead ON TypeBill.Type_id = ReturnSalesBillHead.Type_id_fk";
                    query +="WHERE  (ReturnSalesBillHead.Return_bill_id =DaylyHaed.Refer_id_fk ))";
               query += ",'')) as Bill_Type";

		query +=", DaylyHaed.Refer_id_fk";
		query +=", DaylyHaed.Date_dayly";
		query +=", Accounts.Acc_name";
		query +=", Currencys.Curr_name";
		query +=", AccCurrency.Acc_id_fk";
		query +=", DaylyBody.Debt_local";
		query +=", DaylyBody.Credit_local";
		query +=", DaylyBody.Debt_foreign";
		query +=", DaylyBody.Credit_foreign";
		//  ---البيان---
         query += " ,isnull(iif(DaylyHaed.Oper_id_fk=2";
                             //   ---اذا كان سند قبض---
                      query +="  ,(SELECT   top 1     Note";
                          query +="  FROM  SupportCatchBody";
                           query +=" WHERE  ";      
                           query +=" (Support_id_fk = DaylyHaed.Refer_id_fk) ";
                           query +=" AND (AccCurr_id_fk = (DaylyBody.AccCurr_id_fk))) ";
                       query +=" ,iif(DaylyHaed.Oper_id_fk=3";
                               // ---اذا كان سند صرف---
                      query +="  ,(SELECT   top 1     Note";
                           query +=" FROM    SupportExchangBody";
                           query +=" WHERE";        
                           query +=" (Support_id_fk = DaylyHaed.Refer_id_fk) ";
                          query +="  AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk)) ";
                        query +=",iif(DaylyHaed.Oper_id_fk=6";
                             //   ---اذا كان فاتورة مبيعات ---
                       query +=" ,(SELECT   top 1     Note";
                          query +="  FROM  SalesBillHead";
                           query +=" WHERE  (Bill_id = DaylyHaed.Refer_id_fk))";

                        query +=",iif(DaylyHaed.Oper_id_fk=7";
                                            //---اذا كان مردود مبيعات ---
                       query +=" ,(SELECT   top 1     Note";
                            query +="FROM  ReturnSalesBillHead";
                           query +=" WHERE    (Return_bill_id = DaylyHaed.Refer_id_fk))";

                       query +=" ,iif(DaylyHaed.Oper_id_fk=0";
                                          //  ---اذا كان قيد افتتاحي ---
                      query +="  ,(SELECT   top 1     Note";
                           query += "FROM   DaylyBody";
                            query +="WHERE ";       
                           query +=" (Dayly_id_fk = DaylyHaed.Refer_id_fk)";
                             query +="AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk))";

                       query +=" ,iif(DaylyHaed.Oper_id_fk=1";
                                           
                        query +=",(SELECT  top 1      Note";
                            query +="FROM  EntriesBody";
                           query +=" WHERE ";      
                            query +=" (Entry_id_fk = DaylyHaed.Refer_id_fk)";
                            query += " AND (AccCurr_id_fk =DaylyBody.AccCurr_id_fk )) ";
                       query +=" ,'')))))),'') as Note";

						// ---التاريخ---
          query +=" ,isnull(iif(DaylyHaed.Oper_id_fk=2";
                             //   ---اذا كان سند قبض---
							
                        query +=",(SELECT        Date_support_catch";
								query +="FROM    SupportCatchHead";
								query +="WHERE        Support_id = DaylyHaed.Refer_id_fk)"; 
                       query +=" ,iif(DaylyHaed.Oper_id_fk=3";
                               // ---اذا كان سند صرف---
                       query +=" ,( SELECT        Date_support_exchang";
								query +="FROM            SupportExchangHead";
								query +="WHERE        Support_id = DaylyHaed.Refer_id_fk)"; 

                       query +=" ,iif(DaylyHaed.Oper_id_fk=6";
                                //---اذا كان فاتورة مبيعات ---
                       query +=" ,(SELECT        Date_salesbill";
							query +="	FROM            SalesBillHead";
								query +="WHERE        Bill_id = DaylyHaed.Refer_id_fk)";

                        query +=",iif(DaylyHaed.Oper_id_fk=7";
                                       //     ---اذا كان مردود مبيعات ---
                      query +="  ,(SELECT        Date_return_salesBill";
								query +="FROM            ReturnSalesBillHead";
								query +="WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)";

                        query +=",iif(DaylyHaed.Oper_id_fk=0"
                                       //     ---اذا كان قيد افتتاحي ---
                      query +="  ,( SELECT   top 1     Date_Balance_open";
								query +="	FROM            BalanceOpen)";

                        query +=",iif(DaylyHaed.Oper_id_fk=1";
                                           
                        query +=",( SELECT        Date_entry";
							query +="	FROM            EntriesHead";
							query +="	WHERE        Entry_id = DaylyHaed.Refer_id_fk) ";
                       query +=" ,'')))))),'') as Date_Added";
						
					//	 ---مدخل السجل---
           query +=",isnull(iif(DaylyHaed.Oper_id_fk=2";
                             //   ---اذا كان سند قبض---
							
                      query +="  ,(SELECT    top 1    BoxUser.User_id_fk";
                      query +="FROM   SupportCatchHead INNER JOIN";
                         query +="BoxUser ON SupportCatchHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN";
                        query +=" Users ON BoxUser.User_id_fk = Users.User_id";
							query +="	WHERE       SupportCatchHead.Support_id = DaylyHaed.Refer_id_fk) ";
                       query +=" ,iif(DaylyHaed.Oper_id_fk=3";
                              //  ---اذا كان سند صرف---
                       query +=" ,( SELECT   top 1   BoxUser.User_id_fk";
						query +="FROM            SupportExchangHead INNER JOIN";
												query +=" BoxUser ON SupportExchangHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN";
												query +=" Users ON BoxUser.User_id_fk = Users.User_id";
						query +="WHERE   SupportExchangHead.Support_id = DaylyHaed.Refer_id_fk)"; 

                        query +=",iif(DaylyHaed.Oper_id_fk=6";
                              //  ---اذا كان فاتورة مبيعات ---
                       query +=" ,(SELECT  top 1     BoxUser.User_id_fk";
						query +="FROM   SalesBillHead INNER JOIN";
												query +=" BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN";
												query +=" Users ON BoxUser.User_id_fk = Users.User_id";
								query +="WHERE Bill_id = DaylyHaed.Refer_id_fk)";

                        query +=",iif(DaylyHaed.Oper_id_fk=7";
                                         //   ---اذا كان مردود مبيعات ---
                      query +="  ,(SELECT    top 1    BoxUser.User_id_fk";
					query +="	FROM            ReturnSalesBillHead INNER JOIN";
												query +=" BoxUser ON ReturnSalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN";
												 query +="Users ON BoxUser.User_id_fk = Users.User_id";
								query +="WHERE   Return_bill_id =  DaylyHaed.Refer_id_fk)";

                    query +=" ,iif(DaylyHaed.Oper_id_fk=0";
                                           // ---اذا كان قيد افتتاحي ---
                       query +=" ,( SELECT  top 1   BalanceOpen.User_id_fk";
								query +="FROM  BalanceOpen INNER JOIN";
						query +=" Users ON BalanceOpen.User_id_fk = Users.User_id)";

                       query +=" ,iif(DaylyHaed.Oper_id_fk=1";
                                           
                        query +=",( SELECT   top 1      DaylyHaed.User_id_fk";
						query +="FROM DaylyHaed INNER JOIN";
												query +=" Users ON DaylyHaed.User_id_fk = Users.User_id";
												query +=" where DaylyHaed.Dayly_id= DaylyHaed.Refer_id_fk) ";
                       query +=" ,'')))))),'') as UserAdded";

						//مرحل السجل
						query +=",(SELECT      User_id";
								query +="FROM    Users";
							query +="	WHERE        User_id = DaylyHaed.User_id_fk) as UserPosting";
							query +="	,DaylyHaed.Oper_id_fk";

	                    query +="   FROM  DaylyHaed INNER JOIN";
                        query +=" DaylyBody ON DaylyHaed.Dayly_id = DaylyBody.Dayly_id_fk INNER JOIN";
                        query +=" AccCurrency ON DaylyBody.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN";
                        query +=" Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN";
                       query +="  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN";
                        query +=" Operations ON DaylyHaed.Oper_id_fk = Operations.Oper_id ) a";
						  query +="where (a.Date_dayly between" +con.AddApostropheToString(DateBgin);
                        query +="  and" +con.AddApostropheToString(DateEnd);
                         query +=" or a.Date_Added ";
                         query +=" between" +con.AddApostropheToString(DateBgin); 
                         query +=" and "+con.AddApostropheToString(DateEnd) );
						query += " group by";
						 query +=" a.Dayly_id_fk";
						 query +=" ,a.Oper_name";
						query +="  ,a.Bill_Type";
						 query +=" ,a.Refer_id_fk";
						  query +=",a.Date_dayly";
						 query +=" ,a.Acc_id_fk";
						  query +=",a.Acc_name";
						query +="  ,a.Curr_name";
						  query +=",a.Debt_local";
						  query +=",a.Credit_local";
						  query +=",a.Debt_foreign";
						 query +=" ,a.Credit_foreign";
						 query +=" ,a.Note";
						query +="  ,a.Date_Added";
						query +="  ,a.UserAdded";
						 query +=" ,a.UserPosting";
						 query += ",a.Oper_id_fk";
            */
            #endregion

        }
        void FillData()
        {
            DataTable DTFill = new DataTable();
            DGVBody.Rows.Clear();
          
            DTFill = GetReport(
                dateTimePicker1.Value.ToShortDateString()
               , dateTimePicker2.Value.ToShortDateString()
              );

            if (DTFill != null && DTFill.Rows.Count > 0)
            {
              
                ShowLabelNotFound(false);
                for (int i = 0; i < DTFill.Rows.Count; i++)
                {
                    DGVBody.Rows.Add
                        (

                          DTFill.Rows[i][0].ToString()
                         , DTFill.Rows[i][1].ToString()
                         , DTFill.Rows[i][2].ToString()
                         , DTFill.Rows[i][3].ToString()
                         , Convert.ToDateTime(DTFill.Rows[i][4]).ToShortDateString()
                         , DTFill.Rows[i][5].ToString()
                         , DTFill.Rows[i][6].ToString()
                         , DTFill.Rows[i][7].ToString()
                          , DTFill.Rows[i][8].ToString()
                           , DTFill.Rows[i][9].ToString()
                            , DTFill.Rows[i][10].ToString()
                             , DTFill.Rows[i][11].ToString()
                              , DTFill.Rows[i][12].ToString()
                         , Convert.ToDateTime(DTFill.Rows[i][13]).ToShortDateString()
                            , DTFill.Rows[i][14].ToString()
                              , DTFill.Rows[i][15].ToString()
                                , DTFill.Rows[i][16].ToString()
                                  , DTFill.Rows[i][17].ToString()


                        );




                }
            }
            else
            { ShowLabelNotFound(true); MessageBox.Show("فارغ"); }


        }
        void ShowLabelNotFound(bool State)
        {

            panel5.Visible = State;
            labelNotFound.Visible = State;

        }

        #endregion

     



        private void txtCustId_KeyDown(object sender, KeyEventArgs e)
        {
         
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
          
               // MessageBox.Show(dateTimePicker1.Value.ToShortDateString());
                try { FillData(); } catch (Exception ee) { MessageBox.Show(ee.ToString()); }
            
               
            
        }


        private void txtCustId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
           Reports.TrailBalance item = new Reports.TrailBalance();
            item.Refresh();
          
           
            item.SetParameterValue("@B", this.dateTimePicker1.Value.ToShortDateString());
            item.SetParameterValue("@E", this.dateTimePicker2.Value.ToShortDateString());
            Reports.frm_Reports f = new Reports.frm_Reports();
            f.crystalReportViewer1.ReportSource = item;
            f.Refresh();
            f.ShowDialog();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

       
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            this.pictureBox1.BackColor= Color.Red;
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            this.pictureBox1.BackColor= System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));

        }

        private void DGVBody_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
