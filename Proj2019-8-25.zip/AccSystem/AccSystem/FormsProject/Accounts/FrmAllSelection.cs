﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class FrmAllSelection : Form
    {
        public FrmAllSelection()
        {
            InitializeComponent();
           // cmbBoxIf.ValueMember("");

        }


        #region المتغيرات
        ClassesProject.ConnectionDB con = new ClassesProject.ConnectionDB();
        DataTable DT;
        Dictionary <string,string> TypeSelect = new Dictionary<string,string>();
        #endregion
        void FillTypeSelect()
        {
            TypeSelect.Clear();
            if (chkAll.Checked == true)
                TypeSelect.Add("chkAll","-1");
            if(chkBalanceOpen.Checked==true)
                TypeSelect.Add("chkBalanceOpen","0");
            if(chkEntry.Checked==true)
                TypeSelect.Add("chkEntry","1");
            if (chkSupportCatch.Checked == true)
                TypeSelect.Add("chkSupportCatch", "2");
            if (chkSupportExching.Checked == true)
                TypeSelect.Add("chkSupportExching", "3");
            if (chkSales.Checked==true)
                TypeSelect.Add("chkSales","6");
            if(chkSalesReturn.Checked==true)
                TypeSelect.Add("chkSalesReturn","7");
           // MessageBox.Show(TypeSelect.Count.ToString(), "TypeSelectCount");
          
        }
        DataTable GetReport(string DateBgin
            , string DateEnd
            , string Note = ""
            ,string UserAdded="-1"
            ,string Acc_id_fkBgin="-1"
            , string Acc_id_fkEnd="-1"
            )
        {

            //MessageBox.Show(DateBgin, "DateBgin");
            //MessageBox.Show(DateEnd, "DateEnd");
            //MessageBox.Show(Note, "Note");
            //MessageBox.Show(UserAdded, "UserAdded");
            //MessageBox.Show(Acc_id_fkBgin, "Acc_id_fkBgin");
            //MessageBox.Show(Acc_id_fkEnd, "Acc_id_fkEnd");
            if (DT != null)
                DT = null;
            DT = new DataTable();
            //   MessageBox.Show(Cust_id);
            FillTypeSelect();
            string
           query = "   select        ";
            query += "   a.Dayly_id_fk  ";
            query += "   ,a.Oper_name  ";
            query += "   ,a.Bill_Type ";
            query += "   ,a.Refer_id_fk  ";
            query += "  ,a.Date_dayly  ";
            query += "   ,a.Acc_id_fk  ";
            query += " ,a.Acc_name  ";
            query += "   ,a.Curr_name  ";
            query += " ,a.Debt_local  ";
            query += "  ,a.Credit_local   ";
            query += "   ,a.Debt_foreign ";
            query += "   ,a.Credit_foreign  ";
            query += "  ,a.Note  ";
            query += "  ,a.Date_Added  ";
            query += "  ,a.UserAdded  ";
           
            query += "   ,(SELECT    User_name   ";
            query += " FROM     Users   ";
            query += "  WHERE        User_id = a.UserAdded)   ";

            query += "   ,a.UserPosting  ";

            query += "   ,(SELECT        User_name ";
            query += " FROM            Users  ";
            query += " WHERE        User_id =a.UserPosting)  ";

            query += "   ,a.Oper_id_fk  ";

            query += "  from ( ";
            ////////////////////////////////////////

            query += "  SELECT     ";
            query += "    DaylyBody.Dayly_id_fk ";
            query += "  , Operations.Oper_name  ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=6  ";
            query += "  ,(SELECT   TypeBill.Type_neme ";
            query += "  FROM            TypeBill INNER JOIN  ";
            query += "   SalesBillHead ON TypeBill.Type_id = SalesBillHead.Type_id_fk  ";
            query += "   WHERE        SalesBillHead.Bill_id = DaylyHaed.Refer_id_fk) ";

            query += "  ,iif(DaylyHaed.Oper_id_fk=7  ";
            query += " ,(SELECT        TypeBill.Type_neme  ";
            query += "  FROM            TypeBill INNER JOIN  ";
            query += " ReturnSalesBillHead ON TypeBill.Type_id = ReturnSalesBillHead.Type_id_fk  ";
            query += "   WHERE        (ReturnSalesBillHead.Return_bill_id =DaylyHaed.Refer_id_fk ))  ";
            query += "   ,'')) as Bill_Type ";
          ///////////////////////////////////////
            
            query += "  , DaylyHaed.Refer_id_fk   ";
            query += "  , DaylyHaed.Date_dayly  ";
            query += " , Accounts.Acc_name   ";
            query += " , Currencys.Curr_name  ";
            query += "   , AccCurrency.Acc_id_fk  ";
            query += " , DaylyBody.Debt_local  ";
            query += "   , DaylyBody.Credit_local  ";
            query += "   , DaylyBody.Debt_foreign  ";
            query += "  , DaylyBody.Credit_foreign  ";
         ///////////////////////////////////////////////////
            query += "  ,isnull(iif(DaylyHaed.Oper_id_fk=2   ";
           // query += "  ---اذا كان سند قبض---  ";
            query += "   ,(SELECT   top 1     Note   ";
            query += "  FROM            SupportCatchBody  ";
            query += "  WHERE  ";
            query += "   (Support_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += "  AND (AccCurr_id_fk = (DaylyBody.AccCurr_id_fk)))   ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=3  ";
           // query += "  ---اذا كان سند صرف---  ";
            query += "     ,(SELECT   top 1     Note ";
            query += "   FROM            SupportExchangBody ";
            query += "  WHERE  ";
            query += "   (Support_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += "  AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk))  ";
            query += " ,iif(DaylyHaed.Oper_id_fk=6  ";
         //   query += " ---اذا كان فاتورة مبيعات ---   ";
            query += " ,(SELECT   top 1     Note  ";
            query += "   FROM            SalesBillHead  ";
            query += "   WHERE        (Bill_id = DaylyHaed.Refer_id_fk))  ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=7  ";
          //  query += " ---اذا كان مردود مبيعات ---  ";

            query += "   ,(SELECT   top 1     Note  ";
            query += "   FROM            ReturnSalesBillHead  ";
            query += " WHERE        (Return_bill_id = DaylyHaed.Refer_id_fk))   ";
          
            query += "  ,iif(DaylyHaed.Oper_id_fk=0  ";
          //  query += "  ---اذا كان قيد افتتاحي ---   ";
            query += "  ,(SELECT   top 1     Note  ";
            query += " FROM            DaylyBody  ";
            query += "  WHERE ";
            query += "  (Dayly_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += " AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk))  ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=1  ";
            query += "    ,(SELECT  top 1      Note  ";
            query += " FROM     EntriesBody  ";
            query += "  WHERE    ";
            query += " (Entry_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += " AND (AccCurr_id_fk =DaylyBody.AccCurr_id_fk ))   ";
            query += " ,'')))))),'') as Note  ";
            /////////////////////////////////////////////////////////

            query += "   ,isnull(iif(DaylyHaed.Oper_id_fk=2 ";
          //  query += "  ---اذا كان سند قبض---  ";
            query += "   ,(SELECT        Date_support_catch  ";
            query += "  FROM            SupportCatchHead  ";
            query += "    WHERE        Support_id = DaylyHaed.Refer_id_fk)   ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=3  ";
      //      query += "   ---اذا كان سند صرف---  ";
            query += "     ,( SELECT        Date_support_exchang  ";
            query += "   FROM            SupportExchangHead ";
            query += "   WHERE        Support_id = DaylyHaed.Refer_id_fk)   ";
            query += "    ,iif(DaylyHaed.Oper_id_fk=6  ";
          //  query += "  ---اذا كان فاتورة مبيعات ---  ";
            query += "     ,(SELECT        Date_salesbill  ";
            query += "   FROM            SalesBillHead  ";
            query += "  WHERE        Bill_id = DaylyHaed.Refer_id_fk)   ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=7  ";
            //  query += "  ---اذا كان مردود مبيعات --- ";
            query += "   ,(SELECT        Date_return_salesBill   ";
            query += "  FROM            ReturnSalesBillHead   ";
            query += "  WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)  ";
           
            query += "  ,iif(DaylyHaed.Oper_id_fk=0   ";
        //    query += "   ---اذا كان قيد افتتاحي ---  ";
            query += "  ,( SELECT   top 1     Date_Balance_open  ";
            query += "   FROM            BalanceOpen)  ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=1  ";
            query += "  ,( SELECT        Date_entry  ";
            query += "  FROM            EntriesHead   ";
            query += "  WHERE        Entry_id = DaylyHaed.Refer_id_fk)   ";
            query += "  ,'')))))),'') as Date_Added   ";
            //////////////////////////////////////////////
          //  query += "   ---مدخل السجل---   ";
            query += "  ,isnull(iif(DaylyHaed.Oper_id_fk=2  ";
        //    query += "   ---اذا كان سند قبض---  ";
            query += "  ,(SELECT    top 1    BoxUser.User_id_fk   ";
            query += "  FROM            SupportCatchHead INNER JOIN  ";
            query += "   BoxUser ON SupportCatchHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN  ";
            query += "   Users ON BoxUser.User_id_fk = Users.User_id  ";
            query += " 	WHERE       SupportCatchHead.Support_id = DaylyHaed.Refer_id_fk)    ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=3 ";
         //   query += "   ---اذا كان سند صرف---  ";
            query += "   ,( SELECT   top 1   BoxUser.User_id_fk  ";
            query += "  FROM            SupportExchangHead INNER JOIN  ";
            query += "  BoxUser ON SupportExchangHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN  ";
            query += "   Users ON BoxUser.User_id_fk = Users.User_id  ";
            query += "  WHERE        SupportExchangHead.Support_id = DaylyHaed.Refer_id_fk)   ";
            query += "  ,iif(DaylyHaed.Oper_id_fk=6   ";
         //   query += "  ---اذا كان فاتورة مبيعات ---  ";
            query += "  ,(SELECT  top 1     BoxUser.User_id_fk   ";
            query += "    FROM            SalesBillHead INNER JOIN  ";
            query += "  BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN   ";
            query += "   Users ON BoxUser.User_id_fk = Users.User_id  ";
            query += "   WHERE        Bill_id = DaylyHaed.Refer_id_fk)  ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=7   ";
        //    query += "    ---اذا كان مردود مبيعات --- ";
            query += "  ,(SELECT    top 1    BoxUser.User_id_fk  ";
            query += "   FROM            ReturnSalesBillHead INNER JOIN  ";
            query += " BoxUser ON ReturnSalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN   ";
            query += "  Users ON BoxUser.User_id_fk = Users.User_id  ";
           
            query += "  WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)   ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=0  ";
          //  query += "  ---اذا كان قيد افتتاحي ---  ";
            query += "  ,( SELECT  top 1   BalanceOpen.User_id_fk   ";
            query += "  FROM            BalanceOpen INNER JOIN    ";
          
            query += "    Users ON BalanceOpen.User_id_fk = Users.User_id)  ";
            query += "   ,iif(DaylyHaed.Oper_id_fk=1  ";
            query += "   ,( SELECT   top 1      DaylyHaed.User_id_fk  ";
            query += "   FROM            DaylyHaed INNER JOIN  ";
            query += "  Users ON DaylyHaed.User_id_fk = Users.User_id  ";
            query += "   where DaylyHaed.Dayly_id= DaylyHaed.Refer_id_fk)   ";
            query += "    ,'')))))),'') as UserAdded  ";
            //////////////////////
         
         //   query += "  --مرحل السجل-   ";
            query += "   ,(SELECT      User_id  ";
            query += "   FROM            Users   ";
            query += "   WHERE        User_id = DaylyHaed.User_id_fk) as UserPosting   ";
            query += "  ,DaylyHaed.Oper_id_fk   ";
            query += " FROM            DaylyHaed INNER JOIN   ";
            query += "   DaylyBody ON DaylyHaed.Dayly_id = DaylyBody.Dayly_id_fk INNER JOIN  ";
            query += "   AccCurrency ON DaylyBody.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN  ";
            query += "   Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN  ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN  ";
            query += "   Operations ON DaylyHaed.Oper_id_fk = Operations.Oper_id   ";
            query += "   )  ";
           
            query += "  a  ";
            query += "  where (a.Date_dayly between   " + con.AddApostropheToString(DateBgin);
            query += "  and    " + con.AddApostropheToString(DateEnd);
            query += " or a.Date_Added between " + con.AddApostropheToString(DateBgin);
            query += " and " + con.AddApostropheToString(DateEnd) + " ) ";


            query += " and a.Note like '%" + Note + "%'";

            if (UserAdded != "-1" && UserAdded != string.Empty)
                query += " and a.UserAdded=   " + UserAdded;

            if (Acc_id_fkBgin != "-1" && Acc_id_fkEnd != "-1")
                query += "   and a.Acc_id_fk between  " + Acc_id_fkBgin + " and " + Acc_id_fkEnd;


            if (TypeSelect.Count > 0 && !TypeSelect.ContainsKey("chkAll"))
            {
                if (TypeSelect.Count >= 2 && !TypeSelect.ContainsKey("chkAll"))
                {
                    query += "   and  a.Oper_id_fk in( " + (TypeSelect[TypeSelect.Keys.ElementAt(0)]).ToString();
                    int i = 1;
                    while (i < TypeSelect.Count)
                    {
                        query += "," + (TypeSelect[TypeSelect.Keys.ElementAt(i)]).ToString();
                        i++;
                    }
                    query += " ) ";

                }
                else if (TypeSelect.Count == 1 && !TypeSelect.ContainsKey("chkAll"))
                {
                    query += "   and  a.Oper_id_fk in( " + (TypeSelect[TypeSelect.Keys.ElementAt(0)]).ToString() + ")";
                }


            }

            query += "   group by  ";
            query += "   a.Dayly_id_fk ";
            query += "  ,a.Oper_name  ";
            query += "  ,a.Bill_Type  ";
            query += "  ,a.Refer_id_fk  ";
            query += "  ,a.Date_dayly ";
            query += "  ,a.Acc_id_fk  ";
            query += "  ,a.Acc_name  ";
            query += "  ,a.Curr_name  ";
            query += "  ,a.Debt_local ";
            query += "  ,a.Credit_local  ";
            query += "  ,a.Debt_foreign  ";
            query += "  ,a.Credit_foreign  ";
            query += "  ,a.Note  ";
            query += "  ,a.Date_Added  ";
            query += "  ,a.UserAdded  ";
            query += "  ,a.UserPosting  ";
            query += "  ,a.Oper_id_fk  ";



          //  MessageBox.Show(query);

            con.OpenConnetion();
            try { DT = con.Query(query, true); } catch (Exception e) { MessageBox.Show(e.ToString()); }

            con.CloseConnetion();

            return DT;

            #region الاستعلام مع الشروط
            /*
                				select 
				a.Dayly_id_fk
				,a.Oper_name
				,a.Bill_Type
				,a.Refer_id_fk
				,a.Date_dayly
				,a.Acc_id_fk
				,a.Acc_name
				,a.Curr_name
				,a.Debt_local
				,a.Credit_local
				,a.Debt_foreign
				,a.Credit_foreign
				,a.Note
				,a.Date_Added
				,a.UserAdded
				,(SELECT        User_name
						FROM            Users
						WHERE        User_id = a.UserAdded)
				,a.UserPosting
				,(SELECT        User_name
						FROM            Users
						WHERE        User_id =a.UserPosting)
				,a.Oper_id_fk
				 from(
		SELECT        
		  DaylyBody.Dayly_id_fk
		, Operations.Oper_name

		 ,iif(DaylyHaed.Oper_id_fk=6
                ,(SELECT        TypeBill.Type_neme
                    FROM            TypeBill INNER JOIN
                                             SalesBillHead ON TypeBill.Type_id = SalesBillHead.Type_id_fk
                    WHERE        SalesBillHead.Bill_id = DaylyHaed.Refer_id_fk)
                ,iif(DaylyHaed.Oper_id_fk=7
                ,(SELECT        TypeBill.Type_neme
                    FROM            TypeBill INNER JOIN
                                             ReturnSalesBillHead ON TypeBill.Type_id = ReturnSalesBillHead.Type_id_fk
                    WHERE        (ReturnSalesBillHead.Return_bill_id =DaylyHaed.Refer_id_fk ))
                ,'')) as Bill_Type

		, DaylyHaed.Refer_id_fk
		, DaylyHaed.Date_dayly
		, Accounts.Acc_name
		, Currencys.Curr_name
		, AccCurrency.Acc_id_fk
		, DaylyBody.Debt_local
		, DaylyBody.Credit_local
		, DaylyBody.Debt_foreign
		, DaylyBody.Credit_foreign
		  ---البيان---
           ,isnull(iif(DaylyHaed.Oper_id_fk=2
                                ---اذا كان سند قبض---
                        ,(SELECT   top 1     Note
                            FROM            SupportCatchBody
                            WHERE        
                            (Support_id_fk = DaylyHaed.Refer_id_fk) 
                            AND (AccCurr_id_fk = (DaylyBody.AccCurr_id_fk))) 
                        ,iif(DaylyHaed.Oper_id_fk=3
                                ---اذا كان سند صرف---
                        ,(SELECT   top 1     Note
                            FROM            SupportExchangBody
                            WHERE        
                            (Support_id_fk = DaylyHaed.Refer_id_fk) 
                            AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk)) 
                        ,iif(DaylyHaed.Oper_id_fk=6
                                ---اذا كان فاتورة مبيعات ---
                        ,(SELECT   top 1     Note
                            FROM            SalesBillHead
                            WHERE        (Bill_id = DaylyHaed.Refer_id_fk))

                        ,iif(DaylyHaed.Oper_id_fk=7
                                            ---اذا كان مردود مبيعات ---
                        ,(SELECT   top 1     Note
                            FROM            ReturnSalesBillHead
                            WHERE        (Return_bill_id = DaylyHaed.Refer_id_fk))

                        ,iif(DaylyHaed.Oper_id_fk=0
                                            ---اذا كان قيد افتتاحي ---
                        ,(SELECT   top 1     Note
                            FROM            DaylyBody
                            WHERE        
                            (Dayly_id_fk = DaylyHaed.Refer_id_fk)
                             AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk))

                        ,iif(DaylyHaed.Oper_id_fk=1
                                           
                        ,(SELECT  top 1      Note
                            FROM            EntriesBody
                            WHERE       
                             (Entry_id_fk = DaylyHaed.Refer_id_fk)
                              AND (AccCurr_id_fk =DaylyBody.AccCurr_id_fk )) 
                        ,'')))))),'') as Note

						 ---التاريخ---
           ,isnull(iif(DaylyHaed.Oper_id_fk=2
                                ---اذا كان سند قبض---
							
                        ,(SELECT        Date_support_catch
								FROM            SupportCatchHead
								WHERE        Support_id = DaylyHaed.Refer_id_fk) 
                        ,iif(DaylyHaed.Oper_id_fk=3
                                ---اذا كان سند صرف---
                        ,( SELECT        Date_support_exchang
								FROM            SupportExchangHead
								WHERE        Support_id = DaylyHaed.Refer_id_fk) 

                        ,iif(DaylyHaed.Oper_id_fk=6
                                ---اذا كان فاتورة مبيعات ---
                        ,(SELECT        Date_salesbill
								FROM            SalesBillHead
								WHERE        Bill_id = DaylyHaed.Refer_id_fk)

                        ,iif(DaylyHaed.Oper_id_fk=7
                                            ---اذا كان مردود مبيعات ---
                        ,(SELECT        Date_return_salesBill
								FROM            ReturnSalesBillHead
								WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)

                        ,iif(DaylyHaed.Oper_id_fk=0
                                            ---اذا كان قيد افتتاحي ---
                        ,( SELECT   top 1     Date_Balance_open
									FROM            BalanceOpen)

                        ,iif(DaylyHaed.Oper_id_fk=1
                                           
                        ,( SELECT        Date_entry
								FROM            EntriesHead
								WHERE        Entry_id = DaylyHaed.Refer_id_fk) 
                        ,'')))))),'') as Date_Added
						
						 ---مدخل السجل---
           ,isnull(iif(DaylyHaed.Oper_id_fk=2
                                ---اذا كان سند قبض---
							
                        ,(SELECT    top 1    BoxUser.User_id_fk
        FROM            SupportCatchHead INNER JOIN
                         BoxUser ON SupportCatchHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
                         Users ON BoxUser.User_id_fk = Users.User_id
								WHERE       SupportCatchHead.Support_id = DaylyHaed.Refer_id_fk) 
                        ,iif(DaylyHaed.Oper_id_fk=3
                                ---اذا كان سند صرف---
                        ,( SELECT   top 1   BoxUser.User_id_fk
						FROM            SupportExchangHead INNER JOIN
												 BoxUser ON SupportExchangHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
												 Users ON BoxUser.User_id_fk = Users.User_id
						WHERE        SupportExchangHead.Support_id = DaylyHaed.Refer_id_fk) 

                        ,iif(DaylyHaed.Oper_id_fk=6
                                ---اذا كان فاتورة مبيعات ---
                        ,(SELECT  top 1     BoxUser.User_id_fk
						FROM            SalesBillHead INNER JOIN
												 BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
												 Users ON BoxUser.User_id_fk = Users.User_id
								WHERE        Bill_id = DaylyHaed.Refer_id_fk)

                        ,iif(DaylyHaed.Oper_id_fk=7
                                            ---اذا كان مردود مبيعات ---
                        ,(SELECT    top 1    BoxUser.User_id_fk
						FROM            ReturnSalesBillHead INNER JOIN
												 BoxUser ON ReturnSalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
												 Users ON BoxUser.User_id_fk = Users.User_id
								WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)

                        ,iif(DaylyHaed.Oper_id_fk=0
                                            ---اذا كان قيد افتتاحي ---
                        ,( SELECT  top 1   BalanceOpen.User_id_fk
								FROM            BalanceOpen INNER JOIN
														 Users ON BalanceOpen.User_id_fk = Users.User_id)

                        ,iif(DaylyHaed.Oper_id_fk=1
                                           
                        ,( SELECT   top 1      DaylyHaed.User_id_fk
						FROM            DaylyHaed INNER JOIN
												 Users ON DaylyHaed.User_id_fk = Users.User_id
												 where DaylyHaed.Dayly_id= DaylyHaed.Refer_id_fk) 
                        ,'')))))),'') as UserAdded

						--مرحل السجل-
						,(SELECT      User_id
								FROM            Users
								WHERE        User_id = DaylyHaed.User_id_fk) as UserPosting
								,DaylyHaed.Oper_id_fk

	FROM            DaylyHaed INNER JOIN
                         DaylyBody ON DaylyHaed.Dayly_id = DaylyBody.Dayly_id_fk INNER JOIN
                         AccCurrency ON DaylyBody.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                         Operations ON DaylyHaed.Oper_id_fk = Operations.Oper_id 
						 
						 )
						  a 
						  where (a.Date_dayly between '2019-4-4'and '2019-9-9' or a.Date_Added between '2019-1-1' and '2019-9-9' )
						  
						  
						    and  a.Oper_id_fk in(1,0)
							and a.Acc_id_fk between 1121001 and 2222222
							and a.UserAdded=1
							and a.Note like '%%'
							
						  group by
						   a.Dayly_id_fk
						  ,a.Oper_name
						  ,a.Bill_Type
						  ,a.Refer_id_fk
						  ,a.Date_dayly
						  ,a.Acc_id_fk
						  ,a.Acc_name
						  ,a.Curr_name
						  ,a.Debt_local
						  ,a.Credit_local
						  ,a.Debt_foreign
						  ,a.Credit_foreign
						  ,a.Note
						  ,a.Date_Added
						  ,a.UserAdded
						  ,a.UserPosting
						  ,a.Oper_id_fk


            */
            #endregion
        }

        void FillData()
        {
            DataTable DTFill = new DataTable();
            DGVBody.Rows.Clear();
            DTFill = GetReport(
                dateTimePicker1.Value.ToShortDateString().ToString()
               , dateTimePicker2.Value.ToShortDateString().ToString()
               , txtNote.Text != string.Empty ? txtNote.Text : ""
               , txtUserIdAdded.Text != string.Empty ? txtUserIdAdded.Text : "-1"
               , txtAccIdBign.Text != string.Empty ? txtAccIdBign.Text : "-1"
               , txtAccIdEnd.Text != string.Empty ? txtAccIdEnd.Text : txtAccIdBign.Text != string.Empty ? txtAccIdBign.Text : "-1"
                );
            if (DTFill != null && DTFill.Rows.Count > 0)
            {
                ShowLabelNotFound(false);
                for (int i = 0; i < DTFill.Rows.Count; i++)
                {
                    DGVBody.Rows.Add
                        (

                          DTFill.Rows[i][0].ToString() //Dayly_id_fk
                         , DTFill.Rows[i][1].ToString() //Oper_name
                         , DTFill.Rows[i][2].ToString() //Bill_Type
                         , DTFill.Rows[i][3].ToString() //Refer_id_fk
                         ,Convert.ToDateTime( DTFill.Rows[i][4].ToString()).ToShortDateString() //Date_dayly
                         , DTFill.Rows[i][5].ToString() //Acc_id_fk
                         , DTFill.Rows[i][6].ToString() //Acc_name
                         , DTFill.Rows[i][7].ToString() //Curr_name
                         , DTFill.Rows[i][8].ToString() //Debt_local
                         , DTFill.Rows[i][9].ToString() //Credit_local
                         , DTFill.Rows[i][10].ToString() //Debt_foreign
                         , DTFill.Rows[i][11].ToString() //Credit_foreign
                         , DTFill.Rows[i][12].ToString() //Note
                         , Convert.ToDateTime(DTFill.Rows[i][13].ToString()).ToShortDateString() //Date_Added 
                         , DTFill.Rows[i][14].ToString() + " - " + DTFill.Rows[i][15].ToString() //UserAdded + User_name
                         , DTFill.Rows[i][16].ToString() + " - "+ DTFill.Rows[i][17].ToString() // UserPosting + User_name

                          );
                }

                /*
                     Dayly_id_fk 0
                    Oper_name 1
                    Bill_Type 2
                    Refer_id_fk 3
                    Date_dayly 4
                    Acc_id_fk 5
                    Acc_name 6
                    Curr_name 7
                    Debt_local 8
                    Credit_local 9
                    Debt_foreign 10
                    Credit_foreign 11
                    Note 12
                    Date_Added  13
                    UserAdded 14 
                    User_name  15 
                    UserPosting 16
                    User_name 17 
                    Oper_id_fk 18 
                */

            }
            else
                ShowLabelNotFound(true);

        }
        void ShowLabelNotFound(bool State)
        {

            panel5.Visible = State;
            labelNotFound.Visible = State;

        }

        #region اذا كان الاستعلام بدون اي شرط
        /*
                            select a.Dayly_id_fk,a.Oper_name,a.Bill_Type,a.Refer_id_fk,a.Date_dayly,a.Acc_id_fk,a.Acc_name,a.Curr_name,a.Debt_local,a.Credit_local,a.Debt_foreign,a.Credit_foreign,a.Note,a.Date_Added,a.UserAdded,a.UserPosting,a.Oper_id_fk from(
        SELECT        
          DaylyBody.Dayly_id_fk
        , Operations.Oper_name

         ,iif(DaylyHaed.Oper_id_fk=6
                ,(SELECT        TypeBill.Type_neme
                    FROM            TypeBill INNER JOIN
                                             SalesBillHead ON TypeBill.Type_id = SalesBillHead.Type_id_fk
                    WHERE        SalesBillHead.Bill_id = DaylyHaed.Refer_id_fk)
                ,iif(DaylyHaed.Oper_id_fk=7
                ,(SELECT        TypeBill.Type_neme
                    FROM            TypeBill INNER JOIN
                                             ReturnSalesBillHead ON TypeBill.Type_id = ReturnSalesBillHead.Type_id_fk
                    WHERE        (ReturnSalesBillHead.Return_bill_id =DaylyHaed.Refer_id_fk ))
                ,'')) as Bill_Type

        , DaylyHaed.Refer_id_fk
        , DaylyHaed.Date_dayly
        , Accounts.Acc_name
        , Currencys.Curr_name
        , AccCurrency.Acc_id_fk
        , DaylyBody.Debt_local
        , DaylyBody.Credit_local
        , DaylyBody.Debt_foreign
        , DaylyBody.Credit_foreign
          ---البيان---
           ,isnull(iif(DaylyHaed.Oper_id_fk=2
                                ---اذا كان سند قبض---
                        ,(SELECT   top 1     Note
                            FROM            SupportCatchBody
                            WHERE        
                            (Support_id_fk = DaylyHaed.Refer_id_fk) 
                            AND (AccCurr_id_fk = (DaylyBody.AccCurr_id_fk))) 
                        ,iif(DaylyHaed.Oper_id_fk=3
                                ---اذا كان سند صرف---
                        ,(SELECT   top 1     Note
                            FROM            SupportExchangBody
                            WHERE        
                            (Support_id_fk = DaylyHaed.Refer_id_fk) 
                            AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk)) 
                        ,iif(DaylyHaed.Oper_id_fk=6
                                ---اذا كان فاتورة مبيعات ---
                        ,(SELECT   top 1     Note
                            FROM            SalesBillHead
                            WHERE        (Bill_id = DaylyHaed.Refer_id_fk))

                        ,iif(DaylyHaed.Oper_id_fk=7
                                            ---اذا كان مردود مبيعات ---
                        ,(SELECT   top 1     Note
                            FROM            ReturnSalesBillHead
                            WHERE        (Return_bill_id = DaylyHaed.Refer_id_fk))

                        ,iif(DaylyHaed.Oper_id_fk=0
                                            ---اذا كان قيد افتتاحي ---
                        ,(SELECT   top 1     Note
                            FROM            DaylyBody
                            WHERE        
                            (Dayly_id_fk = DaylyHaed.Refer_id_fk)
                             AND (AccCurr_id_fk = DaylyBody.AccCurr_id_fk))

                        ,iif(DaylyHaed.Oper_id_fk=1

                        ,(SELECT  top 1      Note
                            FROM            EntriesBody
                            WHERE       
                             (Entry_id_fk = DaylyHaed.Refer_id_fk)
                              AND (AccCurr_id_fk =DaylyBody.AccCurr_id_fk )) 
                        ,'')))))),'') as Note

                         ---التاريخ---
           ,isnull(iif(DaylyHaed.Oper_id_fk=2
                                ---اذا كان سند قبض---

                        ,(SELECT        Date_support_catch
                                FROM            SupportCatchHead
                                WHERE        Support_id = DaylyHaed.Refer_id_fk) 
                        ,iif(DaylyHaed.Oper_id_fk=3
                                ---اذا كان سند صرف---
                        ,( SELECT        Date_support_exchang
                                FROM            SupportExchangHead
                                WHERE        Support_id = DaylyHaed.Refer_id_fk) 

                        ,iif(DaylyHaed.Oper_id_fk=6
                                ---اذا كان فاتورة مبيعات ---
                        ,(SELECT        Date_salesbill
                                FROM            SalesBillHead
                                WHERE        Bill_id = DaylyHaed.Refer_id_fk)

                        ,iif(DaylyHaed.Oper_id_fk=7
                                            ---اذا كان مردود مبيعات ---
                        ,(SELECT        Date_return_salesBill
                                FROM            ReturnSalesBillHead
                                WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)

                        ,iif(DaylyHaed.Oper_id_fk=0
                                            ---اذا كان قيد افتتاحي ---
                        ,( SELECT   top 1     Date_Balance_open
                                    FROM            BalanceOpen)

                        ,iif(DaylyHaed.Oper_id_fk=1

                        ,( SELECT        Date_entry
                                FROM            EntriesHead
                                WHERE        Entry_id = DaylyHaed.Refer_id_fk) 
                        ,'')))))),'') as Date_Added

                         ---مدخل السجل---
           ,isnull(iif(DaylyHaed.Oper_id_fk=2
                                ---اذا كان سند قبض---

                        ,(SELECT    top 1   convert(nvarchar, BoxUser.User_id_fk)+' - ' + Users.User_name
        FROM            SupportCatchHead INNER JOIN
                         BoxUser ON SupportCatchHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
                         Users ON BoxUser.User_id_fk = Users.User_id
                                WHERE       SupportCatchHead.Support_id = DaylyHaed.Refer_id_fk) 
                        ,iif(DaylyHaed.Oper_id_fk=3
                                ---اذا كان سند صرف---
                        ,( SELECT   top 1    convert(nvarchar, BoxUser.User_id_fk)+' - ' + Users.User_name
                        FROM            SupportExchangHead INNER JOIN
                                                 BoxUser ON SupportExchangHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
                                                 Users ON BoxUser.User_id_fk = Users.User_id
                        WHERE        SupportExchangHead.Support_id = DaylyHaed.Refer_id_fk) 

                        ,iif(DaylyHaed.Oper_id_fk=6
                                ---اذا كان فاتورة مبيعات ---
                        ,(SELECT  top 1     convert(nvarchar, BoxUser.User_id_fk)+' - ' + Users.User_name
                        FROM            SalesBillHead INNER JOIN
                                                 BoxUser ON SalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
                                                 Users ON BoxUser.User_id_fk = Users.User_id
                                WHERE        Bill_id = DaylyHaed.Refer_id_fk)

                        ,iif(DaylyHaed.Oper_id_fk=7
                                            ---اذا كان مردود مبيعات ---
                        ,(SELECT    top 1   convert(nvarchar, BoxUser.User_id_fk)+' - ' + Users.User_name
                        FROM            ReturnSalesBillHead INNER JOIN
                                                 BoxUser ON ReturnSalesBillHead.BoxUser_id_fk = BoxUser.BoxUser_id INNER JOIN
                                                 Users ON BoxUser.User_id_fk = Users.User_id
                                WHERE        Return_bill_id =  DaylyHaed.Refer_id_fk)

                        ,iif(DaylyHaed.Oper_id_fk=0
                                            ---اذا كان قيد افتتاحي ---
                        ,( SELECT  top 1    CONVERT(nvarchar,BalanceOpen.User_id_fk)+' - '+ Users.User_name
                                FROM            BalanceOpen INNER JOIN
                                                         Users ON BalanceOpen.User_id_fk = Users.User_id)

                        ,iif(DaylyHaed.Oper_id_fk=1

                        ,( SELECT   top 1     convert(nvarchar, DaylyHaed.User_id_fk)+' - '+ Users.User_name
                        FROM            DaylyHaed INNER JOIN
                                                 Users ON DaylyHaed.User_id_fk = Users.User_id
                                                 where DaylyHaed.Dayly_id= DaylyHaed.Refer_id_fk) 
                        ,'')))))),'') as UserAdded

                        --مرحل السجل-
                        ,(SELECT       convert(nvarchar, User_id)+' - '+User_name
                                FROM            Users
                                WHERE        User_id = DaylyHaed.User_id_fk) as UserPosting
                                ,DaylyHaed.Oper_id_fk

    FROM            DaylyHaed INNER JOIN
                         DaylyBody ON DaylyHaed.Dayly_id = DaylyBody.Dayly_id_fk INNER JOIN
                         AccCurrency ON DaylyBody.AccCurr_id_fk = AccCurrency.AccCurr_id INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                         Operations ON DaylyHaed.Oper_id_fk = Operations.Oper_id 

                         )
                          a group by
                           a.Dayly_id_fk
                          ,a.Oper_name
                          ,a.Bill_Type
                          ,a.Refer_id_fk
                          ,a.Date_dayly
                          ,a.Acc_id_fk
                          ,a.Acc_name
                          ,a.Curr_name
                          ,a.Debt_local
                          ,a.Credit_local
                          ,a.Debt_foreign
                          ,a.Credit_foreign
                          ,a.Note
                          ,a.Date_Added
                          ,a.UserAdded
                          ,a.UserPosting
                          ,a.Oper_id_fk


        */
        #endregion

        private void btnSelect_Click(object sender, EventArgs e)
        {
            FillData();
        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtAccIdBign_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9)
            {
                AccList AccList = new AccList();
                AccList.ShowDialog();
                if (AccList.stateSelect == true&& AccList.indeex!=-1)
                {
                    int i = AccList.indeex;


                    txtAccIdBign.Text = AccList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    txtAccNameBegn.Text = AccList.dataGridView1.Rows[i].Cells[2].Value.ToString();

                    AccList.indeex = -1;
                    AccList.stateSelect = false;

                }
            }
            else if (e.KeyData == Keys.Delete)
            {
                txtAccIdBign.Text = string.Empty;
                txtAccNameBegn.Text = string.Empty;
            }
        }

        private void txtAccIdEnd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9)
            {
                AccList AccList = new AccList();
                AccList.ShowDialog();
                if (AccList.stateSelect == true && AccList.indeex != -1)
                {
                    int i = AccList.indeex;


                    txtAccIdEnd.Text = AccList.dataGridView1.Rows[i].Cells[1].Value.ToString();
                    txtAccNameEnd.Text = AccList.dataGridView1.Rows[i].Cells[2].Value.ToString();

                    AccList.indeex = -1;
                    AccList.stateSelect = false;

                }
            }
            else if (e.KeyData == Keys.Delete)
            {
                txtAccIdEnd.Text = string.Empty;
                txtAccNameEnd.Text = string.Empty;
            }
        }
    }
}
