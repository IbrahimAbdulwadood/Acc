﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class FrmNonPosting : Form
    {
        public FrmNonPosting()
        {
            InitializeComponent();
        }
        #region المتغيرات
        ClassesProject.ConnectionDB con = new ClassesProject.ConnectionDB();
        DataTable DT;
        #endregion
        DataTable GetReport(string DateBgin, string DateEnd)
        {
            if (DT != null)
                DT = null;
            DT = new DataTable();
            //   MessageBox.Show(Cust_id);
            string
           query = "    select     ";
            query += "  DaylyHaed.Dayly_id  ";
            query += " ,DaylyHaed.Refer_id_fk ";
            query += " ,Operations.Oper_name  ";
            query += " ,DaylyHaed.Date_dayly  ";
            query += " ,Operations.Oper_id  ";
            query += " FROM  DaylyHaed INNER JOIN  ";
            query += " Operations ON DaylyHaed.Oper_id_fk = Operations.Oper_id  ";
            query += " where DaylyHaed.Date_dayly between  "+con.AddApostropheToString(DateBgin);
            query += " and   "+ con.AddApostropheToString(DateEnd);

            con.OpenConnetion();
            try { DT = con.Query(query, true); } catch (Exception e) { MessageBox.Show(e.ToString()); }

            con.CloseConnetion();

            return DT;
            /*
            SELECT       
             DaylyHaed.Dayly_id
             , DaylyHaed.Refer_id_fk
             , Operations.Oper_name
             , DaylyHaed.Date_dayly
              , Operations.Oper_id
            FROM            DaylyHaed INNER JOIN
             Operations ON DaylyHaed.Oper_id_fk = Operations.Oper_id
              where DaylyHaed.Date_dayly between '2019-8-9' and '2019-9-9'
            */

        }
        void FillData()
        {
            DataTable DTFill = new DataTable();
            DGV.Rows.Clear();

            DTFill = GetReport(
                dateTimePicker1.Value.ToShortDateString()
               , dateTimePicker2.Value.ToShortDateString()
               );

            if (DTFill != null && DTFill.Rows.Count > 0)
            {
                ShowLabelNotFound(false);
                for (int i = 0; i < DTFill.Rows.Count; i++)
                {
                    DGV.Rows.Add
                        (
                        
                          DTFill.Rows[i][0].ToString()
                         , DTFill.Rows[i][1].ToString()
                         , DTFill.Rows[i][2].ToString()
                         , Convert.ToDateTime(DTFill.Rows[i][3]).ToShortDateString()
                        ,false
                        , DTFill.Rows[i][4].ToString()
                        );
                    
                }
                MessageBox.Show(DGV.ColumnCount.ToString());
               for(int i = 0; i < DGV.RowCount; i++)
                {

                    #region منع الكتابة على جميع الحقول
                    for (int x = 0; x < DGV.ColumnCount; x++)
                    {
                        DGV.Rows[i].Cells[x].ReadOnly = true;
                    }
                    DGV.Rows[i].Cells[4].ReadOnly = false;
                    #endregion
                }

            }
            else
            { ShowLabelNotFound(true); MessageBox.Show("فارغ"); }


        }
        void ShowLabelNotFound(bool a)
        {
            lbError.Visible = a;
            pnlError.Visible = a;
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            if (DGV.RowCount > 0)
            {
                for (int i = 0; i < DGV.RowCount; i++)
                    if (Convert.ToBoolean(DGV.Rows[i].Cells[4].Value))
                    {
                        post.DeletePotstingHaed(DGV.Rows[i].Cells[0].Value.ToString());
                        post.EditStateNonPosting(
                              DGV.Rows[i].Cells[1].Value.ToString()
                            , DGV.Rows[i].Cells[5].Value.ToString());
                    }
            }
            //
            //
        }
        ClassesProject.PostingSQL post = new ClassesProject.PostingSQL();
       
        private void button1_Click(object sender, EventArgs e)
        {
            FillData();
        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
