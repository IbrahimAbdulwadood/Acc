﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.FormsProject.Accounts;
using AccSystem.ClassesProject;
using NumberToWord;

namespace AccSystem.FormsProject.Accounts
{
    public partial class FrmRepBoxAnalytical : Form
    {
        public FrmRepBoxAnalytical(string idUser)
        {
            InitializeComponent();
            UserId.Text = idUser;
            UserName.Text = userSql.GetNameUser(idUser);
        }
        UsersSQL userSql = new UsersSQL();
        #region المتغيرات
        ClassesProject.ConnectionDB con = new ClassesProject.ConnectionDB();
        DataTable DT;
        #endregion
        #region  الدوال
        void ShowListBoxsUser(KeyEventArgs e, string BoxOrCoust)
        {
            if (e.KeyData == Keys.F9)
            {

                SupportBoxUserList sbu = new SupportBoxUserList(
                    (UserId.Text == null) ? "-1" : UserId.Text,
                    (txtBoxd.Tag == null ? "-1" : txtBoxd.Tag.ToString()), BoxOrCoust
                    );
                sbu.ShowDialog();
                if (sbu.stateSelect == true)
                {



                    txtBoxd.Text = SupportBoxUserList.SupCatParmHaed.Box_id;
                    txtBoxName.Text = SupportBoxUserList.SupCatParmHaed.Box_name;
                    txtAccId.Text = SupportBoxUserList.SupCatParmHaed.Acc_id_fk;
                    txtAccName.Text = SupportBoxUserList.SupCatParmHaed.Acc_name;
                    txtCurr.Text = SupportBoxUserList.SupCatParmHaed.Curr_name;


                    SupportBoxUserList.SupCatParmHaed.Box_id = null;
                    SupportBoxUserList.SupCatParmHaed.BoxUser_id = null;
                    SupportBoxUserList.SupCatParmHaed.Box_name = null;
                    SupportBoxUserList.SupCatParmHaed.Acc_id_fk = null;
                    SupportBoxUserList.SupCatParmHaed.Acc_name = null;
                    SupportBoxUserList.SupCatParmHaed.Curr_name = null;
                    SupportBoxUserList.SupCatParmHaed.Curr_echange = null;
                    SupportBoxUserList.SupCatParmHaed.Curr_id = null;
                    sbu.stateSelect = false;
                    sbu = null;
                }
            }

            }
            DataTable GetReport(string DateBgin, string DateEnd,string Box_id="-1")
        {
            if (DT != null)
                DT = null;
            DT = new DataTable();
         //   MessageBox.Show(Box_id);
            string
           query = "    select     ";
            query += "  a.Opra  ";
            query += " ,a.Bill_Type ";
            query += " ,a.No_  ";
            query += " ,a.Date_  ";
            query += " ,a.Debt  ";
            query += " ,a.Credit  ";
            query += " ,a.Note  ";
            
            query += "   FROM ( ";
            #region 
            query += "    SELECT   ";
            query += "  (SELECT    Oper_name  ";
            query += "  FROM      Operations  ";
            query += "  WHERE        Oper_id =  DaylyHaed.Oper_id_fk) as Opra  ";

            query += "  ,iif(DaylyHaed.Oper_id_fk=6  ";
            query += " ,(SELECT   TypeBill.Type_neme  ";
            query += "   FROM     TypeBill INNER JOIN  ";
            query += "   SalesBillHead ON TypeBill.Type_id = SalesBillHead.Type_id_fk ";
            query += " WHERE   SalesBillHead.Bill_id = DaylyHaed.Refer_id_fk)  ";
            query += "    ,iif(DaylyHaed.Oper_id_fk=7 ";
            query += "   ,(SELECT        TypeBill.Type_neme  ";
            query += "  FROM            TypeBill INNER JOIN  ";
            query += "   ReturnSalesBillHead ON TypeBill.Type_id = ReturnSalesBillHead.Type_id_fk ";
            query += "  WHERE        (ReturnSalesBillHead.Return_bill_id =DaylyHaed.Refer_id_fk ))  ";
            query += "  ,'')) as Bill_Type  ";
        
            query += "   , DaylyHaed.Refer_id_fk as No_  ";
            query += "   , DaylyHaed.Date_dayly as Date_  ";
          
            //مدين
            query += "  ,iif((SELECT Currencys.Curr_is_local  ";
            query += "  FROM            AccCurrency INNER JOIN  ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN ";
            query += "  Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk ";
            query += "   WHERE        Boxes.Box_id= " +Box_id+ ")=1 ";
            query += "  , DaylyBody.Debt_local  ";
            query += "  , DaylyBody.Debt_foreign) as Debt  ";
           
            //دائن
            query += " ,iif((SELECT Currencys.Curr_is_local  ";
            query += "  FROM            AccCurrency INNER JOIN  ";
            query += "  Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN  ";
            query += "   Boxes ON AccCurrency.AccCurr_id =  Boxes.AccCurr_id_fk  ";
            query += "   WHERE         Boxes.Box_id =  " + Box_id+ ")=1 ";
            query += "   ,DaylyBody.Credit_local ";
            query += " ,DaylyBody.Credit_foreign) as Credit  ";

           
            #region البيان
            query += "  ,iif(DaylyHaed.Oper_id_fk=2  ";
            //اذا كان سند قبض
            query += "  ,(SELECT        Note  ";
            query += "  FROM   SupportCatchBody  ";
            query += "   WHERE   ";
            query += "   (Support_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += "  AND (AccCurr_id_fk = ((SELECT        AccCurr_id_fk  ";
            query += "  FROM  Boxes  ";
            query += "  WHERE        Boxes.Box_id =  " + Box_id + ")))) ";
            //اذا كان سند صرف
            query += "  ,iif(DaylyHaed.Oper_id_fk=3  ";
            query += "   ,(SELECT        Note ";
            query += "   FROM            SupportExchangBody  ";
            query += "  WHERE ";
            query += "   (Support_id_fk = DaylyHaed.Refer_id_fk) ";
            query += "   AND (AccCurr_id_fk = ((SELECT        AccCurr_id_fk ";
            query += "   FROM            Boxes ";
            query += "   WHERE         Boxes.Box_id = " + Box_id + ")))) ";
            //اذا كان فاتورة مبيعات
            query += "   ,iif(DaylyHaed.Oper_id_fk=6 ";
            query += "  ,(SELECT    Note  ";
            query += "  FROM     SalesBillHead  ";
            query += "  WHERE   (Bill_id = DaylyHaed.Refer_id_fk))  ";
            //اذا كان مردود مبيعات
            query += "  ,iif(DaylyHaed.Oper_id_fk=7  ";
            query += " ,(SELECT        Note  ";
            query += "  FROM       ReturnSalesBillHead  ";
            query += "   WHERE   (Return_bill_id = DaylyHaed.Refer_id_fk))  ";
            //-اذا كان قيد افتتاحي 
            query += " ,iif(DaylyHaed.Oper_id_fk=0  ";
            query += "    ,(SELECT        Note ";
            query += "   FROM            DaylyBody  ";
            query += "   WHERE  ";
            query += "  (Dayly_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += "  AND (AccCurr_id_fk = (SELECT        AccCurr_id_fk  ";
            query += "   FROM             Boxes  ";
            query += "   WHERE         Boxes.Box_id = " + Box_id + "))) ";
            //اذا كان سند قيد يدوي
            query += "  ,iif(DaylyHaed.Oper_id_fk=1  ";
            query += " ,(SELECT        Note  ";
            query += "  FROM            EntriesBody  ";
            query += "  WHERE    ";
            query += "  (Entry_id_fk = DaylyHaed.Refer_id_fk)  ";
            query += "  AND (AccCurr_id_fk = (SELECT        AccCurr_id_fk  ";
            query += "  FROM           Boxes  ";
            query += " WHERE          Boxes.Box_id  =   " + Box_id + "))) ";

            query += "  ,'')))))) as Note ";
            #endregion

            query += " FROM            DaylyHaed INNER JOIN  ";
            query += " DaylyBody ON DaylyHaed.Dayly_id = DaylyBody.Dayly_id_fk  ";
            query += "  where ";
            query += "  DaylyBody.AccCurr_id_fk=(SELECT        AccCurr_id_fk  ";
            query += " FROM    Boxes  ";
            query += "  WHERE        Boxes.Box_id=  " + Box_id + ") ";

           // query += "  ------------------------------------------------  ";
            query += "  union all  ";
         //   query += "  ------------------------------------------------ ";
            #region المبيعات النقدية
            query += "  SELECT     (select 'فاتورة مبيعات') as Opra  ";
            query += "  ,  TypeBill.Type_neme as Bill_Type  ";
            query += " , SalesBillHead.Bill_id as No_  ";
            query += " ,SalesBillHead.Date_salesbill as Date_  ";
            query += "  , SalesBillHead.Total as Debt ";
            query += " , SalesBillHead.Total as Credit  ";
            query += " ,ISNULL( SalesBillHead.Note,'')  as Note  ";
            query += "  FROM            SalesBillHead INNER JOIN  ";
            query += "   TypeBill ON SalesBillHead.Type_id_fk = TypeBill.Type_id ";
            query += "  WHERE ";
            query += "  (SalesBillHead.Type_id_fk = 1)  ";
            query += "   AND (SalesBillHead.BoxUser_id_fk =  " + Box_id + ") ";

            #endregion
          //  query += "  -----------------------------------------------------  ";
            query += "  union all  ";
         //   query += " -----------------------------------------------------  ";
            #region مردود المبيعات النقدي
            query += " SELECT     (select 'مردود مبيعات') as Opra  ";
            query += " ,TypeBill.Type_neme as Bill_Type  ";
            query += "  ,ReturnSalesBillHead.Return_bill_id as No_  ";
            query += " ,ReturnSalesBillHead.Date_return_salesBill as Date_  ";
            query += "   ,ReturnSalesBillHead.Total as Debt ";
            query += " ,ReturnSalesBillHead.Total as Credit  ";
            query += " ,ISNULL( ReturnSalesBillHead.Note,'')  as Note  ";
            query += " FROM            ReturnSalesBillHead INNER JOIN  ";
            query += "  TypeBill ON ReturnSalesBillHead.Type_id_fk = TypeBill.Type_id ";
            query += " WHERE  ";
            query += "  (ReturnSalesBillHead.Type_id_fk = 1)  ";
            query += "   AND (ReturnSalesBillHead.BoxUser_id_fk =" + Box_id + ") ";

            #endregion
            #endregion
            query += "  ) A  ";
            query += " where  ";
            query += "  a.Date_ between "+con.AddApostropheToString(DateBgin);
            query += "  and  "+con.AddApostropheToString(DateEnd);
            query += " group by  ";
            query += " a.Date_  ";
            query += " ,a.Opra  ";
            query += " ,a.Bill_Type  ";
            query += " ,a.No_  ";
            query += " ,a.Debt  ";
            query += " ,a.Credit  ";
            query += " ,a.Note  ";
            query += "   order by a.Date_  ";
          //  MessageBox.Show(query);


            con.OpenConnetion();
            try { DT = con.Query(query, true); } catch (Exception e) { MessageBox.Show(e.ToString()); }
            
            con.CloseConnetion();

            return DT;
            #region  الاستعلام
         
            #endregion

        }
        void FillData(string BoxId="-1")
        {
            DataTable DTFill = new DataTable();
            DGVBody.Rows.Clear();
          
            DTFill = GetReport(
                dateTimePicker1.Value.ToShortDateString()
               , dateTimePicker2.Value.ToShortDateString()
               , BoxId);

            if (DTFill != null && DTFill.Rows.Count > 0)
            {
                double SumDebt = 0;
                double SumCredit = 0;
                ShowLabelNotFound(false);
                for (int i = 0; i < DTFill.Rows.Count; i++)
                {
                    DGVBody.Rows.Add
                        (
                        (i + 1).ToString()
                         , DTFill.Rows[i][0].ToString()
                         , DTFill.Rows[i][1].ToString()
                         , DTFill.Rows[i][2].ToString()
                         , Convert.ToDateTime(DTFill.Rows[i][3]).ToShortDateString()
                         ,DTFill.Rows[i][4].ToString()
                         , DTFill.Rows[i][5].ToString()
                         , DTFill.Rows[i][6].ToString()

                        );
                    try { SumDebt += ((double)DTFill.Rows[i][4]); SumCredit+= ((double)DTFill.Rows[i][5]); }
                    catch (Exception e) { MessageBox.Show(e.ToString()); }
                }
                txtCredit.Text = SumCredit.ToString();
                txtDebt.Text = SumDebt.ToString();
                txtTotal.Text = (SumDebt- SumCredit).ToString();
                string a = "";
                try {
                    if (Convert.ToDouble(txtTotal.Text) > 0) a = " عليكم ";
                    else if (Convert.ToDouble(txtTotal.Text) < 0) a = " لكم  ";
                    else a = "";
                } catch (Exception e) { MessageBox.Show(e.ToString()); }
               
                try
                {
                    ToWord toWord = new ToWord(Math.Abs(Convert.ToDecimal(txtTotal.Text)), new CurrencyInfo("1"));
                    txtTotalWord.Text = a + toWord.ConvertToArabic();

                }
                catch
                {

                    txtTotalWord.Text = String.Empty;
                }
            }
            else
            { ShowLabelNotFound(true); MessageBox.Show("فارغ"); }


        }
        void ShowLabelNotFound(bool State)
        {

            panel5.Visible = State;
            labelNotFound.Visible = State;

        }

        #endregion

     



        private void txtCustId_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            if (txtBoxd.Text != string.Empty)
            {
               // MessageBox.Show(dateTimePicker1.Value.ToShortDateString());
                try { FillData(txtBoxd.Text); } catch (Exception ee) { MessageBox.Show(ee.ToString()); }
            }
               
            else MessageBox.Show("يرجى اختيار صندوق");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DGVBody_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtCustId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            Reports.RepBoxAnalytical item = new Reports.RepBoxAnalytical();
            item.Refresh();
            item.SetParameterValue("@Box_idR", this.txtBoxd.Text);
           
            item.SetParameterValue("@BeingeR", this.dateTimePicker1.Value.ToShortDateString());
            item.SetParameterValue("@EndR", this.dateTimePicker2.Value.ToShortDateString());
            Reports.frm_Reports f = new Reports.frm_Reports();
            f.crystalReportViewer1.ReportSource = item;
            f.Refresh();
            f.ShowDialog();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txtBoxd_KeyDown(object sender, KeyEventArgs e)
        {
            ShowListBoxsUser(e, "Box");
        }

        private void pnlDown_Paint(object sender, PaintEventArgs e)
        {

        }

        private void toolStripStatusLabel2_Click(object sender, EventArgs e)
        {

        }
    }
}
