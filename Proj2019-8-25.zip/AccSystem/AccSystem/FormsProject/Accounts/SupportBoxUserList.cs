﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class SupportBoxUserList : Form
    {
       
        public SupportBoxUserList(string idUser,string idUserBox,string BoxOrCoust)
        {
            InitializeComponent();
            this.idUser = idUser;
         //   MessageBox.Show(idUserBox, this.idUserBox);
            this.idUserBox = idUserBox;
            this.BoxOrCoust = BoxOrCoust;
            
           //  DGVListSuppBoxUser.Columns[0].HeaderText = "hhh";
            

        }
        //~SupportBoxUserList()
        //{
        //    MessageBox.Show("Object SupportBoxUserList Done");
        //}
        string BoxOrCoust = string.Empty;
        string idUser = string.Empty;
        string idUserBox = string.Empty;
        int i;
        static  public int indeex;
        public bool stateSelect = false;
        DataTable datatable;
        ClassesProject.BoxsSQL boxss = new ClassesProject.BoxsSQL();
   static  public ClassesProject.SupportCatchParametr SupCatParmHaed = new ClassesProject.SupportCatchParametr();




        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }

        void FormatingDataGrid()
        {
            try
            {
                if (DGVListSuppBoxUser.Rows.Count > 0)
                {
                    for (int i = 0; i < DGVListSuppBoxUser.Rows.Count; i++)
                    {
                        #region منع الكتابة على جميع الحقول
                        for (int x = 0; x < DGVListSuppBoxUser.ColumnCount; x++)
                        {
                            DGVListSuppBoxUser.Rows[i].Cells[x].ReadOnly = true;
                        }
                        #endregion
                      
                    }
                  
                }
            }
            catch (Exception e) { MessageBox.Show(e.ToString(), "jjhjh"); }

        }

        private void BoxAccList_Load(object sender, EventArgs e)
        {
            if (BoxOrCoust == "Box")
                datatable = boxss.GetBoxesUser(idUser, idUserBox);
            else if (BoxOrCoust == "Coust")
                datatable = boxss.GetCoustInfo();
            if (datatable !=null&& datatable.Rows.Count > 0)
            {
                if (BoxOrCoust == "Coust")
                {
                    DGVListSuppBoxUser.Columns[0].HeaderText = "رقم العميل";
                    DGVListSuppBoxUser.Columns[1].HeaderText = "اسم العميل";
                    DGVListSuppBoxUser.Columns[6].Visible = false;
                    DGVListSuppBoxUser.Columns[7].Visible = false;
                    DGVListSuppBoxUser.Columns[8].Visible = false;
                    button52.Text = "اختيار العميل المحدد";
                    label1.Text = "لا يوجد عملاء لعرضهم";
                    label2.Text = "العملاء";

                }

                for (i = 0; i < datatable.Rows.Count; i++)
                {

                    DGVListSuppBoxUser.Rows.Add(
                        datatable.Rows[i][0].ToString(),//BoxId , Cust_id
                        datatable.Rows[i][1].ToString(),//BoxName ,Cust_name
                        datatable.Rows[i][2].ToString(),//AccId ,Acc_id
                        datatable.Rows[i][3].ToString(),//AccName ,Acc_name
                        datatable.Rows[i][4].ToString(),//CurrName ,Curr_sumbol_eng
                        (Convert.ToBoolean(datatable.Rows[i][5].ToString())==true?"متاح":"غير متاح"),//Stat  
                      
                         datatable.Rows[i][6].ToString()//BoxUserId 
                        ,datatable.Rows[i][7].ToString()//CurrExching
                       , datatable.Rows[i][8].ToString()//Curr_id , AccCurr_id
                        );
                    #region

                    /*
                     Customers.Cust_id,
              Customers.Cust_name,
			  Accounts.Acc_id,
			   Accounts.Acc_name, 
			   Currencys.Curr_sumbol_eng, 
			   AccCurrency.State,
			   Currencys.Curr_echange,
			   Currencys.Curr_id,
			   AccCurrency.AccCurr_id*/

                    /*
                    SELECT   
                    BoxUser.Box_id_fk, 
                    Boxes.Box_name,
                    Accounts.Acc_id,
                    Accounts.Acc_name,
                    Currencys.Curr_name, 
                    BoxUser.stateA, 
                    BoxUser.BoxUser_id
        FROM    
        AccCurrency INNER JOIN
                                 Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                                 Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                                 BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk INNER JOIN
                                 Users ON BoxUser.User_id_fk = Users.User_id INNER JOIN
                                 Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id
        WHERE        (BoxUser.User_id_fk = 1)

                    */
                    #endregion
                }
                FormatingDataGrid();
                

            }
            else
            {
                button52.Visible = false;
                label1.Visible = true;
                panel2.Visible = true;

            }

        }


        

        private void button52_Click(object sender, EventArgs e)
        {
            if (DGVListSuppBoxUser.Rows.Count > 0)
            {
                if (indeex >= 0 && DGVListSuppBoxUser.Rows[indeex].Cells[5].Value.ToString() == "متاح")
                {
                    stateSelect = true;
                  
                    SupCatParmHaed.Box_id = DGVListSuppBoxUser.Rows[indeex].Cells[0].Value.ToString();
                    SupCatParmHaed.Box_name = DGVListSuppBoxUser.Rows[indeex].Cells[1].Value.ToString();
                    SupCatParmHaed.Acc_id_fk = DGVListSuppBoxUser.Rows[indeex].Cells[2].Value.ToString();
                    SupCatParmHaed.Acc_name = DGVListSuppBoxUser.Rows[indeex].Cells[3].Value.ToString();
                    SupCatParmHaed.Curr_name = DGVListSuppBoxUser.Rows[indeex].Cells[4].Value.ToString();
                    SupCatParmHaed.BoxUser_id = DGVListSuppBoxUser.Rows[indeex].Cells[6].Value.ToString();
                    SupCatParmHaed.Curr_echange= DGVListSuppBoxUser.Rows[indeex].Cells[7].Value.ToString();
                    SupCatParmHaed.Curr_id= DGVListSuppBoxUser.Rows[indeex].Cells[8].Value.ToString();
                    //  MessageBox.Show(SupCatParmHaed.BoxUser_id+ " ||Exching=" + SupCatParmHaed.Curr_echange);
                    Close();

                }

                else
                {
                    MessageBox.Show("الصندوق الحالي غير متاح", "تنبية",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    stateSelect = false;
                }
               
                
            }


          
           
           

        }

        private void DGVListSuppBoxUser_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

           

        }
       
        private void DGVListSuppBoxUser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }
      
        private void DGVListSuppBoxUser_RowValidating(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (DGVListSuppBoxUser.Rows.Count > 0)
                indeex = DGVListSuppBoxUser.CurrentCell.RowIndex;
       
               
        }
    }
}
