﻿namespace AccSystem.FormsProject.Accounts
{
    partial class SupportCatch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        { 
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SupportCatch));
            this.panMain = new System.Windows.Forms.Panel();
            this.panFill = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.DGVBody = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.TotalDifferenceTxt = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.TotalCreditTxt = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBoxData = new System.Windows.Forms.GroupBox();
            this.textDebtWord = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textDebt_local = new System.Windows.Forms.TextBox();
            this.textCurr_echange = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textPayee = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textAcc_name_fk = new System.Windows.Forms.TextBox();
            this.textAcc_id_fk = new System.Windows.Forms.TextBox();
            this.textBox_name_fk = new System.Windows.Forms.TextBox();
            this.textBox_id_fk = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textNote = new System.Windows.Forms.TextBox();
            this.textCurr_sumbol = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.textSupport_id = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textDebt_foreign = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textRefr_id = new System.Windows.Forms.TextBox();
            this.groupBoxOprea = new System.Windows.Forms.GroupBox();
            this.checkBoxSavePosting = new System.Windows.Forms.CheckBox();
            this.buttPrint = new System.Windows.Forms.Button();
            this.buttPosting = new System.Windows.Forms.Button();
            this.CountRows = new System.Windows.Forms.TextBox();
            this.buttLast = new System.Windows.Forms.Button();
            this.buttBack = new System.Windows.Forms.Button();
            this.buttNext = new System.Windows.Forms.Button();
            this.buttFrist = new System.Windows.Forms.Button();
            this.buttDelete = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.butSave = new System.Windows.Forms.Button();
            this.buttAdd = new System.Windows.Forms.Button();
            this.panDown = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserId = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserName = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.userId_add = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.nameOpration = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel8 = new System.Windows.Forms.ToolStripStatusLabel();
            this.idOpration = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel9 = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatePosting = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel10 = new System.Windows.Forms.ToolStripStatusLabel();
            this.CurrId = new System.Windows.Forms.ToolStripStatusLabel();
            this.panUp = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSerch = new System.Windows.Forms.TextBox();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.panMain.SuspendLayout();
            this.panFill.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVBody)).BeginInit();
            this.panel1.SuspendLayout();
            this.groupBoxData.SuspendLayout();
            this.groupBoxOprea.SuspendLayout();
            this.panDown.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panFill);
            this.panMain.Controls.Add(this.panDown);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1000, 650);
            this.panMain.TabIndex = 0;
            // 
            // panFill
            // 
            this.panFill.Controls.Add(this.groupBox1);
            this.panFill.Controls.Add(this.groupBoxData);
            this.panFill.Controls.Add(this.groupBoxOprea);
            this.panFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFill.Location = new System.Drawing.Point(0, 37);
            this.panFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFill.Name = "panFill";
            this.panFill.Size = new System.Drawing.Size(1000, 581);
            this.panFill.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DGVBody);
            this.groupBox1.Controls.Add(this.panel1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 197);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1000, 269);
            this.groupBox1.TabIndex = 35;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "يقيد إلى حساب/";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // DGVBody
            // 
            this.DGVBody.AllowUserToAddRows = false;
            this.DGVBody.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DGVBody.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGVBody.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVBody.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGVBody.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DGVBody.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVBody.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DGVBody.ColumnHeadersHeight = 30;
            this.DGVBody.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGVBody.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVBody.DefaultCellStyle = dataGridViewCellStyle3;
            this.DGVBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVBody.EnableHeadersVisualStyles = false;
            this.DGVBody.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DGVBody.Location = new System.Drawing.Point(3, 18);
            this.DGVBody.Name = "DGVBody";
            this.DGVBody.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVBody.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DGVBody.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Gray;
            this.DGVBody.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DGVBody.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVBody.Size = new System.Drawing.Size(994, 223);
            this.DGVBody.TabIndex = 43;
            this.DGVBody.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBody_CellClick);
            this.DGVBody.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBody_CellEndEdit);
            this.DGVBody.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBody_CellValueChanged);
            this.DGVBody.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.DGVBody_EditingControlShowing);
            this.DGVBody.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.DGVBody_RowsAdded);
            this.DGVBody.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.DGVBody_RowsRemoved);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "التسلسل";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn2.FillWeight = 288.8852F;
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "رقم الحساب";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 85;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells;
            this.dataGridViewTextBoxColumn3.FillWeight = 525.3807F;
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "اسم الحساب";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 89;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn4.FillWeight = 50.06168F;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "العملة";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 115;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 115;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn5.FillWeight = 20.84476F;
            this.dataGridViewTextBoxColumn5.HeaderText = "سعر الصرف";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 81;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn7.FillWeight = 3.62132F;
            this.dataGridViewTextBoxColumn7.HeaderText = "دائن محلي";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 77;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn9.FillWeight = 0.6372076F;
            this.dataGridViewTextBoxColumn9.HeaderText = "دائن اجنبي";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 79;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn10.FillWeight = 0.3715312F;
            this.dataGridViewTextBoxColumn10.HeaderText = "البيــــــــان";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 68;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn12.HeaderText = "idAccCurr";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Width = 71;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn13.HeaderText = "CurrMax";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Width = 64;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn14.HeaderText = "CurMin";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Width = 56;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Maroon;
            this.panel1.Controls.Add(this.TotalDifferenceTxt);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.TotalCreditTxt);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 241);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(994, 25);
            this.panel1.TabIndex = 46;
            // 
            // TotalDifferenceTxt
            // 
            this.TotalDifferenceTxt.BackColor = System.Drawing.Color.Maroon;
            this.TotalDifferenceTxt.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalDifferenceTxt.ForeColor = System.Drawing.Color.White;
            this.TotalDifferenceTxt.Location = new System.Drawing.Point(254, 0);
            this.TotalDifferenceTxt.Name = "TotalDifferenceTxt";
            this.TotalDifferenceTxt.ReadOnly = true;
            this.TotalDifferenceTxt.Size = new System.Drawing.Size(203, 22);
            this.TotalDifferenceTxt.TabIndex = 44;
            this.TotalDifferenceTxt.Text = "0.0";
            this.TotalDifferenceTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Dock = System.Windows.Forms.DockStyle.Right;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(457, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 16);
            this.label12.TabIndex = 47;
            this.label12.Text = "الفارق:";
            // 
            // TotalCreditTxt
            // 
            this.TotalCreditTxt.BackColor = System.Drawing.Color.Maroon;
            this.TotalCreditTxt.Dock = System.Windows.Forms.DockStyle.Right;
            this.TotalCreditTxt.ForeColor = System.Drawing.Color.White;
            this.TotalCreditTxt.Location = new System.Drawing.Point(508, 0);
            this.TotalCreditTxt.Name = "TotalCreditTxt";
            this.TotalCreditTxt.ReadOnly = true;
            this.TotalCreditTxt.Size = new System.Drawing.Size(203, 22);
            this.TotalCreditTxt.TabIndex = 46;
            this.TotalCreditTxt.Text = "0.0";
            this.TotalCreditTxt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Dock = System.Windows.Forms.DockStyle.Right;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(711, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(145, 16);
            this.label11.TabIndex = 45;
            this.label11.Text = "اجمالي تفاصيل السند:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Dock = System.Windows.Forms.DockStyle.Right;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(856, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(22, 16);
            this.label16.TabIndex = 50;
            this.label16.Text = "||";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Dock = System.Windows.Forms.DockStyle.Right;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(878, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(94, 16);
            this.label15.TabIndex = 49;
            this.label15.Text = "لإضافة حساب";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Dock = System.Windows.Forms.DockStyle.Right;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(972, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(22, 16);
            this.label14.TabIndex = 48;
            this.label14.Text = "F9";
            // 
            // groupBoxData
            // 
            this.groupBoxData.Controls.Add(this.textDebtWord);
            this.groupBoxData.Controls.Add(this.label17);
            this.groupBoxData.Controls.Add(this.textDebt_local);
            this.groupBoxData.Controls.Add(this.textCurr_echange);
            this.groupBoxData.Controls.Add(this.label10);
            this.groupBoxData.Controls.Add(this.textPayee);
            this.groupBoxData.Controls.Add(this.label9);
            this.groupBoxData.Controls.Add(this.textAcc_name_fk);
            this.groupBoxData.Controls.Add(this.textAcc_id_fk);
            this.groupBoxData.Controls.Add(this.textBox_name_fk);
            this.groupBoxData.Controls.Add(this.textBox_id_fk);
            this.groupBoxData.Controls.Add(this.label8);
            this.groupBoxData.Controls.Add(this.textNote);
            this.groupBoxData.Controls.Add(this.textCurr_sumbol);
            this.groupBoxData.Controls.Add(this.label6);
            this.groupBoxData.Controls.Add(this.dateTimePicker1);
            this.groupBoxData.Controls.Add(this.textSupport_id);
            this.groupBoxData.Controls.Add(this.label1);
            this.groupBoxData.Controls.Add(this.textDebt_foreign);
            this.groupBoxData.Controls.Add(this.label7);
            this.groupBoxData.Controls.Add(this.label5);
            this.groupBoxData.Controls.Add(this.label2);
            this.groupBoxData.Controls.Add(this.label3);
            this.groupBoxData.Controls.Add(this.label4);
            this.groupBoxData.Controls.Add(this.textRefr_id);
            this.groupBoxData.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxData.ForeColor = System.Drawing.Color.Black;
            this.groupBoxData.Location = new System.Drawing.Point(0, 0);
            this.groupBoxData.Name = "groupBoxData";
            this.groupBoxData.Size = new System.Drawing.Size(1000, 197);
            this.groupBoxData.TabIndex = 34;
            this.groupBoxData.TabStop = false;
            this.groupBoxData.Text = "البيانات";
            this.groupBoxData.Enter += new System.EventHandler(this.groupBoxData_Enter);
            // 
            // textDebtWord
            // 
            this.textDebtWord.BackColor = System.Drawing.Color.Gray;
            this.textDebtWord.ForeColor = System.Drawing.Color.White;
            this.textDebtWord.Location = new System.Drawing.Point(136, 115);
            this.textDebtWord.Name = "textDebtWord";
            this.textDebtWord.ReadOnly = true;
            this.textDebtWord.Size = new System.Drawing.Size(680, 23);
            this.textDebtWord.TabIndex = 49;
            this.textDebtWord.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(825, 118);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(82, 16);
            this.label17.TabIndex = 48;
            this.label17.Text = "المبلغ كتابة:";
            // 
            // textDebt_local
            // 
            this.textDebt_local.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textDebt_local.Enabled = false;
            this.textDebt_local.ForeColor = System.Drawing.Color.Black;
            this.textDebt_local.Location = new System.Drawing.Point(10, 86);
            this.textDebt_local.Name = "textDebt_local";
            this.textDebt_local.Size = new System.Drawing.Size(120, 23);
            this.textDebt_local.TabIndex = 46;
            this.textDebt_local.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textDebt_local.Visible = false;
            // 
            // textCurr_echange
            // 
            this.textCurr_echange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textCurr_echange.ForeColor = System.Drawing.Color.Black;
            this.textCurr_echange.Location = new System.Drawing.Point(133, 56);
            this.textCurr_echange.Name = "textCurr_echange";
            this.textCurr_echange.Size = new System.Drawing.Size(90, 23);
            this.textCurr_echange.TabIndex = 1;
            this.textCurr_echange.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textCurr_echange.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textCurr_echange_MouseClick);
            this.textCurr_echange.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textCurr_echange_KeyDown);
            this.textCurr_echange.Leave += new System.EventHandler(this.textCurr_echange_Leave);
            this.textCurr_echange.MouseLeave += new System.EventHandler(this.textCurr_echange_MouseLeave);
            this.textCurr_echange.Validating += new System.ComponentModel.CancelEventHandler(this.textCurr_echange_Validating);
            this.textCurr_echange.Validated += new System.EventHandler(this.textCurr_echange_Validated);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(220, 58);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 16);
            this.label10.TabIndex = 45;
            this.label10.Text = "الصرف:";
            // 
            // textPayee
            // 
            this.textPayee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textPayee.ForeColor = System.Drawing.Color.Black;
            this.textPayee.Location = new System.Drawing.Point(397, 88);
            this.textPayee.Name = "textPayee";
            this.textPayee.Size = new System.Drawing.Size(418, 23);
            this.textPayee.TabIndex = 42;
            this.textPayee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textPayee.Enter += new System.EventHandler(this.textPayee_Enter);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(341, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 16);
            this.label9.TabIndex = 43;
            this.label9.Text = "المبلغ:";
            // 
            // textAcc_name_fk
            // 
            this.textAcc_name_fk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textAcc_name_fk.ForeColor = System.Drawing.Color.Black;
            this.textAcc_name_fk.Location = new System.Drawing.Point(397, 57);
            this.textAcc_name_fk.Name = "textAcc_name_fk";
            this.textAcc_name_fk.Size = new System.Drawing.Size(139, 23);
            this.textAcc_name_fk.TabIndex = 41;
            this.textAcc_name_fk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textAcc_id_fk
            // 
            this.textAcc_id_fk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textAcc_id_fk.ForeColor = System.Drawing.Color.Black;
            this.textAcc_id_fk.Location = new System.Drawing.Point(540, 57);
            this.textAcc_id_fk.Name = "textAcc_id_fk";
            this.textAcc_id_fk.Size = new System.Drawing.Size(86, 23);
            this.textAcc_id_fk.TabIndex = 40;
            this.textAcc_id_fk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_name_fk
            // 
            this.textBox_name_fk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox_name_fk.ForeColor = System.Drawing.Color.Black;
            this.textBox_name_fk.Location = new System.Drawing.Point(397, 28);
            this.textBox_name_fk.Name = "textBox_name_fk";
            this.textBox_name_fk.Size = new System.Drawing.Size(139, 23);
            this.textBox_name_fk.TabIndex = 39;
            this.textBox_name_fk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_id_fk
            // 
            this.textBox_id_fk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox_id_fk.ForeColor = System.Drawing.Color.Black;
            this.textBox_id_fk.Location = new System.Drawing.Point(540, 28);
            this.textBox_id_fk.Name = "textBox_id_fk";
            this.textBox_id_fk.ReadOnly = true;
            this.textBox_id_fk.Size = new System.Drawing.Size(86, 23);
            this.textBox_id_fk.TabIndex = 0;
            this.textBox_id_fk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_id_fk.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_id_fk_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(630, 60);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 16);
            this.label8.TabIndex = 37;
            this.label8.Text = "م.الحساب:";
            // 
            // textNote
            // 
            this.textNote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textNote.ForeColor = System.Drawing.Color.Black;
            this.textNote.Location = new System.Drawing.Point(133, 145);
            this.textNote.Multiline = true;
            this.textNote.Name = "textNote";
            this.textNote.Size = new System.Drawing.Size(682, 43);
            this.textNote.TabIndex = 35;
            this.textNote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textNote.Enter += new System.EventHandler(this.textNote_Enter);
            // 
            // textCurr_sumbol
            // 
            this.textCurr_sumbol.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textCurr_sumbol.ForeColor = System.Drawing.Color.Black;
            this.textCurr_sumbol.Location = new System.Drawing.Point(276, 56);
            this.textCurr_sumbol.Name = "textCurr_sumbol";
            this.textCurr_sumbol.Size = new System.Drawing.Size(59, 23);
            this.textCurr_sumbol.TabIndex = 33;
            this.textCurr_sumbol.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(337, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 16);
            this.label6.TabIndex = 34;
            this.label6.Text = "العملة:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.Gray;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(133, 26);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(202, 23);
            this.dateTimePicker1.TabIndex = 31;
            // 
            // textSupport_id
            // 
            this.textSupport_id.BackColor = System.Drawing.Color.Gray;
            this.textSupport_id.ForeColor = System.Drawing.Color.White;
            this.textSupport_id.Location = new System.Drawing.Point(711, 28);
            this.textSupport_id.Name = "textSupport_id";
            this.textSupport_id.ReadOnly = true;
            this.textSupport_id.Size = new System.Drawing.Size(105, 23);
            this.textSupport_id.TabIndex = 30;
            this.textSupport_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(821, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "رقم السند:";
            // 
            // textDebt_foreign
            // 
            this.textDebt_foreign.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textDebt_foreign.ForeColor = System.Drawing.Color.Black;
            this.textDebt_foreign.Location = new System.Drawing.Point(135, 87);
            this.textDebt_foreign.Name = "textDebt_foreign";
            this.textDebt_foreign.Size = new System.Drawing.Size(201, 23);
            this.textDebt_foreign.TabIndex = 15;
            this.textDebt_foreign.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textDebt_foreign.TextChanged += new System.EventHandler(this.textDebt_foreign_TextChanged);
            this.textDebt_foreign.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textDebt_foreign_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(825, 158);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 16);
            this.label7.TabIndex = 26;
            this.label7.Text = "وذلك مقابل:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(822, 62);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 16);
            this.label5.TabIndex = 24;
            this.label5.Text = "رقم المرجع:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(630, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "الصندوق:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(825, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 16);
            this.label3.TabIndex = 18;
            this.label3.Text = "قبضت من الاخ:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(337, 31);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 16);
            this.label4.TabIndex = 19;
            this.label4.Text = "التاريخ:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // textRefr_id
            // 
            this.textRefr_id.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textRefr_id.ForeColor = System.Drawing.Color.Black;
            this.textRefr_id.Location = new System.Drawing.Point(711, 59);
            this.textRefr_id.Name = "textRefr_id";
            this.textRefr_id.Size = new System.Drawing.Size(105, 23);
            this.textRefr_id.TabIndex = 20;
            this.textRefr_id.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textRefr_id.TextChanged += new System.EventHandler(this.CurrMaximum_TextChanged);
            // 
            // groupBoxOprea
            // 
            this.groupBoxOprea.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxOprea.Controls.Add(this.checkBoxSavePosting);
            this.groupBoxOprea.Controls.Add(this.buttPrint);
            this.groupBoxOprea.Controls.Add(this.buttPosting);
            this.groupBoxOprea.Controls.Add(this.CountRows);
            this.groupBoxOprea.Controls.Add(this.buttLast);
            this.groupBoxOprea.Controls.Add(this.buttBack);
            this.groupBoxOprea.Controls.Add(this.buttNext);
            this.groupBoxOprea.Controls.Add(this.buttFrist);
            this.groupBoxOprea.Controls.Add(this.buttDelete);
            this.groupBoxOprea.Controls.Add(this.buttEdite);
            this.groupBoxOprea.Controls.Add(this.butSave);
            this.groupBoxOprea.Controls.Add(this.buttAdd);
            this.groupBoxOprea.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBoxOprea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxOprea.ForeColor = System.Drawing.Color.Black;
            this.groupBoxOprea.Location = new System.Drawing.Point(0, 466);
            this.groupBoxOprea.Name = "groupBoxOprea";
            this.groupBoxOprea.Size = new System.Drawing.Size(1000, 115);
            this.groupBoxOprea.TabIndex = 33;
            this.groupBoxOprea.TabStop = false;
            this.groupBoxOprea.Text = "العمليات";
            // 
            // checkBoxSavePosting
            // 
            this.checkBoxSavePosting.AutoSize = true;
            this.checkBoxSavePosting.Location = new System.Drawing.Point(490, 54);
            this.checkBoxSavePosting.Name = "checkBoxSavePosting";
            this.checkBoxSavePosting.Size = new System.Drawing.Size(103, 20);
            this.checkBoxSavePosting.TabIndex = 155;
            this.checkBoxSavePosting.Text = "حفظ وترحيل";
            this.checkBoxSavePosting.UseVisualStyleBackColor = true;
            // 
            // buttPrint
            // 
            this.buttPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttPrint.FlatAppearance.BorderSize = 0;
            this.buttPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttPrint.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttPrint.ForeColor = System.Drawing.Color.White;
            this.buttPrint.Image = ((System.Drawing.Image)(resources.GetObject("buttPrint.Image")));
            this.buttPrint.Location = new System.Drawing.Point(660, 22);
            this.buttPrint.Name = "buttPrint";
            this.buttPrint.Size = new System.Drawing.Size(54, 82);
            this.buttPrint.TabIndex = 153;
            this.buttPrint.Text = "طباعة";
            this.buttPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttPrint.UseVisualStyleBackColor = false;
            this.buttPrint.Click += new System.EventHandler(this.buttPrint_Click);
            // 
            // buttPosting
            // 
            this.buttPosting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttPosting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttPosting.FlatAppearance.BorderSize = 0;
            this.buttPosting.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttPosting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttPosting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttPosting.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttPosting.ForeColor = System.Drawing.Color.White;
            this.buttPosting.Image = ((System.Drawing.Image)(resources.GetObject("buttPosting.Image")));
            this.buttPosting.Location = new System.Drawing.Point(600, 22);
            this.buttPosting.Name = "buttPosting";
            this.buttPosting.Size = new System.Drawing.Size(54, 82);
            this.buttPosting.TabIndex = 152;
            this.buttPosting.Text = "ترحيل";
            this.buttPosting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttPosting.UseVisualStyleBackColor = false;
            this.buttPosting.Click += new System.EventHandler(this.buttPosting_Click);
            // 
            // CountRows
            // 
            this.CountRows.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CountRows.Enabled = false;
            this.CountRows.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountRows.Location = new System.Drawing.Point(162, 44);
            this.CountRows.Name = "CountRows";
            this.CountRows.ReadOnly = true;
            this.CountRows.Size = new System.Drawing.Size(133, 33);
            this.CountRows.TabIndex = 151;
            this.CountRows.Text = "1111-1111";
            this.CountRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttLast
            // 
            this.buttLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttLast.FlatAppearance.BorderSize = 0;
            this.buttLast.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttLast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttLast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttLast.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttLast.ForeColor = System.Drawing.Color.White;
            this.buttLast.Image = ((System.Drawing.Image)(resources.GetObject("buttLast.Image")));
            this.buttLast.Location = new System.Drawing.Point(35, 22);
            this.buttLast.Name = "buttLast";
            this.buttLast.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.buttLast.Size = new System.Drawing.Size(57, 82);
            this.buttLast.TabIndex = 150;
            this.buttLast.Text = "الاخير";
            this.buttLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttLast.UseVisualStyleBackColor = false;
            this.buttLast.Click += new System.EventHandler(this.buttLast_Click);
            // 
            // buttBack
            // 
            this.buttBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBack.FlatAppearance.BorderSize = 0;
            this.buttBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBack.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttBack.ForeColor = System.Drawing.Color.White;
            this.buttBack.Image = ((System.Drawing.Image)(resources.GetObject("buttBack.Image")));
            this.buttBack.Location = new System.Drawing.Point(98, 22);
            this.buttBack.Name = "buttBack";
            this.buttBack.Size = new System.Drawing.Size(57, 82);
            this.buttBack.TabIndex = 149;
            this.buttBack.Text = "السابق";
            this.buttBack.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttBack.UseVisualStyleBackColor = false;
            this.buttBack.Click += new System.EventHandler(this.buttBack_Click);
            // 
            // buttNext
            // 
            this.buttNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttNext.FlatAppearance.BorderSize = 0;
            this.buttNext.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttNext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttNext.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttNext.ForeColor = System.Drawing.Color.White;
            this.buttNext.Image = ((System.Drawing.Image)(resources.GetObject("buttNext.Image")));
            this.buttNext.Location = new System.Drawing.Point(301, 22);
            this.buttNext.Name = "buttNext";
            this.buttNext.Size = new System.Drawing.Size(57, 82);
            this.buttNext.TabIndex = 148;
            this.buttNext.Text = "التالي";
            this.buttNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttNext.UseVisualStyleBackColor = false;
            this.buttNext.Click += new System.EventHandler(this.buttNext_Click);
            // 
            // buttFrist
            // 
            this.buttFrist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFrist.FlatAppearance.BorderSize = 0;
            this.buttFrist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttFrist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttFrist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttFrist.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttFrist.ForeColor = System.Drawing.Color.White;
            this.buttFrist.Image = ((System.Drawing.Image)(resources.GetObject("buttFrist.Image")));
            this.buttFrist.Location = new System.Drawing.Point(364, 22);
            this.buttFrist.Name = "buttFrist";
            this.buttFrist.Size = new System.Drawing.Size(57, 82);
            this.buttFrist.TabIndex = 147;
            this.buttFrist.Text = "الاول";
            this.buttFrist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttFrist.UseVisualStyleBackColor = false;
            this.buttFrist.Click += new System.EventHandler(this.buttFrist_Click);
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.FlatAppearance.BorderSize = 0;
            this.buttDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.Location = new System.Drawing.Point(720, 22);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(57, 82);
            this.buttDelete.TabIndex = 146;
            this.buttDelete.Text = "حذف";
            this.buttDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttDelete.UseVisualStyleBackColor = false;
            this.buttDelete.Click += new System.EventHandler(this.buttDelete_Click);
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.Location = new System.Drawing.Point(783, 22);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(57, 82);
            this.buttEdite.TabIndex = 145;
            this.buttEdite.Text = "تعديل";
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttEdite.UseVisualStyleBackColor = false;
            this.buttEdite.Click += new System.EventHandler(this.buttEdite_Click);
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.Location = new System.Drawing.Point(846, 22);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(57, 82);
            this.butSave.TabIndex = 144;
            this.butSave.Text = "حفظ";
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butSave.UseVisualStyleBackColor = false;
            this.butSave.Click += new System.EventHandler(this.butSave_Click);
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.FlatAppearance.BorderSize = 0;
            this.buttAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.Location = new System.Drawing.Point(909, 22);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(57, 82);
            this.buttAdd.TabIndex = 143;
            this.buttAdd.Text = "جديد";
            this.buttAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttAdd.UseVisualStyleBackColor = false;
            this.buttAdd.Click += new System.EventHandler(this.buttAdd_Click);
            // 
            // panDown
            // 
            this.panDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panDown.Controls.Add(this.statusStrip1);
            this.panDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDown.Location = new System.Drawing.Point(0, 618);
            this.panDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDown.Name = "panDown";
            this.panDown.Size = new System.Drawing.Size(1000, 32);
            this.panDown.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.UserId,
            this.UserName,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel4,
            this.userId_add,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel5,
            this.nameOpration,
            this.toolStripStatusLabel8,
            this.idOpration,
            this.toolStripStatusLabel7,
            this.toolStripStatusLabel9,
            this.StatePosting,
            this.toolStripStatusLabel6,
            this.toolStripStatusLabel10,
            this.CurrId});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1000, 32);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(96, 27);
            this.toolStripStatusLabel1.Text = "المستخدم الحالي :";
            // 
            // UserId
            // 
            this.UserId.ForeColor = System.Drawing.Color.White;
            this.UserId.Name = "UserId";
            this.UserId.Size = new System.Drawing.Size(0, 27);
            // 
            // UserName
            // 
            this.UserName.ForeColor = System.Drawing.Color.White;
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(60, 27);
            this.UserName.Text = "nameUser";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel2.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(15, 27);
            this.toolStripStatusLabel2.Text = "||";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(84, 27);
            this.toolStripStatusLabel4.Text = "أضافة المستخدم :";
            // 
            // userId_add
            // 
            this.userId_add.ForeColor = System.Drawing.Color.White;
            this.userId_add.Name = "userId_add";
            this.userId_add.Size = new System.Drawing.Size(23, 27);
            this.userId_add.Text = "AA";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel3.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(15, 27);
            this.toolStripStatusLabel3.Text = "||";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(59, 27);
            this.toolStripStatusLabel5.Text = "اسم العملية:";
            // 
            // nameOpration
            // 
            this.nameOpration.ForeColor = System.Drawing.Color.White;
            this.nameOpration.Name = "nameOpration";
            this.nameOpration.Size = new System.Drawing.Size(65, 27);
            this.nameOpration.Text = "NameOpra";
            // 
            // toolStripStatusLabel8
            // 
            this.toolStripStatusLabel8.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel8.Name = "toolStripStatusLabel8";
            this.toolStripStatusLabel8.Size = new System.Drawing.Size(57, 27);
            this.toolStripStatusLabel8.Text = "رقم العملية:";
            // 
            // idOpration
            // 
            this.idOpration.ForeColor = System.Drawing.Color.White;
            this.idOpration.Name = "idOpration";
            this.idOpration.Size = new System.Drawing.Size(43, 27);
            this.idOpration.Text = "idOpra";
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel7.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            this.toolStripStatusLabel7.Size = new System.Drawing.Size(15, 27);
            this.toolStripStatusLabel7.Text = "||";
            // 
            // toolStripStatusLabel9
            // 
            this.toolStripStatusLabel9.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel9.Name = "toolStripStatusLabel9";
            this.toolStripStatusLabel9.Size = new System.Drawing.Size(57, 27);
            this.toolStripStatusLabel9.Text = "حالة السند:";
            // 
            // StatePosting
            // 
            this.StatePosting.ForeColor = System.Drawing.Color.White;
            this.StatePosting.Name = "StatePosting";
            this.StatePosting.Size = new System.Drawing.Size(73, 27);
            this.StatePosting.Text = "StatePosting";
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel6.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            this.toolStripStatusLabel6.Size = new System.Drawing.Size(15, 27);
            this.toolStripStatusLabel6.Text = "||";
            // 
            // toolStripStatusLabel10
            // 
            this.toolStripStatusLabel10.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel10.Name = "toolStripStatusLabel10";
            this.toolStripStatusLabel10.Size = new System.Drawing.Size(53, 27);
            this.toolStripStatusLabel10.Text = "رقم العملة:";
            // 
            // CurrId
            // 
            this.CurrId.ForeColor = System.Drawing.Color.White;
            this.CurrId.Name = "CurrId";
            this.CurrId.Size = new System.Drawing.Size(40, 27);
            this.CurrId.Text = "CurrId";
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.label13);
            this.panUp.Controls.Add(this.txtSerch);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(1000, 37);
            this.panUp.TabIndex = 0;
            this.panUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panUp_MouseDown);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Location = new System.Drawing.Point(825, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(166, 27);
            this.label13.TabIndex = 9;
            this.label13.Text = "        سند قبض";
            // 
            // txtSerch
            // 
            this.txtSerch.BackColor = System.Drawing.Color.DimGray;
            this.txtSerch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSerch.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerch.ForeColor = System.Drawing.Color.White;
            this.txtSerch.Location = new System.Drawing.Point(50, 6);
            this.txtSerch.Name = "txtSerch";
            this.txtSerch.Size = new System.Drawing.Size(316, 23);
            this.txtSerch.TabIndex = 8;
            this.txtSerch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(12, 3);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 27);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 7;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            this.pictureClose.MouseHover += new System.EventHandler(this.pictureClose_MouseHover);
            // 
            // SupportCatch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 650);
            this.Controls.Add(this.panMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "SupportCatch";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "سند صرف";
            this.Load += new System.EventHandler(this.SupportCatch_Load);
            this.panMain.ResumeLayout(false);
            this.panFill.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVBody)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBoxData.ResumeLayout(false);
            this.groupBoxData.PerformLayout();
            this.groupBoxOprea.ResumeLayout(false);
            this.groupBoxOprea.PerformLayout();
            this.panDown.ResumeLayout(false);
            this.panDown.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panFill;
        private System.Windows.Forms.Panel panDown;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.GroupBox groupBoxOprea;
        private System.Windows.Forms.GroupBox groupBoxData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textDebt_foreign;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textRefr_id;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSerch;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textSupport_id;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textCurr_sumbol;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textNote;
        private System.Windows.Forms.Button buttPrint;
        private System.Windows.Forms.Button buttPosting;
        private System.Windows.Forms.TextBox CountRows;
        private System.Windows.Forms.Button buttLast;
        private System.Windows.Forms.Button buttBack;
        private System.Windows.Forms.Button buttNext;
        private System.Windows.Forms.Button buttFrist;
        private System.Windows.Forms.Button buttDelete;
        private System.Windows.Forms.Button buttEdite;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button buttAdd;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.TextBox textAcc_name_fk;
        private System.Windows.Forms.TextBox textAcc_id_fk;
        private System.Windows.Forms.TextBox textBox_name_fk;
        private System.Windows.Forms.TextBox textBox_id_fk;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textCurr_echange;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textPayee;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView DGVBody;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.ToolStripStatusLabel UserName;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel userId_add;
        private System.Windows.Forms.TextBox textDebt_local;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TotalCreditTxt;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TotalDifferenceTxt;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ToolStripStatusLabel UserId;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel nameOpration;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel8;
        private System.Windows.Forms.ToolStripStatusLabel idOpration;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel9;
        private System.Windows.Forms.ToolStripStatusLabel StatePosting;
        private System.Windows.Forms.CheckBox checkBoxSavePosting;
        private System.Windows.Forms.TextBox textDebtWord;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel10;
        private System.Windows.Forms.ToolStripStatusLabel CurrId;
    }
}