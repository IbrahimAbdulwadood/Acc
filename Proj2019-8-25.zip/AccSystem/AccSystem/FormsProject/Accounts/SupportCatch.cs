﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;
using NumberToWord;

namespace AccSystem.FormsProject.Accounts
{
    public partial class SupportCatch : Form
    {
        public SupportCatch(string idUser, Dictionary<string, bool> pre, List<string> idNameOpra)
        {
            
            InitializeComponent();
            UserId.Text = idUser;
            UserName.Text=userSql.GetNameUser(idUser);
            ButtnPre.Clear();
            ButtnPre = pre; 
            if (idNameOpra.Count == 2)
            {
                nameOpration.Text = idNameOpra[1];
                idOpration.Text = idNameOpra[0];
            }
            else MessageBox.Show("لم نستقبل تعريف العمليه");
            DGVBody.Columns[0].Visible = false;
            DGVBody.Columns[8].Visible = false;
            DGVBody.Columns[9].Visible = false;
            DGVBody.Columns[10].Visible = false;
        }

        #region متغيرات داله تحريك الفورم
        /// <summary>
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس
        /// </summary>
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>
        #endregion
        #region المتغيرات والدوال

       
        #region المتغيرات 
      
       Dictionary<string, bool> ButtnPre = new Dictionary<string, bool>(); //الصلاحيات
       SupportCatchSQL SCSql = new SupportCatchSQL();
       CurrSQL CurrClass = new CurrSQL();
       UsersSQL userSql = new UsersSQL();
       List<SupportCatchParametr> ListSupportCatchBodyBeforEdite = new List<SupportCatchParametr>();
       List<SupportCatchParametr> ListSupportCatchBodyAfterEdite = new List<SupportCatchParametr>();

        SupportCatchParametr SupportCatchBodyBeforEdite;
        DataTable DTSupportCatchHaed;
        DataTable DTSupportCatchBody;

        int indexHaed = -1;
        string flagAddOrEdit = "";
        static string ExchingOld = "0"; //يخزن اخر سعر صرف عشان اذا غير السعر وطلع خطا لانه الصيغه موش صح يرجع السعر القديم
        string OpenOrClose = ""; //اقفل او فتح الاحرف والارقام في الداتا جريت فيو
        EntriesAccList eal; // لسته للحسابات
        SupportBoxUserList sbu; //لسته لعرض الصناديق المتاحة للمستخدم

        #region متغيرات الترحيل
        PostingSQL postingSql = new PostingSQL();
        static  bool stingPosting = false;
        /*
        stingPosting المتغير
        عند استدعاء صلاحيات الازرار اروح افحصه 
        اذا حالته نعم 
        يعني السند مرحل 
        يعني وقف زر التعديل والترحيل 
        مالم خليها حسب صلاحيات المستخدم
        */
       
        #endregion
        #endregion
        //////////
        #region الدوال
        #region داله الصلاحيات
        void Permissions(string AddOrLoad)
        {
            if (ButtnPre.Count > 0)
            {
                #region البيانات المستلمه
                /*
            ButtnPreCheck.Add("Showed", Convert.ToBoolean(DTpr.Rows[0][2].ToString()));
            ButtnPreCheck.Add("Inserted", Convert.ToBoolean(DTpr.Rows[0][3].ToString()));
            ButtnPreCheck.Add("EditeDate", Convert.ToBoolean(DTpr.Rows[0][4].ToString()));
            ButtnPreCheck.Add("Posting", Convert.ToBoolean(DTpr.Rows[0][5].ToString()));
            ButtnPreCheck.Add("Saerch", Convert.ToBoolean(DTpr.Rows[0][6].ToString()));
            ButtnPreCheck.Add("Printed", Convert.ToBoolean(DTpr.Rows[0][7].ToString()));
            ButtnPreCheck.Add("Updated", Convert.ToBoolean(DTpr.Rows[0][8].ToString()));
            ButtnPreCheck.Add("Deleted", Convert.ToBoolean(DTpr.Rows[0][9].ToString()));
                */
                #endregion
                bool result;
                if (AddOrLoad == "Load")
                {
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Deleted", out result))
                        buttDelete.Enabled = result;
                    // MessageBox.Show(result.ToString());
                    else MessageBox.Show("لما نستقبل صلاحية الحذف");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Inserted", out result))
                        buttAdd.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية الاضافة");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Updated", out result))
                        buttEdite.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية التعديل");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Posting", out result))
                     buttPosting.Enabled = result;  //اذا قد تم ترحيل هذا السند يكون فولس برجع له
                     else MessageBox.Show("لما نستقبل صلاحية الترحيل");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Printed", out result))
                        buttPrint.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية الطباعة");
                }
                else if (AddOrLoad == "Add")
                {
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("EditeDate", out result))
                        dateTimePicker1.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية تعديل التاريخ");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Posting", out result))
                    {
                        //buttPosting.Enabled = result;  //اذا قد تم ترحيل هذا السند يكون فولس برجع له
                        checkBoxSavePosting.Checked = false;
                        checkBoxSavePosting.Enabled = result;
                    }

                    else MessageBox.Show("لما نستقبل صلاحية الترحيل");
                }
            }

        }
        #endregion
        #region التعامل مع قواعد البيانات 
        void fillData(string NormalOrSerch)
        {
            if (DTSupportCatchHaed != null)
                DTSupportCatchHaed = null;

            DTSupportCatchHaed = new DataTable();

            if (NormalOrSerch == "All")
                DTSupportCatchHaed = SCSql.GetAllSupportCatchHead();

            else if (NormalOrSerch == "Serch")
                DTSupportCatchHaed = SCSql.SerchSupportCatchHead(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                if (DTSupportCatchHaed.Rows.Count > 0)
                { indexHaed = 0; FillTextBox(indexHaed); }
                else if (DTSupportCatchHaed.Rows.Count == 0)
                { ClearAllTextBox(); DGVBody.Rows.Clear(); }
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString()); }

        }
        void Delet(string textSupport_id = "-1")
        {
            SCSql.Delet(textSupport_id);
            fillData("All");
            //DELETE FROM [dbo].[SupportCatchHead]
          //  WHERE Support_id = 1
        }
        void posting(string RefPost="-1")
        {
           /*
           قبل عمليه الترحيل
           اذا كانت حاله السند غير مرحله
           اروح اتاكد من جدول اليومية اذا كان موجود هناك او لا
           في حال كان موجود خليه يطلع 
           رساله خطأ للمستخدم يرجى مراجعة الدعم الفني
           خطأ في عمليه الترحيل
           مالم يرحل طبيعي
            
            */
            if(
                postingSql.CheckPostingOrNot(idOpration.Text, RefPost) //يفحص من جدول اليومية
                &&
                RefPost!="-1"
                &&
                stingPosting== false //يفحص حاله السند من جدول سندات القبض
                )
            {
                MessageBox.Show("لا يمكن ترحيل هذا السند"+"\n"+"يرجى مراجعة مدير النظام او الدعم الفني", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                MessageBox.Show(RefPost,"حالته موش مرحل وهو مرحل مغالط");
            }
            else if(
                !postingSql.CheckPostingOrNot(idOpration.Text, RefPost)
                &&
                RefPost == "-1")
            {
                MessageBox.Show("خطأ في رقم المرجع عند الترحيل", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else if
                (
                !postingSql.CheckPostingOrNot(idOpration.Text, RefPost)
                &&
                  RefPost != "-1"
                )
            {
                
                postingSql.PostSupportCatch(RefPost, idOpration.Text, UserId.Text);
                fillData("All");

            }


            /*
            باقي عند تشغيل البرنامج يروح يحفظ جميع السندات الي مشيك عليهم انهم مرحلين
            بعدين يروح يفحص في اليومية العامة اذا مهلوش يحفظه
            عشان يعرض داتا جريت فيو يوجد سندات فيها اخطاء يرجى مراجعة الدعم الفني او مدير النظام
            */
            
        }
        string DebitLocal()
        { //مدين محلي
            if (textCurr_echange.Text != string.Empty&& textBox_id_fk.Tag!=null)
            {
                if (CurrClass.CurrIsLockalWithBoxUser(textBox_id_fk.Tag.ToString()) == "1")
                {
                    //MessageBox.Show(CurrClass.CurrIsLockalWithBoxUser(textBox_id_fk.Tag.ToString()), "DebitLocal() return is : "+ textDebt_local.Text);
                 return textDebt_foreign.Text;

                }
                else
                {
                    //MessageBox.Show(CurrClass.CurrIsLockalWithBoxUser(textBox_id_fk.Tag.ToString()), "DebitLocal() return is : " + textDebt_local.Text);
                    return textDebt_local.Text;
                }
            }
            return "0";
        }

        //Debt_local مدين محلي
        string DebitForgin()
        {
            if (textCurr_echange.Text != string.Empty && textBox_id_fk.Tag != null)
            {
                if (CurrClass.CurrIsLockalWithBoxUser(textBox_id_fk.Tag.ToString()) == "1")
                {
                    return "0";
                }
                else
                {
                    return textDebt_foreign.Text;
                   
                }
            }
            return "0";
        }

        void ShowBodySupportCatch(string Support_id="-1")
        {//Done

            
                if (DTSupportCatchBody != null)
                    DTSupportCatchBody = null;
                DTSupportCatchBody = new DataTable();
                DTSupportCatchBody = SCSql.GetAllSupportCatchBody(Support_id);

          
            #region Data From Table SupportCatchBody
            /*

                                       ( dataTable)
             SupportCatchBody.SupportBody_id,
             Accounts.Acc_id, 
             Accounts.Acc_name,
             Currencys.Curr_name, 
             SupportCatchBody.CurrExching,
             SupportCatchBody.Credit_local, 
             SupportCatchBody.Credit_foreign,
             SupportCatchBody.Note,
             SupportCatchBody.AccCurr_id_fk
    
      
            */
            #endregion



            DGVBody.Rows.Clear();
               
         
            if (DTSupportCatchBody != null && DTSupportCatchBody.Rows.Count > 0)
            {
                for (int i = 0; i < DTSupportCatchBody.Rows.Count; i++)
                {
                     

                        DGVBody.Rows.Add
                        (
                        DTSupportCatchBody.Rows[i][0].ToString(), //التسلسل
                        DTSupportCatchBody.Rows[i][1].ToString(), //رقم الحساب
                        DTSupportCatchBody.Rows[i][2].ToString(), //اسم الحساب
                        DTSupportCatchBody.Rows[i][3].ToString(), //العملة
                        DTSupportCatchBody.Rows[i][4].ToString(), //سعر الصرف
                        DTSupportCatchBody.Rows[i][5].ToString(), //دائن محلي
                        DTSupportCatchBody.Rows[i][6].ToString(), //دائن اجنبي
                        DTSupportCatchBody.Rows[i][7].ToString(), //البيان
                        DTSupportCatchBody.Rows[i][8].ToString(), //حسابات عملات
                       
                        null, //الحد الاعلى
                        null //الحد الادنى


                        );
                    //داله تجيب الحد الاعلى والادنى لكل عمله
                 
               

                } //endForAddData

         

            }
            //  else MessageBox.Show("idEntry is null can't show body","رقم السند = "+ idEntry);
            

        }
    bool CheckAccHaedSameAnyAccBody()
        {
            /*
            تفحص اذا حساب الصندوق الي اعلا السند 
            موجود كمان في تفاصيل السند ترجع نعم
            مالم يكن موجود ترجع لا
            */
            try {
             
                string AccCuIdHaed = SCSql.GetAccCurrIdHaed(textBox_id_fk.Tag.ToString());
               // MessageBox.Show(AccCuIdHaed, "HaedId");
                if (DGVBody.Rows.Count > 0)
                {
                    for (int i = 0; i < DGVBody.Rows.Count; i++)
                    {
                        if (DGVBody.Rows[i].Cells[8].Value != null)
                        {
                           // MessageBox.Show(DGVBody.Rows[i].Cells[8].Value.ToString(), AccCuIdHaed);
                            if (DGVBody.Rows[i].Cells[8].Value.ToString() == AccCuIdHaed)
                                return true;
                        }
                        
                    }
                        
                }
                return false;
            }catch(Exception e) { MessageBox.Show(e.ToString());return true; }
        }
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                #region

                if (textBox_id_fk.Text != string.Empty && textBox_id_fk.Tag != null
                    && textDebt_foreign.Text!=string.Empty&& textCurr_echange.Text!=string.Empty
                    && textPayee.Text!=string.Empty   && textNote.Text!=string.Empty
                    )
                {
                    /*
                    اولا يتحقق من التالي
                    رقم الصندوق موش فارغ
                    رقم مستخدمين الصناديق موش فارغ
                    تكست المبلغ موش فارغ 
                    سعر الصرف موش فارغ
                    قبضت من الاخ موش فارغ
                    البيان موش فارغ
                    */
                    //   MessageBox.Show(DebitLocal(), "DebitLocal()");
                    //   MessageBox.Show(TotalCreditTxt.Text, "TotalCreditTxt.Text");
                    if (
                        Convert.ToDecimal(TotalDifferenceTxt.Text) == 0 && Convert.ToInt32(TotalCreditTxt.Text) > 0 &&
                        DebitLocal() == TotalCreditTxt.Text
                        )
                    {
                        /* 
                        ثانيا يتحقق من التالي
                        اجمالي المبلغ المقبوض يساوي اجمالي الحسابات الي في التفاصيل*
                        اي ان الفارق يساوي 0 
                        
                       اجمالي المبلغ المقبوض اكبر من الصفر*
  
                        */

                        if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            if (!CheckAccHaedSameAnyAccBody())
                            {
                                /*
                                اذا كان حساب الصندوق اعلا السند 
                                غير موجود في تفاصيل السند خليه يضيف
                                */
                                dateTimePicker1.Format = DateTimePickerFormat.Short;
                                string idSupport
                                         = SCSql.InsertNewSupportCatchHead
                                         (dateTimePicker1.Value.ToShortDateString(),
                                        (textBox_id_fk.Tag).ToString(),
                                        DebitLocal(),
                                        DebitForgin(),
                                        textCurr_echange.Text,
                                        textNote.Text,
                                        (textRefr_id.Text != string.Empty ? textRefr_id.Text : "NULL"),
                                         textPayee.Text,
                                         textDebtWord.Text); //اعمل اضافة للراس واحفظ الاي دي حقه

                           

                                for (int i = 0; i < DGVBody.Rows.Count; i++)
                                {
                                    if (
                                        DGVBody.Rows[i].Cells[1].Value != null
                                        && DGVBody.Rows[i].Cells[3].Value != null
                                        && DGVBody.Rows[i].Cells[8].Value != null
                                        )
                                    {
                                        /*
                                        قبل اضافة التفاصيل يتحقق انه رقم الحساب موش فارغ
                                        و العملة موش فارغة
                                        ورقم حسابات عملات موش فارغ
                                        */


                                        string idAccCurr = DGVBody.Rows[i].Cells[8].Value.ToString();
                                        // MessageBox.Show(DGViewEntryBody.Rows[i].Cells[3].Value.ToString()+"  اسم العملة"+" "+ idAccCurr +" رقم العمله ");

                                        SCSql.InsertNewSupportCatchBody(
                                       idSupport,
                                        idAccCurr,
                                        DGVBody.Rows[i].Cells[5].Value.ToString(), //CreditLocal
                                        DGVBody.Rows[i].Cells[6].Value.ToString(), //CreditFrogen
                                        DGVBody.Rows[i].Cells[7].Value.ToString(), // Note
                                        DGVBody.Rows[i].Cells[4].Value.ToString() //CurrExching

                                        );

                                      

                                    }
                                }

                                MessageBox.Show("تمت الاضافة بنجاح");
                                if (
                                          checkBoxSavePosting.Checked == true
                                          &&
                                          checkBoxSavePosting.Enabled == true
                                          )
                                {
                                    posting(idSupport);

                                }
                                //داله تخزن الحسابات الي ما حددها عشان ينبه المستخدم
                                //   SendAccNullToListError();
                              
                                //if (checkBoxSavePosting.Checked == true)
                                //{
                                //    MessageBox.Show("حفظ وترحيل");
                                //}
                                FormatingTextBoxAndButt("Save");
                                flagAddOrEdit = "";
                                fillData("All");
                                //عرض رسائل التنبية الخاصه ب الحساب الغير مربوطة
                                //  ShowMesgBoxWarningsAccNull();
                            }
                            else MessageBox.Show(" لا يجب ان يكون حساب هذا الصندوق موجود تفاصيل السند","",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                   }
                   else MessageBox.Show("لابد ان يكون اجمالي تفاصيل السند يساوي اجمالي السند اعلاه","",MessageBoxButtons.OK,MessageBoxIcon.Stop);

               }
               else if
                   (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه",
                   MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
               {
                   FormatingTextBoxAndButt("Save");
                   flagAddOrEdit = "";
                   fillData("All");
               }

               #endregion

           }
           else if (flagAddOrEditLo == "Edite")
           {
               if (textBox_id_fk.Text != string.Empty && textBox_id_fk.Tag != null
                    && textDebt_foreign.Text != string.Empty && textCurr_echange.Text != string.Empty
                    && textPayee.Text != string.Empty && textNote.Text != string.Empty
                    )
               {
                    #region ملاحظة
                    /*
                    اولا يتحقق من التالي
                    رقم الصندوق موش فارغ
                    رقم مستخدمين الصناديق موش فارغ
                    تكست المبلغ موش فارغ 
                    سعر الصرف موش فارغ
                    قبضت من الاخ موش فارغ
                    البيان موش فارغ
                    */
                    #endregion
                    if (
                         Convert.ToInt32(TotalDifferenceTxt.Text) == 0 && Convert.ToInt32(TotalCreditTxt.Text) > 0 &&
                        DebitLocal() == TotalCreditTxt.Text
                        )
                    {
                        #region ملاحظة
                        /* 
                        ثانيا يتحقق من التالي
                        اجمالي المبلغ المقبوض يساوي اجمالي الحسابات الي في التفاصيل*
                        اي ان الفارق يساوي 0 
                        
                       اجمالي المبلغ المقبوض اكبر من الصفر*
  
                        */
                        #endregion
                       
                       
                        if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        {
                            if (CheckAccHaedSameAnyAccBody() == false)
                            {
                               // MessageBox.Show("يمكن التعديل");

                                // SendAccNullToListError();
                                #region اذا عدد العناصر قبل التعديل يساوي عدد العناصر بعد التعديل
                                if ((ListSupportCatchBodyAfterEdite.Count >= ListSupportCatchBodyBeforEdite.Count))
                                {

                                    //

                                    #endregion


                                    //يضيف صفوف جديدة في الجدول
                                    #region
                                    int index = 0;

                                    for (int i = 0; i < ListSupportCatchBodyAfterEdite.Count; i++)
                                    {
                                        if (ListSupportCatchBodyBeforEdite.Count > index)
                                        {
                                            SCSql.UpdateSupportCatchBody(
                                  textSupport_id.Text,
                                  ListSupportCatchBodyBeforEdite[i].SupportBody_id,
                                  ListSupportCatchBodyAfterEdite[index].AccCurr_id,
                                  ListSupportCatchBodyAfterEdite[index].Credit_local,
                                  ListSupportCatchBodyAfterEdite[index].Credit_foreign,
                                  ListSupportCatchBodyAfterEdite[index].Note,
                                  ListSupportCatchBodyAfterEdite[index].Curr_echange);
                                            //MessageBox.Show(ListEntrisBodyAfterEdite[index].AccCurr_id,"Update");
                                            index++;

                                        }
                                        else if (ListSupportCatchBodyAfterEdite.Count > index)
                                        {

                                            SCSql.InsertNewSupportCatchBody(
                                  textSupport_id.Text,
                                  ListSupportCatchBodyAfterEdite[index].AccCurr_id,
                                  ListSupportCatchBodyAfterEdite[index].Credit_local,
                                  ListSupportCatchBodyAfterEdite[index].Credit_foreign,
                                  ListSupportCatchBodyAfterEdite[index].Note,
                                  ListSupportCatchBodyAfterEdite[index].Curr_echange);
                                            //MessageBox.Show(ListEntrisBodyAfterEdite[index].AccCurr_id, "Insert");
                                            index++;
                                        }

                                    }

                                    //
                                    #endregion
                                }


                                else if ((ListSupportCatchBodyAfterEdite.Count < ListSupportCatchBodyBeforEdite.Count))
                                {
                                    #region
                                    //يحذف جميع الصفوف من الجدول ويرجع يمليهم من جديد
                                    int index = 0;

                                    for (int i = 0; i < ListSupportCatchBodyBeforEdite.Count; i++)
                                    {
                                        if (ListSupportCatchBodyAfterEdite.Count > index)
                                        {
                                            SCSql.UpdateSupportCatchBody(
                                          textSupport_id.Text,
                                          ListSupportCatchBodyBeforEdite[i].SupportBody_id,
                                          ListSupportCatchBodyAfterEdite[index].AccCurr_id,
                                          ListSupportCatchBodyAfterEdite[index].Credit_local,
                                          ListSupportCatchBodyAfterEdite[index].Credit_foreign,
                                          ListSupportCatchBodyAfterEdite[index].Note,
                                          ListSupportCatchBodyAfterEdite[index].Curr_echange);
                                            //MessageBox.Show(ListEntrisBodyAfterEdite[index].AccCurr_id,"Update");
                                            index++;

                                        }
                                        else if (ListSupportCatchBodyBeforEdite.Count > index)
                                        {
                                            //  MessageBox.Show(ListSupportCatchBodyBeforEdite[i].SupportBody_id);
                                            SCSql.DeleteSupportCatchBody
                                                (
                                              textSupport_id.Text, ListSupportCatchBodyBeforEdite[i].SupportBody_id
                                               );
                                            index++;
                                        }
                                    }
                                    #endregion

                                }

                                SCSql.UpdateSupportCatchHaed(
                                     textSupport_id.Text,
                                     dateTimePicker1.Value.ToShortDateString(),
                                     textBox_id_fk.Tag.ToString(),
                                     DebitLocal(),
                                     DebitForgin(),
                                     textCurr_echange.Text,
                                     textNote.Text,
                                     textPayee.Text,
                                     (textRefr_id.Text != string.Empty ? textRefr_id.Text : "NULL")
                                     ,textDebtWord.Text
                                     );

                                MessageBox.Show("تم التعديل بنجاح");
                                // ShowMesgBoxWarningsAccNull();
                                if (checkBoxSavePosting.Checked == true)
                                {
                                    posting(textSupport_id.Text);
                                    MessageBox.Show("حفظ وترحيل","تعديل");
                                }
                                FormatingTextBoxAndButt("Save");
                                flagAddOrEdit = "";
                                fillData("All");
                            }
                            else { MessageBox.Show("لا يمكن التعديل لان رقم حساب هذا الصندوق موجود في تفاصيل السند"); }    
                        }

                        else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    }
                    else MessageBox.Show("لابد ان يكون اجمالي تفاصيل السند يساوي اجمالي السند اعلاه  ");
                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }

        #endregion

        #region FillData And Control
        void MoveForm(MouseEventArgs e)
        {
            //MouseDown
            //داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        void SetDataBodySupportCatchAfterEdite()
        {
            try
            {
                ListSupportCatchBodyAfterEdite.Clear();


                if ((DGVBody.Rows.Count) > 0)
                {
                    
                        for (int i = 0; i < DGVBody.Rows.Count; i++)
                        {
                            #region

                            if (
                        #region


                            DGVBody.Rows[i].Cells[1].Value != null && // رقم الحساب
                            DGVBody.Rows[i].Cells[3].Value != null && //العملة 
                            DGVBody.Rows[i].Cells[4].Value != null && //سعر الصرف 
                            DGVBody.Rows[i].Cells[5].Value != null && //دائن محلي 
                            DGVBody.Rows[i].Cells[6].Value != null && //دائن اجنبي 
                            DGVBody.Rows[i].Cells[7].Value != null && //البيان
                            DGVBody.Rows[i].Cells[8].Value != null && //AccCurrId

                            textSupport_id.Text != string.Empty //رقم السند
                            #endregion
                        )
                            {
                                if (SupportCatchBodyBeforEdite != null)
                                SupportCatchBodyBeforEdite = null;
                            SupportCatchBodyBeforEdite = new SupportCatchParametr();

                            #region

                           

                            SupportCatchBodyBeforEdite.Curr_echange =
                                    DGVBody.Rows[i].Cells[4].Value.ToString(); //سعر الصرف


                            
                            SupportCatchBodyBeforEdite.Credit_local =
                                    DGVBody.Rows[i].Cells[5].Value.ToString();//دائن محلي

                            SupportCatchBodyBeforEdite.Credit_foreign =
                                    DGVBody.Rows[i].Cells[6].Value.ToString(); //دائن اجنبي

                            SupportCatchBodyBeforEdite.Note = 
                                DGVBody.Rows[i].Cells[7].Value.ToString(); //البيان 

                            SupportCatchBodyBeforEdite.AccCurr_id =
                                   DGVBody.Rows[i].Cells[8].Value.ToString();//AccCurrId

                            ListSupportCatchBodyAfterEdite.Add(SupportCatchBodyBeforEdite);
                                #endregion




                            }
                            #endregion

                        }

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "Error in Func SetDataEntriBodyABeforEdite()");
            }


        }
        void SetDataEntriBodyBeforEdite()
        {
            try
            {
                ListSupportCatchBodyBeforEdite.Clear();

                if ((DGVBody.Rows.Count) > 0)
                {
                    
                        for (int i = 0; i < DGVBody.Rows.Count; i++)
                        {
                            #region

                            if (
                            #region

                            DGVBody.Rows[i].Cells[0].Value != null && //التسلسل
                            DGVBody.Rows[i].Cells[4].Value != null && //سعر الصرف 
                            DGVBody.Rows[i].Cells[5].Value != null && //دائن محلي 
                            DGVBody.Rows[i].Cells[6].Value != null && //دائن اجنبي 
                            DGVBody.Rows[i].Cells[7].Value != null && //البيان
                            DGVBody.Rows[i].Cells[8].Value != null && //AccCurrId
                            textSupport_id.Text != string.Empty //رقم السند
                            #endregion
                        )
                            {
                                if (SupportCatchBodyBeforEdite != null)
                                SupportCatchBodyBeforEdite = null;
                            SupportCatchBodyBeforEdite = new SupportCatchParametr();

                            #region

                            SupportCatchBodyBeforEdite.AccCurr_id =
                                    DGVBody.Rows[i].Cells[8].Value.ToString();//AccCurrId

                            SupportCatchBodyBeforEdite.Curr_echange =
                                    DGVBody.Rows[i].Cells[4].Value.ToString(); //سعر الصرف

                            SupportCatchBodyBeforEdite.SupportBody_id =
                                    DGVBody.Rows[i].Cells[0].Value.ToString(); // التسلسل
                                                                               //MessageBox.Show(DGVBody[j].Rows[i].Cells[0].Value.ToString());
                            SupportCatchBodyBeforEdite.Credit_local =
                                    DGVBody.Rows[i].Cells[5].Value.ToString();//دائن محلي

                            SupportCatchBodyBeforEdite.Credit_foreign =
                                    DGVBody.Rows[i].Cells[6].Value.ToString(); //دائن اجنبي



                            SupportCatchBodyBeforEdite.Note =
                                    DGVBody.Rows[i].Cells[7].Value.ToString(); //البيان

                            ListSupportCatchBodyBeforEdite.Add(SupportCatchBodyBeforEdite);
                                #endregion




                            }
                            #endregion

                        }

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "Error in Func SetDataEntriBodyABeforEdite()");
            }
        }

     
        void StopAlphaInColumn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (OpenOrClose == "CloseAlpha")
            {     //IsPunctuation الفواصل العشرية
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsPunctuation(e.KeyChar))
                {
                    e.Handled = true;
                }

            }
            else if (OpenOrClose == "OpenAll") e.Handled = false;

            else if (OpenOrClose == "CloseAll")
            {
                e.Handled = true;

            }
            // OpenOrClose = string.Empty;
        }
        void StopAlphaFromDataGridView_EditingControlShowing(DataGridViewEditingControlShowingEventArgs e, int IndexColums)
        { //Doneeeeee
            try
            {
                int CurrentCellColumIndex = -1;
                //used in even dataGridView_EditingControlShowing
                e.Control.KeyPress -= new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
                
                    CurrentCellColumIndex = DGVBody.CurrentCell.ColumnIndex;
                
                

                if (CurrentCellColumIndex == IndexColums)
                {
                    TextBox tb = e.Control as TextBox;
                    if (tb != null)
                    {
                        tb.KeyPress += new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
                        //  tb.KeyPress+=new KeyPressEventHandler(StopAlphaInTextBox);
                    }
                }
            }
            catch { MessageBox.Show("StopAlphaFromDataGridView_EditingControlShowing Function", "Error"); }



        }
        void ShowListAcc(object sender, KeyEventArgs e)
        {

            if (e.KeyData == Keys.F9 || e.KeyData == Keys.Delete)
            {
                if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                {
                    List<string> AccCurrIdEx2 = new List<string>();



                    if (e.KeyData == Keys.Delete && OpenOrClose == "CloseAll")
                    {
                        e.Handled = true;
                    }
                    else
                    {
                        
                        int i = DGVBody.CurrentCell.RowIndex;
                        int j = DGVBody.CurrentCell.ColumnIndex;
                        if (textBox_id_fk.Tag != null)
                        {
                            if (j == 1)
                            {
                                try
                                {

                                    try
                                    {

                                        ////MessageBox.Show(DGVBody[0].Rows.Count.ToString(), DGVBody[1].Rows.Count.ToString()
                                        //       );
                                        //MessageBox.Show((1+ind).ToString());
                                        if (DGVBody.Rows.Count > 0)
                                        {

                                            try
                                            {
                                                for (int x = 0; x < DGVBody.Rows.Count; x++)
                                                {
                                                    if
                                                    (
                                                    DGVBody.Rows[x].Cells[1].Value != null
                                                    && DGVBody.Rows[x].Cells[8].Value != null
                                                    )
                                                    {
                                                        AccCurrIdEx2.Add(DGVBody.Rows[x].Cells[8].Value.ToString());

                                                    }
                                                    //else MessageBox.Show("Loool");
                                                }


                                            }
                                            catch (Exception eee) { MessageBox.Show(eee.ToString(), "Line 740"); }
                                        }




                                    }
                                    catch (Exception ee)
                                    {
                                        MessageBox.Show(ee.ToString(), "Error in fill AccCurrIdEx {ShowListAcc}  ");
                                    }

                                    eal = new EntriesAccList(AccCurrIdEx2);
                                    eal.ShowDialog();

                                    if (EntriesAccList.AccSelection.Count > 0)
                                    {

                                        List<EntriesParametr> AccSelection99 = EntriesAccList.AccSelection;


                                        for (int indx = 0; indx < AccSelection99.Count; indx++)
                                        {

                                            DGVBody.Rows.Add
                                                            (
                                                             "", //التسلسل
                                                             AccSelection99[indx].Acc_id_fk, //
                                                             AccSelection99[indx].Acc_name, //
                                                             AccSelection99[indx].Curr_name, //
                                                              AccSelection99[indx].Curr_echange, //
                                                              "0", //دائن محلي
                                                              "0", //دائن اجنبي
                                             " سنــد قبض رقم" + textSupport_id.Text + "  " + textNote.Text,//البيان

                                                               AccSelection99[indx].AccCurr_id, //
                                                              null, //الحد الاعلى
                                                              null //الحد الادنى
                                                            );

                                        }
                                        EntriesAccList.AccSelection.Clear();
                                        AccSelection99.Clear();
                                        //نستدعي داله تفحص جميع  العناصر عشان تعمل الفورمتنج حق العملات الاجنبية
                                        //FormatingDataGridViewCurrExching("Add");





                                    }

                                    if (eal != null)
                                        eal = null;
                                }

                                catch (Exception ee) { MessageBox.Show(ee.ToString(), "ShowListAcc try"); }
                            }
                        }
                        else MessageBox.Show("يرجى تعبئة رأس السند اولا","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    }
                }
            }
        }
        void afterCellEndEditDataGridView()
        { //Doneeeee
            
                   if (DGVBody.Rows.Count > 0)
                {
                    if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                    {



                        int i = DGVBody.CurrentCell.RowIndex;
                        int j = DGVBody.CurrentCell.ColumnIndex;

                        if (j == 4) // سعر الصرف
                        {
                            #region
                            if (DGVBody.Rows[i].Cells[4].Value == null //سعر الصرف
                                && DGVBody.Rows[i].Cells[3].Value != null //العملة
                                && DGVBody.Rows[i].Cells[2].Value != null //اسم الحساب
                                && DGVBody.Rows[i].Cells[1].Value != null) //رقم الحساب
                            {
                                DGVBody.Rows[i].Cells[4].Value = ExchingOld;

                            }

                            //يروح يتحقق من سعر الصرف من القيم الادنى والاعلى للصرف
                            if (DGVBody.Rows[i].Cells[4].Value != null //سعر الصرف
                                && DGVBody.Rows[i].Cells[3].Value != null) //العملة
                            {
                                #region
                                try
                                {
                                    #region
                                    if (
                                       (
                                       DGVBody.Rows[i].Cells[9].Value != null //CurrMax
                                        && DGVBody.Rows[i].Cells[9].Value.ToString() != "0" //
                                       )
                                       ||
                                       (
                                       DGVBody.Rows[i].Cells[10].Value != null //CurrMin
                                        && DGVBody.Rows[i].Cells[10].Value.ToString() != "0"
                                       )
                                       )
                                    {
                                        #region

                                        if (Convert.ToDouble(DGVBody.Rows[i].Cells[4].Value.ToString()) < Convert.ToDouble(DGVBody.Rows[i].Cells[10].Value.ToString()))
                                        {
                                            MessageBox.Show(" \n سعر الصرف اقل من الحد الادنى\n  " + "الحد الادنى = " + DGVBody.Rows[i].Cells[10].Value.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            DGVBody.Rows[i].Cells[4].Value = ExchingOld;
                                        }
                                        else if (Convert.ToDouble(DGVBody.Rows[i].Cells[4].Value.ToString()) > Convert.ToDouble(DGVBody.Rows[i].Cells[9].Value.ToString()))
                                        {
                                            MessageBox.Show(" \n سعر الصرف اكبر من الحد الاعلى\n  " + "الحد الاعلى  = " + DGVBody.Rows[i].Cells[9].Value.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            DGVBody.Rows[i].Cells[4].Value = ExchingOld;
                                        }

                                        #endregion
                                    }

                                    else
                                    {
                                        #region

                                        if (Convert.ToDouble(DGVBody.Rows[i].Cells[4].Value.ToString()) <= 1)
                                        {
                                            MessageBox.Show("سعر الصرف المدخل لا يمكن ان يكون اقل من الواحد");
                                            //DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                        }
                                        DGVBody.Rows[i].Cells[4].Value = ExchingOld;
                                        #endregion
                                    }
                                    ExchingOld = DGVBody.Rows[i].Cells[4].Value.ToString();
                                    #endregion
                                }
                                catch
                                {
                                    MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "bemoo", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                                    DGVBody.Rows[i].Cells[4].Value = ExchingOld;//سعر الصرف

                                }
                                try
                                {
                                    DGVBody.Rows[i].Cells[5].Value = //دائن محلي
                                        ((Convert.ToDouble(DGVBody.Rows[i].Cells[6].Value) * //دائن اجنبي
                                            Convert.ToDouble(DGVBody.Rows[i].Cells[4].Value)).ToString()); //سعر الصرف

                             

                                }
                                catch
                                {
                                    MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                                    DGVBody.Rows[i].Cells[5].Value = "0"; //دائن محلي
                                    DGVBody.Rows[i].Cells[6].Value = "0"; //دائن اجنبي
                                   

                                }
                                #endregion

                            }
                            else
                            {
                                // DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                DGVBody.CurrentRow.Cells[4].ReadOnly = true;
                            }

                            #endregion
                        }
                        if (j == 5) // دائن محلي
                        {
                            #region

                            if (DGVBody.Rows[i].Cells[4].Value != null //سعر الصرف
                                
                                )
                            {
                            if(DGVBody.Rows[i].Cells[5].Value == null)
                            {
                                MessageBox.Show("الحقل قيمة فارغة", "دائن محلي", MessageBoxButtons.OK,
                                       MessageBoxIcon.Error);
                                DGVBody.Rows[i].Cells[5].Value = "0";
                            }
                              
                            if(DGVBody.Rows[i].Cells[4].Value.ToString()=="1")//اذا كانت العمله محليه خلي الاجنبي بصفر
                                DGVBody.Rows[i].Cells[6].Value = "0";

                        }
                            
                           
                           
                            #endregion
                        }
                       
                        if (j == 6) // دائن اجنبي
                        {
                            #region

                            if (
                                DGVBody.Rows[i].Cells[4].Value != null //سعر الصرف
                               && DGVBody.Rows[i].Cells[6].Value != null //دائن اجنبي 
                                )
                            {
                                #region
                               
                                DGVBody.Rows[i].Cells[5].Value = "0"; //دائن محلي
                                try
                                {
                                    DGVBody.Rows[i].Cells[5].Value =  //دائن محلي
                                Convert.ToDouble(DGVBody.Rows[i].Cells[6].Value) * //دائن اجنبي
                                Convert.ToDouble(DGVBody.Rows[i].Cells[4].Value);  //سعر الصرف
                                }
                                catch
                                {
                                    MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "دائن اجنبي", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                                    DGVBody.Rows[i].Cells[6].Value = "0"; //مدين اجنبي
                                }
                                #endregion
                            }
                            else
                            {
                                MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "دائن اجنبي", MessageBoxButtons.OK,
                                          MessageBoxIcon.Error);
                                DGVBody.Rows[i].Cells[6].Value = "0";
                            }
                            #endregion
                        }
                     





                    }

                }
         

        }
        void cellClickDataGridView()
        { //عند الضغط على الخليه يستقبل فلاج نوع العمليه عشان يتحكم في الكتابة عليها
            try
            { //Doneeeeeeeee
                #region
              
                    
                    //   MessageBox.Show(DGVBodyIndex.ToString(),"DGVInde");
                    if (DGVBody.Rows.Count > 0)
                    {
                        //DGV1Or2 = "";
                        int i = DGVBody.CurrentCell.RowIndex;
                        int j = DGVBody.CurrentCell.ColumnIndex;

                        if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                        {

                            //DGViewEntryBody.AllowUserToAddRows = true;
                            //DGViewEntryBody.AllowUserToDeleteRows = true;
                            #region


                            DGVBody.Rows[i].Cells[1].ReadOnly = false;
                            if
                            (
                            DGVBody.Rows[i].Cells[1].Value != null && // رقم الحساب
                            DGVBody.Rows[i].Cells[2].Value != null && // اسم الحساب
                            DGVBody.Rows[i].Cells[3].Value != null &&    // العملة
                            DGVBody.Rows[i].Cells[4].Value != null &&    // سعر الصرف
                            DGVBody.Rows[i].Cells[8].Value != null // رقم حسابات عملات
                            )
                            {
                                #region اذا كان رقم واسم الحساب والعملة وسعر الصرف وحساب

                                DGVBody.Rows[i].Cells[0].ReadOnly = true; //التسلسل
                                DGVBody.Rows[i].Cells[1].ReadOnly = false;//رقم الحساب
                                DGVBody.Rows[i].Cells[2].ReadOnly = true; // اسم الحساب
                                DGVBody.Rows[i].Cells[3].ReadOnly = true;// العملة
                                DGVBody.Rows[i].Cells[7].ReadOnly = false; // البيان
                                DGVBody.Rows[i].Cells[8].ReadOnly = true; // رقم حسابات عملات
                                DGVBody.Rows[i].Cells[9].ReadOnly = true; // الحد الاعلى
                                DGVBody.Rows[i].Cells[10].ReadOnly = true; // الحد الادنى


                                string AccCurr_id = (DGVBody.Rows[i].Cells[8]).Value.ToString();


                                if (AccCurr_id != string.Empty)
                                {
                                    #region تحديد اذا كانت العملة محلية ام اجنبية

                                    if (CurrClass.CurrIsLockal(AccCurr_id) == "1")
                                    {
                                        DGVBody.Rows[i].Cells[4].ReadOnly = true;  //وقف تغيير سعر الصرف
                                        DGVBody.Rows[i].Cells[5].ReadOnly = false; //دائن محلي
                                        DGVBody.Rows[i].Cells[6].ReadOnly = true; //دائن اجنبي وقف
                                     }
                                    else if (CurrClass.CurrIsLockal(AccCurr_id) == "0")
                                    {
                                        DGVBody.Rows[i].Cells[4].ReadOnly = false;  //اسمح بتغيير الصرف
                                        DGVBody.Rows[i].Cells[5].ReadOnly = true;   // اوقف دائن محلي
                                        DGVBody.Rows[i].Cells[6].ReadOnly = false;   //  افتح دائن اجنبي
                                       
                                    }
                                    #region يخزن سعر الصرف قبل التعديل

                                    if (j == 4 && DGVBody.Rows[i].Cells[4].ReadOnly == false)
                                        ExchingOld = DGVBody.Rows[i].Cells[4].Value.ToString(); //اتاكد منه
                                    #endregion

                                    #endregion
                                    #region يجيب الحد الاعلى والادنى وسعر الصرف 

                                    string[] currEx = CurrClass.GetCurrEchange(AccCurr_id);
                                    //DGViewEntryBody.Rows[i].Cells[4].Value = currEx[0]; // سعر الصرف
                                    DGVBody.Rows[i].Cells[9].Value = currEx[1]; // الحد الاعلى
                                    DGVBody.Rows[i].Cells[10].Value = currEx[2]; // الحد الادنى
                                    #endregion

                                }
                                else
                                {
                                    MessageBox.Show("AccCurr_id is null", " in function cellClickDataGridView() ");
                                }
                                #endregion

                            }
                            else if (DGVBody.Rows[i].Cells[1].Value == null && DGVBody.Rows.Count == 1)
                            {

                                DGVBody.Rows[0].Cells[1].ReadOnly = false;
                                // MessageBox.Show("");
                            }
                            #endregion

                            // DGVBody[0].Rows[0].Cells[1].ReadOnly = false;
                        }
                        else if (flagAddOrEdit == "Load" || flagAddOrEdit == "Save")
                        {
                            //DGViewEntryBody.AllowUserToAddRows = false;
                            //DGViewEntryBody.AllowUserToDeleteRows = false;

                            #region

                            DGVBody.Rows[i].Cells[0].ReadOnly = true; //التسلسل
                            DGVBody.Rows[i].Cells[1].ReadOnly = true;//رقم الحساب
                            DGVBody.Rows[i].Cells[2].ReadOnly = true; // اسم الحساب
                            DGVBody.Rows[i].Cells[3].ReadOnly = true;// العملة
                            DGVBody.Rows[i].Cells[4].ReadOnly = true; // سعر الصرف
                            DGVBody.Rows[i].Cells[5].ReadOnly = true; // دائن حلي
                            DGVBody.Rows[i].Cells[6].ReadOnly = true; // دائن اجنبي
                            DGVBody.Rows[i].Cells[7].ReadOnly = true; // البيان
                            DGVBody.Rows[i].Cells[8].ReadOnly = true; // رقم حسابات عملات
                            DGVBody.Rows[i].Cells[9].ReadOnly = true; // لحد الاعلى
                            DGVBody.Rows[i].Cells[10].ReadOnly = true; // الحد الادنى
                            
                            #endregion
                        }
                    } //endif DGV.Ro>0
              
                #endregion
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString(), "Error in function cellClickDataGridView() "); }
        }
        void EditingControlShowingDataGridView(object sender, DataGridViewEditingControlShowingEventArgs e)
        { //Doneeeeeeee
            //جعل خصائص الخلايا مثل التكست بوكس
         
                
                if (DGVBody.CurrentCell.ColumnIndex == 1 && e.Control is DataGridViewTextBoxEditingControl)
                {
                    OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 1); //ايقاف الكتابة كاملة
                    //DataGridViewTextBoxEditingControl tb = e.Control as DataGridViewTextBoxEditingControl;
                    DataGridViewTextBoxEditingControl tb = e.Control as DataGridViewTextBoxEditingControl;
                    //e.Control.KeyDown -= ShowListAcc;
                    //e.Control.KeyDown += ShowListAcc;

                    tb.KeyDown -= ShowListAcc;

                    tb.KeyDown += ShowListAcc; //عرض شاشة الحسابات


                }

                /////////////////////////////////////
                else if (DGVBody.CurrentCell.ColumnIndex == 2)
                { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 2); }
                /////////////////////////////////////
                else if (DGVBody.CurrentCell.ColumnIndex == 3)
                { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 3); }

                /////////////////////////////////////
                else if (DGVBody.CurrentCell.ColumnIndex == 4)
                { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 4); } //ايقاف الاحرف فقط
                                                                                                       /////////////////////////////////////
                else if (DGVBody.CurrentCell.ColumnIndex == 5)
                { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 5); }
                /////////////////////////////////////
                else if (DGVBody.CurrentCell.ColumnIndex == 6)
                { OpenOrClose = "CloseAlpha"; StopAlphaFromDataGridView_EditingControlShowing(e, 6); }
                /////////////////////////////////////
                else if (DGVBody.CurrentCell.ColumnIndex == 7)
                { OpenOrClose = "OpenAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 7); }
                /////////////////////////////////////
                

            

        }

        #region داله تحويل اللغه
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }


        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }
        #endregion



    void FillTextBox(int indexRows)
        {
            /*

            */
            if (DTSupportCatchHaed.Rows.Count > 0 && indexRows < DTSupportCatchHaed.Rows.Count && indexRows >= 0)
            {

                int i = indexRows;

                /*
                 
                */
                #region الاستعلام
                /*
                        Support_id, 0
                        Date_support_catch, 1
                        Box_id,  2
                        Box_name,  3
                        Acc_id, 4
                        Acc_name, 5
                        Curr_sumbol_eng, 6
                        Debt_local,  7
                        Debt_foreign, 8
                        CurrExching, 9
                        Note, 10
                        payee, 11
                        User_id, 12
                        User_name, 13
                        BoxUser_id_fk , 14
                        Refr_id ,  15
                        Posting  , 16
	                    TotalWord , 17
	                    Curr_id  18
                  
         
                 
                */
                #endregion

                textSupport_id.Text = DTSupportCatchHaed.Rows[i][0].ToString();
                dateTimePicker1.Value =
                Convert.ToDateTime(DTSupportCatchHaed.Rows[i][1].ToString());
                textBox_id_fk.Text = DTSupportCatchHaed.Rows[i][2].ToString();

                textBox_name_fk.Text = DTSupportCatchHaed.Rows[i][3].ToString();

                textAcc_id_fk.Text = DTSupportCatchHaed.Rows[i][4].ToString();
                textAcc_name_fk.Text = DTSupportCatchHaed.Rows[i][5].ToString();
                textCurr_sumbol.Text = DTSupportCatchHaed.Rows[i][6].ToString();
                textCurr_echange.Text = DTSupportCatchHaed.Rows[i][9].ToString();
                textPayee.Text = DTSupportCatchHaed.Rows[i][11].ToString();
                if (DTSupportCatchHaed.Rows[i][9].ToString() != "1"
                     && DTSupportCatchHaed.Rows[i][8].ToString() != "0" //ارجع افتح التعليق
                    )
                {
                    /*
                    اذا سعر الصرف لا يساوي واحد اي ان العملة اجنبية
                    ومدين اجنبي لا يساوي الصفر عشان اتاكد كمان انه اجنبي
                    خلي تكست المبلغ ياخذ المدين الاجنبي
                    واظهر التكست المخفي واعرض فيه المدين محلي
                    */
                    textDebt_foreign.Text = DTSupportCatchHaed.Rows[i][8].ToString();
                    textDebt_local.Text = DTSupportCatchHaed.Rows[i][7].ToString();
                    textDebt_local.Visible = true;
                }
                else if (DTSupportCatchHaed.Rows[i][9].ToString() == "1" 
                    && DTSupportCatchHaed.Rows[i][8].ToString() == "0" //ارجع افتح التعليق
                    )

                {
                    /*
                    اذا سعر الصرف يساوي واحد اي ان العملط محلية
                    ومدين اجنبي يساوي الصفر عشان اتاكد انه محلي
                    خلي تكست المبلغ ياخذ المدين محلي
                    واخفي التكست الثانيه
                    */
                    textDebt_foreign.Text = DTSupportCatchHaed.Rows[i][7].ToString();
                    textDebt_local.Text = DTSupportCatchHaed.Rows[i][8].ToString();
                    textDebt_local.Visible = true;

                }

                userId_add.Text = DTSupportCatchHaed.Rows[i][12].ToString();
                textNote.Text = DTSupportCatchHaed.Rows[i][10].ToString();
                textRefr_id.Text = DTSupportCatchHaed.Rows[i][15].ToString();
                textBox_id_fk.Tag = DTSupportCatchHaed.Rows[i][14].ToString(); //BoxUser_id

                try
                {
                    #region شرح عمل الداله
                    /*
                    اذا كان السند مرحل خلي الحاله حقه مرحل
                    والغي تفعيل زرار الترحيل والتعديل سواء معاه 
                    صلاحيات او لا 

                    */
                    /*
                    اذا السند لم يكن مرحل خلي الحاله حقه غير مرحل
                    وافتح له زرار الترحيل والتعديل حسب حقه الصلاحيات    
                    */
                    #endregion
                    IsPosting(Convert.ToBoolean(DTSupportCatchHaed.Rows[i][16].ToString()));
                }
           
                catch (Exception ee) { MessageBox.Show(ee.ToString()); }

                CurrId.Text= DTSupportCatchHaed.Rows[i][18].ToString();
                textDebtWord.Text= DTSupportCatchHaed.Rows[i][17].ToString();
                ShowBodySupportCatch(textSupport_id.Text);
                FillTextBoxCountRows((indexHaed + 1).ToString());

            }
            else
            {
                MessageBox.Show("index is: " + indexRows, "DTcount is: " + DTSupportCatchHaed.Rows.Count);
            }


        }
      
        void IsPosting(bool state)
        {
            if (state)
            {
                StatePosting.Text = "مرحل";
                stingPosting = true;
            }
            else
            {
                StatePosting.Text = "غير مرحل";
                stingPosting = false;
            }
        }
    void FillTextBoxCountRows(string index)
        {
            if (Convert.ToUInt32(index) >= 0 && DTSupportCatchHaed !=null && DTSupportCatchHaed.Rows.Count > 0)
                CountRows.Text = index + " - " +
                    DTSupportCatchHaed.Rows.Count.ToString();
            else
                CountRows.Text = "0 - 0";
        }
    int  indexSupportCatchHaedButt(string btName,ref int index)
        {
            /*
            
            
            */
            if (DTSupportCatchHaed.Rows.Count > 0)
            {
              
                

                if (btName == "Frist")
                {

                  //  index = 0;
                    return index=0;
                    
                }
                else if (btName == "Next")
                {
                    if (index < DTSupportCatchHaed.Rows.Count - 1)
                     return   ++index;
                    else { MessageBox.Show("اخر سجل"); return index; }

                }
                else if (btName == "Back")
                {
                    if (index > 0)
                        return --index;
                    else { MessageBox.Show("اول سجل"); return index; }
                }
                else if (btName == "Last")
                {
                    return index = DTSupportCatchHaed.Rows.Count - 1;
                  
                }
              
            }
            else
                MessageBox.Show("لا يوجد سندات في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return index = - 1;
          
        }

    void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {
            //Doneeeeee
            /////////عند التعديل وجديد//////////////
          
            textSupport_id.ReadOnly = true;
            textBox_id_fk.ReadOnly = true;
            textBox_name_fk.ReadOnly = true;
            textAcc_id_fk.ReadOnly = true;
            textAcc_name_fk.ReadOnly = true;
            textCurr_sumbol.ReadOnly = true;
            textDebt_local.ReadOnly = true;
            textCurr_echange.ReadOnly = true;

            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
             
                textRefr_id.ReadOnly = false;
                textPayee.ReadOnly = false;
                textNote.ReadOnly = false;
                textDebt_foreign.ReadOnly = false;
                /////////////////////////////
                textCurr_echange.ReadOnly = true;
                textDebt_local.Visible = false;
                textDebt_local.ReadOnly = true;
                textDebt_local.Enabled = true;
                /////////////////////////////
                Permissions("Add"); //استدعاء الصلاحيات
               
                // dateTimePicker1.Enabled = true;
                /////////////////////


                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
               // buttSerch.Enabled = false;
                buttPosting.Enabled = false;
                buttPrint.Enabled = false;

                ////////////////////////////////////////////
                //for (int i = 0; i < 2; i++)
                //{
                    DGVBody.AllowUserToAddRows = true;
                    DGVBody.AllowUserToDeleteRows = true;
                    DGVBody.MultiSelect = false;
                   // DGVBody.SelectionMode = DataGridViewSelectionMode.CellSelect;
                    DGVBody.ReadOnly = false;


                //}



                if (flagEditeOrAddOrSave == "Edite")
                {

                    //يروح يتحقق من اليومة العامة اذا كان هذا السند قد تم ترحيله لا يمكن التعديل
                    if (textBox_id_fk.Tag != null)
                    {
                        textDebt_local.Visible = true;
                    }
                    
                }


            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                textRefr_id.ReadOnly = true;
                textPayee.ReadOnly = true;
                textNote.ReadOnly = true;
                textDebt_foreign.ReadOnly = true;
                textCurr_echange.ReadOnly = true;
          ////////////////////////////////////////////////
                checkBoxSavePosting.Checked = false;
                checkBoxSavePosting.Enabled = false;
                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                //DGVBody.Columns[0].Visible = true;


                DGVBody.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    DGVBody.AllowUserToAddRows = false;
                    DGVBody.AllowUserToDeleteRows = false;


                dateTimePicker1.Enabled = false;
                Permissions("Load"); //استدعاء الصلاحيات
                ///////////////////

                //فعل البوتونات
               
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
                //buttSerch.Enabled = true;
                //buttPosting.Enabled = true; //اذا قد تم ترحيل هذا السند يكون فولس برجع له
              
                /////////////////////////




            }
           

        }
    void ForamtingAdd()
        {
            ClearAllTextBox();
            textSupport_id.Text = SCSql.GetMaxIdSupportCatchHead(); 
            dateTimePicker1.Value = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd"));
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";
            DGVBody.Rows.Clear(); //التفاصيل
           

        }
        void GetSupCatParmHaedAndFinshid()
        {

            /*
            اعبي بيانات الصندوق الي اخترته من ليسته الصناديق 
            وارجع افرغ قيم البارمترات الي استخدمتهم من اليسته
            */
            textBox_id_fk.Text = SupportBoxUserList.SupCatParmHaed.Box_id;
            textBox_id_fk.Tag = SupportBoxUserList.SupCatParmHaed.BoxUser_id;
            textBox_name_fk.Text = SupportBoxUserList.SupCatParmHaed.Box_name;
            textAcc_id_fk.Text = SupportBoxUserList.SupCatParmHaed.Acc_id_fk;
            textAcc_name_fk.Text = SupportBoxUserList.SupCatParmHaed.Acc_name;
            textCurr_sumbol.Text = SupportBoxUserList.SupCatParmHaed.Curr_name;
            textCurr_echange.Text = SupportBoxUserList.SupCatParmHaed.Curr_echange;
            CurrId.Text= SupportBoxUserList.SupCatParmHaed.Curr_id;

            SupportBoxUserList.SupCatParmHaed.Box_id = null;
            SupportBoxUserList.SupCatParmHaed.BoxUser_id = null;
            SupportBoxUserList.SupCatParmHaed.Box_name = null;
            SupportBoxUserList.SupCatParmHaed.Acc_id_fk = null;
            SupportBoxUserList.SupCatParmHaed.Acc_name = null;
            SupportBoxUserList.SupCatParmHaed.Curr_name = null;
            SupportBoxUserList.SupCatParmHaed.Curr_echange = null;
            SupportBoxUserList.SupCatParmHaed.Curr_id=null;

        }
        void ClearAllTextBox()
        {

            textSupport_id.Text = string.Empty;

            textBox_id_fk.Text = string.Empty;
            try
            {
                textBox_id_fk.Tag = null; //تحت التجربة
            }
            catch { MessageBox.Show("Error textBox_id_fk.Tag=null", "Function FillData"); }
            textBox_name_fk.Text = string.Empty;

            textAcc_id_fk.Text = string.Empty;
            textAcc_name_fk.Text = string.Empty;

            textRefr_id.Text = string.Empty;
            textPayee.Text = string.Empty;
            textCurr_sumbol.Text = string.Empty;
            textCurr_echange.Text = string.Empty;
            textDebt_foreign.Text = string.Empty;
            textNote.Text = string.Empty;
            textDebt_local.Text = string.Empty;
            dateTimePicker1.Enabled = false;

        }
        void ShowListBoxsUser(KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9)
            {
                
                sbu = new SupportBoxUserList(
                    (UserId.Text==null)?"-1": UserId.Text, 
                    (textBox_id_fk.Tag == null ? "-1" : textBox_id_fk.Tag.ToString()),"Box"
                    );
                sbu.ShowDialog();
                if (sbu.stateSelect == true)
                {

                    GetSupCatParmHaedAndFinshid();
                    sbu.stateSelect = false;
                    if (textCurr_echange.Text == "1")
                    {
                        textCurr_echange.ReadOnly = true;
                        textDebt_local.Visible = false;
                        textDebt_local.ReadOnly = true;
                        textDebt_local.Enabled = true;
                    }
                    else if (Convert.ToInt32(textCurr_echange.Text) > 1)
                    {
                        textCurr_echange.ReadOnly = true; //يحتاج تعديل اذا كان الحد الادنى والاعلى
                        textDebt_local.Visible = true;
                        textDebt_local.ReadOnly = true;
                        textDebt_local.Enabled = true;
                    }
                    sbu = null;



                }


            }
        }
        void TotalCreditAndDebit()
        { //Doneeeeeeee
            decimal SumDebit = 0; //مدين
            decimal SumCredit = 0; //دائن

                                 

            #region 


            for (int i = 0; i < DGVBody.Rows.Count; i++)
                {
                    if
                    (
                    DGVBody.Rows[i].Cells[1].Value != null //AccId
                    && DGVBody.Rows[i].Cells[3].Value != null //العملة
                    && DGVBody.Rows[i].Cells[4].Value != null //سعر الصرف
                    && DGVBody.Rows[i].Cells[5].Value != null //دائن محلي
                    && DGVBody.Rows[i].Cells[6].Value != null //دائن اجنبي
                    && DGVBody.Rows[i].Cells[8].Value != null //حسابات عملات 
                    )
                    {
                        
                            try
                            {
                               
                                    SumCredit += Convert.ToDecimal(DGVBody.Rows[i].Cells[5].Value.ToString()); //الجانب الدائن
                               
                            }
                            catch { MessageBox.Show("صيغة ادخال ارصدة الحسابات خاطئة", "", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                       
                    }
                }
            if (textCurr_echange.Text != string.Empty)
            {
                /*
                اذا كانت العمله لا تساوي الفراغ
                اتحقق هل العمله محليه
                اذا كانت محليه
                <خلي التكست بكوس الي اخزن فيه العمله الاجنبيه بصفر>
                مالم
                <خليى التكست بوكس يخزن العمله المحليه>
                
                
                */

                if (CurrClass.CurrIsLockalWithBoxUser
                    ((textBox_id_fk.Tag==null)?"-1": textBox_id_fk.Tag.ToString()) == "1"
                    )
                {
                    textDebt_local.Text = "0";
                }
                else
                {
                    try {
                        ExchingOld = textDebt_foreign.Text;
                        textDebt_local.Text =
                            (Convert.ToDecimal(textDebt_foreign.Text) * Convert.ToDecimal(textCurr_echange.Text)).ToString();
                    }
                    catch {
                        MessageBox.Show("خطأ في صيفة المبلغ","",MessageBoxButtons.OK,MessageBoxIcon.Error);
                        try
                        {
                            textDebt_foreign.Text = ExchingOld;
                        }
                        catch
                        {
                            MessageBox.Show("خطأ في صيفة المبلغ", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            textDebt_local.Text = "0";
                            textDebt_foreign.Text = "0";
                        }
                        
                    }
                }
            }
            #endregion
            try {
                SumDebit = Convert.ToDecimal(DebitLocal());
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString());
            }
            TotalCreditTxt.Text = SumCredit.ToString();
            TotalDifferenceTxt.Text = (SumDebit - SumCredit).ToString();

        }
        #endregion

        #endregion
        //////////
        #endregion
        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            MoveForm(e);
        }
     
        private void CurrMaximum_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            stingPosting = false;//حاله السند غير مرحل
            FormatingTextBoxAndButt(flagAddOrEdit);
           
        }

        private void SupportCatch_Load(object sender, EventArgs e)
        {
            fillData("All");
            flagAddOrEdit = "Load";

            dateTimePicker1.Format = DateTimePickerFormat.Custom;

            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            FormatingTextBoxAndButt("Load");
        

        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SetDataBodySupportCatchAfterEdite();
            SendDataToAddOrEdit(flagAddOrEdit);
          
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
          
             FillTextBox(indexSupportCatchHaedButt("Next", ref indexHaed));
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
           
            FillTextBox(indexSupportCatchHaedButt("Back", ref indexHaed));
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
           
            FillTextBox(indexSupportCatchHaedButt("Frist", ref indexHaed));
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
           
            FillTextBox(indexSupportCatchHaedButt("Last", ref indexHaed));
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            if (!stingPosting)
            {
                flagAddOrEdit = "Edite";
                SetDataEntriBodyBeforEdite();
                FormatingTextBoxAndButt(flagAddOrEdit);
            }
            else MessageBox.Show("السند مرحل لايمكن تعديله", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }
    
        private void textBox_id_fk_KeyDown(object sender, KeyEventArgs e)
        {
            if (flagAddOrEdit == "Edite" || flagAddOrEdit == "Add")
                ShowListBoxsUser(e);

        }

        private void DGVBody_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            TotalCreditAndDebit();
        }

        private void DGVBody_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            TotalCreditAndDebit();
        }

        private void DGVBody_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (DGVBody.RowCount>0)
            {
                int j = DGVBody.CurrentCell.ColumnIndex;
                if(j==4||j==5||j==6)
                TotalCreditAndDebit();
            }
        }

        private void DGVBody_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            afterCellEndEditDataGridView();
        }

        private void DGVBody_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cellClickDataGridView();
        }

        private void DGVBody_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            EditingControlShowingDataGridView(sender, e);
        }

        private void textDebt_foreign_TextChanged(object sender, EventArgs e)
        {
            TotalCreditAndDebit();
            try
            {
                ToWord toWord = new ToWord(Convert.ToDecimal(textDebt_foreign.Text), new CurrencyInfo(CurrId.Text));
                textDebtWord.Text = toWord.ConvertToArabic();
            }
            catch
            {
               
                textDebtWord.Text = String.Empty;
            }
        }

        private void textCurr_echange_Validating(object sender, CancelEventArgs e)
        {
            //if (textBox_id_fk.Tag != null)
            //{
            //    if (CurrClass.CurrIsLockalWithBoxUser(textBox_id_fk.Tag.ToString()) == "1")
            //    {
            //        textCurr_echange.ReadOnly = true;
            //    }
            //    else
            //    {
            //        MessageBox.Show("دخل");
            //        ExchingOld = textCurr_echange.Text;
            //        textCurr_echange.ReadOnly = false;
            //    }
            //}
            //MessageBox.Show("Leave2");
        }

        private void textCurr_echange_Validated(object sender, EventArgs e)
        {
            //if(textCurr_echange.ReadOnly == false)
            //{
            //    textCurr_echange.Text = ExchingOld;
            //    MessageBox.Show("غادر");
            //}
            //MessageBox.Show("Leave3");
        }

        private void textCurr_echange_Leave(object sender, EventArgs e)
        {
            //MessageBox.Show("Leave");
        }

        private void textCurr_echange_MouseLeave(object sender, EventArgs e)
        {
           
        }

        private void textCurr_echange_MouseClick(object sender, MouseEventArgs e)
        {
            //if (CurrClass.CurrIsLockalWithBoxUser(textBox_id_fk.Tag.ToString()) == "1")
            //{
            //    textCurr_echange.ReadOnly = true;
            //}
            //else textCurr_echange.ReadOnly = false;
            //ExchingOld = textCurr_echange.Text;
            //MessageBox.Show("دخل4");
        }

      

        private void textCurr_echange_KeyDown(object sender, KeyEventArgs e)
        {
           
        }

        private void textDebt_foreign_KeyPress(object sender, KeyPressEventArgs e)
        {
            OpenOrClose = "CloseAlpha";
            StopAlphaInColumn_KeyPress(sender,e);
            OpenOrClose = "";
        }
      
        private void textPayee_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void textNote_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void buttPosting_Click(object sender, EventArgs e)
        {
            if (textSupport_id.Text!=string.Empty&& !stingPosting)
            {
                posting(textSupport_id.Text);
            }
            else { MessageBox.Show("قد تم ترحيل السند سابقا", "", MessageBoxButtons.OK, MessageBoxIcon.Stop); }
        }

        private void buttPrint_Click(object sender, EventArgs e)
        {
            Reports.SupportCatchs CS = new Reports.SupportCatchs();
            CS.SetParameterValue("@Support_id", textSupport_id.Text);
            Reports.frm_Reports f = new Reports.frm_Reports();
            f.crystalReportViewer1.ReportSource = CS;
            f.ShowDialog();
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (textSupport_id.Text != string.Empty)
            {
                if (!stingPosting && !postingSql.CheckPostingOrNot(idOpration.Text, textSupport_id.Text))
                {
                    Delet(textSupport_id.Text);
                }
                else MessageBox.Show("السند مرحل لايمكن حذفه", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
