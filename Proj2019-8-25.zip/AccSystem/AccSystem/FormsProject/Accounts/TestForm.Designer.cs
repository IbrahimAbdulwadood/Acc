﻿namespace AccSystem.FormsProject.Accounts
{
    partial class TestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.bunifuFlatButton34 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton35 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton36 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton37 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton38 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.button12 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bunifuFlatButton19 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.buttAdd = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuFlatButton18 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton15 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton12 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton20 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton22 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton21 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton16 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton14 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton26 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton13 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton7 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton23 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton11 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton24 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton25 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton27 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton28 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton31 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton32 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuFlatButton33 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewEntryHaed = new System.Windows.Forms.DataGridView();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button6 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.txtSerch = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.buttDelete = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.butSave = new System.Windows.Forms.Button();
            this.buttAdd1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.DGViewDate = new System.Windows.Forms.DataGridView();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEntryHaed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGViewDate)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.AccessibleDescription = "";
            this.groupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.groupBox1.AutoSize = true;
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackColor = System.Drawing.Color.DimGray;
            this.groupBox1.Controls.Add(this.button9);
            this.groupBox1.Controls.Add(this.button24);
            this.groupBox1.Controls.Add(this.button26);
            this.groupBox1.Controls.Add(this.button20);
            this.groupBox1.Controls.Add(this.button22);
            this.groupBox1.Controls.Add(this.bunifuFlatButton34);
            this.groupBox1.Controls.Add(this.bunifuFlatButton35);
            this.groupBox1.Controls.Add(this.bunifuFlatButton36);
            this.groupBox1.Controls.Add(this.bunifuFlatButton37);
            this.groupBox1.Controls.Add(this.bunifuFlatButton38);
            this.groupBox1.Controls.Add(this.button12);
            this.groupBox1.Controls.Add(this.button25);
            this.groupBox1.Controls.Add(this.button32);
            this.groupBox1.Controls.Add(this.button33);
            this.groupBox1.Controls.Add(this.button34);
            this.groupBox1.Controls.Add(this.button23);
            this.groupBox1.Controls.Add(this.button17);
            this.groupBox1.Controls.Add(this.button16);
            this.groupBox1.Controls.Add(this.button18);
            this.groupBox1.Controls.Add(this.button35);
            this.groupBox1.Controls.Add(this.button19);
            this.groupBox1.Controls.Add(this.button27);
            this.groupBox1.Controls.Add(this.button21);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(1337, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(283, 797);
            this.groupBox1.TabIndex = 132;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "الوصول السريع";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button9.ForeColor = System.Drawing.Color.White;
            this.button9.Image = ((System.Drawing.Image)(resources.GetObject("button9.Image")));
            this.button9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button9.Location = new System.Drawing.Point(12, 186);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(124, 50);
            this.button9.TabIndex = 230;
            this.button9.Text = "الفترات المالــيه";
            this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button9.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button24.ForeColor = System.Drawing.Color.White;
            this.button24.Image = ((System.Drawing.Image)(resources.GetObject("button24.Image")));
            this.button24.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button24.Location = new System.Drawing.Point(142, 130);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(124, 50);
            this.button24.TabIndex = 229;
            this.button24.Text = "امر جرد";
            this.button24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button24.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button26.ForeColor = System.Drawing.Color.White;
            this.button26.Image = ((System.Drawing.Image)(resources.GetObject("button26.Image")));
            this.button26.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button26.Location = new System.Drawing.Point(12, 130);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(124, 50);
            this.button26.TabIndex = 228;
            this.button26.Text = "المخازن";
            this.button26.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button26.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button20.ForeColor = System.Drawing.Color.White;
            this.button20.Image = ((System.Drawing.Image)(resources.GetObject("button20.Image")));
            this.button20.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button20.Location = new System.Drawing.Point(142, 74);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(124, 50);
            this.button20.TabIndex = 227;
            this.button20.Text = "صرف مخزني";
            this.button20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button20.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button22.ForeColor = System.Drawing.Color.White;
            this.button22.Image = ((System.Drawing.Image)(resources.GetObject("button22.Image")));
            this.button22.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button22.Location = new System.Drawing.Point(12, 74);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(124, 50);
            this.button22.TabIndex = 226;
            this.button22.Text = "توريد مخزني";
            this.button22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button22.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button22.UseVisualStyleBackColor = false;
            // 
            // bunifuFlatButton34
            // 
            this.bunifuFlatButton34.Activecolor = System.Drawing.Color.SteelBlue;
            this.bunifuFlatButton34.BackColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton34.BorderRadius = 0;
            this.bunifuFlatButton34.ButtonText = "بيانات الشركة";
            this.bunifuFlatButton34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton34.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton34.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton34.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bunifuFlatButton34.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton34.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton34.Iconimage")));
            this.bunifuFlatButton34.Iconimage_right = null;
            this.bunifuFlatButton34.Iconimage_right_Selected = null;
            this.bunifuFlatButton34.Iconimage_Selected = null;
            this.bunifuFlatButton34.IconMarginLeft = 0;
            this.bunifuFlatButton34.IconMarginRight = 0;
            this.bunifuFlatButton34.IconRightVisible = true;
            this.bunifuFlatButton34.IconRightZoom = 0D;
            this.bunifuFlatButton34.IconVisible = true;
            this.bunifuFlatButton34.IconZoom = 60D;
            this.bunifuFlatButton34.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.bunifuFlatButton34.IsTab = false;
            this.bunifuFlatButton34.Location = new System.Drawing.Point(20, 911);
            this.bunifuFlatButton34.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuFlatButton34.Name = "bunifuFlatButton34";
            this.bunifuFlatButton34.Normalcolor = System.Drawing.Color.Gray;
            this.bunifuFlatButton34.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton34.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton34.selected = false;
            this.bunifuFlatButton34.Size = new System.Drawing.Size(252, 50);
            this.bunifuFlatButton34.TabIndex = 49;
            this.bunifuFlatButton34.Text = "بيانات الشركة";
            this.bunifuFlatButton34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton34.Textcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton34.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            // 
            // bunifuFlatButton35
            // 
            this.bunifuFlatButton35.Activecolor = System.Drawing.Color.SteelBlue;
            this.bunifuFlatButton35.BackColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton35.BorderRadius = 0;
            this.bunifuFlatButton35.ButtonText = "الصناديق";
            this.bunifuFlatButton35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton35.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton35.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton35.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bunifuFlatButton35.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton35.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton35.Iconimage")));
            this.bunifuFlatButton35.Iconimage_right = null;
            this.bunifuFlatButton35.Iconimage_right_Selected = null;
            this.bunifuFlatButton35.Iconimage_Selected = null;
            this.bunifuFlatButton35.IconMarginLeft = 0;
            this.bunifuFlatButton35.IconMarginRight = 0;
            this.bunifuFlatButton35.IconRightVisible = true;
            this.bunifuFlatButton35.IconRightZoom = 0D;
            this.bunifuFlatButton35.IconVisible = true;
            this.bunifuFlatButton35.IconZoom = 60D;
            this.bunifuFlatButton35.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.bunifuFlatButton35.IsTab = false;
            this.bunifuFlatButton35.Location = new System.Drawing.Point(20, 776);
            this.bunifuFlatButton35.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuFlatButton35.Name = "bunifuFlatButton35";
            this.bunifuFlatButton35.Normalcolor = System.Drawing.Color.Gray;
            this.bunifuFlatButton35.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton35.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton35.selected = false;
            this.bunifuFlatButton35.Size = new System.Drawing.Size(252, 50);
            this.bunifuFlatButton35.TabIndex = 48;
            this.bunifuFlatButton35.Text = "الصناديق";
            this.bunifuFlatButton35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton35.Textcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton35.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            // 
            // bunifuFlatButton36
            // 
            this.bunifuFlatButton36.Activecolor = System.Drawing.Color.SteelBlue;
            this.bunifuFlatButton36.BackColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton36.BorderRadius = 0;
            this.bunifuFlatButton36.ButtonText = "مردود مشتريات";
            this.bunifuFlatButton36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton36.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton36.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton36.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bunifuFlatButton36.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton36.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton36.Iconimage")));
            this.bunifuFlatButton36.Iconimage_right = null;
            this.bunifuFlatButton36.Iconimage_right_Selected = null;
            this.bunifuFlatButton36.Iconimage_Selected = null;
            this.bunifuFlatButton36.IconMarginLeft = 0;
            this.bunifuFlatButton36.IconMarginRight = 0;
            this.bunifuFlatButton36.IconRightVisible = true;
            this.bunifuFlatButton36.IconRightZoom = 0D;
            this.bunifuFlatButton36.IconVisible = true;
            this.bunifuFlatButton36.IconZoom = 60D;
            this.bunifuFlatButton36.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.bunifuFlatButton36.IsTab = false;
            this.bunifuFlatButton36.Location = new System.Drawing.Point(20, 718);
            this.bunifuFlatButton36.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuFlatButton36.Name = "bunifuFlatButton36";
            this.bunifuFlatButton36.Normalcolor = System.Drawing.Color.Gray;
            this.bunifuFlatButton36.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton36.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton36.selected = false;
            this.bunifuFlatButton36.Size = new System.Drawing.Size(124, 50);
            this.bunifuFlatButton36.TabIndex = 47;
            this.bunifuFlatButton36.Text = "مردود مشتريات";
            this.bunifuFlatButton36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton36.Textcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton36.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            // 
            // bunifuFlatButton37
            // 
            this.bunifuFlatButton37.Activecolor = System.Drawing.Color.SteelBlue;
            this.bunifuFlatButton37.BackColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton37.BorderRadius = 0;
            this.bunifuFlatButton37.ButtonText = "مردود مبيعات";
            this.bunifuFlatButton37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton37.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton37.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton37.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bunifuFlatButton37.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton37.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton37.Iconimage")));
            this.bunifuFlatButton37.Iconimage_right = null;
            this.bunifuFlatButton37.Iconimage_right_Selected = null;
            this.bunifuFlatButton37.Iconimage_Selected = null;
            this.bunifuFlatButton37.IconMarginLeft = 0;
            this.bunifuFlatButton37.IconMarginRight = 0;
            this.bunifuFlatButton37.IconRightVisible = true;
            this.bunifuFlatButton37.IconRightZoom = 0D;
            this.bunifuFlatButton37.IconVisible = true;
            this.bunifuFlatButton37.IconZoom = 60D;
            this.bunifuFlatButton37.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.bunifuFlatButton37.IsTab = false;
            this.bunifuFlatButton37.Location = new System.Drawing.Point(148, 718);
            this.bunifuFlatButton37.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuFlatButton37.Name = "bunifuFlatButton37";
            this.bunifuFlatButton37.Normalcolor = System.Drawing.Color.Gray;
            this.bunifuFlatButton37.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton37.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton37.selected = false;
            this.bunifuFlatButton37.Size = new System.Drawing.Size(124, 50);
            this.bunifuFlatButton37.TabIndex = 46;
            this.bunifuFlatButton37.Text = "مردود مبيعات";
            this.bunifuFlatButton37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton37.Textcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton37.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            // 
            // bunifuFlatButton38
            // 
            this.bunifuFlatButton38.Activecolor = System.Drawing.Color.SteelBlue;
            this.bunifuFlatButton38.BackColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton38.BorderRadius = 0;
            this.bunifuFlatButton38.ButtonText = "بيانات الشركة";
            this.bunifuFlatButton38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton38.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton38.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton38.ForeColor = System.Drawing.SystemColors.ControlText;
            this.bunifuFlatButton38.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton38.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton38.Iconimage")));
            this.bunifuFlatButton38.Iconimage_right = null;
            this.bunifuFlatButton38.Iconimage_right_Selected = null;
            this.bunifuFlatButton38.Iconimage_Selected = null;
            this.bunifuFlatButton38.IconMarginLeft = 0;
            this.bunifuFlatButton38.IconMarginRight = 0;
            this.bunifuFlatButton38.IconRightVisible = true;
            this.bunifuFlatButton38.IconRightZoom = 0D;
            this.bunifuFlatButton38.IconVisible = true;
            this.bunifuFlatButton38.IconZoom = 60D;
            this.bunifuFlatButton38.ImeMode = System.Windows.Forms.ImeMode.AlphaFull;
            this.bunifuFlatButton38.IsTab = false;
            this.bunifuFlatButton38.Location = new System.Drawing.Point(24, 656);
            this.bunifuFlatButton38.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuFlatButton38.Name = "bunifuFlatButton38";
            this.bunifuFlatButton38.Normalcolor = System.Drawing.Color.Gray;
            this.bunifuFlatButton38.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton38.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton38.selected = false;
            this.bunifuFlatButton38.Size = new System.Drawing.Size(252, 50);
            this.bunifuFlatButton38.TabIndex = 45;
            this.bunifuFlatButton38.Text = "بيانات الشركة";
            this.bunifuFlatButton38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton38.Textcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton38.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button12.ForeColor = System.Drawing.Color.White;
            this.button12.Image = ((System.Drawing.Image)(resources.GetObject("button12.Image")));
            this.button12.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button12.Location = new System.Drawing.Point(12, 21);
            this.button12.Name = "button12";
            this.button12.Padding = new System.Windows.Forms.Padding(20, 0, 40, 0);
            this.button12.Size = new System.Drawing.Size(254, 50);
            this.button12.TabIndex = 171;
            this.button12.Text = "الدليل المحاسبي";
            this.button12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button25.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button25.ForeColor = System.Drawing.Color.White;
            this.button25.Image = ((System.Drawing.Image)(resources.GetObject("button25.Image")));
            this.button25.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button25.Location = new System.Drawing.Point(12, 301);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(124, 50);
            this.button25.TabIndex = 184;
            this.button25.Text = "فاتورة مشتريات";
            this.button25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button25.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button32.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button32.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button32.ForeColor = System.Drawing.Color.White;
            this.button32.Image = ((System.Drawing.Image)(resources.GetObject("button32.Image")));
            this.button32.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button32.Location = new System.Drawing.Point(142, 302);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(124, 50);
            this.button32.TabIndex = 192;
            this.button32.Text = "مردود مبيعات";
            this.button32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button32.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button33.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button33.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button33.ForeColor = System.Drawing.Color.White;
            this.button33.Image = ((System.Drawing.Image)(resources.GetObject("button33.Image")));
            this.button33.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button33.Location = new System.Drawing.Point(12, 357);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(124, 50);
            this.button33.TabIndex = 191;
            this.button33.Text = "مردود  مشتريات";
            this.button33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button33.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button33.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button34.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button34.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button34.ForeColor = System.Drawing.Color.White;
            this.button34.Image = ((System.Drawing.Image)(resources.GetObject("button34.Image")));
            this.button34.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button34.Location = new System.Drawing.Point(142, 357);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(124, 50);
            this.button34.TabIndex = 190;
            this.button34.Text = "بيانات الشركة";
            this.button34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button34.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button23.ForeColor = System.Drawing.Color.White;
            this.button23.Image = ((System.Drawing.Image)(resources.GetObject("button23.Image")));
            this.button23.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button23.Location = new System.Drawing.Point(12, 413);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(124, 50);
            this.button23.TabIndex = 182;
            this.button23.Text = "العملات";
            this.button23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button23.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button17.ForeColor = System.Drawing.Color.White;
            this.button17.Image = ((System.Drawing.Image)(resources.GetObject("button17.Image")));
            this.button17.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button17.Location = new System.Drawing.Point(142, 413);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(124, 50);
            this.button17.TabIndex = 176;
            this.button17.Text = "امر جرد";
            this.button17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button17.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Image = ((System.Drawing.Image)(resources.GetObject("button16.Image")));
            this.button16.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button16.Location = new System.Drawing.Point(12, 469);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(124, 50);
            this.button16.TabIndex = 175;
            this.button16.Text = "المخازن";
            this.button16.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button16.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button18.ForeColor = System.Drawing.Color.White;
            this.button18.Image = ((System.Drawing.Image)(resources.GetObject("button18.Image")));
            this.button18.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button18.Location = new System.Drawing.Point(142, 469);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(124, 50);
            this.button18.TabIndex = 177;
            this.button18.Text = "الموردين";
            this.button18.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button18.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button35.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button35.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button35.ForeColor = System.Drawing.Color.White;
            this.button35.Image = ((System.Drawing.Image)(resources.GetObject("button35.Image")));
            this.button35.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button35.Location = new System.Drawing.Point(12, 525);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(124, 50);
            this.button35.TabIndex = 194;
            this.button35.Text = "الصناديق";
            this.button35.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button35.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button19.ForeColor = System.Drawing.Color.White;
            this.button19.Image = ((System.Drawing.Image)(resources.GetObject("button19.Image")));
            this.button19.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button19.Location = new System.Drawing.Point(142, 525);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(124, 50);
            this.button19.TabIndex = 178;
            this.button19.Text = "العملاء";
            this.button19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button19.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button27.ForeColor = System.Drawing.Color.White;
            this.button27.Image = ((System.Drawing.Image)(resources.GetObject("button27.Image")));
            this.button27.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button27.Location = new System.Drawing.Point(12, 581);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(124, 50);
            this.button27.TabIndex = 186;
            this.button27.Text = "كشف حساب";
            this.button27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button27.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button21.ForeColor = System.Drawing.Color.White;
            this.button21.Image = ((System.Drawing.Image)(resources.GetObject("button21.Image")));
            this.button21.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button21.Location = new System.Drawing.Point(142, 581);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(124, 50);
            this.button21.TabIndex = 180;
            this.button21.Text = "الاصناف";
            this.button21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button21.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button21.UseVisualStyleBackColor = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.bunifuFlatButton19);
            this.groupBox2.Controls.Add(this.buttAdd);
            this.groupBox2.Controls.Add(this.bunifuFlatButton18);
            this.groupBox2.Controls.Add(this.bunifuFlatButton15);
            this.groupBox2.Controls.Add(this.bunifuFlatButton12);
            this.groupBox2.Controls.Add(this.bunifuFlatButton20);
            this.groupBox2.Controls.Add(this.bunifuFlatButton22);
            this.groupBox2.Controls.Add(this.bunifuFlatButton21);
            this.groupBox2.Controls.Add(this.bunifuFlatButton16);
            this.groupBox2.Controls.Add(this.bunifuFlatButton14);
            this.groupBox2.Controls.Add(this.bunifuFlatButton26);
            this.groupBox2.Controls.Add(this.bunifuFlatButton13);
            this.groupBox2.Controls.Add(this.bunifuFlatButton7);
            this.groupBox2.Controls.Add(this.bunifuFlatButton23);
            this.groupBox2.Controls.Add(this.bunifuFlatButton11);
            this.groupBox2.Controls.Add(this.bunifuFlatButton24);
            this.groupBox2.Controls.Add(this.bunifuFlatButton25);
            this.groupBox2.Controls.Add(this.bunifuFlatButton27);
            this.groupBox2.Controls.Add(this.bunifuFlatButton28);
            this.groupBox2.Controls.Add(this.bunifuFlatButton31);
            this.groupBox2.Controls.Add(this.bunifuFlatButton32);
            this.groupBox2.Controls.Add(this.bunifuFlatButton33);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1337, 190);
            this.groupBox2.TabIndex = 133;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ادوات خارجي";
            // 
            // bunifuFlatButton19
            // 
            this.bunifuFlatButton19.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton19.BorderRadius = 0;
            this.bunifuFlatButton19.ButtonText = "جديد";
            this.bunifuFlatButton19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton19.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton19.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton19.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton19.Iconimage")));
            this.bunifuFlatButton19.Iconimage_right = null;
            this.bunifuFlatButton19.Iconimage_right_Selected = null;
            this.bunifuFlatButton19.Iconimage_Selected = null;
            this.bunifuFlatButton19.IconMarginLeft = 0;
            this.bunifuFlatButton19.IconMarginRight = 0;
            this.bunifuFlatButton19.IconRightVisible = false;
            this.bunifuFlatButton19.IconRightZoom = 0D;
            this.bunifuFlatButton19.IconVisible = true;
            this.bunifuFlatButton19.IconZoom = 75D;
            this.bunifuFlatButton19.IsTab = false;
            this.bunifuFlatButton19.Location = new System.Drawing.Point(601, 35);
            this.bunifuFlatButton19.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton19.Name = "bunifuFlatButton19";
            this.bunifuFlatButton19.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton19.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton19.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton19.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton19.selected = false;
            this.bunifuFlatButton19.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton19.TabIndex = 150;
            this.bunifuFlatButton19.Text = "جديد";
            this.bunifuFlatButton19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton19.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton19.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.Enabled = false;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.ImagePosition = 15;
            this.buttAdd.ImageZoom = 50;
            this.buttAdd.LabelPosition = 31;
            this.buttAdd.LabelText = "جديد";
            this.buttAdd.Location = new System.Drawing.Point(1246, 68);
            this.buttAdd.Margin = new System.Windows.Forms.Padding(6);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(66, 100);
            this.buttAdd.TabIndex = 152;
            // 
            // bunifuFlatButton18
            // 
            this.bunifuFlatButton18.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton18.BorderRadius = 0;
            this.bunifuFlatButton18.ButtonText = "حذف";
            this.bunifuFlatButton18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton18.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton18.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton18.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton18.Iconimage")));
            this.bunifuFlatButton18.Iconimage_right = null;
            this.bunifuFlatButton18.Iconimage_right_Selected = null;
            this.bunifuFlatButton18.Iconimage_Selected = null;
            this.bunifuFlatButton18.IconMarginLeft = 0;
            this.bunifuFlatButton18.IconMarginRight = 0;
            this.bunifuFlatButton18.IconRightVisible = false;
            this.bunifuFlatButton18.IconRightZoom = 0D;
            this.bunifuFlatButton18.IconVisible = true;
            this.bunifuFlatButton18.IconZoom = 75D;
            this.bunifuFlatButton18.IsTab = false;
            this.bunifuFlatButton18.Location = new System.Drawing.Point(601, 89);
            this.bunifuFlatButton18.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton18.Name = "bunifuFlatButton18";
            this.bunifuFlatButton18.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton18.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton18.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton18.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton18.selected = false;
            this.bunifuFlatButton18.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton18.TabIndex = 149;
            this.bunifuFlatButton18.Text = "حذف";
            this.bunifuFlatButton18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton18.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton18.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton15
            // 
            this.bunifuFlatButton15.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton15.BorderRadius = 0;
            this.bunifuFlatButton15.ButtonText = "الغاء";
            this.bunifuFlatButton15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton15.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton15.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton15.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton15.Iconimage")));
            this.bunifuFlatButton15.Iconimage_right = null;
            this.bunifuFlatButton15.Iconimage_right_Selected = null;
            this.bunifuFlatButton15.Iconimage_Selected = null;
            this.bunifuFlatButton15.IconMarginLeft = 0;
            this.bunifuFlatButton15.IconMarginRight = 0;
            this.bunifuFlatButton15.IconRightVisible = false;
            this.bunifuFlatButton15.IconRightZoom = 0D;
            this.bunifuFlatButton15.IconVisible = true;
            this.bunifuFlatButton15.IconZoom = 75D;
            this.bunifuFlatButton15.IsTab = false;
            this.bunifuFlatButton15.Location = new System.Drawing.Point(483, 89);
            this.bunifuFlatButton15.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton15.Name = "bunifuFlatButton15";
            this.bunifuFlatButton15.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton15.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton15.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton15.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton15.selected = false;
            this.bunifuFlatButton15.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton15.TabIndex = 148;
            this.bunifuFlatButton15.Text = "الغاء";
            this.bunifuFlatButton15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton15.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton15.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton12
            // 
            this.bunifuFlatButton12.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton12.BorderRadius = 0;
            this.bunifuFlatButton12.ButtonText = "جديد";
            this.bunifuFlatButton12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton12.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton12.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton12.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton12.Iconimage")));
            this.bunifuFlatButton12.Iconimage_right = null;
            this.bunifuFlatButton12.Iconimage_right_Selected = null;
            this.bunifuFlatButton12.Iconimage_Selected = null;
            this.bunifuFlatButton12.IconMarginLeft = 0;
            this.bunifuFlatButton12.IconMarginRight = 0;
            this.bunifuFlatButton12.IconRightVisible = false;
            this.bunifuFlatButton12.IconRightZoom = 0D;
            this.bunifuFlatButton12.IconVisible = true;
            this.bunifuFlatButton12.IconZoom = 75D;
            this.bunifuFlatButton12.IsTab = false;
            this.bunifuFlatButton12.Location = new System.Drawing.Point(483, 35);
            this.bunifuFlatButton12.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton12.Name = "bunifuFlatButton12";
            this.bunifuFlatButton12.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton12.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton12.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton12.selected = false;
            this.bunifuFlatButton12.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton12.TabIndex = 145;
            this.bunifuFlatButton12.Text = "جديد";
            this.bunifuFlatButton12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton12.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton12.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton20
            // 
            this.bunifuFlatButton20.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton20.BorderRadius = 0;
            this.bunifuFlatButton20.ButtonText = "بحث";
            this.bunifuFlatButton20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton20.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton20.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton20.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton20.Iconimage")));
            this.bunifuFlatButton20.Iconimage_right = null;
            this.bunifuFlatButton20.Iconimage_right_Selected = null;
            this.bunifuFlatButton20.Iconimage_Selected = null;
            this.bunifuFlatButton20.IconMarginLeft = 0;
            this.bunifuFlatButton20.IconMarginRight = 0;
            this.bunifuFlatButton20.IconRightVisible = false;
            this.bunifuFlatButton20.IconRightZoom = 0D;
            this.bunifuFlatButton20.IconVisible = true;
            this.bunifuFlatButton20.IconZoom = 75D;
            this.bunifuFlatButton20.IsTab = false;
            this.bunifuFlatButton20.Location = new System.Drawing.Point(853, 19);
            this.bunifuFlatButton20.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton20.Name = "bunifuFlatButton20";
            this.bunifuFlatButton20.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton20.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton20.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton20.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton20.selected = false;
            this.bunifuFlatButton20.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton20.TabIndex = 151;
            this.bunifuFlatButton20.Text = "بحث";
            this.bunifuFlatButton20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton20.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton20.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton22
            // 
            this.bunifuFlatButton22.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton22.BorderRadius = 0;
            this.bunifuFlatButton22.ButtonText = "ترحيل";
            this.bunifuFlatButton22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton22.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton22.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton22.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton22.Iconimage")));
            this.bunifuFlatButton22.Iconimage_right = null;
            this.bunifuFlatButton22.Iconimage_right_Selected = null;
            this.bunifuFlatButton22.Iconimage_Selected = null;
            this.bunifuFlatButton22.IconMarginLeft = 0;
            this.bunifuFlatButton22.IconMarginRight = 0;
            this.bunifuFlatButton22.IconRightVisible = false;
            this.bunifuFlatButton22.IconRightZoom = 0D;
            this.bunifuFlatButton22.IconVisible = true;
            this.bunifuFlatButton22.IconZoom = 75D;
            this.bunifuFlatButton22.IsTab = false;
            this.bunifuFlatButton22.Location = new System.Drawing.Point(933, 122);
            this.bunifuFlatButton22.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton22.Name = "bunifuFlatButton22";
            this.bunifuFlatButton22.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton22.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton22.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton22.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton22.selected = false;
            this.bunifuFlatButton22.Size = new System.Drawing.Size(125, 46);
            this.bunifuFlatButton22.TabIndex = 115;
            this.bunifuFlatButton22.Text = "ترحيل";
            this.bunifuFlatButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton22.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton22.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton21
            // 
            this.bunifuFlatButton21.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton21.BorderRadius = 0;
            this.bunifuFlatButton21.ButtonText = "إلغاء الترحيل";
            this.bunifuFlatButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton21.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton21.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton21.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton21.Iconimage")));
            this.bunifuFlatButton21.Iconimage_right = null;
            this.bunifuFlatButton21.Iconimage_right_Selected = null;
            this.bunifuFlatButton21.Iconimage_Selected = null;
            this.bunifuFlatButton21.IconMarginLeft = 0;
            this.bunifuFlatButton21.IconMarginRight = 0;
            this.bunifuFlatButton21.IconRightVisible = false;
            this.bunifuFlatButton21.IconRightZoom = 0D;
            this.bunifuFlatButton21.IconVisible = true;
            this.bunifuFlatButton21.IconZoom = 75D;
            this.bunifuFlatButton21.IsTab = false;
            this.bunifuFlatButton21.Location = new System.Drawing.Point(1074, 122);
            this.bunifuFlatButton21.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton21.Name = "bunifuFlatButton21";
            this.bunifuFlatButton21.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton21.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton21.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton21.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton21.selected = false;
            this.bunifuFlatButton21.Size = new System.Drawing.Size(125, 46);
            this.bunifuFlatButton21.TabIndex = 114;
            this.bunifuFlatButton21.Text = "إلغاء الترحيل";
            this.bunifuFlatButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton21.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton21.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton16
            // 
            this.bunifuFlatButton16.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton16.BorderRadius = 0;
            this.bunifuFlatButton16.ButtonText = "كشف حساب";
            this.bunifuFlatButton16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton16.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton16.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton16.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton16.Iconimage")));
            this.bunifuFlatButton16.Iconimage_right = null;
            this.bunifuFlatButton16.Iconimage_right_Selected = null;
            this.bunifuFlatButton16.Iconimage_Selected = null;
            this.bunifuFlatButton16.IconMarginLeft = 0;
            this.bunifuFlatButton16.IconMarginRight = 0;
            this.bunifuFlatButton16.IconRightVisible = false;
            this.bunifuFlatButton16.IconRightZoom = 0D;
            this.bunifuFlatButton16.IconVisible = true;
            this.bunifuFlatButton16.IconZoom = 75D;
            this.bunifuFlatButton16.IsTab = false;
            this.bunifuFlatButton16.Location = new System.Drawing.Point(1070, 73);
            this.bunifuFlatButton16.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton16.Name = "bunifuFlatButton16";
            this.bunifuFlatButton16.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton16.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton16.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton16.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton16.selected = false;
            this.bunifuFlatButton16.Size = new System.Drawing.Size(140, 46);
            this.bunifuFlatButton16.TabIndex = 113;
            this.bunifuFlatButton16.Text = "كشف حساب";
            this.bunifuFlatButton16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton16.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton16.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton14
            // 
            this.bunifuFlatButton14.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton14.BorderRadius = 0;
            this.bunifuFlatButton14.ButtonText = "حذف";
            this.bunifuFlatButton14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton14.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton14.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton14.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton14.Iconimage")));
            this.bunifuFlatButton14.Iconimage_right = null;
            this.bunifuFlatButton14.Iconimage_right_Selected = null;
            this.bunifuFlatButton14.Iconimage_Selected = null;
            this.bunifuFlatButton14.IconMarginLeft = 0;
            this.bunifuFlatButton14.IconMarginRight = 0;
            this.bunifuFlatButton14.IconRightVisible = false;
            this.bunifuFlatButton14.IconRightZoom = 0D;
            this.bunifuFlatButton14.IconVisible = true;
            this.bunifuFlatButton14.IconZoom = 75D;
            this.bunifuFlatButton14.IsTab = false;
            this.bunifuFlatButton14.Location = new System.Drawing.Point(971, 19);
            this.bunifuFlatButton14.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton14.Name = "bunifuFlatButton14";
            this.bunifuFlatButton14.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton14.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton14.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton14.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton14.selected = false;
            this.bunifuFlatButton14.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton14.TabIndex = 147;
            this.bunifuFlatButton14.Text = "حذف";
            this.bunifuFlatButton14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton14.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton14.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton26
            // 
            this.bunifuFlatButton26.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton26.BorderRadius = 0;
            this.bunifuFlatButton26.ButtonText = "استعراض";
            this.bunifuFlatButton26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton26.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton26.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton26.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton26.Iconimage")));
            this.bunifuFlatButton26.Iconimage_right = null;
            this.bunifuFlatButton26.Iconimage_right_Selected = null;
            this.bunifuFlatButton26.Iconimage_Selected = null;
            this.bunifuFlatButton26.IconMarginLeft = 0;
            this.bunifuFlatButton26.IconMarginRight = 0;
            this.bunifuFlatButton26.IconRightVisible = false;
            this.bunifuFlatButton26.IconRightZoom = 0D;
            this.bunifuFlatButton26.IconVisible = true;
            this.bunifuFlatButton26.IconZoom = 75D;
            this.bunifuFlatButton26.IsTab = false;
            this.bunifuFlatButton26.Location = new System.Drawing.Point(129, 35);
            this.bunifuFlatButton26.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton26.Name = "bunifuFlatButton26";
            this.bunifuFlatButton26.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton26.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton26.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton26.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton26.selected = false;
            this.bunifuFlatButton26.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton26.TabIndex = 105;
            this.bunifuFlatButton26.Text = "استعراض";
            this.bunifuFlatButton26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton26.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton26.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton13
            // 
            this.bunifuFlatButton13.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton13.BorderRadius = 0;
            this.bunifuFlatButton13.ButtonText = "حفظ";
            this.bunifuFlatButton13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton13.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton13.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton13.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton13.Iconimage")));
            this.bunifuFlatButton13.Iconimage_right = null;
            this.bunifuFlatButton13.Iconimage_right_Selected = null;
            this.bunifuFlatButton13.Iconimage_Selected = null;
            this.bunifuFlatButton13.IconMarginLeft = 0;
            this.bunifuFlatButton13.IconMarginRight = 0;
            this.bunifuFlatButton13.IconRightVisible = false;
            this.bunifuFlatButton13.IconRightZoom = 0D;
            this.bunifuFlatButton13.IconVisible = true;
            this.bunifuFlatButton13.IconZoom = 75D;
            this.bunifuFlatButton13.IsTab = false;
            this.bunifuFlatButton13.Location = new System.Drawing.Point(1089, 19);
            this.bunifuFlatButton13.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton13.Name = "bunifuFlatButton13";
            this.bunifuFlatButton13.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton13.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton13.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton13.selected = false;
            this.bunifuFlatButton13.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton13.TabIndex = 146;
            this.bunifuFlatButton13.Text = "حفظ";
            this.bunifuFlatButton13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton13.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton13.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton7
            // 
            this.bunifuFlatButton7.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton7.BorderRadius = 0;
            this.bunifuFlatButton7.ButtonText = "جديد";
            this.bunifuFlatButton7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton7.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton7.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton7.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton7.Iconimage")));
            this.bunifuFlatButton7.Iconimage_right = null;
            this.bunifuFlatButton7.Iconimage_right_Selected = null;
            this.bunifuFlatButton7.Iconimage_Selected = null;
            this.bunifuFlatButton7.IconMarginLeft = 0;
            this.bunifuFlatButton7.IconMarginRight = 0;
            this.bunifuFlatButton7.IconRightVisible = false;
            this.bunifuFlatButton7.IconRightZoom = 0D;
            this.bunifuFlatButton7.IconVisible = true;
            this.bunifuFlatButton7.IconZoom = 75D;
            this.bunifuFlatButton7.IsTab = false;
            this.bunifuFlatButton7.Location = new System.Drawing.Point(129, 89);
            this.bunifuFlatButton7.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton7.Name = "bunifuFlatButton7";
            this.bunifuFlatButton7.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton7.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton7.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton7.selected = false;
            this.bunifuFlatButton7.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton7.TabIndex = 86;
            this.bunifuFlatButton7.Text = "جديد";
            this.bunifuFlatButton7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton7.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton7.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton23
            // 
            this.bunifuFlatButton23.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton23.BorderRadius = 0;
            this.bunifuFlatButton23.ButtonText = "تقرير";
            this.bunifuFlatButton23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton23.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton23.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton23.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton23.Iconimage")));
            this.bunifuFlatButton23.Iconimage_right = null;
            this.bunifuFlatButton23.Iconimage_right_Selected = null;
            this.bunifuFlatButton23.Iconimage_Selected = null;
            this.bunifuFlatButton23.IconMarginLeft = 0;
            this.bunifuFlatButton23.IconMarginRight = 0;
            this.bunifuFlatButton23.IconRightVisible = false;
            this.bunifuFlatButton23.IconRightZoom = 0D;
            this.bunifuFlatButton23.IconVisible = true;
            this.bunifuFlatButton23.IconZoom = 75D;
            this.bunifuFlatButton23.IsTab = false;
            this.bunifuFlatButton23.Location = new System.Drawing.Point(365, 89);
            this.bunifuFlatButton23.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton23.Name = "bunifuFlatButton23";
            this.bunifuFlatButton23.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton23.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton23.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton23.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton23.selected = false;
            this.bunifuFlatButton23.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton23.TabIndex = 102;
            this.bunifuFlatButton23.Text = "تقرير";
            this.bunifuFlatButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton23.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton23.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton11
            // 
            this.bunifuFlatButton11.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton11.BorderRadius = 0;
            this.bunifuFlatButton11.ButtonText = "جديد";
            this.bunifuFlatButton11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton11.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton11.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton11.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton11.Iconimage")));
            this.bunifuFlatButton11.Iconimage_right = null;
            this.bunifuFlatButton11.Iconimage_right_Selected = null;
            this.bunifuFlatButton11.Iconimage_Selected = null;
            this.bunifuFlatButton11.IconMarginLeft = 0;
            this.bunifuFlatButton11.IconMarginRight = 0;
            this.bunifuFlatButton11.IconRightVisible = false;
            this.bunifuFlatButton11.IconRightZoom = 0D;
            this.bunifuFlatButton11.IconVisible = true;
            this.bunifuFlatButton11.IconZoom = 75D;
            this.bunifuFlatButton11.IsTab = false;
            this.bunifuFlatButton11.Location = new System.Drawing.Point(1207, 19);
            this.bunifuFlatButton11.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton11.Name = "bunifuFlatButton11";
            this.bunifuFlatButton11.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton11.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton11.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton11.selected = false;
            this.bunifuFlatButton11.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton11.TabIndex = 144;
            this.bunifuFlatButton11.Text = "جديد";
            this.bunifuFlatButton11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton11.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton11.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton24
            // 
            this.bunifuFlatButton24.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton24.BorderRadius = 0;
            this.bunifuFlatButton24.ButtonText = "تصدير اكسل";
            this.bunifuFlatButton24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton24.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton24.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton24.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton24.Iconimage")));
            this.bunifuFlatButton24.Iconimage_right = null;
            this.bunifuFlatButton24.Iconimage_right_Selected = null;
            this.bunifuFlatButton24.Iconimage_Selected = null;
            this.bunifuFlatButton24.IconMarginLeft = 0;
            this.bunifuFlatButton24.IconMarginRight = 0;
            this.bunifuFlatButton24.IconRightVisible = false;
            this.bunifuFlatButton24.IconRightZoom = 0D;
            this.bunifuFlatButton24.IconVisible = true;
            this.bunifuFlatButton24.IconZoom = 75D;
            this.bunifuFlatButton24.IsTab = false;
            this.bunifuFlatButton24.Location = new System.Drawing.Point(247, 89);
            this.bunifuFlatButton24.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton24.Name = "bunifuFlatButton24";
            this.bunifuFlatButton24.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton24.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton24.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton24.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton24.selected = false;
            this.bunifuFlatButton24.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton24.TabIndex = 103;
            this.bunifuFlatButton24.Text = "تصدير اكسل";
            this.bunifuFlatButton24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton24.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton24.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton25
            // 
            this.bunifuFlatButton25.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton25.BorderRadius = 0;
            this.bunifuFlatButton25.ButtonText = "الحسابات";
            this.bunifuFlatButton25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton25.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton25.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton25.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton25.Iconimage")));
            this.bunifuFlatButton25.Iconimage_right = null;
            this.bunifuFlatButton25.Iconimage_right_Selected = null;
            this.bunifuFlatButton25.Iconimage_Selected = null;
            this.bunifuFlatButton25.IconMarginLeft = 0;
            this.bunifuFlatButton25.IconMarginRight = 0;
            this.bunifuFlatButton25.IconRightVisible = false;
            this.bunifuFlatButton25.IconRightZoom = 0D;
            this.bunifuFlatButton25.IconVisible = true;
            this.bunifuFlatButton25.IconZoom = 75D;
            this.bunifuFlatButton25.IsTab = false;
            this.bunifuFlatButton25.Location = new System.Drawing.Point(11, 35);
            this.bunifuFlatButton25.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton25.Name = "bunifuFlatButton25";
            this.bunifuFlatButton25.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton25.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton25.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton25.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton25.selected = false;
            this.bunifuFlatButton25.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton25.TabIndex = 104;
            this.bunifuFlatButton25.Text = "الحسابات";
            this.bunifuFlatButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton25.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton25.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton27
            // 
            this.bunifuFlatButton27.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton27.BorderRadius = 0;
            this.bunifuFlatButton27.ButtonText = "اختيار";
            this.bunifuFlatButton27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton27.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton27.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton27.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton27.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton27.Iconimage")));
            this.bunifuFlatButton27.Iconimage_right = null;
            this.bunifuFlatButton27.Iconimage_right_Selected = null;
            this.bunifuFlatButton27.Iconimage_Selected = null;
            this.bunifuFlatButton27.IconMarginLeft = 0;
            this.bunifuFlatButton27.IconMarginRight = 0;
            this.bunifuFlatButton27.IconRightVisible = false;
            this.bunifuFlatButton27.IconRightZoom = 0D;
            this.bunifuFlatButton27.IconVisible = true;
            this.bunifuFlatButton27.IconZoom = 75D;
            this.bunifuFlatButton27.IsTab = false;
            this.bunifuFlatButton27.Location = new System.Drawing.Point(251, 35);
            this.bunifuFlatButton27.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton27.Name = "bunifuFlatButton27";
            this.bunifuFlatButton27.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton27.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton27.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton27.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton27.selected = false;
            this.bunifuFlatButton27.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton27.TabIndex = 106;
            this.bunifuFlatButton27.Text = "اختيار";
            this.bunifuFlatButton27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton27.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton27.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton28
            // 
            this.bunifuFlatButton28.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton28.BorderRadius = 0;
            this.bunifuFlatButton28.ButtonText = "استعلام";
            this.bunifuFlatButton28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton28.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton28.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton28.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton28.Iconimage")));
            this.bunifuFlatButton28.Iconimage_right = null;
            this.bunifuFlatButton28.Iconimage_right_Selected = null;
            this.bunifuFlatButton28.Iconimage_Selected = null;
            this.bunifuFlatButton28.IconMarginLeft = 0;
            this.bunifuFlatButton28.IconMarginRight = 0;
            this.bunifuFlatButton28.IconRightVisible = false;
            this.bunifuFlatButton28.IconRightZoom = 0D;
            this.bunifuFlatButton28.IconVisible = true;
            this.bunifuFlatButton28.IconZoom = 75D;
            this.bunifuFlatButton28.IsTab = false;
            this.bunifuFlatButton28.Location = new System.Drawing.Point(365, 35);
            this.bunifuFlatButton28.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton28.Name = "bunifuFlatButton28";
            this.bunifuFlatButton28.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton28.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton28.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton28.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton28.selected = false;
            this.bunifuFlatButton28.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton28.TabIndex = 107;
            this.bunifuFlatButton28.Text = "استعلام";
            this.bunifuFlatButton28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton28.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton28.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton31
            // 
            this.bunifuFlatButton31.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton31.BorderRadius = 0;
            this.bunifuFlatButton31.ButtonText = "تحديث";
            this.bunifuFlatButton31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton31.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton31.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton31.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton31.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton31.Iconimage")));
            this.bunifuFlatButton31.Iconimage_right = null;
            this.bunifuFlatButton31.Iconimage_right_Selected = null;
            this.bunifuFlatButton31.Iconimage_Selected = null;
            this.bunifuFlatButton31.IconMarginLeft = 0;
            this.bunifuFlatButton31.IconMarginRight = 0;
            this.bunifuFlatButton31.IconRightVisible = false;
            this.bunifuFlatButton31.IconRightZoom = 0D;
            this.bunifuFlatButton31.IconVisible = true;
            this.bunifuFlatButton31.IconZoom = 75D;
            this.bunifuFlatButton31.IsTab = false;
            this.bunifuFlatButton31.Location = new System.Drawing.Point(129, 139);
            this.bunifuFlatButton31.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton31.Name = "bunifuFlatButton31";
            this.bunifuFlatButton31.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton31.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton31.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton31.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton31.selected = false;
            this.bunifuFlatButton31.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton31.TabIndex = 110;
            this.bunifuFlatButton31.Text = "تحديث";
            this.bunifuFlatButton31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton31.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton31.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton32
            // 
            this.bunifuFlatButton32.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton32.BorderRadius = 0;
            this.bunifuFlatButton32.ButtonText = "تصدير   بي دي اف";
            this.bunifuFlatButton32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton32.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton32.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton32.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton32.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton32.Iconimage")));
            this.bunifuFlatButton32.Iconimage_right = null;
            this.bunifuFlatButton32.Iconimage_right_Selected = null;
            this.bunifuFlatButton32.Iconimage_Selected = null;
            this.bunifuFlatButton32.IconMarginLeft = 0;
            this.bunifuFlatButton32.IconMarginRight = 0;
            this.bunifuFlatButton32.IconRightVisible = false;
            this.bunifuFlatButton32.IconRightZoom = 0D;
            this.bunifuFlatButton32.IconVisible = true;
            this.bunifuFlatButton32.IconZoom = 75D;
            this.bunifuFlatButton32.IsTab = false;
            this.bunifuFlatButton32.Location = new System.Drawing.Point(247, 139);
            this.bunifuFlatButton32.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton32.Name = "bunifuFlatButton32";
            this.bunifuFlatButton32.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton32.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton32.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton32.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton32.selected = false;
            this.bunifuFlatButton32.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton32.TabIndex = 111;
            this.bunifuFlatButton32.Text = "تصدير   بي دي اف";
            this.bunifuFlatButton32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton32.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton32.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // bunifuFlatButton33
            // 
            this.bunifuFlatButton33.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton33.BorderRadius = 0;
            this.bunifuFlatButton33.ButtonText = "القيد المحاسبي";
            this.bunifuFlatButton33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton33.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton33.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton33.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton33.Iconimage = ((System.Drawing.Image)(resources.GetObject("bunifuFlatButton33.Iconimage")));
            this.bunifuFlatButton33.Iconimage_right = null;
            this.bunifuFlatButton33.Iconimage_right_Selected = null;
            this.bunifuFlatButton33.Iconimage_Selected = null;
            this.bunifuFlatButton33.IconMarginLeft = 0;
            this.bunifuFlatButton33.IconMarginRight = 0;
            this.bunifuFlatButton33.IconRightVisible = false;
            this.bunifuFlatButton33.IconRightZoom = 0D;
            this.bunifuFlatButton33.IconVisible = true;
            this.bunifuFlatButton33.IconZoom = 75D;
            this.bunifuFlatButton33.IsTab = false;
            this.bunifuFlatButton33.Location = new System.Drawing.Point(365, 139);
            this.bunifuFlatButton33.Margin = new System.Windows.Forms.Padding(4);
            this.bunifuFlatButton33.Name = "bunifuFlatButton33";
            this.bunifuFlatButton33.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuFlatButton33.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.bunifuFlatButton33.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton33.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.bunifuFlatButton33.selected = false;
            this.bunifuFlatButton33.Size = new System.Drawing.Size(110, 46);
            this.bunifuFlatButton33.TabIndex = 112;
            this.bunifuFlatButton33.Text = "القيد المحاسبي";
            this.bunifuFlatButton33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton33.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton33.TextFont = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.DimGray;
            this.groupBox3.Controls.Add(this.textBox1);
            this.groupBox3.Controls.Add(this.dateTimePicker1);
            this.groupBox3.Controls.Add(this.dataGridViewEntryHaed);
            this.groupBox3.Controls.Add(this.button6);
            this.groupBox3.Controls.Add(this.comboBox1);
            this.groupBox3.Controls.Add(this.button43);
            this.groupBox3.Controls.Add(this.button44);
            this.groupBox3.Controls.Add(this.button41);
            this.groupBox3.Controls.Add(this.button42);
            this.groupBox3.Controls.Add(this.button40);
            this.groupBox3.Controls.Add(this.button39);
            this.groupBox3.Controls.Add(this.button57);
            this.groupBox3.Controls.Add(this.button56);
            this.groupBox3.Controls.Add(this.button55);
            this.groupBox3.Controls.Add(this.button54);
            this.groupBox3.Controls.Add(this.button53);
            this.groupBox3.Controls.Add(this.button52);
            this.groupBox3.Controls.Add(this.button50);
            this.groupBox3.Controls.Add(this.button49);
            this.groupBox3.Controls.Add(this.button51);
            this.groupBox3.Controls.Add(this.button47);
            this.groupBox3.Controls.Add(this.button48);
            this.groupBox3.Controls.Add(this.button46);
            this.groupBox3.Controls.Add(this.button45);
            this.groupBox3.Controls.Add(this.button37);
            this.groupBox3.Controls.Add(this.button38);
            this.groupBox3.Controls.Add(this.button36);
            this.groupBox3.Controls.Add(this.button31);
            this.groupBox3.Controls.Add(this.button30);
            this.groupBox3.Controls.Add(this.button29);
            this.groupBox3.Controls.Add(this.button28);
            this.groupBox3.Controls.Add(this.txtSerch);
            this.groupBox3.Controls.Add(this.button5);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button8);
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.buttDelete);
            this.groupBox3.Controls.Add(this.buttEdite);
            this.groupBox3.Controls.Add(this.butSave);
            this.groupBox3.Controls.Add(this.buttAdd1);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 190);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1337, 456);
            this.groupBox3.TabIndex = 134;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "groupBox3";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(493, 364);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(197, 20);
            this.textBox1.TabIndex = 230;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(490, 324);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 228;
            // 
            // dataGridViewEntryHaed
            // 
            this.dataGridViewEntryHaed.AllowUserToAddRows = false;
            this.dataGridViewEntryHaed.AllowUserToDeleteRows = false;
            this.dataGridViewEntryHaed.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEntryHaed.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column10,
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14});
            this.dataGridViewEntryHaed.Dock = System.Windows.Forms.DockStyle.Right;
            this.dataGridViewEntryHaed.Location = new System.Drawing.Point(817, 16);
            this.dataGridViewEntryHaed.Name = "dataGridViewEntryHaed";
            this.dataGridViewEntryHaed.ReadOnly = true;
            this.dataGridViewEntryHaed.Size = new System.Drawing.Size(517, 437);
            this.dataGridViewEntryHaed.TabIndex = 227;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "رقم الصنف";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "اسم الصنف";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "الوحدة";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "السعر";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "IdUibtIteam";
            this.Column14.Name = "Column14";
            this.Column14.ReadOnly = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.White;
            this.button6.Image = global::AccSystem.Properties.Resources.Average_2_32px;
            this.button6.Location = new System.Drawing.Point(642, 55);
            this.button6.Name = "button6";
            this.button6.Padding = new System.Windows.Forms.Padding(10, 0, 10, 15);
            this.button6.Size = new System.Drawing.Size(69, 100);
            this.button6.TabIndex = 226;
            this.button6.Text = "عرض عناصر الكومبو2";
            this.button6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.SystemColors.Window;
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(435, 206);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(204, 21);
            this.comboBox1.TabIndex = 225;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button43.FlatAppearance.BorderSize = 0;
            this.button43.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button43.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button43.ForeColor = System.Drawing.Color.White;
            this.button43.Image = ((System.Drawing.Image)(resources.GetObject("button43.Image")));
            this.button43.Location = new System.Drawing.Point(130, 350);
            this.button43.Name = "button43";
            this.button43.Padding = new System.Windows.Forms.Padding(15, 0, 7, 0);
            this.button43.Size = new System.Drawing.Size(110, 46);
            this.button43.TabIndex = 224;
            this.button43.Text = "التالي";
            this.button43.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button43.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button44.FlatAppearance.BorderSize = 0;
            this.button44.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button44.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button44.ForeColor = System.Drawing.Color.White;
            this.button44.Image = ((System.Drawing.Image)(resources.GetObject("button44.Image")));
            this.button44.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button44.Location = new System.Drawing.Point(130, 402);
            this.button44.Name = "button44";
            this.button44.Padding = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.button44.Size = new System.Drawing.Size(110, 46);
            this.button44.TabIndex = 223;
            this.button44.Text = "الاخير";
            this.button44.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button44.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button41.FlatAppearance.BorderSize = 0;
            this.button41.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button41.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button41.ForeColor = System.Drawing.Color.White;
            this.button41.Image = ((System.Drawing.Image)(resources.GetObject("button41.Image")));
            this.button41.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button41.Location = new System.Drawing.Point(247, 350);
            this.button41.Name = "button41";
            this.button41.Padding = new System.Windows.Forms.Padding(20, 0, 11, 0);
            this.button41.Size = new System.Drawing.Size(110, 46);
            this.button41.TabIndex = 222;
            this.button41.Text = "الاول";
            this.button41.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button42.FlatAppearance.BorderSize = 0;
            this.button42.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button42.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button42.ForeColor = System.Drawing.Color.White;
            this.button42.Image = ((System.Drawing.Image)(resources.GetObject("button42.Image")));
            this.button42.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button42.Location = new System.Drawing.Point(247, 402);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(110, 46);
            this.button42.TabIndex = 221;
            this.button42.Text = "السابق";
            this.button42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button42.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button40.FlatAppearance.BorderSize = 0;
            this.button40.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button40.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button40.ForeColor = System.Drawing.Color.White;
            this.button40.Image = ((System.Drawing.Image)(resources.GetObject("button40.Image")));
            this.button40.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button40.Location = new System.Drawing.Point(15, 298);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(110, 46);
            this.button40.TabIndex = 220;
            this.button40.Text = "طباعة";
            this.button40.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button40.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button39.FlatAppearance.BorderSize = 0;
            this.button39.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button39.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button39.ForeColor = System.Drawing.Color.White;
            this.button39.Image = ((System.Drawing.Image)(resources.GetObject("button39.Image")));
            this.button39.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button39.Location = new System.Drawing.Point(131, 298);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(110, 46);
            this.button39.TabIndex = 219;
            this.button39.Text = "ترحيل";
            this.button39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button39.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button57.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button57.FlatAppearance.BorderSize = 0;
            this.button57.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button57.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button57.ForeColor = System.Drawing.Color.White;
            this.button57.Image = ((System.Drawing.Image)(resources.GetObject("button57.Image")));
            this.button57.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button57.Location = new System.Drawing.Point(247, 298);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(110, 46);
            this.button57.TabIndex = 218;
            this.button57.Text = "حذف";
            this.button57.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button57.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button57.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button56.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button56.FlatAppearance.BorderSize = 0;
            this.button56.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button56.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button56.ForeColor = System.Drawing.Color.White;
            this.button56.Image = ((System.Drawing.Image)(resources.GetObject("button56.Image")));
            this.button56.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button56.Location = new System.Drawing.Point(247, 246);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(110, 46);
            this.button56.TabIndex = 217;
            this.button56.Text = "جديد";
            this.button56.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button56.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button55.FlatAppearance.BorderSize = 0;
            this.button55.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button55.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button55.ForeColor = System.Drawing.Color.White;
            this.button55.Image = ((System.Drawing.Image)(resources.GetObject("button55.Image")));
            this.button55.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button55.Location = new System.Drawing.Point(131, 246);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(110, 46);
            this.button55.TabIndex = 216;
            this.button55.Text = "حفظ";
            this.button55.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button55.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button54.FlatAppearance.BorderSize = 0;
            this.button54.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button54.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button54.ForeColor = System.Drawing.Color.White;
            this.button54.Image = ((System.Drawing.Image)(resources.GetObject("button54.Image")));
            this.button54.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button54.Location = new System.Drawing.Point(363, 402);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(110, 46);
            this.button54.TabIndex = 215;
            this.button54.Text = "إضافة مستخدم";
            this.button54.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button54.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button54.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button53.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button53.FlatAppearance.BorderSize = 0;
            this.button53.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button53.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button53.ForeColor = System.Drawing.Color.White;
            this.button53.Image = ((System.Drawing.Image)(resources.GetObject("button53.Image")));
            this.button53.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button53.Location = new System.Drawing.Point(363, 350);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(110, 46);
            this.button53.TabIndex = 214;
            this.button53.Text = "إلغاء   الترحيل";
            this.button53.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button53.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button52.FlatAppearance.BorderSize = 0;
            this.button52.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button52.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button52.ForeColor = System.Drawing.Color.White;
            this.button52.Image = ((System.Drawing.Image)(resources.GetObject("button52.Image")));
            this.button52.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button52.Location = new System.Drawing.Point(363, 246);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(110, 46);
            this.button52.TabIndex = 213;
            this.button52.Text = "ترحيل";
            this.button52.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button52.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button50.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button50.FlatAppearance.BorderSize = 0;
            this.button50.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button50.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button50.ForeColor = System.Drawing.Color.White;
            this.button50.Image = ((System.Drawing.Image)(resources.GetObject("button50.Image")));
            this.button50.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button50.Location = new System.Drawing.Point(15, 246);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(110, 46);
            this.button50.TabIndex = 212;
            this.button50.Text = "تعديل";
            this.button50.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button50.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button50.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button49.FlatAppearance.BorderSize = 0;
            this.button49.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button49.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button49.ForeColor = System.Drawing.Color.White;
            this.button49.Image = ((System.Drawing.Image)(resources.GetObject("button49.Image")));
            this.button49.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button49.Location = new System.Drawing.Point(15, 350);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(110, 46);
            this.button49.TabIndex = 211;
            this.button49.Text = "تقريـــر";
            this.button49.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button49.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button49.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button51.FlatAppearance.BorderSize = 0;
            this.button51.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button51.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button51.ForeColor = System.Drawing.Color.White;
            this.button51.Image = ((System.Drawing.Image)(resources.GetObject("button51.Image")));
            this.button51.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button51.Location = new System.Drawing.Point(15, 402);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(110, 46);
            this.button51.TabIndex = 210;
            this.button51.Text = "استعلام";
            this.button51.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button51.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button47.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button47.FlatAppearance.BorderSize = 0;
            this.button47.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button47.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button47.ForeColor = System.Drawing.Color.White;
            this.button47.Image = ((System.Drawing.Image)(resources.GetObject("button47.Image")));
            this.button47.Location = new System.Drawing.Point(391, 106);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(54, 82);
            this.button47.TabIndex = 207;
            this.button47.Text = "انشاء نسخة";
            this.button47.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button47.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button48.FlatAppearance.BorderSize = 0;
            this.button48.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button48.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Font = new System.Drawing.Font("Tahoma", 6.5F, System.Drawing.FontStyle.Bold);
            this.button48.ForeColor = System.Drawing.Color.White;
            this.button48.Image = ((System.Drawing.Image)(resources.GetObject("button48.Image")));
            this.button48.Location = new System.Drawing.Point(451, 107);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(54, 82);
            this.button48.TabIndex = 206;
            this.button48.Text = "اضافة مستخدم";
            this.button48.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button48.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button46.FlatAppearance.BorderSize = 0;
            this.button46.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button46.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button46.ForeColor = System.Drawing.Color.White;
            this.button46.Image = ((System.Drawing.Image)(resources.GetObject("button46.Image")));
            this.button46.Location = new System.Drawing.Point(539, 236);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(54, 82);
            this.button46.TabIndex = 205;
            this.button46.Text = "تعبئة التاريخ";
            this.button46.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button45.FlatAppearance.BorderSize = 0;
            this.button45.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button45.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button45.ForeColor = System.Drawing.Color.White;
            this.button45.Image = ((System.Drawing.Image)(resources.GetObject("button45.Image")));
            this.button45.Location = new System.Drawing.Point(511, 107);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(54, 82);
            this.button45.TabIndex = 204;
            this.button45.Text = "انشاء نسخة";
            this.button45.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button45.UseVisualStyleBackColor = false;
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button37.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button37.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.button37.ForeColor = System.Drawing.Color.White;
            this.button37.Image = ((System.Drawing.Image)(resources.GetObject("button37.Image")));
            this.button37.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button37.Location = new System.Drawing.Point(11, 190);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(124, 50);
            this.button37.TabIndex = 197;
            this.button37.Text = "المجموعات المخــــــزنية";
            this.button37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button37.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button37.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button38.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button38.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button38.ForeColor = System.Drawing.Color.White;
            this.button38.Image = ((System.Drawing.Image)(resources.GetObject("button38.Image")));
            this.button38.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button38.Location = new System.Drawing.Point(11, 134);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(124, 50);
            this.button38.TabIndex = 196;
            this.button38.Text = "مخزون اول الـــــــــمده";
            this.button38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button38.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button36.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button36.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button36.ForeColor = System.Drawing.Color.White;
            this.button36.Image = ((System.Drawing.Image)(resources.GetObject("button36.Image")));
            this.button36.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button36.Location = new System.Drawing.Point(141, 190);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(124, 50);
            this.button36.TabIndex = 195;
            this.button36.Text = "رصـــيد افتتاحي";
            this.button36.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button36.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button31.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button31.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button31.ForeColor = System.Drawing.Color.White;
            this.button31.Image = ((System.Drawing.Image)(resources.GetObject("button31.Image")));
            this.button31.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button31.Location = new System.Drawing.Point(141, 134);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(124, 50);
            this.button31.TabIndex = 193;
            this.button31.Text = "صنف مكتسب";
            this.button31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button31.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button30.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button30.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button30.ForeColor = System.Drawing.Color.White;
            this.button30.Image = ((System.Drawing.Image)(resources.GetObject("button30.Image")));
            this.button30.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button30.Location = new System.Drawing.Point(11, 19);
            this.button30.Name = "button30";
            this.button30.Padding = new System.Windows.Forms.Padding(20, 0, 40, 0);
            this.button30.Size = new System.Drawing.Size(254, 50);
            this.button30.TabIndex = 189;
            this.button30.Text = "تقرير اليومة العامة";
            this.button30.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button29.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button29.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button29.ForeColor = System.Drawing.Color.White;
            this.button29.Image = ((System.Drawing.Image)(resources.GetObject("button29.Image")));
            this.button29.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button29.Location = new System.Drawing.Point(141, 78);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(124, 50);
            this.button29.TabIndex = 188;
            this.button29.Text = "ترحيل";
            this.button29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button29.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button28.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button28.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.button28.ForeColor = System.Drawing.Color.White;
            this.button28.Image = ((System.Drawing.Image)(resources.GetObject("button28.Image")));
            this.button28.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button28.Location = new System.Drawing.Point(11, 78);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(124, 50);
            this.button28.TabIndex = 187;
            this.button28.Text = "الغاء الترحيل";
            this.button28.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button28.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button28.UseVisualStyleBackColor = false;
            // 
            // txtSerch
            // 
            this.txtSerch.Location = new System.Drawing.Point(358, 186);
            this.txtSerch.Name = "txtSerch";
            this.txtSerch.Size = new System.Drawing.Size(353, 20);
            this.txtSerch.TabIndex = 168;
            this.txtSerch.Text = "يمنع الكتابة من خلال الاحداث";
            this.txtSerch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSerch.TextChanged += new System.EventHandler(this.txtSerch_TextChanged);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.White;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(331, 212);
            this.button5.Name = "button5";
            this.button5.Padding = new System.Windows.Forms.Padding(2);
            this.button5.Size = new System.Drawing.Size(30, 30);
            this.button5.TabIndex = 164;
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.Location = new System.Drawing.Point(304, 220);
            this.button4.Name = "button4";
            this.button4.Padding = new System.Windows.Forms.Padding(2);
            this.button4.Size = new System.Drawing.Size(20, 20);
            this.button4.TabIndex = 163;
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(730, 236);
            this.button3.Name = "button3";
            this.button3.Padding = new System.Windows.Forms.Padding(2);
            this.button3.Size = new System.Drawing.Size(25, 25);
            this.button3.TabIndex = 162;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.Location = new System.Drawing.Point(273, 19);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(54, 82);
            this.button8.TabIndex = 161;
            this.button8.Text = "طباعة";
            this.button8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.White;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.Location = new System.Drawing.Point(333, 19);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(54, 82);
            this.button7.TabIndex = 160;
            this.button7.Text = "ترحيل";
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.FlatAppearance.BorderSize = 0;
            this.buttDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.Location = new System.Drawing.Point(391, 19);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(54, 82);
            this.buttDelete.TabIndex = 159;
            this.buttDelete.Text = "حذف";
            this.buttDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttDelete.UseVisualStyleBackColor = false;
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.Location = new System.Drawing.Point(451, 19);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(54, 82);
            this.buttEdite.TabIndex = 158;
            this.buttEdite.Text = "تعديل";
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttEdite.UseVisualStyleBackColor = false;
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.Enabled = false;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.Location = new System.Drawing.Point(511, 19);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(54, 82);
            this.butSave.TabIndex = 157;
            this.butSave.Text = "حفظ";
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butSave.UseVisualStyleBackColor = false;
            // 
            // buttAdd1
            // 
            this.buttAdd1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd1.FlatAppearance.BorderSize = 0;
            this.buttAdd1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAdd1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAdd1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAdd1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd1.ForeColor = System.Drawing.Color.White;
            this.buttAdd1.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd1.Image")));
            this.buttAdd1.Location = new System.Drawing.Point(571, 19);
            this.buttAdd1.Name = "buttAdd1";
            this.buttAdd1.Size = new System.Drawing.Size(55, 82);
            this.buttAdd1.TabIndex = 156;
            this.buttAdd1.Text = "جديد";
            this.buttAdd1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttAdd1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = global::AccSystem.Properties.Resources.Average_2_32px;
            this.button2.Location = new System.Drawing.Point(717, 55);
            this.button2.Name = "button2";
            this.button2.Padding = new System.Windows.Forms.Padding(10, 0, 10, 15);
            this.button2.Size = new System.Drawing.Size(69, 100);
            this.button2.TabIndex = 155;
            this.button2.Text = "عرض عناصر الكمبو";
            this.button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = global::AccSystem.Properties.Resources.Flow_Chart_32px;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(363, 298);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 46);
            this.button1.TabIndex = 154;
            this.button1.Text = "تقرير";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // DGViewDate
            // 
            this.DGViewDate.AllowUserToAddRows = false;
            this.DGViewDate.AllowUserToDeleteRows = false;
            this.DGViewDate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGViewDate.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column1});
            this.DGViewDate.Dock = System.Windows.Forms.DockStyle.Left;
            this.DGViewDate.Location = new System.Drawing.Point(0, 646);
            this.DGViewDate.Name = "DGViewDate";
            this.DGViewDate.Size = new System.Drawing.Size(645, 151);
            this.DGViewDate.TabIndex = 229;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "رقم الصنف";
            this.Column17.Name = "Column17";
            // 
            // Column18
            // 
            this.Column18.HeaderText = "اسم الصنف";
            this.Column18.Name = "Column18";
            // 
            // Column19
            // 
            this.Column19.HeaderText = "الوحدة";
            this.Column19.Name = "Column19";
            // 
            // Column20
            // 
            this.Column20.HeaderText = "السعر";
            this.Column20.Name = "Column20";
            // 
            // Column21
            // 
            this.Column21.HeaderText = "اختيار";
            this.Column21.Name = "Column21";
            this.Column21.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "IdUnitIteam";
            this.Column1.Name = "Column1";
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button10.ForeColor = System.Drawing.Color.White;
            this.button10.Image = ((System.Drawing.Image)(resources.GetObject("button10.Image")));
            this.button10.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button10.Location = new System.Drawing.Point(651, 718);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(110, 46);
            this.button10.TabIndex = 230;
            this.button10.Text = "عرض الكل";
            this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button10.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.button11.ForeColor = System.Drawing.Color.White;
            this.button11.Image = ((System.Drawing.Image)(resources.GetObject("button11.Image")));
            this.button11.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button11.Location = new System.Drawing.Point(651, 666);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(110, 46);
            this.button11.TabIndex = 231;
            this.button11.Text = "عرض المحدد";
            this.button11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button11.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.Enabled = false;
            this.button13.FlatAppearance.BorderSize = 0;
            this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.ForeColor = System.Drawing.Color.White;
            this.button13.Image = ((System.Drawing.Image)(resources.GetObject("button13.Image")));
            this.button13.Location = new System.Drawing.Point(790, 666);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(117, 98);
            this.button13.TabIndex = 232;
            this.button13.Text = "حفظها في داتا تيبل";
            this.button13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button14.FlatAppearance.BorderSize = 0;
            this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.ForeColor = System.Drawing.Color.White;
            this.button14.Image = ((System.Drawing.Image)(resources.GetObject("button14.Image")));
            this.button14.Location = new System.Drawing.Point(925, 666);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(108, 98);
            this.button14.TabIndex = 231;
            this.button14.Text = "عرض العناصر من التيبل";
            this.button14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button14.UseVisualStyleBackColor = false;
            // 
            // TestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1620, 797);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.DGViewDate);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TestForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "TestForm";
            this.Load += new System.EventHandler(this.TestForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEntryHaed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGViewDate)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton33;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton32;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton31;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton28;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton27;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton26;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton25;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton24;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton23;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton7;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton34;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton35;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton36;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton37;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton38;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuTileButton buttAdd;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton20;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton19;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton18;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton15;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton14;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton13;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton12;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton11;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton22;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton21;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.TextBox txtSerch;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button buttDelete;
        private System.Windows.Forms.Button buttEdite;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button buttAdd1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridView dataGridViewEntryHaed;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DataGridView DGViewDate;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
    }
}