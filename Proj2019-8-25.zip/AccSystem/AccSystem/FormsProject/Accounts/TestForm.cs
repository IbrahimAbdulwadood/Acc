﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Accounts
{
    public partial class TestForm : Form
    {


        void ExampleDataTable()
        {


            //Example to define how to do :

            DataTable dt = new DataTable();

            dt.Columns.Add("ID");
            dt.Columns.Add("FirstName");
            dt.Columns.Add("LastName");
            dt.Columns.Add("Address");
            dt.Columns.Add("City");
            //  The table structure is:
            //ID    FirstName   LastName    Address     City

            //Now we want to add a PhoneNo column after the LastName column. For this we use the                               
            //SetOrdinal function, as iin:
            dt.Columns.Add("PhoneNo").SetOrdinal(3);

            //3 is the position number and positions start from 0.`enter code here`

            //Now the table structure will be:
            // ID      FirstName   LastName    LastName   PhoneNo     Address     City


            ////////////////////////////////////////////////////////////
           // this.callsTable.Columns.Add("Call", typeof(String));

        }

        #region مثال عن الدكشنري
        Dictionary<string, bool> dict = new Dictionary<string, bool>();
        void aa()
        {
            dict.Add("buttAdd", true);
            dict.Add("buttEdit", true);
            dict.Add("buttDelet", true);
            dict.Add("buttSearch", true);
            for (int i = 0; i < dict.Count; i++)
            {
                //Console.WriteLine("Key: {0}, Value: {1}",
                //                                        dict.Keys.ElementAt(i),
                //                                        dict[dict.Keys.ElementAt(i)]);
                MessageBox.Show(dict.Keys.ElementAt(i),(dict[dict.Keys.ElementAt(i)]).ToString());
            }
            MessageBox.Show(dict.Count.ToString());
            MessageBox.Show(dict["buttAdd"].ToString());
            ///////////////////////////////////////////
            bool result;

            if (dict.TryGetValue("buttDelet12", out result))
            {
                //Console.WriteLine(result);
                MessageBox.Show(result.ToString());
            }
            else
            {
                MessageBox.Show("لا يمكن العثور على المفتاح المحدد.");
                //Console.WriteLine("Could not find the specified key.");
            }
            ///////////////////////////////////////////////////
            //يحتوي على
            dict.ContainsKey("buttAdd"); // returns true
            dict.ContainsKey("buttAdd33"); // returns false

            ///////////////////////////////////////////////////
        }
        #endregion
        public TestForm(Dictionary<string, bool> pre)
        {
            InitializeComponent();
        }
        private class Item
        {
            public string Name;
            public int Value;
            public Item(string name, int value)
            {
                Name = name; Value = value;
            }
            public override string ToString()
            {
               // Generates the text shown in the combo box
                return Name;
            }
        }
        string flagAddOrEdit="";
        EntriesAccList eal;
        ClassesProject.AccountSQL AccClass = new ClassesProject.AccountSQL();
        ClassesProject.EntriesSQL EntriesClass = new ClassesProject.EntriesSQL();
        DataTable DTableEntryHaed;
        void fillData(string NormalOrSerch)
        {
            if (DTableEntryHaed == null)
                DTableEntryHaed = new DataTable();
            else
                DTableEntryHaed = null;
            DTableEntryHaed = new DataTable();

            if (NormalOrSerch == "All")

                DTableEntryHaed = EntriesClass.GetAllEntries();

            else if (NormalOrSerch == "Serch")
                DTableEntryHaed = EntriesClass.SerchEntreiesHaed(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridViewEntryHaed.Rows.Clear();
                MessageBox.Show(DTableEntryHaed.Rows.Count.ToString());
                for (int i = 0; i < DTableEntryHaed.Rows.Count; i++)
                {

                    /*
                     DTableEntryHaed
    Entry_id [0] , Date_entry [1] , Entry_sum [2], 	Refr_id[3], User_id_fk[4], .User_name[5],  Note[6]
      
                    DGV
 Entry_id [0] , 	Refr_id[1] ,  Date_entry [2] ,  Entry_sum [3] ,  User_id_fk[4] , .User_name[5] , Note[6]
                    */
                    dataGridViewEntryHaed.Rows.Add
                     (
                    DTableEntryHaed.Rows[i][0].ToString(), //Entry_id
                    DTableEntryHaed.Rows[i][3].ToString(), //Refr_idv
                    DTableEntryHaed.Rows[i][1].ToString(), //Date_entry
                    DTableEntryHaed.Rows[i][2].ToString(), //Entry_sum
                    DTableEntryHaed.Rows[i][4].ToString(), //User_id_fk
                    DTableEntryHaed.Rows[i][5].ToString(), //User_name
                    DTableEntryHaed.Rows[i][6].ToString()  //Note

                     );
                }
                if (dataGridViewEntryHaed.Rows.Count > 0)
                {
                    //FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridViewEntryHaed.Rows.Count == 0)
                {
                    //Entry_id.Text = string.Empty;
                    //Refr_id.Text = string.Empty;
                    //Entry_sum.Text = string.Empty;
                    //User_id_fk.Text = string.Empty;
                    //Note.Text = string.Empty;
                    //dateTimePicker1.Enabled = false;
                    //DGViewEntryBody.Rows.Clear();
                    //FillTextBoxCountRows((0).ToString());
                }

            }
            catch (Exception ee) { MessageBox.Show(ee.ToString()); }

        }
        void ShowListAcc(object sender, KeyEventArgs e)
        {

        //    if (e.KeyData == Keys.F9)
        //    {
        //        if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
        //        {
        //            int i = dataGridViewCurr.CurrentCell.RowIndex;
        //            int j = dataGridViewCurr.CurrentCell.ColumnIndex;
        //            try
        //            {
        //                // string[] a = null;
        //                List<string> a = new List<string>();
        //                eal = new EntriesAccList(a);
        //                eal.ShowDialog();
        //                if (eal.stateSelect = true && eal.dataGridView1.Rows.Count > 0)
        //                {
        //                    int indexSelect = EntriesAccList.indeex;

        //                    dataGridViewCurr.Rows[i].Cells[j].Value //رقم الحساب
        //                        = eal.dataGridView1.Rows[indexSelect].Cells[0].Value.ToString();
        //                    dataGridViewCurr.Rows[i].Cells[j + 1].Value //اسم الحساب
        //                        = eal.dataGridView1.Rows[indexSelect].Cells[1].Value.ToString();
        //                    dataGridViewCurr.Rows[i].Cells[4].Value  // سعر الصرف
        //                        = string.Empty;

        //                    ((DataGridViewComboBoxCell)dataGridViewCurr.Rows[i].Cells[3]).Items.Clear();

        //                    DataTable tbCurrAccComboBox =
        //                       AccClass.GetAccCurrIdAndNameCurr(dataGridViewCurr.Rows[i].Cells[j].Value.ToString());
        //                    //AccCurr_id,Curr_name
        //                    if (tbCurrAccComboBox.Rows.Count > 0)
        //                    {







        //                        for (int ii = 0; ii < tbCurrAccComboBox.Rows.Count; ii++)
        //                        {


        //                            ((DataGridViewComboBoxCell)dataGridViewCurr.Rows[i].Cells[3]).Items.Add((tbCurrAccComboBox.Rows[ii][1].ToString()));
                                   

        //                        }
                                

        //                        //   ChingCurr(i);
        //                        if (tbCurrAccComboBox != null)
        //                            tbCurrAccComboBox = null;
        //                    }
        //                    else
        //                    {
        //                        MessageBox.Show("الحساب موقف جميع عملاته لايمكن عمل اي قيد محاسبي على هذا الحساب", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //                        dataGridViewCurr.Rows[i].Cells[j].Value = "";
        //                        dataGridViewCurr.Rows[i].Cells[j + 1].Value = "";
                               
        //                    }
        //                }

        //                if (eal != null) eal = null;
        //            }
        //            catch (Exception ee) { MessageBox.Show(ee.ToString()); }
        //        }
        //    }
        //}
        //private void TestForm_Load(object sender, EventArgs e)
        //{
        //    comboBox1.Items.Add(new Item("Blue", 1));
        //    comboBox1.Items.Add(new Item("Red", 2));
        //    comboBox1.Items.Add(new Item("Nobugz", 666));
        //    fillData("All");

        }

        private void button1_MouseHover(object sender, EventArgs e)
        {

            // button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            // button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0)
            {
                Item itm = (Item)comboBox1.SelectedItem;
                MessageBox.Show(itm.Name + " " + itm.Value);

            }
            else
                MessageBox.Show("اختر حساب");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Item itm = (Item)comboBox1.SelectedItem;
            //MessageBox.Show(itm.Name+" "+ itm.Value);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex >= 0)
            {
              //  Item itm = (Item)comboBox1.SelectedItem;
                MessageBox.Show(comboBox1.ValueMember + " || " + comboBox1.DisplayMember);

            }
            else
                MessageBox.Show("اختر حساب");
        }
        string OpenOrClose = "";
        void StopAlphaInColumn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (OpenOrClose == "CloseAlpha")
            {     //IsPunctuation الفواصل العشرية
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsPunctuation(e.KeyChar))
                {
                    e.Handled = true;
                }

            }
            else if (OpenOrClose == "OpenAll") e.Handled = false;

            else if (OpenOrClose == "CloseAll") e.Handled = true;
            // OpenOrClose = string.Empty;
        }
        void StopAlphaFromDataGridView_EditingControlShowing(DataGridViewEditingControlShowingEventArgs e, int IndexColums)
        {
            //used in even dataGridView_EditingControlShowing
            //e.Control.KeyPress -= new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
            //if (dataGridViewCurr.CurrentCell.ColumnIndex == IndexColums)
            //{
            //    TextBox tb = e.Control as TextBox;
            //    if (tb != null)
            //    {
            //        tb.KeyPress += new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
            //        //  tb.KeyPress+=new KeyPressEventHandler(StopAlphaInTextBox);
            //    }
            //}


        }
        private void dataGridViewCurr_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //if (dataGridViewCurr.CurrentCell.ColumnIndex == 1 && e.Control is DataGridViewTextBoxEditingControl)
            //{
            //    flagAddOrEdit = "Add";
            //    OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 1); //ايقاف الكتابة كاملة
            //    DataGridViewTextBoxEditingControl tb = e.Control as DataGridViewTextBoxEditingControl;
            //    tb.KeyDown -= ShowListAcc;
            //    tb.KeyDown += ShowListAcc; //عرض شاشة الحسابات

            //}
            //if(dataGridViewCurr.CurrentCell.ColumnIndex==3 && e.Control is DataGridViewComboBoxEditingControl)
            //{

            //    ComboBox combo = e.Control as ComboBox;
            //    if (combo != null)
            //    {
            //        combo.SelectedIndexChanged -= new EventHandler(ComboBox_SelectedIndexChanged);
            //        combo.SelectedIndexChanged += new EventHandler(ComboBox_SelectedIndexChanged);
                    
            //    }
                
            //}
           
        }
     
         //cb;
        private void ComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //int i = dataGridViewCurr.CurrentCell.RowIndex;
            //int j = dataGridViewCurr.CurrentCell.ColumnIndex;
            //ComboBox cb = (ComboBox)sender;
            //string item = cb.Text;
            //if (item != null)
            //{
            //    MessageBox.Show(item + " || " + cb.SelectedIndex);
            //   // FlagChingIndexCombo2 = "True";

            //}
        }
      
        private void dataGridViewCurr_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
          
            
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

        private void button46_Click(object sender, EventArgs e)
        {
            DGViewDate.Rows.Add(dateTimePicker1.Value.ToShortDateString());
        }

        private void TestForm_Load(object sender, EventArgs e)
        {

        }
        DataTable tb;
        private void button10_Click(object sender, EventArgs e)
        { //تعبئة الجريد الرئيسية
            DGViewDate.Rows.Clear();
            tb= Push(false);
            if (tb.Rows.Count > 0)
            {
                for (int i = 0; i < tb.Rows.Count; i++)
                    DGViewDate.Rows.Add
                        (
                        tb.Rows[i][0].ToString(),
                         tb.Rows[i][1].ToString(),
                          tb.Rows[i][2].ToString(),
                           tb.Rows[i][3].ToString(),
                            null,
                             tb.Rows[i][4].ToString()
                        );
                for (int i = 0; i < DGViewDate.Rows.Count; i++)
                    DGViewDate.Rows[i].Cells[4].ReadOnly = false;
            }
        }

        ClassesProject.ConnectionDB con = new ClassesProject.ConnectionDB();
        DataTable Push(bool b)
        {
            //الداله اذا استقبلت فوولس يعني يشتي جميع الاصناف
            //اذا استقبلت ترووو تشتي اصناف محددة
            List<string> idItemUnit = new List<string>();
            idItemUnit.Clear();
            //عرفنا ليسته عشان تحفظ ارقام الاصناف الي حددناهم
            #region اذا اشتي اصناف محدد
            if (b) //اذا كان تروو يعني يشتي اصناف محددة
            if (DGViewDate.RowCount > 0)
            {
                    //يتاكد قبل ما يدخل هل في عناصر عشان يحددهم
                    //اذا كان في عناصر نعبيهم في اللسته الي عرفناه فوق
                    //اذا كان في اصناف في الدتا جريت
                    for (int i = 0; i < DGViewDate.RowCount; i++)
                {
                    if (Convert.ToBoolean(DGViewDate.Rows[i].Cells[4].Value) == true)
                        { //اذا كان مؤشر على هذا الصنف ضيفه
                            idItemUnit.Add(DGViewDate.Rows[i].Cells[5].Value.ToString());
                    }
                }
            }
            #endregion
            string
                quary = " SELECT   ";
                quary += " Items.barc, ";
                quary += " Items.Item_name, ";
                quary += " Units.Unit_name, ";
                quary += " ItemUnit.Selling_price, ";
                quary += " ItemUnit.idItemUnit ";
                quary += " FROM  ";
                quary += "  Items INNER JOIN ";
                quary += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN ";
                quary += "  Units ON ItemUnit.Unit_id_fk = Units.Unit_id ";
            #region اذا اشتي اصناف محددة
            if (b)
                {
                    quary += "  WHERE        (ItemUnit.idItemUnit in( ";
                if (idItemUnit.Count > 0) //اذا كان حجم اللسته اكبر من الصفر
                {
                    quary += idItemUnit[0];
                    for (int i = 1; i < idItemUnit.Count; i++)
                        quary += " ," + idItemUnit[i];
                }
                else  //اذا اللسته فاضي
                    quary += "-1";
                    quary += " )) ";
                }
            #endregion
            quary += " order by  Items.barc  ";

             MessageBox.Show(quary);
            con.OpenConnetion();
            DataTable dt = con.Query(quary, true);
            con.CloseConnetion();

            return dt;
                #region الاستعلام
                /*

SELECT        Items.barc, Items.Item_name, Units.Unit_name, ItemUnit.Selling_price
FROM            Items INNER JOIN
                     ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN
                     Units ON ItemUnit.Unit_id_fk = Units.Unit_id
                     WHERE        (ItemUnit.idItemUnit in(1,2,3,4,5))
                      order by  Items.barc

            */
                #endregion


            
        }

        private void button11_Click(object sender, EventArgs e)
        {
            dataGridViewEntryHaed.Rows.Clear();
            tb = Push(true);
            if (tb.Rows.Count > 0)
            {
                for (int i = 0; i < tb.Rows.Count; i++)
                    dataGridViewEntryHaed.Rows.Add
                        (
                        tb.Rows[i][0].ToString(),
                         tb.Rows[i][1].ToString(),
                          tb.Rows[i][2].ToString(),
                           tb.Rows[i][3].ToString(),
                            tb.Rows[i][4].ToString()
                        );
            }
        }

        private void button52_Click(object sender, EventArgs e)
        {
            aa();
        }







        ////////////
        //      as             as
        //     ss   sd     as    ss
        //     dd       ss       sd
        //     sd                sd         
        //      sd              gh
        //       df            df
        //        ff          sd
        //          we      sd
        //              dd
        ///////////

    }
}
