﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;
using NumberToWord;




namespace AccSystem.FormsProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //try
            //{
            //    ToWord toWord = new ToWord(Convert.ToDecimal(textBox1.Text), new CurrencyInfo(CurrencyInfo.Currencies.SaudiArabia));
            //    //MessageBox.Show(Convert.ToInt32(cboCurrency.SelectedValue).ToString());
            //   // txtEnglishWord.Text = toWord.ConvertToEnglish();
            //    label1.Text = toWord.ConvertToArabic();
            //}
            //catch 
            //{
            //   // txtEnglishWord.Text = String.Empty;
            //    label1.Text = String.Empty;
            //}

        }
    }
}
