﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Purchs
{
    public partial class AccListSupllier : Form
    {
        string[] AccsupllierExist;
        public AccListSupllier()
        {
            InitializeComponent();
        }

        int i;
        static public int indeex;
        public bool stateSelect = true;
        DataTable datatable;
        ClassesProject.SpulliersSql suplliersql = new ClassesProject.SpulliersSql();
        private void AccListSupllier_Load(object sender, EventArgs e)
        {
            AccsupllierExist = suplliersql.GetAccsupllier();
            datatable = suplliersql.GetAllAcc();
            bool b;
            if (datatable.Rows.Count > 0)
            {
                if (AccsupllierExist != null)
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        b = true;
                        for (int j = 0; j < AccsupllierExist.Length; j++)
                        {





                            if (AccsupllierExist[j] == datatable.Rows[i][0].ToString())
                            {


                                b = false;
                            }



                        }
                        if (b)
                        {
                            dataGridView1.Rows.Add(datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString());
                        }

                    }

                    if (dataGridView1.Rows.Count == 0)

                    {
                     
                        bunifuThinButton21.Visible = false;
                        label1.Visible = true;
                        label1.Text = "لا يوجد حسابات غير مرتبطة يرجى اضافة حساب من الدليل المحسابي";
                    }

                }
                else
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString());
                    }

                
            }


        }
    }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;

        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            indeex = dataGridView1.CurrentCell.RowIndex;
            MessageBox.Show(indeex.ToString());
            Close();
        }
    }
}
