﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;


namespace AccSystem.FormsProject.Purchs
{
    public partial class Suplliers : Form
    {
        ClassesProject.SpulliersSql Cs = new ClassesProject.SpulliersSql();
        DataTable dataTable;

        public string flagAddOrEdit = "";
        public Suplliers()
        {
            InitializeComponent();
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// داله خارجية تستقبل اسم اللغه و تحولها حسب الطلب و تستدعى عند الحدث انتر وليف
        /// </summary>
        /// <param name="inputName"></param>
        /// <returns></returns>
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }

        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>                                                                                  ///
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس                                        ///
        ///                                                                                           ///
        /// </summary>                                                                               ///
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        void MoveForm(MouseEventArgs e)
        {

            ///      نعملها في الحدث ماوووس داون//داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        
        /// <param name="e"></param>
        
        void FillTextBox()
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (dataGridView1.Rows.Count > 0)
            {

                int i = dataGridView1.CurrentCell.RowIndex;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */


              txtID.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                splName.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                txtAddress.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                txtphone.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
               txtEmail.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
                txtAcc.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
                txt_id_Acc.Text = dataGridView1.Rows[i].Cells[6].Value.ToString();
                txtNote.Text = dataGridView1.Rows[i].Cells[7].Value.ToString();
                FillTextBoxCountRows((i + 1).ToString());
            }
        }

        void fillData(string NormalOrSerch)
        {

            dataTable = new DataTable();
            if (NormalOrSerch == "All")
                //يستعلم عن جميع الموردين
                dataTable = Cs.GetAllSuplliers();
            else if (NormalOrSerch == "Serch")
                dataTable = Cs.Serch(txtSearch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridView1.Rows.Clear();

                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString(), dataTable.Rows[i][4].ToString(), dataTable.Rows[i][5].ToString(), dataTable.Rows[i][6].ToString(),dataTable.Rows[i][7].ToString());
                }
                if (dataGridView1.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    txtID.Text = string.Empty;
                    splName.Text = string.Empty;
                    txtAddress.Text = string.Empty;
                    txtphone.Text = string.Empty;
                    txtEmail.Text = string.Empty;
                  //  txtAcc.Text = string.Empty;
                    txtNote.Text = string.Empty;
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch { }

        }

        /// <param name="flagAddOrEditLo"></param>
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (splName.Text != string.Empty  && txtAcc.Text != string.Empty&&txtAddress.Text != string.Empty && txtphone.Text != string.Empty && txtEmail.Text != string.Empty )
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                       Cs.InsertSpullier(txtID.Text, splName.Text, txt_id_Acc.Text,txtAddress.Text, txtphone.Text,txtEmail.Text,txtNote.Text);

                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }


                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////////////////
           /* if (flagAddOrEditLo == "DELETE")
            {
                Cs.DELETEunit(txtid.Text);
                MessageBox.Show("تم الحذف");
                fillData("All");
            }*/
       ///////////////////////////////////////////////
            else if (flagAddOrEditLo == "Edite")
            {
                if (splName.Text != string.Empty && txtAddress.Text != string.Empty && txtphone.Text != string.Empty && txtEmail.Text != string.Empty  )
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                       Cs.UpdateCurrentsuplliers(txtID.Text, splName.Text,  txtAddress.Text, txtphone.Text, txtEmail.Text,  txtNote.Text);
                        MessageBox.Show("تم التعديل بنجاح");
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }

                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }

        /// </summary>
        /// <param name="flagEditeOrAddOrSave"></param>
        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                splName.ReadOnly = false;
                txtAddress.ReadOnly = false;
                txtphone.ReadOnly = false;
                txtEmail.ReadOnly = false;
                txtAcc.ReadOnly = false;
                txtNote.ReadOnly = false;

                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;



            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load" || flagEditeOrAddOrSave == "DELETE")
            {
                splName.ReadOnly = true;
                txtAddress.ReadOnly = true;
                txtphone.ReadOnly = true;
                txtEmail.ReadOnly = true;
                txtAcc.ReadOnly = true;
                txtNote.ReadOnly = true;

                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
            }
        }

        void ForamtingAdd()
        {
            txtID.Text = Cs.GetMaxId();
            splName.Text = "";
            txtAddress.Text = "";
            txtphone.Text = "";
            txtEmail.Text = "";
            txtAcc.Text = "";
            txtNote.Text = "";
        }
        void FillTextBoxFromButtMove(int i)
        {
            if (i >= 0)
            {
                dataGridView1.ClearSelection();

                txtID.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                splName.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                txtAddress.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                txtphone.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                txtEmail.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
                txtAcc.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
               txt_id_Acc.Text = dataGridView1.Rows[i].Cells[6].Value.ToString();
                txtNote.Text = dataGridView1.Rows[i].Cells[7].Value.ToString();

                FillTextBoxCountRows((i + 1).ToString());
            }

        }

        int indexsupllierButt(string btName, string SuplId)
        {
            /*
            داله لايجاد اندكس المورد حسب رقم المورد
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (SuplId == dataGridView1.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < dataGridView1.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return dataGridView1.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لايوجد مورين في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }

        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + dataGridView1.Rows.Count.ToString();
        }

        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));

        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Suplliers_Load(object sender, EventArgs e)
        {

            fillData("All");
            FormatingTextBoxAndButt("Load");
            dataGridView1.Select();
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {

            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SendDataToAddOrEdit(flagAddOrEdit);

        }

        private void buttEdite_Click(object sender, EventArgs e)
        {  flagAddOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
          
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexsupllierButt("Last", txtID.Text));
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexsupllierButt("Back", txtID.Text));

        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexsupllierButt("Next", txtID.Text));
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexsupllierButt("Frist", txtID.Text));

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Down || e.KeyData == Keys.Up)
            {
                if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                    FillTextBox();
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            MoveForm(e);
        }

        private void txtID_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void splName_TextChanged(object sender, EventArgs e)
        {

        }

        private void splName_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));

        }

        private void txtphone_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);

        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        AccListSupllier acclistsuplier;

        private void txtAcc_KeyDown(object sender, KeyEventArgs e)
        {


            if (txtAcc.Text == string.Empty && e.KeyData == Keys.F9)
            {
                // MessageBox.Show("Habloooooooo ya leeeed");
                acclistsuplier = new AccListSupllier();
                acclistsuplier.ShowDialog();

                /*
                 * معي متغير داخل الواجهه حق العملات من نوع بولين اذا كان مفعل
                 * و عدد الصفوف في الجريد حق العملات اكبر من 1 ادخل الشرط
                 * 
            */

                if (acclistsuplier.stateSelect && acclistsuplier.dataGridView1.RowCount > 0)
                {
                    int indexAccInDatGrV = AccListSupllier.indeex;
                    /*
               *  اندكس العمله حسب الداتا جريت فيو
                     *  عشان نجيب رقمها كما مكتوب قي الاسفل* 
          */
                    txt_id_Acc.Text = acclistsuplier.dataGridView1.Rows[indexAccInDatGrV].Cells[0].Value.ToString();
                    txtAcc.Text = acclistsuplier.dataGridView1.Rows[indexAccInDatGrV].Cells[1].Value.ToString();
                    //اضافة هذا المستخدم الى الصندوق



                }
            }
        }

        private void txtphone_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

