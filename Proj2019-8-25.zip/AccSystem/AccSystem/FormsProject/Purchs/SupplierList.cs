﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Purchs
{
    public partial class SupplierList : Form
    {
        string[] supllierExist;
        public SupplierList()
        {
            InitializeComponent();
        }
        int i;
        static public int indeex;
        public bool stateSelect = true;
        DataTable datatable;
        ClassesProject.SpulliersSql suplliersql = new ClassesProject.SpulliersSql();

        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            indeex = dataGridView1.CurrentCell.RowIndex;
            MessageBox.Show(indeex.ToString());
            Close();
        }

        private void SupplierList_Load(object sender, EventArgs e)
        {
            supllierExist = suplliersql.Getsupllierslist();
            datatable = suplliersql.GetAllSupplierlist();
            bool b;
            if (datatable.Rows.Count > 0)
            {
                if (supllierExist != null)
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        b = true;
                        for (int j = 0; j < supllierExist.Length; j++)
                        {





                            if (supllierExist[j] == datatable.Rows[i][0].ToString())
                            {


                                b = false;
                            }



                        }
                        if (b)
                        {
                            dataGridView1.Rows.Add(datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString());
                        }

                    }

                    if (dataGridView1.Rows.Count == 0)

                    {

                        bunifuThinButton21.Visible = false;
                        label1.Visible = true;
                        label1.Text = "لا يوجد موردين يرجى إضافة مورد من شاشة الموردين";
                    }

                }
                else
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString());
                    }


                }


            }
        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;

        }
    }
}
