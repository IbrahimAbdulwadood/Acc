﻿namespace AccSystem.FormsProject.Purchs
{
    partial class purchBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(purchBill));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panFillUp = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txt_id_store = new System.Windows.Forms.TextBox();
            this.txt_id_box = new System.Windows.Forms.TextBox();
            this.txt_name_user = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_id_user = new System.Windows.Forms.TextBox();
            this.txt_type_purch = new System.Windows.Forms.TextBox();
            this.txt_name_store = new System.Windows.Forms.TextBox();
            this.txt_name_box = new System.Windows.Forms.TextBox();
            this.txt_name_Acc = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_id_Acc = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.date_time1 = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_name_supllier = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_id_supiller = new System.Windows.Forms.TextBox();
            this.txt_id_purch = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSerch = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panDown = new System.Windows.Forms.Panel();
            this.panUp = new System.Windows.Forms.Panel();
            this.groupBoxOprea = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.buttDelete = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.butSave = new System.Windows.Forms.Button();
            this.buttAdd = new System.Windows.Forms.Button();
            this.CountRows = new System.Windows.Forms.TextBox();
            this.buttLast = new System.Windows.Forms.Button();
            this.buttBack = new System.Windows.Forms.Button();
            this.buttNext = new System.Windows.Forms.Button();
            this.buttFrist = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panFFDUp = new System.Windows.Forms.Panel();
            this.panFFDawn = new System.Windows.Forms.Panel();
            this.panFFDDown = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panFFUp = new System.Windows.Forms.Panel();
            this.panFillFill = new System.Windows.Forms.Panel();
            this.panFill = new System.Windows.Forms.Panel();
            this.panFillDawn = new System.Windows.Forms.Panel();
            this.panMain = new System.Windows.Forms.Panel();
            this.panFillUp.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.panUp.SuspendLayout();
            this.groupBoxOprea.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panFFDUp.SuspendLayout();
            this.panFFDawn.SuspendLayout();
            this.panFFDDown.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.panFFUp.SuspendLayout();
            this.panFillFill.SuspendLayout();
            this.panFill.SuspendLayout();
            this.panFillDawn.SuspendLayout();
            this.panMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox16
            // 
            this.textBox16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox16.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.ForeColor = System.Drawing.Color.Black;
            this.textBox16.Location = new System.Drawing.Point(12, 136);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(314, 26);
            this.textBox16.TabIndex = 9;
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label19.Location = new System.Drawing.Point(330, 142);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label19.Size = new System.Drawing.Size(48, 14);
            this.label19.TabIndex = 41;
            this.label19.Text = "البــيان:";
            // 
            // panFillUp
            // 
            this.panFillUp.Controls.Add(this.groupBox1);
            this.panFillUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFillUp.Location = new System.Drawing.Point(0, 0);
            this.panFillUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillUp.Name = "panFillUp";
            this.panFillUp.Size = new System.Drawing.Size(1290, 179);
            this.panFillUp.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView2);
            this.groupBox1.Controls.Add(this.txt_id_store);
            this.groupBox1.Controls.Add(this.txt_id_box);
            this.groupBox1.Controls.Add(this.txt_name_user);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txt_id_user);
            this.groupBox1.Controls.Add(this.txt_type_purch);
            this.groupBox1.Controls.Add(this.txt_name_store);
            this.groupBox1.Controls.Add(this.txt_name_box);
            this.groupBox1.Controls.Add(this.textBox16);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txt_name_Acc);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.txt_id_Acc);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.date_time1);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txt_name_supllier);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txt_id_supiller);
            this.groupBox1.Controls.Add(this.txt_id_purch);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(1290, 179);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column11,
            this.Column12,
            this.Column13,
            this.Column14,
            this.Column15,
            this.Column16,
            this.Column17,
            this.Column18,
            this.Column19,
            this.Column20,
            this.Column21,
            this.Column22,
            this.Column23,
            this.Column24,
            this.Column25,
            this.Column26,
            this.Column27,
            this.Column28,
            this.Column29,
            this.Column30,
            this.Column31});
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Right;
            this.dataGridView2.Location = new System.Drawing.Point(574, 18);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.dataGridView2.Size = new System.Drawing.Size(713, 159);
            this.dataGridView2.TabIndex = 52;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "رقم الفاتورة";
            this.Column11.Name = "Column11";
            // 
            // Column12
            // 
            this.Column12.HeaderText = "نوع الفاتورة";
            this.Column12.Name = "Column12";
            // 
            // Column13
            // 
            this.Column13.HeaderText = "رقم الصندوق";
            this.Column13.Name = "Column13";
            this.Column13.Visible = false;
            // 
            // Column14
            // 
            this.Column14.HeaderText = "اسم الصندوق";
            this.Column14.Name = "Column14";
            // 
            // Column15
            // 
            this.Column15.HeaderText = "رقم المخزن";
            this.Column15.Name = "Column15";
            this.Column15.Visible = false;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "اسم المخزن";
            this.Column16.Name = "Column16";
            this.Column16.Visible = false;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "رقم الحساب";
            this.Column17.Name = "Column17";
            this.Column17.Visible = false;
            // 
            // Column18
            // 
            this.Column18.HeaderText = "اسم الحساب";
            this.Column18.Name = "Column18";
            // 
            // Column19
            // 
            this.Column19.HeaderText = "رقم المورد";
            this.Column19.Name = "Column19";
            this.Column19.Visible = false;
            // 
            // Column20
            // 
            this.Column20.HeaderText = "اسم المورد";
            this.Column20.Name = "Column20";
            this.Column20.Visible = false;
            // 
            // Column21
            // 
            this.Column21.HeaderText = "رقم لمستخدم";
            this.Column21.Name = "Column21";
            this.Column21.Visible = false;
            // 
            // Column22
            // 
            this.Column22.HeaderText = "اسم المستخدم";
            this.Column22.Name = "Column22";
            // 
            // Column23
            // 
            this.Column23.HeaderText = "التاريخ";
            this.Column23.Name = "Column23";
            // 
            // Column24
            // 
            this.Column24.HeaderText = "البيان";
            this.Column24.Name = "Column24";
            // 
            // Column25
            // 
            this.Column25.HeaderText = "ضريبة المشتريات";
            this.Column25.Name = "Column25";
            // 
            // Column26
            // 
            this.Column26.HeaderText = "الخصم";
            this.Column26.Name = "Column26";
            // 
            // Column27
            // 
            this.Column27.HeaderText = "مصاريف حمالة";
            this.Column27.Name = "Column27";
            this.Column27.Visible = false;
            // 
            // Column28
            // 
            this.Column28.HeaderText = "مصاريف الشحن";
            this.Column28.Name = "Column28";
            this.Column28.Visible = false;
            // 
            // Column29
            // 
            this.Column29.HeaderText = "مصاريف التأمين";
            this.Column29.Name = "Column29";
            this.Column29.Visible = false;
            // 
            // Column30
            // 
            this.Column30.HeaderText = "إجمالي الفاتورة";
            this.Column30.Name = "Column30";
            this.Column30.Visible = false;
            // 
            // Column31
            // 
            this.Column31.HeaderText = "الصافي";
            this.Column31.Name = "Column31";
            this.Column31.Visible = false;
            // 
            // txt_id_store
            // 
            this.txt_id_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_id_store.Enabled = false;
            this.txt_id_store.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_store.ForeColor = System.Drawing.Color.Red;
            this.txt_id_store.Location = new System.Drawing.Point(364, 58);
            this.txt_id_store.Name = "txt_id_store";
            this.txt_id_store.Size = new System.Drawing.Size(19, 26);
            this.txt_id_store.TabIndex = 51;
            this.txt_id_store.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_id_box
            // 
            this.txt_id_box.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_id_box.Enabled = false;
            this.txt_id_box.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_box.ForeColor = System.Drawing.Color.Red;
            this.txt_id_box.Location = new System.Drawing.Point(12, 21);
            this.txt_id_box.Name = "txt_id_box";
            this.txt_id_box.Size = new System.Drawing.Size(20, 26);
            this.txt_id_box.TabIndex = 50;
            this.txt_id_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_name_user
            // 
            this.txt_name_user.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_name_user.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name_user.ForeColor = System.Drawing.Color.Black;
            this.txt_name_user.Location = new System.Drawing.Point(26, 90);
            this.txt_name_user.Name = "txt_name_user";
            this.txt_name_user.Size = new System.Drawing.Size(174, 26);
            this.txt_name_user.TabIndex = 7;
            this.txt_name_user.Text = "المستخدم";
            this.txt_name_user.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label18.Location = new System.Drawing.Point(199, 96);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(78, 14);
            this.label18.TabIndex = 48;
            this.label18.Text = ":  المستخدم";
            // 
            // txt_id_user
            // 
            this.txt_id_user.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_id_user.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_user.ForeColor = System.Drawing.Color.Black;
            this.txt_id_user.Location = new System.Drawing.Point(9, 93);
            this.txt_id_user.Name = "txt_id_user";
            this.txt_id_user.Size = new System.Drawing.Size(18, 26);
            this.txt_id_user.TabIndex = 47;
            this.txt_id_user.Text = "1";
            this.txt_id_user.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_type_purch
            // 
            this.txt_type_purch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_type_purch.Enabled = false;
            this.txt_type_purch.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_type_purch.ForeColor = System.Drawing.Color.Red;
            this.txt_type_purch.Location = new System.Drawing.Point(205, 21);
            this.txt_type_purch.Name = "txt_type_purch";
            this.txt_type_purch.Size = new System.Drawing.Size(104, 26);
            this.txt_type_purch.TabIndex = 2;
            this.txt_type_purch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_type_purch.TextChanged += new System.EventHandler(this.textBox19_TextChanged);
            // 
            // txt_name_store
            // 
            this.txt_name_store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_name_store.Enabled = false;
            this.txt_name_store.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name_store.ForeColor = System.Drawing.Color.Red;
            this.txt_name_store.Location = new System.Drawing.Point(389, 58);
            this.txt_name_store.Name = "txt_name_store";
            this.txt_name_store.Size = new System.Drawing.Size(104, 26);
            this.txt_name_store.TabIndex = 4;
            this.txt_name_store.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_name_box
            // 
            this.txt_name_box.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_name_box.Enabled = false;
            this.txt_name_box.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name_box.ForeColor = System.Drawing.Color.Red;
            this.txt_name_box.Location = new System.Drawing.Point(38, 21);
            this.txt_name_box.Name = "txt_name_box";
            this.txt_name_box.Size = new System.Drawing.Size(104, 26);
            this.txt_name_box.TabIndex = 3;
            this.txt_name_box.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_name_box.TextChanged += new System.EventHandler(this.textBox17_TextChanged);
            // 
            // txt_name_Acc
            // 
            this.txt_name_Acc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_name_Acc.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name_Acc.ForeColor = System.Drawing.Color.Black;
            this.txt_name_Acc.Location = new System.Drawing.Point(302, 93);
            this.txt_name_Acc.Name = "txt_name_Acc";
            this.txt_name_Acc.Size = new System.Drawing.Size(198, 26);
            this.txt_name_Acc.TabIndex = 6;
            this.txt_name_Acc.Text = "الحساب ";
            this.txt_name_Acc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_name_Acc.TextChanged += new System.EventHandler(this.txt_name_Acc_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label17.Location = new System.Drawing.Point(490, 102);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 14);
            this.label17.TabIndex = 37;
            this.label17.Text = ":  الحساب";
            // 
            // txt_id_Acc
            // 
            this.txt_id_Acc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_id_Acc.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_Acc.ForeColor = System.Drawing.Color.Black;
            this.txt_id_Acc.Location = new System.Drawing.Point(275, 93);
            this.txt_id_Acc.Name = "txt_id_Acc";
            this.txt_id_Acc.Size = new System.Drawing.Size(26, 26);
            this.txt_id_Acc.TabIndex = 36;
            this.txt_id_Acc.Text = "112321";
            this.txt_id_Acc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label15.Location = new System.Drawing.Point(499, 64);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 14);
            this.label15.TabIndex = 33;
            this.label15.Text = ": المخزن";
            // 
            // date_time1
            // 
            this.date_time1.AllowDrop = true;
            this.date_time1.CalendarMonthBackground = System.Drawing.Color.Silver;
            this.date_time1.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.date_time1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date_time1.Location = new System.Drawing.Point(384, 139);
            this.date_time1.Name = "date_time1";
            this.date_time1.Size = new System.Drawing.Size(129, 23);
            this.date_time1.TabIndex = 8;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(519, 142);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 14);
            this.label14.TabIndex = 16;
            this.label14.Text = ": التاريخ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label11.Location = new System.Drawing.Point(141, 27);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 14);
            this.label11.TabIndex = 12;
            this.label11.Text = ": الصندوق";
            // 
            // txt_name_supllier
            // 
            this.txt_name_supllier.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_name_supllier.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_name_supllier.ForeColor = System.Drawing.Color.Black;
            this.txt_name_supllier.Location = new System.Drawing.Point(38, 58);
            this.txt_name_supllier.Name = "txt_name_supllier";
            this.txt_name_supllier.Size = new System.Drawing.Size(263, 26);
            this.txt_name_supllier.TabIndex = 5;
            this.txt_name_supllier.Text = "مورد نقدي";
            this.txt_name_supllier.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(307, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 14);
            this.label10.TabIndex = 10;
            this.label10.Text = ": المورد";
            // 
            // txt_id_supiller
            // 
            this.txt_id_supiller.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txt_id_supiller.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_supiller.ForeColor = System.Drawing.Color.Black;
            this.txt_id_supiller.Location = new System.Drawing.Point(9, 58);
            this.txt_id_supiller.Name = "txt_id_supiller";
            this.txt_id_supiller.Size = new System.Drawing.Size(23, 26);
            this.txt_id_supiller.TabIndex = 9;
            this.txt_id_supiller.Text = "1";
            this.txt_id_supiller.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_id_purch
            // 
            this.txt_id_purch.BackColor = System.Drawing.Color.Gray;
            this.txt_id_purch.Enabled = false;
            this.txt_id_purch.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_id_purch.ForeColor = System.Drawing.Color.White;
            this.txt_id_purch.Location = new System.Drawing.Point(384, 21);
            this.txt_id_purch.Name = "txt_id_purch";
            this.txt_id_purch.ReadOnly = true;
            this.txt_id_purch.Size = new System.Drawing.Size(109, 26);
            this.txt_id_purch.TabIndex = 1;
            this.txt_id_purch.Text = "12";
            this.txt_id_purch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label8.Location = new System.Drawing.Point(308, 27);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(77, 14);
            this.label8.TabIndex = 7;
            this.label8.Text = "نوع الفاتورة:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(489, 27);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(84, 14);
            this.label1.TabIndex = 3;
            this.label1.Text = "رقم الفاتورة: ";
            // 
            // txtSerch
            // 
            this.txtSerch.BackColor = System.Drawing.Color.DimGray;
            this.txtSerch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSerch.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerch.ForeColor = System.Drawing.Color.White;
            this.txtSerch.Location = new System.Drawing.Point(50, 8);
            this.txtSerch.Name = "txtSerch";
            this.txtSerch.Size = new System.Drawing.Size(316, 23);
            this.txtSerch.TabIndex = 8;
            this.txtSerch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(12, 5);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 27);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 10;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Location = new System.Drawing.Point(989, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(234, 27);
            this.label13.TabIndex = 9;
            this.label13.Text = "        فاتورة مشتريات  ";
            // 
            // panDown
            // 
            this.panDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDown.Location = new System.Drawing.Point(0, 577);
            this.panDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDown.Name = "panDown";
            this.panDown.Size = new System.Drawing.Size(1290, 27);
            this.panDown.TabIndex = 1;
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Controls.Add(this.label13);
            this.panUp.Controls.Add(this.txtSerch);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(1290, 37);
            this.panUp.TabIndex = 0;
            // 
            // groupBoxOprea
            // 
            this.groupBoxOprea.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxOprea.Controls.Add(this.button1);
            this.groupBoxOprea.Controls.Add(this.button2);
            this.groupBoxOprea.Controls.Add(this.buttDelete);
            this.groupBoxOprea.Controls.Add(this.buttEdite);
            this.groupBoxOprea.Controls.Add(this.butSave);
            this.groupBoxOprea.Controls.Add(this.buttAdd);
            this.groupBoxOprea.Controls.Add(this.CountRows);
            this.groupBoxOprea.Controls.Add(this.buttLast);
            this.groupBoxOprea.Controls.Add(this.buttBack);
            this.groupBoxOprea.Controls.Add(this.buttNext);
            this.groupBoxOprea.Controls.Add(this.buttFrist);
            this.groupBoxOprea.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBoxOprea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxOprea.ForeColor = System.Drawing.Color.Black;
            this.groupBoxOprea.Location = new System.Drawing.Point(0, 3);
            this.groupBoxOprea.Name = "groupBoxOprea";
            this.groupBoxOprea.Size = new System.Drawing.Size(1290, 102);
            this.groupBoxOprea.TabIndex = 34;
            this.groupBoxOprea.TabStop = false;
            this.groupBoxOprea.Enter += new System.EventHandler(this.groupBoxOprea_Enter);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.Location = new System.Drawing.Point(818, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(54, 82);
            this.button1.TabIndex = 165;
            this.button1.Text = "طباعة";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.Location = new System.Drawing.Point(878, 17);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(54, 82);
            this.button2.TabIndex = 164;
            this.button2.Text = "ترحيل";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.FlatAppearance.BorderSize = 0;
            this.buttDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.Location = new System.Drawing.Point(944, 17);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(54, 82);
            this.buttDelete.TabIndex = 163;
            this.buttDelete.Text = "حذف";
            this.buttDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttDelete.UseVisualStyleBackColor = false;
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.Location = new System.Drawing.Point(1004, 17);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(54, 82);
            this.buttEdite.TabIndex = 162;
            this.buttEdite.Text = "تعديل";
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttEdite.UseVisualStyleBackColor = false;
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.Location = new System.Drawing.Point(1064, 17);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(54, 82);
            this.butSave.TabIndex = 161;
            this.butSave.Text = "حفظ";
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butSave.UseVisualStyleBackColor = false;
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.FlatAppearance.BorderSize = 0;
            this.buttAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.Location = new System.Drawing.Point(1124, 17);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(55, 82);
            this.buttAdd.TabIndex = 160;
            this.buttAdd.Text = "جديد";
            this.buttAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttAdd.UseVisualStyleBackColor = false;
            // 
            // CountRows
            // 
            this.CountRows.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CountRows.Enabled = false;
            this.CountRows.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountRows.Location = new System.Drawing.Point(153, 39);
            this.CountRows.Name = "CountRows";
            this.CountRows.ReadOnly = true;
            this.CountRows.Size = new System.Drawing.Size(133, 33);
            this.CountRows.TabIndex = 159;
            this.CountRows.Text = "1111-1111";
            this.CountRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttLast
            // 
            this.buttLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttLast.FlatAppearance.BorderSize = 0;
            this.buttLast.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttLast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttLast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttLast.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttLast.ForeColor = System.Drawing.Color.White;
            this.buttLast.Image = ((System.Drawing.Image)(resources.GetObject("buttLast.Image")));
            this.buttLast.Location = new System.Drawing.Point(26, 17);
            this.buttLast.Name = "buttLast";
            this.buttLast.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.buttLast.Size = new System.Drawing.Size(57, 82);
            this.buttLast.TabIndex = 158;
            this.buttLast.Text = "الاخير";
            this.buttLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttLast.UseVisualStyleBackColor = false;
            // 
            // buttBack
            // 
            this.buttBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBack.FlatAppearance.BorderSize = 0;
            this.buttBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBack.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttBack.ForeColor = System.Drawing.Color.White;
            this.buttBack.Image = ((System.Drawing.Image)(resources.GetObject("buttBack.Image")));
            this.buttBack.Location = new System.Drawing.Point(89, 17);
            this.buttBack.Name = "buttBack";
            this.buttBack.Size = new System.Drawing.Size(57, 82);
            this.buttBack.TabIndex = 157;
            this.buttBack.Text = "السابق";
            this.buttBack.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttBack.UseVisualStyleBackColor = false;
            // 
            // buttNext
            // 
            this.buttNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttNext.FlatAppearance.BorderSize = 0;
            this.buttNext.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttNext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttNext.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttNext.ForeColor = System.Drawing.Color.White;
            this.buttNext.Image = ((System.Drawing.Image)(resources.GetObject("buttNext.Image")));
            this.buttNext.Location = new System.Drawing.Point(292, 17);
            this.buttNext.Name = "buttNext";
            this.buttNext.Size = new System.Drawing.Size(57, 82);
            this.buttNext.TabIndex = 156;
            this.buttNext.Text = "التالي";
            this.buttNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttNext.UseVisualStyleBackColor = false;
            // 
            // buttFrist
            // 
            this.buttFrist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFrist.FlatAppearance.BorderSize = 0;
            this.buttFrist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttFrist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttFrist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttFrist.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttFrist.ForeColor = System.Drawing.Color.White;
            this.buttFrist.Image = ((System.Drawing.Image)(resources.GetObject("buttFrist.Image")));
            this.buttFrist.Location = new System.Drawing.Point(355, 17);
            this.buttFrist.Name = "buttFrist";
            this.buttFrist.Size = new System.Drawing.Size(57, 82);
            this.buttFrist.TabIndex = 155;
            this.buttFrist.Text = "الاول";
            this.buttFrist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttFrist.UseVisualStyleBackColor = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox2);
            this.groupBox4.Controls.Add(this.label12);
            this.groupBox4.Controls.Add(this.textBox1);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.textBox9);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.textBox8);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.textBox4);
            this.groupBox4.Controls.Add(this.textBox7);
            this.groupBox4.Controls.Add(this.textBox3);
            this.groupBox4.Controls.Add(this.textBox5);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox4.Size = new System.Drawing.Size(1290, 91);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "المبلغ رقماً";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.ForeColor = System.Drawing.Color.SeaGreen;
            this.textBox2.Location = new System.Drawing.Point(384, 42);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(131, 36);
            this.textBox2.TabIndex = 30;
            this.textBox2.Text = "1220000";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label12.Location = new System.Drawing.Point(407, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 14);
            this.label12.TabIndex = 29;
            this.label12.Text = "مصاريف التأمين";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.SeaGreen;
            this.textBox1.Location = new System.Drawing.Point(525, 42);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(131, 36);
            this.textBox1.TabIndex = 28;
            this.textBox1.Text = "1220000";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(548, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 14);
            this.label3.TabIndex = 27;
            this.label3.Text = "مصاريف الشحن";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox9.Enabled = false;
            this.textBox9.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.ForeColor = System.Drawing.Color.Brown;
            this.textBox9.Location = new System.Drawing.Point(192, 42);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(157, 36);
            this.textBox9.TabIndex = 26;
            this.textBox9.Text = "1220000.12";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label9.Location = new System.Drawing.Point(74, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 14);
            this.label9.TabIndex = 25;
            this.label9.Text = "المتبقي";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox8.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.ForeColor = System.Drawing.Color.Green;
            this.textBox8.Location = new System.Drawing.Point(8, 43);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(163, 36);
            this.textBox8.TabIndex = 24;
            this.textBox8.Text = "1220000";
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(232, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 14);
            this.label2.TabIndex = 23;
            this.label2.Text = "المدفوع";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox4.Enabled = false;
            this.textBox4.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.ForeColor = System.Drawing.Color.Blue;
            this.textBox4.Location = new System.Drawing.Point(1080, 42);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(166, 36);
            this.textBox4.TabIndex = 22;
            this.textBox4.Text = "1220000";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox7.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.ForeColor = System.Drawing.Color.Red;
            this.textBox7.Location = new System.Drawing.Point(936, 42);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(131, 36);
            this.textBox7.TabIndex = 21;
            this.textBox7.Text = "1220000";
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox3.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox3.Location = new System.Drawing.Point(799, 42);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(131, 36);
            this.textBox3.TabIndex = 20;
            this.textBox3.Text = "1220000";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox5.Enabled = false;
            this.textBox5.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.ForeColor = System.Drawing.Color.SeaGreen;
            this.textBox5.Location = new System.Drawing.Point(662, 42);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(131, 36);
            this.textBox5.TabIndex = 19;
            this.textBox5.Text = "1220000";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(685, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 14);
            this.label7.TabIndex = 13;
            this.label7.Text = "مصاريف حماله";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(820, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 14);
            this.label6.TabIndex = 11;
            this.label6.Text = "ضريبة مشتريات";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(981, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 14);
            this.label5.TabIndex = 9;
            this.label5.Text = "الخصم";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(1117, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 14);
            this.label4.TabIndex = 7;
            this.label4.Text = "اجمالي الفاتورة";
            // 
            // panFFDUp
            // 
            this.panFFDUp.Controls.Add(this.groupBox4);
            this.panFFDUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFFDUp.Location = new System.Drawing.Point(0, 0);
            this.panFFDUp.Name = "panFFDUp";
            this.panFFDUp.Size = new System.Drawing.Size(1290, 107);
            this.panFFDUp.TabIndex = 1;
            // 
            // panFFDawn
            // 
            this.panFFDawn.Controls.Add(this.panFFDUp);
            this.panFFDawn.Controls.Add(this.panFFDDown);
            this.panFFDawn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panFFDawn.Location = new System.Drawing.Point(0, 122);
            this.panFFDawn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFFDawn.Name = "panFFDawn";
            this.panFFDawn.Size = new System.Drawing.Size(1290, 134);
            this.panFFDawn.TabIndex = 0;
            // 
            // panFFDDown
            // 
            this.panFFDDown.Controls.Add(this.groupBox2);
            this.panFFDDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panFFDDown.Location = new System.Drawing.Point(0, 84);
            this.panFFDDown.Name = "panFFDDown";
            this.panFFDDown.Size = new System.Drawing.Size(1290, 50);
            this.panFFDDown.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox10);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox2.Size = new System.Drawing.Size(1290, 50);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "المبلغ كتابة";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.Color.Lavender;
            this.textBox10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.ForeColor = System.Drawing.Color.Black;
            this.textBox10.Location = new System.Drawing.Point(3, 19);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(1284, 27);
            this.textBox10.TabIndex = 10;
            this.textBox10.Text = "اثنا عشر الف وخمس مائة ريال يمني فقط لا غير";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "الاجمالي الكلي";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "اجمالي الوحدة";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "اجمالي الجزء";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "سعر الجزء";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "سعر الوحدة";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "الجزء";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "الوحدة";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "اسم الصنف";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "رقم الصنف";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 18);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1284, 102);
            this.dataGridView1.TabIndex = 36;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column4
            // 
            this.Column4.HeaderText = "الكمية";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dataGridView1);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox3.Size = new System.Drawing.Size(1290, 122);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "تفاصيل الفاتورة";
            // 
            // panFFUp
            // 
            this.panFFUp.Controls.Add(this.groupBox3);
            this.panFFUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFFUp.Location = new System.Drawing.Point(0, 0);
            this.panFFUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFFUp.Name = "panFFUp";
            this.panFFUp.Size = new System.Drawing.Size(1290, 122);
            this.panFFUp.TabIndex = 2;
            // 
            // panFillFill
            // 
            this.panFillFill.Controls.Add(this.panFFUp);
            this.panFillFill.Controls.Add(this.panFFDawn);
            this.panFillFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFillFill.Location = new System.Drawing.Point(0, 179);
            this.panFillFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillFill.Name = "panFillFill";
            this.panFillFill.Size = new System.Drawing.Size(1290, 256);
            this.panFillFill.TabIndex = 2;
            // 
            // panFill
            // 
            this.panFill.Controls.Add(this.panFillFill);
            this.panFill.Controls.Add(this.panFillDawn);
            this.panFill.Controls.Add(this.panFillUp);
            this.panFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFill.Location = new System.Drawing.Point(0, 37);
            this.panFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFill.Name = "panFill";
            this.panFill.Size = new System.Drawing.Size(1290, 540);
            this.panFill.TabIndex = 2;
            // 
            // panFillDawn
            // 
            this.panFillDawn.Controls.Add(this.groupBoxOprea);
            this.panFillDawn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panFillDawn.Location = new System.Drawing.Point(0, 435);
            this.panFillDawn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillDawn.Name = "panFillDawn";
            this.panFillDawn.Size = new System.Drawing.Size(1290, 105);
            this.panFillDawn.TabIndex = 1;
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panFill);
            this.panMain.Controls.Add(this.panDown);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1290, 604);
            this.panMain.TabIndex = 1;
            // 
            // purchBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1290, 604);
            this.Controls.Add(this.panMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "purchBill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "purchBill";
            this.panFillUp.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            this.groupBoxOprea.ResumeLayout(false);
            this.groupBoxOprea.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panFFDUp.ResumeLayout(false);
            this.panFFDawn.ResumeLayout(false);
            this.panFFDDown.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.panFFUp.ResumeLayout(false);
            this.panFillFill.ResumeLayout(false);
            this.panFill.ResumeLayout(false);
            this.panFillDawn.ResumeLayout(false);
            this.panMain.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panFillUp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_name_Acc;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txt_id_Acc;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker date_time1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txt_name_supllier;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_id_supiller;
        private System.Windows.Forms.TextBox txt_id_purch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSerch;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panDown;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.GroupBox groupBoxOprea;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panFFDUp;
        private System.Windows.Forms.Panel panFFDawn;
        private System.Windows.Forms.Panel panFFDDown;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewComboBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panFFUp;
        private System.Windows.Forms.Panel panFillFill;
        private System.Windows.Forms.Panel panFill;
        private System.Windows.Forms.Panel panFillDawn;
        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.TextBox txt_name_store;
        private System.Windows.Forms.TextBox txt_name_box;
        private System.Windows.Forms.TextBox txt_name_user;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_id_user;
        private System.Windows.Forms.TextBox txt_type_purch;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox CountRows;
        private System.Windows.Forms.Button buttLast;
        private System.Windows.Forms.Button buttBack;
        private System.Windows.Forms.Button buttNext;
        private System.Windows.Forms.Button buttFrist;
        private System.Windows.Forms.Button buttDelete;
        private System.Windows.Forms.Button buttEdite;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button buttAdd;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox txt_id_store;
        private System.Windows.Forms.TextBox txt_id_box;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column22;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column24;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column25;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column29;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column30;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column31;
    }
}