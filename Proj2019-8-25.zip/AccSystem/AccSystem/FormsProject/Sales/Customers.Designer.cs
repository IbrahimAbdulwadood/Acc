﻿namespace AccSystem.FormsProject.Sales
{
    partial class Customers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customers));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_main = new System.Windows.Forms.Panel();
            this.groupBoxOprea = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.buttNext = new System.Windows.Forms.Button();
            this.buttFrist = new System.Windows.Forms.Button();
            this.CountRows = new System.Windows.Forms.TextBox();
            this.buttBack = new System.Windows.Forms.Button();
            this.buttLast = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.butSave = new System.Windows.Forms.Button();
            this.buttAdd = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.buttDelete = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panFillUpUp = new System.Windows.Forms.Panel();
            this.panel_Main_Center_Center = new System.Windows.Forms.Panel();
            this.groupBoxAllCurr = new System.Windows.Forms.GroupBox();
            this.DGVBody = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel_Main_cenetr_up = new System.Windows.Forms.Panel();
            this.groupBoxData = new System.Windows.Forms.GroupBox();
            this.txtCustAcount = new System.Windows.Forms.TextBox();
            this.txtCustMax = new System.Windows.Forms.TextBox();
            this.txtCustCurr = new System.Windows.Forms.TextBox();
            this.txtCustAccName = new System.Windows.Forms.TextBox();
            this.txtCustAccId = new System.Windows.Forms.TextBox();
            this.txtCustNote = new System.Windows.Forms.TextBox();
            this.txtCustPhone = new System.Windows.Forms.TextBox();
            this.txtCustEmail = new System.Windows.Forms.TextBox();
            this.txtCustAddress = new System.Windows.Forms.TextBox();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.txtCustId = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panUp = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSerch = new System.Windows.Forms.TextBox();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.panel_main.SuspendLayout();
            this.groupBoxOprea.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panFillUpUp.SuspendLayout();
            this.panel_Main_Center_Center.SuspendLayout();
            this.groupBoxAllCurr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVBody)).BeginInit();
            this.panel_Main_cenetr_up.SuspendLayout();
            this.groupBoxData.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_main
            // 
            this.panel_main.Controls.Add(this.groupBoxOprea);
            this.panel_main.Controls.Add(this.panel1);
            this.panel_main.Controls.Add(this.panFillUpUp);
            this.panel_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_main.Location = new System.Drawing.Point(0, 0);
            this.panel_main.Name = "panel_main";
            this.panel_main.Size = new System.Drawing.Size(921, 548);
            this.panel_main.TabIndex = 0;
            // 
            // groupBoxOprea
            // 
            this.groupBoxOprea.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxOprea.Controls.Add(this.panel3);
            this.groupBoxOprea.Controls.Add(this.panel2);
            this.groupBoxOprea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxOprea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxOprea.ForeColor = System.Drawing.Color.Black;
            this.groupBoxOprea.Location = new System.Drawing.Point(0, 376);
            this.groupBoxOprea.Name = "groupBoxOprea";
            this.groupBoxOprea.Size = new System.Drawing.Size(921, 137);
            this.groupBoxOprea.TabIndex = 38;
            this.groupBoxOprea.TabStop = false;
            this.groupBoxOprea.Text = "العمليات";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.buttNext);
            this.panel3.Controls.Add(this.buttFrist);
            this.panel3.Controls.Add(this.CountRows);
            this.panel3.Controls.Add(this.buttBack);
            this.panel3.Controls.Add(this.buttLast);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(3, 19);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(434, 115);
            this.panel3.TabIndex = 180;
            // 
            // buttNext
            // 
            this.buttNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttNext.FlatAppearance.BorderSize = 0;
            this.buttNext.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttNext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttNext.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttNext.ForeColor = System.Drawing.Color.White;
            this.buttNext.Image = ((System.Drawing.Image)(resources.GetObject("buttNext.Image")));
            this.buttNext.Location = new System.Drawing.Point(282, 12);
            this.buttNext.Name = "buttNext";
            this.buttNext.Size = new System.Drawing.Size(57, 82);
            this.buttNext.TabIndex = 169;
            this.buttNext.Text = "التالي";
            this.buttNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttNext.UseVisualStyleBackColor = false;
            this.buttNext.Click += new System.EventHandler(this.buttNext_Click);
            // 
            // buttFrist
            // 
            this.buttFrist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFrist.FlatAppearance.BorderSize = 0;
            this.buttFrist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttFrist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttFrist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttFrist.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttFrist.ForeColor = System.Drawing.Color.White;
            this.buttFrist.Image = ((System.Drawing.Image)(resources.GetObject("buttFrist.Image")));
            this.buttFrist.Location = new System.Drawing.Point(345, 12);
            this.buttFrist.Name = "buttFrist";
            this.buttFrist.Size = new System.Drawing.Size(57, 82);
            this.buttFrist.TabIndex = 168;
            this.buttFrist.Text = "الاول";
            this.buttFrist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttFrist.UseVisualStyleBackColor = false;
            this.buttFrist.Click += new System.EventHandler(this.buttFrist_Click);
            // 
            // CountRows
            // 
            this.CountRows.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CountRows.Enabled = false;
            this.CountRows.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountRows.Location = new System.Drawing.Point(143, 34);
            this.CountRows.Name = "CountRows";
            this.CountRows.ReadOnly = true;
            this.CountRows.Size = new System.Drawing.Size(133, 33);
            this.CountRows.TabIndex = 172;
            this.CountRows.Text = "1111-1111";
            this.CountRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttBack
            // 
            this.buttBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBack.FlatAppearance.BorderSize = 0;
            this.buttBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBack.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttBack.ForeColor = System.Drawing.Color.White;
            this.buttBack.Image = ((System.Drawing.Image)(resources.GetObject("buttBack.Image")));
            this.buttBack.Location = new System.Drawing.Point(79, 12);
            this.buttBack.Name = "buttBack";
            this.buttBack.Size = new System.Drawing.Size(57, 82);
            this.buttBack.TabIndex = 170;
            this.buttBack.Text = "السابق";
            this.buttBack.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttBack.UseVisualStyleBackColor = false;
            this.buttBack.Click += new System.EventHandler(this.buttBack_Click);
            // 
            // buttLast
            // 
            this.buttLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttLast.FlatAppearance.BorderSize = 0;
            this.buttLast.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttLast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttLast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttLast.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttLast.ForeColor = System.Drawing.Color.White;
            this.buttLast.Image = ((System.Drawing.Image)(resources.GetObject("buttLast.Image")));
            this.buttLast.Location = new System.Drawing.Point(15, 12);
            this.buttLast.Name = "buttLast";
            this.buttLast.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.buttLast.Size = new System.Drawing.Size(57, 82);
            this.buttLast.TabIndex = 171;
            this.buttLast.Text = "الاخير";
            this.buttLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttLast.UseVisualStyleBackColor = false;
            this.buttLast.Click += new System.EventHandler(this.buttLast_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.butSave);
            this.panel2.Controls.Add(this.buttAdd);
            this.panel2.Controls.Add(this.buttEdite);
            this.panel2.Controls.Add(this.buttDelete);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(644, 19);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(274, 115);
            this.panel2.TabIndex = 179;
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.Location = new System.Drawing.Point(139, 12);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(54, 82);
            this.butSave.TabIndex = 165;
            this.butSave.Text = "حفظ";
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butSave.UseVisualStyleBackColor = false;
            this.butSave.Click += new System.EventHandler(this.butSave_Click);
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.FlatAppearance.BorderSize = 0;
            this.buttAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.Location = new System.Drawing.Point(199, 12);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(55, 82);
            this.buttAdd.TabIndex = 164;
            this.buttAdd.Text = "جديد";
            this.buttAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttAdd.UseVisualStyleBackColor = false;
            this.buttAdd.Click += new System.EventHandler(this.buttAdd_Click);
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.Location = new System.Drawing.Point(79, 12);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(54, 82);
            this.buttEdite.TabIndex = 166;
            this.buttEdite.Text = "تعديل";
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttEdite.UseVisualStyleBackColor = false;
            this.buttEdite.Click += new System.EventHandler(this.buttEdite_Click);
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.FlatAppearance.BorderSize = 0;
            this.buttDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.Location = new System.Drawing.Point(19, 12);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(54, 82);
            this.buttDelete.TabIndex = 167;
            this.buttDelete.Text = "حذف";
            this.buttDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttDelete.UseVisualStyleBackColor = false;
            this.buttDelete.Click += new System.EventHandler(this.buttDelete_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 513);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(921, 35);
            this.panel1.TabIndex = 36;
            // 
            // panFillUpUp
            // 
            this.panFillUpUp.Controls.Add(this.panel_Main_Center_Center);
            this.panFillUpUp.Controls.Add(this.panel_Main_cenetr_up);
            this.panFillUpUp.Controls.Add(this.panUp);
            this.panFillUpUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFillUpUp.Location = new System.Drawing.Point(0, 0);
            this.panFillUpUp.Name = "panFillUpUp";
            this.panFillUpUp.Size = new System.Drawing.Size(921, 376);
            this.panFillUpUp.TabIndex = 35;
            // 
            // panel_Main_Center_Center
            // 
            this.panel_Main_Center_Center.Controls.Add(this.groupBoxAllCurr);
            this.panel_Main_Center_Center.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main_Center_Center.Location = new System.Drawing.Point(0, 174);
            this.panel_Main_Center_Center.Name = "panel_Main_Center_Center";
            this.panel_Main_Center_Center.Size = new System.Drawing.Size(921, 202);
            this.panel_Main_Center_Center.TabIndex = 45;
            // 
            // groupBoxAllCurr
            // 
            this.groupBoxAllCurr.Controls.Add(this.DGVBody);
            this.groupBoxAllCurr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxAllCurr.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxAllCurr.Location = new System.Drawing.Point(0, 0);
            this.groupBoxAllCurr.Name = "groupBoxAllCurr";
            this.groupBoxAllCurr.Size = new System.Drawing.Size(921, 202);
            this.groupBoxAllCurr.TabIndex = 1;
            this.groupBoxAllCurr.TabStop = false;
            this.groupBoxAllCurr.Text = "بيانات جميع العملاء";
            // 
            // DGVBody
            // 
            this.DGVBody.AllowUserToAddRows = false;
            this.DGVBody.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            this.DGVBody.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.DGVBody.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVBody.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGVBody.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DGVBody.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVBody.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.DGVBody.ColumnHeadersHeight = 30;
            this.DGVBody.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGVBody.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn11});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVBody.DefaultCellStyle = dataGridViewCellStyle8;
            this.DGVBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVBody.EnableHeadersVisualStyles = false;
            this.DGVBody.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DGVBody.Location = new System.Drawing.Point(3, 19);
            this.DGVBody.Name = "DGVBody";
            this.DGVBody.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVBody.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.DGVBody.RowHeadersVisible = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.Gray;
            this.DGVBody.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.DGVBody.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVBody.Size = new System.Drawing.Size(915, 180);
            this.DGVBody.TabIndex = 44;
            this.DGVBody.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBody_CellClick);
            this.DGVBody.SelectionChanged += new System.EventHandler(this.DGVBody_SelectionChanged);
            this.DGVBody.KeyUp += new System.Windows.Forms.KeyEventHandler(this.DGVBody_KeyUp);
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn12.Frozen = true;
            this.dataGridViewTextBoxColumn12.HeaderText = "idAccCurr";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Visible = false;
            this.dataGridViewTextBoxColumn12.Width = 77;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "رقم العميل";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 82;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn2.FillWeight = 288.8852F;
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "اسم العميل";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 87;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn3.FillWeight = 525.3807F;
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "العنوان";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 56;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn4.FillWeight = 50.06168F;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "رقم التلفون";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 115;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 115;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn5.FillWeight = 20.84476F;
            this.dataGridViewTextBoxColumn5.Frozen = true;
            this.dataGridViewTextBoxColumn5.HeaderText = "البريد الالكتروني";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 112;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn6.FillWeight = 8.683408F;
            this.dataGridViewTextBoxColumn6.Frozen = true;
            this.dataGridViewTextBoxColumn6.HeaderText = "البيان";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 46;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn7.FillWeight = 3.62132F;
            this.dataGridViewTextBoxColumn7.HeaderText = "رقم الحساب";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 90;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn8.FillWeight = 1.514259F;
            this.dataGridViewTextBoxColumn8.HeaderText = "اسم الحساب";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 95;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn10.FillWeight = 0.3715312F;
            this.dataGridViewTextBoxColumn10.HeaderText = "العملة";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 53;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn9.FillWeight = 0.6372076F;
            this.dataGridViewTextBoxColumn9.HeaderText = "حد الدين";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 65;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn11.HeaderText = "الرصيد";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Width = 53;
            // 
            // panel_Main_cenetr_up
            // 
            this.panel_Main_cenetr_up.Controls.Add(this.groupBoxData);
            this.panel_Main_cenetr_up.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Main_cenetr_up.Location = new System.Drawing.Point(0, 44);
            this.panel_Main_cenetr_up.Name = "panel_Main_cenetr_up";
            this.panel_Main_cenetr_up.Size = new System.Drawing.Size(921, 130);
            this.panel_Main_cenetr_up.TabIndex = 44;
            // 
            // groupBoxData
            // 
            this.groupBoxData.Controls.Add(this.txtCustAcount);
            this.groupBoxData.Controls.Add(this.txtCustMax);
            this.groupBoxData.Controls.Add(this.txtCustCurr);
            this.groupBoxData.Controls.Add(this.txtCustAccName);
            this.groupBoxData.Controls.Add(this.txtCustAccId);
            this.groupBoxData.Controls.Add(this.txtCustNote);
            this.groupBoxData.Controls.Add(this.txtCustPhone);
            this.groupBoxData.Controls.Add(this.txtCustEmail);
            this.groupBoxData.Controls.Add(this.txtCustAddress);
            this.groupBoxData.Controls.Add(this.txtCustName);
            this.groupBoxData.Controls.Add(this.txtCustId);
            this.groupBoxData.Controls.Add(this.label12);
            this.groupBoxData.Controls.Add(this.label11);
            this.groupBoxData.Controls.Add(this.label9);
            this.groupBoxData.Controls.Add(this.label8);
            this.groupBoxData.Controls.Add(this.label7);
            this.groupBoxData.Controls.Add(this.label5);
            this.groupBoxData.Controls.Add(this.label4);
            this.groupBoxData.Controls.Add(this.label3);
            this.groupBoxData.Controls.Add(this.label2);
            this.groupBoxData.Controls.Add(this.label6);
            this.groupBoxData.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxData.ForeColor = System.Drawing.Color.Black;
            this.groupBoxData.Location = new System.Drawing.Point(0, 0);
            this.groupBoxData.Name = "groupBoxData";
            this.groupBoxData.Size = new System.Drawing.Size(921, 128);
            this.groupBoxData.TabIndex = 39;
            this.groupBoxData.TabStop = false;
            this.groupBoxData.Text = "البيانات";
            // 
            // txtCustAcount
            // 
            this.txtCustAcount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustAcount.ForeColor = System.Drawing.Color.Black;
            this.txtCustAcount.Location = new System.Drawing.Point(37, 86);
            this.txtCustAcount.Name = "txtCustAcount";
            this.txtCustAcount.ReadOnly = true;
            this.txtCustAcount.Size = new System.Drawing.Size(141, 23);
            this.txtCustAcount.TabIndex = 60;
            this.txtCustAcount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCustMax
            // 
            this.txtCustMax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustMax.ForeColor = System.Drawing.Color.Black;
            this.txtCustMax.Location = new System.Drawing.Point(226, 86);
            this.txtCustMax.Name = "txtCustMax";
            this.txtCustMax.ReadOnly = true;
            this.txtCustMax.Size = new System.Drawing.Size(100, 23);
            this.txtCustMax.TabIndex = 59;
            this.txtCustMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCustCurr
            // 
            this.txtCustCurr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustCurr.ForeColor = System.Drawing.Color.Black;
            this.txtCustCurr.Location = new System.Drawing.Point(393, 86);
            this.txtCustCurr.Name = "txtCustCurr";
            this.txtCustCurr.ReadOnly = true;
            this.txtCustCurr.Size = new System.Drawing.Size(86, 23);
            this.txtCustCurr.TabIndex = 58;
            this.txtCustCurr.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCustAccName
            // 
            this.txtCustAccName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustAccName.ForeColor = System.Drawing.Color.Black;
            this.txtCustAccName.Location = new System.Drawing.Point(546, 86);
            this.txtCustAccName.Name = "txtCustAccName";
            this.txtCustAccName.ReadOnly = true;
            this.txtCustAccName.Size = new System.Drawing.Size(151, 23);
            this.txtCustAccName.TabIndex = 57;
            this.txtCustAccName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCustAccId
            // 
            this.txtCustAccId.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustAccId.ForeColor = System.Drawing.Color.Black;
            this.txtCustAccId.Location = new System.Drawing.Point(700, 86);
            this.txtCustAccId.Name = "txtCustAccId";
            this.txtCustAccId.ReadOnly = true;
            this.txtCustAccId.Size = new System.Drawing.Size(111, 23);
            this.txtCustAccId.TabIndex = 56;
            this.txtCustAccId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCustAccId.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCustAccId_KeyDown);
            // 
            // txtCustNote
            // 
            this.txtCustNote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustNote.ForeColor = System.Drawing.Color.Black;
            this.txtCustNote.Location = new System.Drawing.Point(37, 52);
            this.txtCustNote.Name = "txtCustNote";
            this.txtCustNote.ReadOnly = true;
            this.txtCustNote.Size = new System.Drawing.Size(278, 23);
            this.txtCustNote.TabIndex = 55;
            this.txtCustNote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCustPhone
            // 
            this.txtCustPhone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustPhone.ForeColor = System.Drawing.Color.Black;
            this.txtCustPhone.Location = new System.Drawing.Point(680, 56);
            this.txtCustPhone.Name = "txtCustPhone";
            this.txtCustPhone.ReadOnly = true;
            this.txtCustPhone.Size = new System.Drawing.Size(131, 23);
            this.txtCustPhone.TabIndex = 54;
            this.txtCustPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCustPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCustPhone_KeyPress);
            // 
            // txtCustEmail
            // 
            this.txtCustEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustEmail.ForeColor = System.Drawing.Color.Black;
            this.txtCustEmail.Location = new System.Drawing.Point(381, 52);
            this.txtCustEmail.Name = "txtCustEmail";
            this.txtCustEmail.ReadOnly = true;
            this.txtCustEmail.Size = new System.Drawing.Size(180, 23);
            this.txtCustEmail.TabIndex = 53;
            this.txtCustEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCustAddress
            // 
            this.txtCustAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustAddress.ForeColor = System.Drawing.Color.Black;
            this.txtCustAddress.Location = new System.Drawing.Point(37, 20);
            this.txtCustAddress.Name = "txtCustAddress";
            this.txtCustAddress.ReadOnly = true;
            this.txtCustAddress.Size = new System.Drawing.Size(278, 23);
            this.txtCustAddress.TabIndex = 52;
            this.txtCustAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCustAddress.Leave += new System.EventHandler(this.txtCustAddress_Leave);
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustName.ForeColor = System.Drawing.Color.Black;
            this.txtCustName.Location = new System.Drawing.Point(381, 20);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.ReadOnly = true;
            this.txtCustName.Size = new System.Drawing.Size(180, 23);
            this.txtCustName.TabIndex = 51;
            this.txtCustName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCustName.Enter += new System.EventHandler(this.txtCustName_Enter);
            this.txtCustName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCustName_KeyPress);
            // 
            // txtCustId
            // 
            this.txtCustId.BackColor = System.Drawing.Color.Gray;
            this.txtCustId.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustId.ForeColor = System.Drawing.Color.White;
            this.txtCustId.Location = new System.Drawing.Point(680, 18);
            this.txtCustId.Name = "txtCustId";
            this.txtCustId.ReadOnly = true;
            this.txtCustId.Size = new System.Drawing.Size(131, 26);
            this.txtCustId.TabIndex = 35;
            this.txtCustId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(176, 89);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 16);
            this.label12.TabIndex = 34;
            this.label12.Text = "الرصيد:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(481, 89);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(52, 16);
            this.label11.TabIndex = 33;
            this.label11.Text = "العملة:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(817, 89);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 16);
            this.label9.TabIndex = 31;
            this.label9.Text = "الحساب:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(317, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 16);
            this.label8.TabIndex = 29;
            this.label8.Text = "البيان:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(324, 89);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(64, 16);
            this.label7.TabIndex = 26;
            this.label7.Text = "حد الدين:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(317, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 16);
            this.label5.TabIndex = 24;
            this.label5.Text = "العنوان:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(564, 59);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 16);
            this.label4.TabIndex = 22;
            this.label4.Text = "البريد الإلكتروني:";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(816, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 20;
            this.label3.Text = "رقم التلفون:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(817, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "رقم العميل:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(564, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 16);
            this.label6.TabIndex = 19;
            this.label6.Text = "اسم العميل:";
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.pictureBox2);
            this.panUp.Controls.Add(this.label1);
            this.panUp.Controls.Add(this.txtSerch);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(921, 44);
            this.panUp.TabIndex = 43;
            this.panUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panUp_MouseDown);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::AccSystem.Properties.Resources.Search_32px;
            this.pictureBox2.Location = new System.Drawing.Point(382, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 27);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(751, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 27);
            this.label1.TabIndex = 9;
            this.label1.Text = "        العـــــمــلاء";
            // 
            // txtSerch
            // 
            this.txtSerch.BackColor = System.Drawing.Color.DimGray;
            this.txtSerch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSerch.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerch.ForeColor = System.Drawing.Color.White;
            this.txtSerch.Location = new System.Drawing.Point(50, 6);
            this.txtSerch.Name = "txtSerch";
            this.txtSerch.Size = new System.Drawing.Size(316, 23);
            this.txtSerch.TabIndex = 8;
            this.txtSerch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSerch.TextChanged += new System.EventHandler(this.txtSerch_TextChanged);
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(12, 3);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 27);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 7;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            this.pictureClose.MouseHover += new System.EventHandler(this.pictureClose_MouseHover);
            // 
            // Customers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 548);
            this.Controls.Add(this.panel_main);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Customers";
            this.Opacity = 0.95D;
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "Customers";
            this.Load += new System.EventHandler(this.Customers_Load);
            this.panel_main.ResumeLayout(false);
            this.groupBoxOprea.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panFillUpUp.ResumeLayout(false);
            this.panel_Main_Center_Center.ResumeLayout(false);
            this.groupBoxAllCurr.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVBody)).EndInit();
            this.panel_Main_cenetr_up.ResumeLayout(false);
            this.groupBoxData.ResumeLayout(false);
            this.groupBoxData.PerformLayout();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_main;
        private System.Windows.Forms.Panel panFillUpUp;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSerch;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.Panel panel_Main_Center_Center;
        private System.Windows.Forms.Panel panel_Main_cenetr_up;
        private System.Windows.Forms.GroupBox groupBoxData;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBoxAllCurr;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBoxOprea;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView DGVBody;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCustId;
        private System.Windows.Forms.TextBox txtCustAcount;
        private System.Windows.Forms.TextBox txtCustMax;
        private System.Windows.Forms.TextBox txtCustCurr;
        private System.Windows.Forms.TextBox txtCustAccName;
        private System.Windows.Forms.TextBox txtCustAccId;
        private System.Windows.Forms.TextBox txtCustNote;
        private System.Windows.Forms.TextBox txtCustPhone;
        private System.Windows.Forms.TextBox txtCustEmail;
        private System.Windows.Forms.TextBox txtCustAddress;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button buttAdd;
        private System.Windows.Forms.Button buttEdite;
        private System.Windows.Forms.Button buttDelete;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button buttNext;
        private System.Windows.Forms.Button buttFrist;
        private System.Windows.Forms.TextBox CountRows;
        private System.Windows.Forms.Button buttBack;
        private System.Windows.Forms.Button buttLast;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
    }
}