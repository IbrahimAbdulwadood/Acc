﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;

namespace AccSystem.FormsProject.Sales
{
    public partial class Customers : Form
    {
        public Customers(Dictionary<string, bool> pre)
        {
            InitializeComponent();
            preForm = pre;
        }

        #region

        #region لغه الادخال

        ////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// داله خارجية تستقبل اسم اللغه و تحولها حسب الطلب و تستدعى عند الحدث انتر وليف
        /// </summary>
        /// <param name="inputName"></param>
        /// <returns></returns>
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }

        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }


        ///
        ///
        ///
        //////////////////////////////////////////////////////////////////////////////////////////////////////

        #endregion

        #region تحريك الواجهة
        /////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>                                                                                  ///
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس                                        ///
        ///                                                                                           ///
        /// </summary>                                                                               ///
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        void MoveForm(MouseEventArgs e)
        {

            ///      نعملها في الحدث ماوووس داون//داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        /// 
        /// 
        /// <param name="e"></param>
        /// 
        /// 
        ///     //داله عشان احرك الفورم 
        /// //ننسخها في الحدث MouseDown
        ///    //if (e.Button == MouseButtons.Left)
        ///    //{
        ///    //    ReleaseCapture();
        ///    //    SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        ///    //}
        ///
        ///
        ///////////////////////////////////////////////////////////////////////////////
        #endregion


        #region المتغيرات

        AccListCustomer ListCust;
        CustomersSql CustSql = new CustomersSql();
        Dictionary<string, bool> preForm = new Dictionary<string, bool>();


        DataTable dataTable;
        public string flagAddOrEdit = "";
        #endregion

        #region الدوال
        #region استدعاء الواجه التي تعرض الحسابات المتاحه لربطها مع العميل
        void ShowListAcc()
        {
            ListCust = new AccListCustomer();
            ListCust.ShowDialog();
            if (
                ListCust.stateSelect
                && AccListCustomer.indeex>=0
                &&ListCust.dataGridView1.RowCount>0
                )
            {

                int i = AccListCustomer.indeex;
              
                txtCustAccId.Tag = ListCust.dataGridView1.Rows[i].Cells[0].Value.ToString();
                txtCustAccId.Text= ListCust.dataGridView1.Rows[i].Cells[1].Value.ToString();
                txtCustAccName.Text= ListCust.dataGridView1.Rows[i].Cells[2].Value.ToString();
                txtCustCurr.Text = ListCust.dataGridView1.Rows[i].Cells[3].Value.ToString();
                AccListCustomer.indeex = -1;
                ListCust.stateSelect = false;

            }


        }
        #endregion
        void fillData(string NormalOrSerch)
        {

            dataTable = new DataTable();
            if (NormalOrSerch == "All")
                //يستعلم عن جميع العملات
                dataTable = CustSql.GetAllCustomers();
            //curClass.GetAllCurr();
            else if (NormalOrSerch == "Serch")
                dataTable = CustSql.Serch(txtSerch.Text);
            //curClass.Serch(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                DGVBody.Rows.Clear();
                #region البيانات الي ترجع في التيبل
                /*
                Customers.Cust_id 0
              , Customers.Cust_name 1
              , Customers.Cust_address  2
              , Customers.Cust_phone 3
              , Customers.Cust_email 4
              , Customers.Note 5
              , AccCurrency.AccCurr_id 6
              , Accounts.Acc_id 7
              , Accounts.Acc_name 8
              , AccCurrency.Maximum 9
              , Currencys.Curr_sumbol_eng 10
              , Account 11
                
                */
                #endregion
                if (dataTable != null && dataTable.Rows.Count > 0)
                    for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    DGVBody.Rows.Add(
                         dataTable.Rows[i][6].ToString() //AccCurr_id
                       , dataTable.Rows[i][0].ToString() //Cust_id
                       , dataTable.Rows[i][1].ToString() //Cust_name
                       , dataTable.Rows[i][2].ToString() //Cust_address
                       , dataTable.Rows[i][3].ToString() //Cust_phone
                       , dataTable.Rows[i][4].ToString() //Cust_email
                       , dataTable.Rows[i][5].ToString() //Note
                       , dataTable.Rows[i][7].ToString() //Acc_id
                       , dataTable.Rows[i][8].ToString() //Acc_name
                       , dataTable.Rows[i][10].ToString() //Curr_sumbol_eng
                       , dataTable.Rows[i][9].ToString() //Maximum
                       , dataTable.Rows[i][11].ToString() //Account
                        );
                }
                if (DGVBody.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (DGVBody.Rows.Count == 0)
                {
                        ClearAllTxtBox();
                }

            }
            catch(Exception e) { MessageBox.Show(e.ToString()); }

        }

        void ClearAllTxtBox()
        {
            txtCustId.Text = string.Empty;
            txtCustName.Text = string.Empty;
            txtCustPhone.Text = string.Empty;
            txtCustEmail.Text = string.Empty;
            txtCustAddress.Text = string.Empty;
            txtCustNote.Text = string.Empty;

            txtCustAccId.Text = string.Empty;
            txtCustAccId.Tag = null;
            txtCustAccName.Text = string.Empty;
            txtCustCurr.Text = string.Empty;
            txtCustMax.Text = string.Empty;
            txtCustAcount.Text = string.Empty;

            FillTextBoxCountRows((0).ToString());

        }
        void FillTextBox()
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (DGVBody.Rows.Count > 0)
            {

                int i = DGVBody.CurrentCell.RowIndex;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */
               

                txtCustAccId.Tag = DGVBody.Rows[i].Cells[0].Value.ToString(); 
                txtCustId.Text = DGVBody.Rows[i].Cells[1].Value.ToString();
                txtCustName.Text = DGVBody.Rows[i].Cells[2].Value.ToString();
                txtCustAddress.Text = DGVBody.Rows[i].Cells[3].Value.ToString();
                txtCustPhone.Text = DGVBody.Rows[i].Cells[4].Value.ToString();
                txtCustEmail.Text = DGVBody.Rows[i].Cells[5].Value.ToString();
                txtCustNote.Text = DGVBody.Rows[i].Cells[6].Value.ToString();
                txtCustAccId.Text = DGVBody.Rows[i].Cells[7].Value.ToString();
                txtCustAccName.Text = DGVBody.Rows[i].Cells[8].Value.ToString();
                txtCustCurr.Text= DGVBody.Rows[i].Cells[9].Value.ToString();
                txtCustMax.Text = DGVBody.Rows[i].Cells[10].Value.ToString();
                txtCustAcount.Text = DGVBody.Rows[i].Cells[11].Value.ToString();

                FillTextBoxCountRows((i + 1).ToString());

            }



        }
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (txtCustName.Text != string.Empty
                    && txtCustAccId.Text != string.Empty
                    && txtCustAccName.Text != string.Empty
                    && txtCustAccId.Tag != null
                    )
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {

                        CustSql.InsertCustomers(
                            txtCustAccId.Tag.ToString()
                            , txtCustName.Text
                            , txtCustAddress.Text == string.Empty ? "NULL" : txtCustAddress.Text
                            , txtCustPhone.Text == string.Empty ? "NULL" : txtCustPhone.Text
                            , txtCustNote.Text == string.Empty ? "NULL" : txtCustNote.Text
                            , txtCustEmail.Text == string.Empty ? "NULL" : txtCustEmail.Text
                            );
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }


                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }



            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (txtCustId.Text != string.Empty
                    && txtCustName.Text != string.Empty
                    && txtCustAccId.Text != string.Empty
                    && txtCustAccName.Text != string.Empty
                    && txtCustAccId.Tag != null)
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        CustSql.Updatecustom(
                              txtCustId.Text
                            , txtCustName.Text
                            , txtCustAddress.Text == string.Empty ? "NULL" : txtCustAddress.Text
                            , txtCustPhone.Text == string.Empty ? "NULL" : txtCustPhone.Text
                            , txtCustNote.Text == string.Empty ? "NULL" : txtCustNote.Text
                            , txtCustEmail.Text == string.Empty ? "NULL" : txtCustEmail.Text
                            );
                        MessageBox.Show("تم التعديل بنجاح");
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }

                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }
        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                txtCustName.ReadOnly = false;
                txtCustAddress.ReadOnly = false;
                txtCustEmail.ReadOnly = false;
                txtCustPhone.ReadOnly = false;
                txtCustNote.ReadOnly = false;
               
                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;

             

            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {

                txtCustName.ReadOnly = true;
                txtCustAddress.ReadOnly = true;
                txtCustEmail.ReadOnly = true;
                txtCustPhone.ReadOnly = true;
                txtCustNote.ReadOnly = true;

                Permissions(); //استدعاء الصلاحيات
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;

            }


        }
        void Delet()
        {
           List<string> data= CustSql.ChaeckCanDelet(txtCustId.Text, txtCustAccId.Tag.ToString());
            if (data.Count > 0)
            {
                MessageBox.Show("لا يمكن الحذف يوجد عمليات مرتبطة بهذا العميل","تنبية",MessageBoxButtons.OK,MessageBoxIcon.Stop);
            }
            else if(DialogResult.Yes==MessageBox.Show("؟تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                CustSql.Delet(txtCustId.Text);
                fillData("All");

            }
                
        }
        #region داله صلاحيات العمليات
        void Permissions()
        {

            #region الصلاحيات
            if (preForm.Count > 0)
            {

                #region البيانات المستلمه
                /*
            ButtnPreCheck.Add("Showed", Convert.ToBoolean(DTpr.Rows[0][2].ToString()));
            ButtnPreCheck.Add("Inserted", Convert.ToBoolean(DTpr.Rows[0][3].ToString()));
            ButtnPreCheck.Add("EditeDate", Convert.ToBoolean(DTpr.Rows[0][4].ToString()));
            ButtnPreCheck.Add("Posting", Convert.ToBoolean(DTpr.Rows[0][5].ToString()));
            ButtnPreCheck.Add("Saerch", Convert.ToBoolean(DTpr.Rows[0][6].ToString()));
            ButtnPreCheck.Add("Printed", Convert.ToBoolean(DTpr.Rows[0][7].ToString()));
            ButtnPreCheck.Add("Updated", Convert.ToBoolean(DTpr.Rows[0][8].ToString()));
            ButtnPreCheck.Add("Deleted", Convert.ToBoolean(DTpr.Rows[0][9].ToString()));
                */
                #endregion

                bool result;
                /////////////////////////////////////////////////////////////////
                if (preForm.TryGetValue("Deleted", out result))
                    buttDelete.Enabled = result;

                else { buttDelete.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "الحذف"); }
                ///////////////////////////////////////////////////////////////////
                if (preForm.TryGetValue("Inserted", out result))
                    buttAdd.Enabled = result;

                else { buttAdd.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "الاضافة"); }
                ///////////////////////////////////////////////////////////////////
                if (preForm.TryGetValue("Updated", out result))
                    buttEdite.Enabled = result;

                else { buttEdite.Enabled = false; MessageBox.Show("لم يتم العثور على صلاحيه ", "التعديل"); }
                ///////////////////////////////////////////////////////////////////

                //فعل البوتونات
            }
            else
            {
                MessageBox.Show("لم يتم استلام اي صلاحيات", "FormatingTextBoxAndButt()");
            }
            #endregion
        }
        #endregion

        void ForamtingAdd()
        {
            txtCustId.Text = CustSql.GetMaxId();
            txtCustName.Text = "";
            txtCustNote.Text = "";
            txtCustPhone.Text = "";
            txtCustAddress.Text = "";
            txtCustEmail.Text = "";

            txtCustCurr.Text = "";
            txtCustMax.Text = "";
            txtCustAcount.Text = "";
            txtCustAccName.Text = "";
            txtCustAccId.Text = "";
            txtCustAccId.Tag = null;




        }
        void FillTextBoxFromButtMove(int i)
        {
            if (i >= 0)
            {
                DGVBody.ClearSelection();

                txtCustAccId.Tag = DGVBody.Rows[i].Cells[0].Value.ToString();
                txtCustId.Text = DGVBody.Rows[i].Cells[1].Value.ToString();
                txtCustName.Text = DGVBody.Rows[i].Cells[2].Value.ToString();
                txtCustAddress.Text = DGVBody.Rows[i].Cells[3].Value.ToString();
                txtCustPhone.Text = DGVBody.Rows[i].Cells[4].Value.ToString();
                txtCustEmail.Text = DGVBody.Rows[i].Cells[5].Value.ToString();
                txtCustNote.Text = DGVBody.Rows[i].Cells[6].Value.ToString();
                txtCustAccId.Text = DGVBody.Rows[i].Cells[7].Value.ToString();
                txtCustAccName.Text = DGVBody.Rows[i].Cells[8].Value.ToString();
                txtCustCurr.Text = DGVBody.Rows[i].Cells[9].Value.ToString();
                txtCustMax.Text = DGVBody.Rows[i].Cells[10].Value.ToString();
                txtCustAcount.Text = DGVBody.Rows[i].Cells[11].Value.ToString();

                FillTextBoxCountRows((i + 1).ToString());
            }

        }

        int indexCustoButt(string btName, string CustId)
        {
            
            if (DGVBody.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < DGVBody.Rows.Count; i++)
                {
                    if (CustId == DGVBody.Rows[i].Cells[1].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < DGVBody.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return DGVBody.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد عملات في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }

        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + DGVBody.Rows.Count.ToString();
        }

        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        #endregion

        #endregion


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {

            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));


        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

      

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Customers_Load(object sender, EventArgs e)
        {
            fillData("All");
            FormatingTextBoxAndButt("Load");
            DGVBody.Select();
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SendDataToAddOrEdit(flagAddOrEdit);
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            flagAddOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCustoButt("Last", txtCustId.Text));
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCustoButt("Back", txtCustId.Text));
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCustoButt("Next", txtCustId.Text));
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCustoButt("Frist", txtCustId.Text));
        }

        private void DGVBody_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void DGVBody_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Down || e.KeyData == Keys.Up)
            {
                if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                    FillTextBox();
            }
        }

        private void DGVBody_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            MoveForm(e);
        }

        private void txtCustName_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void txtCustPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

        private void txtCustAddress_Leave(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void txtCustName_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopNumberInTextBox(e);
        }

        private void txtCustAccId_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show(flagAddOrEdit);
            if (flagAddOrEdit == "Add"&&e.KeyData==Keys.F9)
                ShowListAcc();
        }

        private void buttDelete_Click(object sender, EventArgs e)
        { if(txtCustId.Text!=string.Empty&&txtCustAccId.Tag!=null)
            Delet();
        }
    }
}
