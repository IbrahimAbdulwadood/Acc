﻿namespace AccSystem.FormsProject.Sales
{
    partial class FrmAmountReceived
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAmountReceived));
            this.panUp = new System.Windows.Forms.Panel();
            this.button16 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbBillId = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panCenter = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSave = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.txtReturn = new System.Windows.Forms.TextBox();
            this.lbCurrName3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtCatch = new System.Windows.Forms.TextBox();
            this.lbCurrName2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.txtTotalForg = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.lbCurrName1 = new System.Windows.Forms.Label();
            this.txtExching = new System.Windows.Forms.TextBox();
            this.panUp.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panCenter.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.button16);
            this.panUp.Controls.Add(this.panel3);
            this.panUp.Controls.Add(this.label2);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.ForeColor = System.Drawing.Color.Transparent;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(449, 31);
            this.panUp.TabIndex = 0;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.Dock = System.Windows.Forms.DockStyle.Left;
            this.button16.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.button16.FlatAppearance.BorderSize = 0;
            this.button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Image = ((System.Drawing.Image)(resources.GetObject("button16.Image")));
            this.button16.Location = new System.Drawing.Point(0, 0);
            this.button16.Name = "button16";
            this.button16.Padding = new System.Windows.Forms.Padding(2);
            this.button16.Size = new System.Drawing.Size(36, 31);
            this.button16.TabIndex = 163;
            this.button16.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbBillId);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(176, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(197, 31);
            this.panel3.TabIndex = 2;
            // 
            // lbBillId
            // 
            this.lbBillId.AutoSize = true;
            this.lbBillId.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbBillId.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbBillId.ForeColor = System.Drawing.Color.White;
            this.lbBillId.Location = new System.Drawing.Point(77, 0);
            this.lbBillId.Name = "lbBillId";
            this.lbBillId.Size = new System.Drawing.Size(19, 19);
            this.lbBillId.TabIndex = 1;
            this.lbBillId.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(96, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "الفاتورة رقم:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Right;
            this.label2.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.Location = new System.Drawing.Point(373, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "         ";
            // 
            // panCenter
            // 
            this.panCenter.Controls.Add(this.panel1);
            this.panCenter.Controls.Add(this.panel2);
            this.panCenter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panCenter.Location = new System.Drawing.Point(0, 31);
            this.panCenter.Name = "panCenter";
            this.panCenter.Size = new System.Drawing.Size(449, 323);
            this.panCenter.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 264);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 59);
            this.panel1.TabIndex = 0;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.btnSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.Location = new System.Drawing.Point(0, 0);
            this.btnSave.Name = "btnSave";
            this.btnSave.Padding = new System.Windows.Forms.Padding(100, 0, 100, 15);
            this.btnSave.Size = new System.Drawing.Size(449, 59);
            this.btnSave.TabIndex = 199;
            this.btnSave.Text = "حفظ وتأكيد الفاتورة";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(449, 264);
            this.panel2.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.txtReturn);
            this.groupBox3.Controls.Add(this.lbCurrName3);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(0, 174);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(449, 66);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "المتبقي";
            // 
            // txtReturn
            // 
            this.txtReturn.BackColor = System.Drawing.Color.Silver;
            this.txtReturn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtReturn.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold);
            this.txtReturn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtReturn.Location = new System.Drawing.Point(3, 19);
            this.txtReturn.Name = "txtReturn";
            this.txtReturn.ReadOnly = true;
            this.txtReturn.Size = new System.Drawing.Size(424, 40);
            this.txtReturn.TabIndex = 0;
            this.txtReturn.Text = "-15000";
            this.txtReturn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbCurrName3
            // 
            this.lbCurrName3.AutoSize = true;
            this.lbCurrName3.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbCurrName3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCurrName3.ForeColor = System.Drawing.Color.White;
            this.lbCurrName3.Location = new System.Drawing.Point(427, 19);
            this.lbCurrName3.Name = "lbCurrName3";
            this.lbCurrName3.Size = new System.Drawing.Size(19, 19);
            this.lbCurrName3.TabIndex = 165;
            this.lbCurrName3.Text = "$";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtCatch);
            this.groupBox2.Controls.Add(this.lbCurrName2);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(0, 105);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(449, 69);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "المقبوض";
            // 
            // txtCatch
            // 
            this.txtCatch.BackColor = System.Drawing.Color.Silver;
            this.txtCatch.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCatch.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold);
            this.txtCatch.ForeColor = System.Drawing.Color.Green;
            this.txtCatch.Location = new System.Drawing.Point(3, 19);
            this.txtCatch.Name = "txtCatch";
            this.txtCatch.Size = new System.Drawing.Size(424, 40);
            this.txtCatch.TabIndex = 0;
            this.txtCatch.Text = "0";
            this.txtCatch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCatch.TextChanged += new System.EventHandler(this.txtCatch_TextChanged);
            this.txtCatch.Leave += new System.EventHandler(this.txtCatch_Leave);
            // 
            // lbCurrName2
            // 
            this.lbCurrName2.AutoSize = true;
            this.lbCurrName2.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbCurrName2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCurrName2.ForeColor = System.Drawing.Color.White;
            this.lbCurrName2.Location = new System.Drawing.Point(427, 19);
            this.lbCurrName2.Name = "lbCurrName2";
            this.lbCurrName2.Size = new System.Drawing.Size(19, 19);
            this.lbCurrName2.TabIndex = 165;
            this.lbCurrName2.Text = "$";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel5);
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(449, 105);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "المطلوب";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txtTotal);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(3, 59);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(443, 43);
            this.panel5.TabIndex = 1;
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.Silver;
            this.txtTotal.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.txtTotal.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold);
            this.txtTotal.ForeColor = System.Drawing.Color.Black;
            this.txtTotal.Location = new System.Drawing.Point(0, 3);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.Size = new System.Drawing.Size(443, 40);
            this.txtTotal.TabIndex = 2;
            this.txtTotal.Text = "15000";
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.txtTotalForg);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.lbCurrName1);
            this.panel4.Controls.Add(this.txtExching);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(3, 19);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(443, 40);
            this.panel4.TabIndex = 0;
            // 
            // txtTotalForg
            // 
            this.txtTotalForg.BackColor = System.Drawing.Color.Silver;
            this.txtTotalForg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTotalForg.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold);
            this.txtTotalForg.ForeColor = System.Drawing.Color.MidnightBlue;
            this.txtTotalForg.Location = new System.Drawing.Point(207, 0);
            this.txtTotalForg.Name = "txtTotalForg";
            this.txtTotalForg.ReadOnly = true;
            this.txtTotalForg.Size = new System.Drawing.Size(217, 40);
            this.txtTotalForg.TabIndex = 1;
            this.txtTotalForg.Text = "30";
            this.txtTotalForg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Left;
            this.label9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(149, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 19);
            this.label9.TabIndex = 168;
            this.label9.Text = "الصرف";
            // 
            // lbCurrName1
            // 
            this.lbCurrName1.AutoSize = true;
            this.lbCurrName1.Dock = System.Windows.Forms.DockStyle.Right;
            this.lbCurrName1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCurrName1.ForeColor = System.Drawing.Color.White;
            this.lbCurrName1.Location = new System.Drawing.Point(424, 0);
            this.lbCurrName1.Name = "lbCurrName1";
            this.lbCurrName1.Size = new System.Drawing.Size(19, 19);
            this.lbCurrName1.TabIndex = 164;
            this.lbCurrName1.Text = "$";
            // 
            // txtExching
            // 
            this.txtExching.BackColor = System.Drawing.Color.Silver;
            this.txtExching.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtExching.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold);
            this.txtExching.ForeColor = System.Drawing.Color.MidnightBlue;
            this.txtExching.Location = new System.Drawing.Point(0, 0);
            this.txtExching.Name = "txtExching";
            this.txtExching.ReadOnly = true;
            this.txtExching.Size = new System.Drawing.Size(149, 40);
            this.txtExching.TabIndex = 167;
            this.txtExching.Text = "500";
            this.txtExching.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FrmAmountReceived
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 354);
            this.Controls.Add(this.panCenter);
            this.Controls.Add(this.panUp);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FrmAmountReceived";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FrmAmountReceived";
            this.TopMost = true;
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panCenter.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panCenter;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtCatch;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbBillId;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtReturn;
        private System.Windows.Forms.Label lbCurrName3;
        private System.Windows.Forms.Label lbCurrName2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbCurrName1;
        private System.Windows.Forms.Button btnSave;
        public System.Windows.Forms.TextBox txtTotalForg;
        public System.Windows.Forms.TextBox txtExching;
    }
}