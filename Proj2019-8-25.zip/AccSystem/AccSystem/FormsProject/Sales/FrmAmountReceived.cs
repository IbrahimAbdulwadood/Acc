﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Sales
{
    public partial class FrmAmountReceived : Form
    { ClassesProject.CurrSQL cur = new ClassesProject.CurrSQL();
        public FrmAmountReceived(string Totale,string BillId,string CurrName,string CurrExching)
        {
            InitializeComponent();
            txtTotal.Text = Totale;
            lbBillId.Text = BillId;
            lbCurrName1.Text = CurrName;
            lbCurrName2.Text = CurrName;
            lbCurrName3.Text = CurrName;
            txtExching.Text = CurrExching;
            txtTotalForg.Text = cur.GetExchingPawCurr(CurrExching, Totale);

            State = false;
        }
     
       
        public bool State = false;
        private void button16_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtCatch_Leave(object sender, EventArgs e)
        {
            if (txtCatch.Text == string.Empty) txtCatch.Text = "0";
        }

        private void txtCatch_TextChanged(object sender, EventArgs e)
        {
            try
            {

                txtReturn.Text = (Convert.ToDecimal(txtCatch.Text) - Convert.ToDecimal(txtTotalForg.Text)).ToString();
              
            } catch(Exception w) { MessageBox.Show(w.ToString()); txtCatch.Text = "0"; txtReturn.Text = txtTotalForg.Text; }
           
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDecimal(txtCatch.Text) >= Convert.ToDecimal(txtTotalForg.Text))
                {
                    State = true;
                    Close();
                }
                else MessageBox.Show("المبلغ المقبوض اقل من المبلغ المطلوب", "تحـــذير!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            catch (Exception w) { MessageBox.Show(w.ToString()); }
        }
    }
}
