﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Sales
{
    public partial class FrmAmountReceivedForgn : Form
    {
        public FrmAmountReceivedForgn(string Total,string IdBill)
        {
            InitializeComponent();
            txtTotal.Text = Total;
            lbBillId.Text = IdBill;
            txtReturn.Text = Total;
            State = false;
        }
        public static bool State = false;
        private void button16_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToDouble(txtTotal.Text) <= Convert.ToDouble(txtCatch.Text))
                {
                    State = true;
                    Close();

                }
                else MessageBox.Show("المبلغ المقبوض اقل من المبلغ المستحق!!!", "تحــــــــــذير", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            catch (Exception w)
            {
                MessageBox.Show(w.ToString());
            }
        }

        private void txtCatch_Leave(object sender, EventArgs e)
        {
            if (txtCatch.Text == string.Empty)
                txtCatch.Text = "0";
        }

        private void txtCatch_TextChanged(object sender, EventArgs e)
        {
            try { txtReturn.Text = (Convert.ToDecimal(txtCatch.Text) - Convert.ToDecimal(txtTotal.Text)).ToString(); } catch(Exception w) { MessageBox.Show(w.ToString()); txtReturn.Text = txtTotal.Text; txtCatch.Text = "0"; }
           
        }
    }
}
