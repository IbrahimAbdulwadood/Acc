﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NumberToWord;
namespace AccSystem.FormsProject.Sales
{
    public partial class FrmRepBill : Form
    {
        public FrmRepBill()
        {
            InitializeComponent();
        }



        ClassesProject.ConnectionDB con = new ClassesProject.ConnectionDB();
        DataTable DT;

        DataTable GetReport(string DateBgin, string DateEnd)
        {
            if (DT != null)
                DT = null;
            DT = new DataTable();
            string
           query = "   SELECT  ";
            query += "  SalesBillHead.Bill_id  ";
            query += "   , TypeBill.Type_neme  ";
            query += "  , SalesBillHead.Date_salesbill  ";
            query += "  , SalesBillHead.Cust_id_fk  ";
            query += "  , Customers.Cust_name  ";
            query += "   , SalesBillHead.Sum  ";
            query += "   , SalesBillHead.Discount  ";
            query += "    , SalesBillHead.Total  ";
            query += "   ,iif(Type_id = 1  ";
            query += "   , (SELECT        Currencys.Curr_sumbol_eng  ";
            query += "   FROM  AccCurrency INNER JOIN  ";
            query += "   Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN  ";
            query += "    Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN  ";
            query += "    BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk  ";
            query += "  WHERE        BoxUser.BoxUser_id = SalesBillHead.BoxUser_id_fk)  ";
            query += "  ,(SELECT        Currencys.Curr_sumbol_eng  ";
            query += "    FROM      AccCurrency INNER JOIN  ";
            query += "    Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN  ";
            query += "  Customers ON AccCurrency.AccCurr_id = Customers.AccCurr_id_fk  ";
            query += "   WHERE(Customers.Cust_id = SalesBillHead.Cust_id_fk)))  ";
            query += "  FROM  SalesBillHead INNER JOIN  ";
            query += "   TypeBill ON SalesBillHead.Type_id_fk = TypeBill.Type_id INNER JOIN  ";
            query += "   Customers ON SalesBillHead.Cust_id_fk = Customers.Cust_id  ";

            query += "    where SalesBillHead.Date_salesbill between  " + con.AddApostropheToString(DateBgin);
            query += "  and  "+ con.AddApostropheToString(DateEnd);

         

            con.OpenConnetion();
            DT = con.Query(query, true);

            con.CloseConnetion();

            return DT;
         

            /*
            SELECT  
            SalesBillHead.Bill_id
          , TypeBill.Type_neme
          , SalesBillHead.Date_salesbill
          , SalesBillHead.Cust_id_fk
          , Customers.Cust_name
          , SalesBillHead.Sum
          , SalesBillHead.Discount
          , SalesBillHead.Total
          --------------------------------------------------------------------
          ,iif(Type_id=1
          --------------------------------اذا كان نقدا = 1 بيجيب العمله حق الصندوق الي قبض------------------------------------
          ,(SELECT        Currencys.Curr_sumbol_eng
                FROM            AccCurrency INNER JOIN
                                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                                         Boxes ON AccCurrency.AccCurr_id = Boxes.AccCurr_id_fk INNER JOIN
                                         BoxUser ON Boxes.Box_id = BoxUser.Box_id_fk
                WHERE        BoxUser.BoxUser_id = SalesBillHead.BoxUser_id_fk)
          ----------------------------------اذا كان اجل بيجيب العمله حق الي دفع بها العميل----------------------------------
          ,(SELECT        Currencys.Curr_sumbol_eng
                FROM      AccCurrency INNER JOIN
                                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id INNER JOIN
                                         Customers ON AccCurrency.AccCurr_id = Customers.AccCurr_id_fk
                WHERE        (Customers.Cust_id = SalesBillHead.Cust_id_fk)))
          -------------------------------------نهاية تنفيذ الشرط-------------------------------
    FROM            SalesBillHead INNER JOIN
                             TypeBill ON SalesBillHead.Type_id_fk = TypeBill.Type_id INNER JOIN
                             Customers ON SalesBillHead.Cust_id_fk = Customers.Cust_id

                             where SalesBillHead.Date_salesbill between '2019-07-04'and'2019-08-05'
            */
        }
        void FillData()
        {
            DataTable DTFill = new DataTable();
            DGVBody.Rows.Clear();
           textBox6.Text = "0";
            textBox7.Text = "0";
            textBox8.Text = "0";
            textBox9.Text = "";
            DTFill = GetReport(
                dateTimePicker1.Value.ToShortDateString()
               , dateTimePicker2.Value.ToShortDateString());

            if (DTFill != null && DTFill.Rows.Count > 0)
            {
                double sum = 0;
                double Di = 0;
                double Total = 0;
                ShowLabelNotFound(false);
                for (int i = 0; i < DTFill.Rows.Count; i++)
                {
                    DGVBody.Rows.Add
                        (
                        (i + 1).ToString()
                        , DTFill.Rows[i][0].ToString()
                         , DTFill.Rows[i][1].ToString()
                          , DTFill.Rows[i][2].ToString()
                           , DTFill.Rows[i][3].ToString()
                            , DTFill.Rows[i][4].ToString()
                             , DTFill.Rows[i][5].ToString()
                              , DTFill.Rows[i][6].ToString()
                               , DTFill.Rows[i][7].ToString()
                                , DTFill.Rows[i][8].ToString()
                                 

                        );
                    try { Total += ((double)DTFill.Rows[i][7]);
                        Di += ((double)DTFill.Rows[i][6]);
                        sum += ((double)DTFill.Rows[i][5]);
                    }
                    catch (Exception e) { MessageBox.Show(e.ToString()); }
                }

                textBox8.Text = Total.ToString();
                textBox7.Text = Di.ToString();
                textBox6.Text = sum.ToString();
                try
                {
                    ToWord toWord = new ToWord(Convert.ToDecimal(textBox8.Text), new CurrencyInfo("1"));
                    textBox9.Text = toWord.ConvertToArabic();
                }
                catch
                {

                   textBox9.Text = String.Empty;
                }
            }
            else
                ShowLabelNotFound(true);


        }
        void ShowLabelNotFound(bool State)
        {

            panel5.Visible = State;
            label8.Visible = State;

        }



        private void DGVBody_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button51_Click(object sender, EventArgs e)
        {
            FillData();
        }

        private void pnlUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DGVBody_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button40_Click(object sender, EventArgs e)
        {
            Reports.RepBill item = new Reports.RepBill();
            item.Refresh();

            item.SetParameterValue("@BeingeBill", this.dateTimePicker1.Value.ToShortDateString());
            item.SetParameterValue("@EndBill", this.dateTimePicker2.Value.ToShortDateString());
            Reports.frm_Reports f = new Reports.frm_Reports();

            f.crystalReportViewer1.ReportSource = item;
            f.Refresh();
            f.ShowDialog();
        }
    }
}
