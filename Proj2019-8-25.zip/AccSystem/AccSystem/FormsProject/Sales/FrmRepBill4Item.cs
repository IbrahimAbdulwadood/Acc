﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NumberToWord;

namespace AccSystem.FormsProject.Sales
{
    public partial class FrmRepBill4Item : Form
    {
        public FrmRepBill4Item()
        {
            InitializeComponent();
        }
        #region المتغيرات

        ClassesProject.ConnectionDB con = new ClassesProject.ConnectionDB();
        DataTable DT;

        #endregion
        DataTable GetReport(string DateBgin,string DateEnd)
        {
            if (DT != null)
                DT = null;
            DT = new DataTable();

            string
           query  = "    SELECT     ";
           query += "  Items.barc  ";
           query += " , Items.Item_name  ";
           query += " ,(SELECT    Units.Unit_name  ";
           query += "  	FROM    Units INNER JOIN ";
           query += "   ItemUnit ON Units.Unit_id = ItemUnit.Unit_id_fk ";
           query += " WHERE   ItemUnit.idItemUnit = SalesBillBody.idItemUnit_fk) as Unit  ";
           query += "  ,(Sum(SalesBillBody.Quantity)) as Quantity_Sa  ";
           query += "   ,(sum(SalesBillBody.Part)) as Part_Sa ";
           query += "  ,(SUM(SalesBillBody.Total)) as Total_Sa  ";

          
            query += "  ,(SELECT  ISNULL(Sum(ReturnSalesBillBody.Quantity),0)   ";
            query += "  FROM   ReturnSalesBillBody INNER JOIN ";
            query += "   ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk =  ";
            query += "  ReturnSalesBillHead.Return_bill_id ";
            query += "  WHERE ";
            query += "  (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk) ";
            query += " and ReturnSalesBillHead.Date_return_salesBill between " + con.AddApostropheToString(DateBgin);
            query += "              and " +con.AddApostropheToString(DateEnd) +" ) as Quantity_Re  ";

            
            query += "  ,(SELECT    ISNULL(Sum(ReturnSalesBillBody.Part),0) ";
            query += "  FROM    ReturnSalesBillBody INNER JOIN  ";
            query += "   ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id ";
            query += "  WHERE ";
            query += "   (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk) ";
            query += "  and ReturnSalesBillHead.Date_return_salesBill between " + con.AddApostropheToString(DateBgin);
            query += "                 and " + con.AddApostropheToString(DateEnd) + " ) as Part_Re  ";

            

            query += "   ,(SELECT  ISNULL(Sum(ReturnSalesBillBody.Total),0) ";
            query += "  FROM     ReturnSalesBillBody INNER JOIN ";
            query += " ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id  ";
            query += " WHERE  ";
            query += " (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk) ";
            query += "  and ReturnSalesBillHead.Date_return_salesBill between " + con.AddApostropheToString(DateBgin);
            query += "        and  " + con.AddApostropheToString(DateEnd) + ") as Total_Re ";

          
            query += "  ,(Sum(SalesBillBody.Quantity)-(SELECT  ISNULL(Sum(ReturnSalesBillBody.Quantity),0)  ";
            query += "  FROM      ReturnSalesBillBody INNER JOIN ";
            query += "  ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id  ";
            query += "  WHERE ";
            query += "   (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk) ";
            query += "   and ReturnSalesBillHead.Date_return_salesBill between " + con.AddApostropheToString(DateBgin);
            query += "            and " + con.AddApostropheToString(DateEnd) + ")) as Quantity_Net  ";


            query += "   ,(sum(SalesBillBody.Part)-(SELECT    ISNULL(Sum(ReturnSalesBillBody.Part),0) ";
            query += "  FROM    ReturnSalesBillBody INNER JOIN ";
            query += "  ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id  ";
            query += "  WHERE ";
            query += "  (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk) ";
            query += "  and ReturnSalesBillHead.Date_return_salesBill between  " + con.AddApostropheToString(DateBgin);
            query += "            and " + con.AddApostropheToString(DateEnd) + ")) as Part_Net ";

            
           
            query += "  ,(SUM(SalesBillBody.Total)-(SELECT  ISNULL(Sum(ReturnSalesBillBody.Total),0)  ";
            query += " 	FROM    ReturnSalesBillBody INNER JOIN  ";
            query += "  ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id  ";
            query += "  WHERE ";
            query += "  (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk)  ";
            query += "  and ReturnSalesBillHead.Date_return_salesBill between " + con.AddApostropheToString(DateBgin);
            query += "             and " + con.AddApostropheToString(DateEnd) + ")) as Total_Net ";



           
            query += "  FROM    ItemUnit INNER JOIN  ";
            query += "  Items ON ItemUnit.Item_id_fk = Items.Item_id INNER JOIN  ";
            query += "  SalesBillBody ON ItemUnit.idItemUnit = SalesBillBody.idItemUnit_fk INNER JOIN ";
            query += "  SalesBillHead ON SalesBillBody.Bill_id_fk = SalesBillHead.Bill_id  ";
            query += "  where SalesBillHead.Date_salesbill between " + con.AddApostropheToString(DateBgin);
            query += "        and  " + con.AddApostropheToString(DateEnd);

            query += "  group by ";
            query += "   Items.barc ";
            query += "  ,Items.Item_name  ";
            query += "  ,SalesBillBody.idItemUnit_fk ";
            query += "  order by  ";
            query += "  Items.barc ";

            con.OpenConnetion();
            DT= con.Query(query, true);
            con.CloseConnetion();

            return DT;
            #region  الاستعلام
            /*
                    SELECT   
                 Items.barc
            , Items.Item_name
            ,(SELECT    Units.Unit_name
                    FROM    Units INNER JOIN
                                             ItemUnit ON Units.Unit_id = ItemUnit.Unit_id_fk
                    WHERE   ItemUnit.idItemUnit = SalesBillBody.idItemUnit_fk) as Unit
             ,(Sum(SalesBillBody.Quantity)) as Quantity_Sa
             ,(sum(SalesBillBody.Part)) as Part_Sa
             ,(SUM(SalesBillBody.Total)) as Total_Sa


             ,(SELECT  ISNULL(Sum(ReturnSalesBillBody.Quantity),0) 
                    FROM            ReturnSalesBillBody INNER JOIN
                                     ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id
                    WHERE        
                    (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk)
                    and ReturnSalesBillHead.Date_return_salesBill between '2019-01-01'and '2019-09-09') as Quantity_Re


             ,(SELECT    ISNULL(Sum(ReturnSalesBillBody.Part),0)
                    FROM            ReturnSalesBillBody INNER JOIN
                                     ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id
                    WHERE     
                       (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk)
                       and ReturnSalesBillHead.Date_return_salesBill between '2019-01-01'and '2019-09-09') as Part_Re

             ,(SELECT  ISNULL(Sum(ReturnSalesBillBody.Total),0)
                    FROM            ReturnSalesBillBody INNER JOIN
                                     ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id
                    WHERE        
                    (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk)
                    and ReturnSalesBillHead.Date_return_salesBill between '2019-01-01'and '2019-09-09') as Total_Re


            ,(Sum(SalesBillBody.Quantity)-(SELECT  ISNULL(Sum(ReturnSalesBillBody.Quantity),0) 
                    FROM            ReturnSalesBillBody INNER JOIN
                                     ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id
                    WHERE       
                     (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk)
                     and ReturnSalesBillHead.Date_return_salesBill between '2019-01-01'and '2019-09-09')) as Quantity_Net


            ,(sum(SalesBillBody.Part)-(SELECT    ISNULL(Sum(ReturnSalesBillBody.Part),0)
                    FROM            ReturnSalesBillBody INNER JOIN
                                     ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id
                    WHERE        
                    (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk)
                    and ReturnSalesBillHead.Date_return_salesBill between '2019-01-01'and '2019-09-09')) as Part_Net


            ,(SUM(SalesBillBody.Total)-(SELECT  ISNULL(Sum(ReturnSalesBillBody.Total),0)
                    FROM            ReturnSalesBillBody INNER JOIN
                                     ReturnSalesBillHead ON ReturnSalesBillBody.Return_bill_id_fk = ReturnSalesBillHead.Return_bill_id
                    WHERE        
                    (ReturnSalesBillBody.idItemUnit_fk = SalesBillBody.idItemUnit_fk) 
                    and ReturnSalesBillHead.Date_return_salesBill between '2019-01-01'and '2019-09-09')) as Total_Net


            FROM            ItemUnit INNER JOIN
                                     Items ON ItemUnit.Item_id_fk = Items.Item_id INNER JOIN
                                     SalesBillBody ON ItemUnit.idItemUnit = SalesBillBody.idItemUnit_fk INNER JOIN
                                     SalesBillHead ON SalesBillBody.Bill_id_fk = SalesBillHead.Bill_id

                                     where SalesBillHead.Date_salesbill between '2019-01-01'and '2019-09-09'

                                      group by
                                         Items.barc
                                         ,Items.Item_name
                                         ,SalesBillBody.idItemUnit_fk
                                       order by 
                                            Items.barc




            */
            #endregion

        }

        void FillData()
        {
            DataTable DTFill = new DataTable();
            DGVBody.Rows.Clear();
            txtNetNumb.Text = "0";
            txtNetWord.Text = "";
            DTFill =GetReport(
                dateTimePicker1.Value.ToShortDateString()
               ,dateTimePicker2.Value.ToShortDateString());

            if (DTFill != null && DTFill.Rows.Count > 0)
            {
                double Total = 0;
                ShowLabelNotFound(false);
                for (int i = 0; i < DTFill.Rows.Count; i++)
                {
                    DGVBody.Rows.Add
                        (
                        (i + 1).ToString()
                        , DTFill.Rows[i][0].ToString()
                         , DTFill.Rows[i][1].ToString()
                          , DTFill.Rows[i][2].ToString()
                           , DTFill.Rows[i][3].ToString()
                            , DTFill.Rows[i][4].ToString()
                             , DTFill.Rows[i][5].ToString()
                              , DTFill.Rows[i][6].ToString()
                               , DTFill.Rows[i][7].ToString()
                                , DTFill.Rows[i][8].ToString()
                                 , DTFill.Rows[i][9].ToString()
                                  , DTFill.Rows[i][10].ToString()
                                   , DTFill.Rows[i][11].ToString()
                        );
                    try { Total += ((double)DTFill.Rows[i][11]); }
                    catch (Exception e) { MessageBox.Show(e.ToString()); }
                }

                txtNetNumb.Text = Total.ToString();
                try
                {
                    ToWord toWord = new ToWord(Convert.ToDecimal(txtNetNumb.Text), new CurrencyInfo("1"));
                    txtNetWord.Text = toWord.ConvertToArabic();
                }
                catch
                {

                    txtNetWord.Text = String.Empty;
                }
            }
            else
                ShowLabelNotFound(true);


        }
        void ShowLabelNotFound(bool State)
        {
            
                panel5.Visible = State;
                labelNotFound.Visible = State;
            
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            FillData();
        }

        

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pnlUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            Reports.RepBill4Item item = new Reports.RepBill4Item();
            item.Refresh();
         
            item.SetParameterValue("@BeingBill", this.dateTimePicker1.Value.ToShortDateString());
            item.SetParameterValue("@EndBill", this.dateTimePicker2.Value.ToShortDateString());
            Reports.frm_Reports f = new Reports.frm_Reports();

            f.crystalReportViewer1.ReportSource = item;
            f.Refresh();
            f.ShowDialog();
        }

        private void DGVBody_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
