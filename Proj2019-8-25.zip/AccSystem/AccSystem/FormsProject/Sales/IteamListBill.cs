﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;

namespace AccSystem.FormsProject.Sales
{
    public partial class IteamListBill : Form
    {
       
        #region المتغيرات

      // List<string> AccIdSelected = new List<string>(); //يحفظ ارقام الحسابات الي قد اشر عليهم عشان ما يروحو عند عمليه البحث
      // string[] AccCurrId;
        //تستقبل الحسابات الي قدها موجودة في القيود عشان ما تظهر مره ثاني
        List<string> IteamUniteIdCame = new List<string>();
        int i;
        static public int indeex;
        public bool stateSelect = false; 
        DataTable datatable;
        DataTable datatableGroupStored = new DataTable();
        DataTable datatableItemTypes = new DataTable();
        GroupStoredSQL groupClass = new GroupStoredSQL();
        ItemsTypesSQL itemsTyp = new ItemsTypesSQL();

        BillSalesSQL BillClass = new BillSalesSQL();
        
   static   public  List<BillParametr> ItemSelection = new List<BillParametr>();
        BillParametr ItemIdSelected;
        
        #endregion
        #region الاستعلام الجديد
        /*
        
SELECT        AccCurrency.AccCurr_id, AccCurrency.Acc_id_fk, AccCurrency.Curr_id_fk, Accounts.Acc_name, Currencys.Curr_name, Currencys.Curr_is_local, 
                         Currencys.Curr_echange, Currencys.Curr_maximum, Currencys.Curr_minimum, Accounts.Acc_state, AccCurrency.State
FROM            AccCurrency INNER JOIN
                         Accounts ON AccCurrency.Acc_id_fk = Accounts.Acc_id INNER JOIN
                         Currencys ON AccCurrency.Curr_id_fk = Currencys.Curr_id where   AccCurrency.AccCurr_id in(1,2,3,4)
            
            */
        #endregion

        public IteamListBill(List<string> IteamUniteIdCame)
        {
            InitializeComponent();
            this.IteamUniteIdCame = IteamUniteIdCame;
            datatableGroupStored.Columns.Add("idGroupStored"); //  
            datatableGroupStored.Columns.Add("nameGroupStored"); //   
            datatableItemTypes.Columns.Add("idItemTypes");
            datatableItemTypes.Columns.Add("nameItemTypes");
            FillComboBox();
        
            //if(AccCurrId!=null)
            //foreach (var item in AccCurrId)
            //{
            //    MessageBox.Show(item);
            //}

        }
        
        void FillComboBox()
        {

            DataTable DT = new DataTable();
           
            datatableGroupStored.Rows.Clear(); 
            datatableGroupStored.Clear();
            datatableGroupStored.Rows.Add("-1", "جميع المجموعات المخزنية"); 
            ////////////////////////////////////////////////////////////////////////////
          
            ////////////////////////////////////////////////////////////////////////////
            DT = groupClass.GetAllGroup();
        
            if (DT.Rows.Count > 0 && DT != null)
            {
                for (int i = 0; i < DT.Rows.Count; i++) //تعبئة بقية الصفوف حسب قاعدة البيانات
                    datatableGroupStored.Rows.Add(DT.Rows[i][0].ToString(), DT.Rows[i][1].ToString());
               DT.Clear();
            }
            comboBoxGroupStored.DataSource = datatableGroupStored;
            comboBoxGroupStored.ValueMember = datatableGroupStored.Columns[0].ToString();
            comboBoxGroupStored.DisplayMember = datatableGroupStored.Columns[1].ToString();
            ////////////////////////////////////////////////////////////////////////////
         
        }
        private void pictureClose_Click(object sender, EventArgs e)
        {
            if (ItemSelection.Count > 0)
            {
                if (MessageBox.Show("لن تحفظ الاصناف التي حددتها، هل تأكد الخروج من هذه الشاشة؟","تحذير",MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    ItemSelection.Clear();
                    stateSelect = false;
                    this.Close();
                }
            }
            else {
                stateSelect = false;
                this.Close();
                 }
             
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
     

        private void button52_Click(object sender, EventArgs e)
        {
            if (ItemSelection.Count > 0)
            {
                stateSelect = true;

            }
            else
                stateSelect = false;
           //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());
           // indeex = dataGridView1.CurrentCell.RowIndex;
           Close();
            //setIndex();
        }
        void FormatingDataGrid()
        {
            try
            {
                if (dataGridView1.Rows.Count > 0)
                { for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        #region منع الكتابة على جميع الحقول
                        for (int x = 0; x < dataGridView1.ColumnCount; x++)
                        {
                            dataGridView1.Rows[i].Cells[x].ReadOnly = true;
                        }
                        #endregion
                        #region السماح باختيار الحسابات النشطة وذات العملة المفعلة
                        //MessageBox.Show(dataGridView1.Rows[i].Cells[10].Value.ToString(), dataGridView1.Rows[i].Cells[11].Value.ToString());
                        dataGridView1.Rows[i].Cells[9].ReadOnly =
                            (dataGridView1.Rows[i].Cells[10].Value.ToString() == "صنف نشط" ?
                            (dataGridView1.Rows[i].Cells[11].Value.ToString() == "وحدة مفعلة" ? false : true)
                                                                                                    : true);
                        //MessageBox.Show((dataGridView1.Rows[i].Cells[10].Value.ToString() == "صنف نشط" ?
                        //    (dataGridView1.Rows[i].Cells[11].Value.ToString() == "وحدة مفعلة" ? "false" : "true")
                        //                                                                            : "true"));
                        #endregion
                        #region الحساب الي قد تم عمل تشك عليه يخليه ترو
                        //bool AccFound = false;
                        string IteamUnitId = dataGridView1.Rows[i].Cells[0].Value.ToString();
                        for (int x = 0; x < ItemSelection.Count; x++)
                        {
                            if (IteamUnitId == ItemSelection[x].idItemUnit)
                            {
                                DataGridViewCheckBoxCell chk = dataGridView1.Rows[i].Cells[9] as DataGridViewCheckBoxCell;

                                chk.Value = true;
                                break;
                            }

                        }
                    }
                    #endregion
                }
            }
            catch (Exception e) { MessageBox.Show(e.ToString(), "jjhjh"); }

        }
        void FillData(string NormalOrSerch)
        {
            #region بناء الداتا تيبل
            if (datatable != null)
                datatable = null;

            datatable = new DataTable();
         
            #endregion

            #region تعبئة البيانات في الداتا تيبل هل الجميع ولا بحث
            if (NormalOrSerch == "All")
            { //MessageBox.Show("");
                if (comboBoxGroupStored.ValueMember != "")
                     datatable = BillClass.GetIteamAll(comboBoxGroupStored.SelectedValue.ToString());
                else datatable = BillClass.GetIteamAll(); 
            }


            else if (NormalOrSerch == "Serch")
                datatable = BillClass.GetIteamSerch(comboBoxGroupStored.SelectedValue.ToString(),txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            #endregion


            try
            {
                dataGridView1.Rows.Clear();
                bool NotAlreadyExists; //غير موجود سابقا
                #region اذا كان يوجد بيانات في الداتا تيبل
              
                if (datatable.Rows.Count > 0)
                {
                   // MessageBox.Show(datatable.Columns.Count.ToString());
                    #region اذا شاشة القيود رسلت بحسابات موجودة عندها عشان ما يعرضها هنا
                   
                    if (IteamUniteIdCame.Count>0) //اذا قد في حسابات موجود في شاشة القيود عشان ما يظهرها هنا
                    {   
                        for (i = 0; i < datatable.Rows.Count; i++)
                        {
                            NotAlreadyExists = true;
                            for (int j = 0; j < IteamUniteIdCame.Count; j++)
                            {
                               // MessageBox.Show(AccCurrId[j], datatable.Rows[i][0].ToString());
                                if (IteamUniteIdCame[j] == datatable.Rows[i][0].ToString()&& IteamUniteIdCame[j]!=string.Empty)
                                {
                                    NotAlreadyExists = false;
                                   // MessageBox.Show(AccCurrId[j], datatable.Rows[i][0].ToString(),MessageBoxButtons.YesNo); 
                                   break;
                                }
                            }
                            try
                            {
                                if (NotAlreadyExists)
                                {
                                    #region

                                    /*   
                                                       
                                  

                                     idItemUnit, 0
                                     Items.barc,1
                                     Items.Item_name, 2
                                     Units.Unit_name,3
                                     ItemUnit.Selling_price4
                                     price_part ,5
                                   Items.State,6
                                   ItemUnit.State ,7
                                     Units.Unit_part8
 
                                    */
                                    #endregion

                                    #region اضافة البيانات الى الداتا جريت

                                    //اذا موش موجود سابفا من خلال الحسابات التي ارسلت عند استدعاء هذه الشاشه ضيفه
                                    dataGridView1.Rows.Add
                          (datatable.Rows[i][0].ToString(), //idItemUnit,
                           datatable.Rows[i][1].ToString(),  //Items_barc[1],
                           datatable.Rows[i][2].ToString(),  //Item_name[2],
                           datatable.Rows[i][3].ToString(),  //Unit_name[3],
                           datatable.Rows[i][4].ToString(),  //Selling_price[4],
                           datatable.Rows[i][5].ToString(),  //price_part[5],
                           "0"  //العدد واحدة
                          ,"0" // العدد جزء
                         , "0" // الاجمالي
                         ,false //Select
    , (Convert.ToBoolean(datatable.Rows[i][6].ToString()) == true? "صنف نشط" : "صنف غير نشط"),  // Items.State,
      (Convert.ToBoolean(datatable.Rows[i][7].ToString()) == true? "وحدة مفعلة" : "وحدة صنف غير مفعلة"),  // ItemUnit.State[9],
                          "0",  //متوفر واحدة,
                          "0",  //متوفر جزء,
                          datatable.Rows[i][8].ToString()  //Unit_part,
                        
                                        );
                                    #endregion
                                   
                                } //endIfNotAlread
                            }
                            catch (Exception ee) { MessageBox.Show(ee.ToString()); }

                        } //endforDTable
                        #region اذا الحاسابات الموجودة في شاشة القيود هي جميع الحسابات المتوفرة عشان ما يكررها
                       
                        if (dataGridView1.Rows.Count == 0& ItemSelection.Count==0)

                        {

                            buttSend.Visible = false;
                            label1.Visible = true;
                            panel2.Visible = true;
                            label1.Text = "لا يوجد اصناف لعرضها";
                        }
                        else if(dataGridView1.Rows.Count>0)
                        {
                            buttSend.Visible = true;
                            label1.Visible = false;
                            panel2.Visible = false;
                        }
                        #endregion
                    }
                    #endregion
                    #region اذا ما رسلت شاشو القيود حاسبات يعبي جميع الحسابات

                    else
                    {
                            #region اضافة البيانات الى الداتا جريت
                       
                        for (i = 0; i < datatable.Rows.Count; i++)
                        {
                           

                            dataGridView1.Rows.Add
                         (datatable.Rows[i][0].ToString(), //idItemUnit,
                          datatable.Rows[i][1].ToString(),  //Items_barc[1],
                          datatable.Rows[i][2].ToString(),  //Item_name[2],
                          datatable.Rows[i][3].ToString(),  //Unit_name[3],
                          datatable.Rows[i][4].ToString(),  //Selling_price[4],
                          datatable.Rows[i][5].ToString(),  //price_part[5],
                          "0"  //العدد واحدة
                         , "0" // العدد جزء
                        , "0" // الاجمالي
                        , false //Select
   , (Convert.ToBoolean(datatable.Rows[i][6].ToString()) == true
   ? "صنف نشط" : "صنف غير نشط"),  // Items.State,
     (Convert.ToBoolean(datatable.Rows[i][7].ToString()) == true
     ? "وحدة مفعلة" : "وحدة صنف غير مفعلة"),  // ItemUnit.State[9],
                         "0",  //متوفر واحدة,
                         "0",  //متوفر جزء,
                         datatable.Rows[i][8].ToString()  //Unit_part,

                                       );
                            #endregion



                            if (dataGridView1.Rows.Count == 0 && ItemSelection.Count == 0)

                            {

                                buttSend.Visible = false;
                                label1.Visible = true;
                                panel2.Visible = true;
                                label1.Text = "لا يوجد اصناف لعرضها لعرضها";
                            }
                            else if (dataGridView1.Rows.Count > 0)
                            {
                                buttSend.Visible = true;
                                label1.Visible = false;
                                panel2.Visible = false;
                            }

                        }


                    }
                    #endregion
                }
                #endregion
                #region لا يوجد بيانات في الداتا تيبل
               
                else
                {
                    if (dataGridView1.Rows.Count == 0&& ItemSelection.Count==0)

                    {

                        buttSend.Visible = false;
                        label1.Visible = true;
                        panel2.Visible = true;
                        label1.Text = "لا يوجد اصناف لعرضها";
                    }
                    else if((dataGridView1.Rows.Count == 0 && ItemSelection.Count > 0))
                    {
                        buttSend.Visible = true;
                        label1.Visible = true;
                        panel2.Visible = true;
                        label1.Text = "لا يوجد اصناف لعرضها";

                    }
                    else if (dataGridView1.Rows.Count > 0)
                    {
                        label1.Visible = false;
                        panel2.Visible = false;
                    }
                   
                }
                #endregion
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString(),"Error in Fill Data",MessageBoxButtons.OK,MessageBoxIcon.Error); }

        }
        private void EntriesAccList_Load(object sender, EventArgs e)
        {
           
            FillData("All");
            FormatingDataGrid();
            CountItemSelect();
            
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                int i = dataGridView1.CurrentCell.RowIndex;
                int j = dataGridView1.CurrentCell.ColumnIndex;

                if (j == 9)
                {
                    if (dataGridView1.Rows[i].Cells[10].Value.ToString() == "صنف نشط" && dataGridView1.Rows[i].Cells[11].Value.ToString() == "وحدة مفعلة")
                    {
                        // dataGridView1.Rows[i].Cells[9].ReadOnly =
                       // (dataGridView1.Rows[i].Cells[10].Value.ToString() == "صنف نشط" ?
                       // (dataGridView1.Rows[i].Cells[11].Value.ToString() == "وحدة مفعلة" ? false : true)
                      //                                                                          : true);
                        try {
                            DataGridViewCheckBoxCell chk = dataGridView1.Rows[i].Cells[9] as DataGridViewCheckBoxCell;

                            if (Convert.ToBoolean(chk.Value) == true)
                            {
                                bool AccFound = false;
                                string ItemUnitId = dataGridView1.Rows[i].Cells[0].Value.ToString();
                                for (int x = 0; x < ItemSelection.Count; x++)
                                {
                                    if (ItemUnitId == ItemSelection[x].idItemUnit)
                                    {
                                        AccFound = true; break;
                                    }

                                }
                                if (!AccFound)
                                {
                                    ItemIdSelected = new BillParametr();

                                ItemIdSelected.idItemUnit = dataGridView1.Rows[i].Cells[0].Value.ToString();
                                ItemIdSelected.barc = dataGridView1.Rows[i].Cells[1].Value.ToString();
                                ItemIdSelected.Item_name = dataGridView1.Rows[i].Cells[2].Value.ToString();
                                ItemIdSelected.Unit_name = dataGridView1.Rows[i].Cells[3].Value.ToString();
                                ItemIdSelected.Selling_price = dataGridView1.Rows[i].Cells[4].Value.ToString();
                                ItemIdSelected.price_part = dataGridView1.Rows[i].Cells[5].Value.ToString();
                                ItemIdSelected.Quantity = dataGridView1.Rows[i].Cells[6].Value.ToString();
                                ItemIdSelected.Part = dataGridView1.Rows[i].Cells[7].Value.ToString();
                                ItemIdSelected.Unit_part = dataGridView1.Rows[i].Cells[14].Value.ToString();
                                    ItemSelection.Add(ItemIdSelected);
                                    CountItemSelect();
                                }
                            }
                            else
                            {
                                string ItemUnitId = dataGridView1.Rows[i].Cells[0].Value.ToString();
                                for (int x = 0; x < ItemSelection.Count; x++)
                                {
                                    if (ItemUnitId == ItemSelection[x].idItemUnit)
                                    {
                                        ItemSelection.RemoveAt(x);
                                        CountItemSelect();
                                        break;
                                    }

                                }


                            }
                            CountItemSelect(); 

                        }
                        catch(Exception ee)  { MessageBox.Show(ee.ToString(), "Convert.ToBoolean(dataGridView1.Rows[i].Cells[5].Value) == true"); }

                    }

                }
            } //
        }
        void CountItemSelect()
        {
            //textBoxCountSelect.Text = ItemSelection.Count.ToString();
        }
       

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            FillData("Serch");
            FormatingDataGrid();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBoxGroupStored_SelectedIndexChanged(object sender, EventArgs e)
        {
          
            FillData("All");
            FormatingDataGrid();
            

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            //if (ItemSelection.Count > 0)
            //{
            //    int i = 1;
            //    foreach (var item in ItemSelection)
            //    {
            //        MessageBox.Show(item.Item_name, i.ToString());
            //        i++;
            //    }
            //}
          
        }

        private void buttSend_Click(object sender, EventArgs e)
        {
            if (ItemSelection.Count > 0)
               stateSelect = true;
           else
                stateSelect = false;
            Close();
            
        }
    }
}
