﻿namespace AccSystem.FormsProject.Sales
{
    partial class SaleBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SaleBill));
            this.panMain = new System.Windows.Forms.Panel();
            this.panFill = new System.Windows.Forms.Panel();
            this.panFillFill = new System.Windows.Forms.Panel();
            this.panFFUp = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.DGVBody = new System.Windows.Forms.DataGridView();
            this.idBodyBill = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panFFDawn = new System.Windows.Forms.Panel();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textDebtWord = new System.Windows.Forms.TextBox();
            this.txtSum = new System.Windows.Forms.TextBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panFillDawn = new System.Windows.Forms.Panel();
            this.groupBoxOprea = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttNext = new System.Windows.Forms.Button();
            this.buttFrist = new System.Windows.Forms.Button();
            this.CountRows = new System.Windows.Forms.TextBox();
            this.buttBack = new System.Windows.Forms.Button();
            this.buttLast = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.checkBoxSavePosting = new System.Windows.Forms.CheckBox();
            this.buttPrint = new System.Windows.Forms.Button();
            this.butSave = new System.Windows.Forms.Button();
            this.buttAdd = new System.Windows.Forms.Button();
            this.buttPosting = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.buttDelete = new System.Windows.Forms.Button();
            this.panFillUp = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textNote = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.txtAccBoxMax = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtAccBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_name_fk = new System.Windows.Forms.TextBox();
            this.textBox_id_fk = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.txtCust_id_fk = new System.Windows.Forms.TextBox();
            this.txtAccCustMax = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtAccCust = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioButtLetar = new System.Windows.Forms.RadioButton();
            this.radioButtCach = new System.Windows.Forms.RadioButton();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.textIdBill = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panDown = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserId = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserName = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserIdAdd = new System.Windows.Forms.ToolStripStatusLabel();
            this.UserNameAdd = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel8 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel9 = new System.Windows.Forms.ToolStripStatusLabel();
            this.idOpration = new System.Windows.Forms.ToolStripStatusLabel();
            this.nameOpration = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel12 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel13 = new System.Windows.Forms.ToolStripStatusLabel();
            this.StatPosting = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel15 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel16 = new System.Windows.Forms.ToolStripStatusLabel();
            this.CurrId = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Discount_percentage = new System.Windows.Forms.ToolStripStatusLabel();
            this.panUp = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.txtSerch = new System.Windows.Forms.TextBox();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.panMain.SuspendLayout();
            this.panFill.SuspendLayout();
            this.panFillFill.SuspendLayout();
            this.panFFUp.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVBody)).BeginInit();
            this.panFFDawn.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panFillDawn.SuspendLayout();
            this.groupBoxOprea.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panFillUp.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.panDown.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panFill);
            this.panMain.Controls.Add(this.panDown);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1161, 650);
            this.panMain.TabIndex = 0;
            // 
            // panFill
            // 
            this.panFill.Controls.Add(this.panFillFill);
            this.panFill.Controls.Add(this.panFillDawn);
            this.panFill.Controls.Add(this.panFillUp);
            this.panFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFill.Location = new System.Drawing.Point(0, 31);
            this.panFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFill.Name = "panFill";
            this.panFill.Size = new System.Drawing.Size(1161, 588);
            this.panFill.TabIndex = 2;
            // 
            // panFillFill
            // 
            this.panFillFill.Controls.Add(this.panFFUp);
            this.panFillFill.Controls.Add(this.panFFDawn);
            this.panFillFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFillFill.Location = new System.Drawing.Point(0, 146);
            this.panFillFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillFill.Name = "panFillFill";
            this.panFillFill.Size = new System.Drawing.Size(1161, 318);
            this.panFillFill.TabIndex = 2;
            // 
            // panFFUp
            // 
            this.panFFUp.Controls.Add(this.groupBox3);
            this.panFFUp.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFFUp.Location = new System.Drawing.Point(0, 0);
            this.panFFUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFFUp.Name = "panFFUp";
            this.panFFUp.Size = new System.Drawing.Size(1161, 235);
            this.panFFUp.TabIndex = 2;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.DGVBody);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(1161, 235);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "تفاصيل الفاتورة";
            // 
            // DGVBody
            // 
            this.DGVBody.AllowUserToAddRows = false;
            this.DGVBody.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DGVBody.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGVBody.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVBody.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGVBody.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DGVBody.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVBody.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DGVBody.ColumnHeadersHeight = 30;
            this.DGVBody.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGVBody.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idBodyBill,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn13,
            this.Column11,
            this.dataGridViewTextBoxColumn14});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVBody.DefaultCellStyle = dataGridViewCellStyle3;
            this.DGVBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVBody.EnableHeadersVisualStyles = false;
            this.DGVBody.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DGVBody.Location = new System.Drawing.Point(3, 18);
            this.DGVBody.Name = "DGVBody";
            this.DGVBody.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVBody.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DGVBody.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Gray;
            this.DGVBody.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DGVBody.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVBody.Size = new System.Drawing.Size(1155, 215);
            this.DGVBody.TabIndex = 43;
            this.DGVBody.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBody_CellClick);
            this.DGVBody.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBody_CellContentClick);
            this.DGVBody.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBody_CellEndEdit);
            this.DGVBody.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVBody_CellValueChanged);
            this.DGVBody.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.DGVBody_EditingControlShowing);
            this.DGVBody.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.DGVBody_RowsAdded);
            this.DGVBody.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.DGVBody_RowsRemoved);
            // 
            // idBodyBill
            // 
            this.idBodyBill.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.idBodyBill.Frozen = true;
            this.idBodyBill.HeaderText = "idBodyBill";
            this.idBodyBill.Name = "idBodyBill";
            this.idBodyBill.ReadOnly = true;
            this.idBodyBill.Visible = false;
            this.idBodyBill.Width = 93;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn12.Frozen = true;
            this.dataGridViewTextBoxColumn12.HeaderText = "idUnitItem";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Visible = false;
            this.dataGridViewTextBoxColumn12.Width = 80;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "التسلسل";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 73;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn2.FillWeight = 288.8852F;
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "رقم الصنف";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 81;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn3.FillWeight = 525.3807F;
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "اسم الصنف";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 86;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn4.FillWeight = 50.06168F;
            this.dataGridViewTextBoxColumn4.Frozen = true;
            this.dataGridViewTextBoxColumn4.HeaderText = "الوحدة";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 115;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 115;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn5.FillWeight = 20.84476F;
            this.dataGridViewTextBoxColumn5.HeaderText = "الكمية وحدة";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 89;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn6.FillWeight = 8.683408F;
            this.dataGridViewTextBoxColumn6.HeaderText = "الكمية جزء";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn6.Width = 80;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn7.FillWeight = 3.62132F;
            this.dataGridViewTextBoxColumn7.HeaderText = "سعر الوحدة";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn7.Width = 87;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn8.FillWeight = 1.514259F;
            this.dataGridViewTextBoxColumn8.HeaderText = "سعر الجزء";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Width = 78;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn10.FillWeight = 0.3715312F;
            this.dataGridViewTextBoxColumn10.HeaderText = "اجمالي وحدة";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Width = 96;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn9.FillWeight = 0.6372076F;
            this.dataGridViewTextBoxColumn9.HeaderText = "اجمالي جزء";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 87;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn11.HeaderText = "الاجمالي الكلي";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Width = 109;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn13.HeaderText = "اجزاء الوحدة";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Width = 89;
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column11.HeaderText = "الكمية المتبقية وحدة";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 160;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn14.HeaderText = "الكمية المتبقية جزء";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Width = 132;
            // 
            // panFFDawn
            // 
            this.panFFDawn.Controls.Add(this.groupBox4);
            this.panFFDawn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panFFDawn.Location = new System.Drawing.Point(0, 235);
            this.panFFDawn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFFDawn.Name = "panFFDawn";
            this.panFFDawn.Size = new System.Drawing.Size(1161, 83);
            this.panFFDawn.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textDebtWord);
            this.groupBox4.Controls.Add(this.txtSum);
            this.groupBox4.Controls.Add(this.txtDiscount);
            this.groupBox4.Controls.Add(this.txtTotal);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(1161, 83);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "المبلغ";
            // 
            // textDebtWord
            // 
            this.textDebtWord.BackColor = System.Drawing.Color.Lavender;
            this.textDebtWord.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textDebtWord.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textDebtWord.ForeColor = System.Drawing.Color.Black;
            this.textDebtWord.Location = new System.Drawing.Point(3, 54);
            this.textDebtWord.Name = "textDebtWord";
            this.textDebtWord.Size = new System.Drawing.Size(1155, 27);
            this.textDebtWord.TabIndex = 23;
            this.textDebtWord.Text = "اثنا عشر الف وخمس مائة ريال يمني فقط لا غير";
            this.textDebtWord.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtSum
            // 
            this.txtSum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtSum.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSum.ForeColor = System.Drawing.Color.Blue;
            this.txtSum.Location = new System.Drawing.Point(762, 19);
            this.txtSum.Name = "txtSum";
            this.txtSum.Size = new System.Drawing.Size(166, 27);
            this.txtSum.TabIndex = 22;
            this.txtSum.Text = "0";
            this.txtSum.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDiscount
            // 
            this.txtDiscount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtDiscount.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.txtDiscount.ForeColor = System.Drawing.Color.Red;
            this.txtDiscount.Location = new System.Drawing.Point(536, 20);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.ReadOnly = true;
            this.txtDiscount.Size = new System.Drawing.Size(166, 27);
            this.txtDiscount.TabIndex = 21;
            this.txtDiscount.Text = "0";
            this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDiscount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDiscount_KeyPress);
            this.txtDiscount.Leave += new System.EventHandler(this.txtDiscount_Leave);
            // 
            // txtTotal
            // 
            this.txtTotal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtTotal.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.txtTotal.ForeColor = System.Drawing.Color.SeaGreen;
            this.txtTotal.Location = new System.Drawing.Point(248, 20);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(166, 27);
            this.txtTotal.TabIndex = 19;
            this.txtTotal.Text = "0";
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtTotal.TextChanged += new System.EventHandler(this.txtTotal_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(420, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(94, 14);
            this.label7.TabIndex = 13;
            this.label7.Text = "صافي الفاتورة:";
            this.label7.DoubleClick += new System.EventHandler(this.label7_DoubleClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(705, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 14);
            this.label5.TabIndex = 9;
            this.label5.Text = "الخصم:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(932, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 14);
            this.label4.TabIndex = 7;
            this.label4.Text = "اجمالي الفاتورة:";
            // 
            // panFillDawn
            // 
            this.panFillDawn.Controls.Add(this.groupBoxOprea);
            this.panFillDawn.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panFillDawn.Location = new System.Drawing.Point(0, 464);
            this.panFillDawn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillDawn.Name = "panFillDawn";
            this.panFillDawn.Size = new System.Drawing.Size(1161, 124);
            this.panFillDawn.TabIndex = 1;
            // 
            // groupBoxOprea
            // 
            this.groupBoxOprea.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxOprea.Controls.Add(this.panel2);
            this.groupBoxOprea.Controls.Add(this.panel1);
            this.groupBoxOprea.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxOprea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxOprea.ForeColor = System.Drawing.Color.Black;
            this.groupBoxOprea.Location = new System.Drawing.Point(0, 0);
            this.groupBoxOprea.Name = "groupBoxOprea";
            this.groupBoxOprea.Size = new System.Drawing.Size(1161, 124);
            this.groupBoxOprea.TabIndex = 34;
            this.groupBoxOprea.TabStop = false;
            this.groupBoxOprea.Text = "العمليات";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttNext);
            this.panel2.Controls.Add(this.buttFrist);
            this.panel2.Controls.Add(this.CountRows);
            this.panel2.Controls.Add(this.buttBack);
            this.panel2.Controls.Add(this.buttLast);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(3, 19);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(434, 102);
            this.panel2.TabIndex = 179;
            // 
            // buttNext
            // 
            this.buttNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttNext.FlatAppearance.BorderSize = 0;
            this.buttNext.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttNext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttNext.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttNext.ForeColor = System.Drawing.Color.White;
            this.buttNext.Image = ((System.Drawing.Image)(resources.GetObject("buttNext.Image")));
            this.buttNext.Location = new System.Drawing.Point(282, 12);
            this.buttNext.Name = "buttNext";
            this.buttNext.Size = new System.Drawing.Size(57, 82);
            this.buttNext.TabIndex = 169;
            this.buttNext.Text = "التالي";
            this.buttNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttNext.UseVisualStyleBackColor = false;
            this.buttNext.Click += new System.EventHandler(this.buttNext_Click);
            // 
            // buttFrist
            // 
            this.buttFrist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFrist.FlatAppearance.BorderSize = 0;
            this.buttFrist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttFrist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttFrist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttFrist.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttFrist.ForeColor = System.Drawing.Color.White;
            this.buttFrist.Image = ((System.Drawing.Image)(resources.GetObject("buttFrist.Image")));
            this.buttFrist.Location = new System.Drawing.Point(345, 12);
            this.buttFrist.Name = "buttFrist";
            this.buttFrist.Size = new System.Drawing.Size(57, 82);
            this.buttFrist.TabIndex = 168;
            this.buttFrist.Text = "الاول";
            this.buttFrist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttFrist.UseVisualStyleBackColor = false;
            this.buttFrist.Click += new System.EventHandler(this.buttFrist_Click);
            // 
            // CountRows
            // 
            this.CountRows.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CountRows.Enabled = false;
            this.CountRows.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountRows.Location = new System.Drawing.Point(143, 34);
            this.CountRows.Name = "CountRows";
            this.CountRows.ReadOnly = true;
            this.CountRows.Size = new System.Drawing.Size(133, 33);
            this.CountRows.TabIndex = 172;
            this.CountRows.Text = "1111-1111";
            this.CountRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttBack
            // 
            this.buttBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBack.FlatAppearance.BorderSize = 0;
            this.buttBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBack.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttBack.ForeColor = System.Drawing.Color.White;
            this.buttBack.Image = ((System.Drawing.Image)(resources.GetObject("buttBack.Image")));
            this.buttBack.Location = new System.Drawing.Point(79, 12);
            this.buttBack.Name = "buttBack";
            this.buttBack.Size = new System.Drawing.Size(57, 82);
            this.buttBack.TabIndex = 170;
            this.buttBack.Text = "السابق";
            this.buttBack.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttBack.UseVisualStyleBackColor = false;
            this.buttBack.Click += new System.EventHandler(this.buttBack_Click);
            // 
            // buttLast
            // 
            this.buttLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttLast.FlatAppearance.BorderSize = 0;
            this.buttLast.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttLast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttLast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttLast.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttLast.ForeColor = System.Drawing.Color.White;
            this.buttLast.Image = ((System.Drawing.Image)(resources.GetObject("buttLast.Image")));
            this.buttLast.Location = new System.Drawing.Point(15, 12);
            this.buttLast.Name = "buttLast";
            this.buttLast.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.buttLast.Size = new System.Drawing.Size(57, 82);
            this.buttLast.TabIndex = 171;
            this.buttLast.Text = "الاخير";
            this.buttLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttLast.UseVisualStyleBackColor = false;
            this.buttLast.Click += new System.EventHandler(this.buttLast_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.checkBoxSavePosting);
            this.panel1.Controls.Add(this.buttPrint);
            this.panel1.Controls.Add(this.butSave);
            this.panel1.Controls.Add(this.buttAdd);
            this.panel1.Controls.Add(this.buttPosting);
            this.panel1.Controls.Add(this.buttEdite);
            this.panel1.Controls.Add(this.buttDelete);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(672, 19);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(486, 102);
            this.panel1.TabIndex = 178;
            // 
            // checkBoxSavePosting
            // 
            this.checkBoxSavePosting.AutoSize = true;
            this.checkBoxSavePosting.Location = new System.Drawing.Point(10, 41);
            this.checkBoxSavePosting.Name = "checkBoxSavePosting";
            this.checkBoxSavePosting.Size = new System.Drawing.Size(103, 20);
            this.checkBoxSavePosting.TabIndex = 178;
            this.checkBoxSavePosting.Text = "حفظ وترحيل";
            this.checkBoxSavePosting.UseVisualStyleBackColor = true;
            // 
            // buttPrint
            // 
            this.buttPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttPrint.FlatAppearance.BorderSize = 0;
            this.buttPrint.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttPrint.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttPrint.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttPrint.ForeColor = System.Drawing.Color.White;
            this.buttPrint.Image = ((System.Drawing.Image)(resources.GetObject("buttPrint.Image")));
            this.buttPrint.Location = new System.Drawing.Point(119, 12);
            this.buttPrint.Name = "buttPrint";
            this.buttPrint.Size = new System.Drawing.Size(54, 82);
            this.buttPrint.TabIndex = 175;
            this.buttPrint.Text = "طباعة";
            this.buttPrint.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttPrint.UseVisualStyleBackColor = false;
            this.buttPrint.Click += new System.EventHandler(this.buttPrint_Click);
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.Location = new System.Drawing.Point(358, 12);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(54, 82);
            this.butSave.TabIndex = 165;
            this.butSave.Text = "حفظ";
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butSave.UseVisualStyleBackColor = false;
            this.butSave.Click += new System.EventHandler(this.butSave_Click);
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.FlatAppearance.BorderSize = 0;
            this.buttAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.Location = new System.Drawing.Point(418, 12);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(55, 82);
            this.buttAdd.TabIndex = 164;
            this.buttAdd.Text = "جديد";
            this.buttAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttAdd.UseVisualStyleBackColor = false;
            this.buttAdd.Click += new System.EventHandler(this.buttAdd_Click);
            // 
            // buttPosting
            // 
            this.buttPosting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttPosting.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttPosting.FlatAppearance.BorderSize = 0;
            this.buttPosting.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttPosting.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttPosting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttPosting.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttPosting.ForeColor = System.Drawing.Color.White;
            this.buttPosting.Image = ((System.Drawing.Image)(resources.GetObject("buttPosting.Image")));
            this.buttPosting.Location = new System.Drawing.Point(179, 12);
            this.buttPosting.Name = "buttPosting";
            this.buttPosting.Size = new System.Drawing.Size(54, 82);
            this.buttPosting.TabIndex = 174;
            this.buttPosting.Text = "ترحيل";
            this.buttPosting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttPosting.UseVisualStyleBackColor = false;
            this.buttPosting.Click += new System.EventHandler(this.buttPosting_Click);
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.Location = new System.Drawing.Point(298, 12);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(54, 82);
            this.buttEdite.TabIndex = 166;
            this.buttEdite.Text = "تعديل";
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttEdite.UseVisualStyleBackColor = false;
            this.buttEdite.Click += new System.EventHandler(this.buttEdite_Click);
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.FlatAppearance.BorderSize = 0;
            this.buttDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.Location = new System.Drawing.Point(238, 12);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(54, 82);
            this.buttDelete.TabIndex = 167;
            this.buttDelete.Text = "حذف";
            this.buttDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttDelete.UseVisualStyleBackColor = false;
            this.buttDelete.Click += new System.EventHandler(this.buttDelete_Click);
            // 
            // panFillUp
            // 
            this.panFillUp.Controls.Add(this.groupBox1);
            this.panFillUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFillUp.Location = new System.Drawing.Point(0, 0);
            this.panFillUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFillUp.Name = "panFillUp";
            this.panFillUp.Size = new System.Drawing.Size(1161, 146);
            this.panFillUp.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.textIdBill);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(1161, 146);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textNote);
            this.groupBox2.Location = new System.Drawing.Point(12, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(386, 121);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "ملاحـــظات";
            // 
            // textNote
            // 
            this.textNote.AcceptsReturn = true;
            this.textNote.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textNote.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textNote.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNote.ForeColor = System.Drawing.Color.Black;
            this.textNote.Location = new System.Drawing.Point(3, 19);
            this.textNote.Multiline = true;
            this.textNote.Name = "textNote";
            this.textNote.Size = new System.Drawing.Size(380, 99);
            this.textNote.TabIndex = 42;
            this.textNote.Text = "فاتورة بيع 12  نقدا";
            this.textNote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.txtAccBoxMax);
            this.groupBox8.Controls.Add(this.label2);
            this.groupBox8.Controls.Add(this.txtAccBox);
            this.groupBox8.Controls.Add(this.label3);
            this.groupBox8.Controls.Add(this.textBox_name_fk);
            this.groupBox8.Controls.Add(this.textBox_id_fk);
            this.groupBox8.Location = new System.Drawing.Point(410, 10);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(260, 121);
            this.groupBox8.TabIndex = 56;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "بيانات الصندوق";
            // 
            // txtAccBoxMax
            // 
            this.txtAccBoxMax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtAccBoxMax.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccBoxMax.ForeColor = System.Drawing.Color.Red;
            this.txtAccBoxMax.Location = new System.Drawing.Point(12, 84);
            this.txtAccBoxMax.Name = "txtAccBoxMax";
            this.txtAccBoxMax.ReadOnly = true;
            this.txtAccBoxMax.Size = new System.Drawing.Size(172, 26);
            this.txtAccBoxMax.TabIndex = 58;
            this.txtAccBoxMax.Text = "0";
            this.txtAccBoxMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(189, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 14);
            this.label2.TabIndex = 57;
            this.label2.Text = "حد الدين:";
            // 
            // txtAccBox
            // 
            this.txtAccBox.BackColor = System.Drawing.Color.Gray;
            this.txtAccBox.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccBox.ForeColor = System.Drawing.Color.White;
            this.txtAccBox.Location = new System.Drawing.Point(12, 56);
            this.txtAccBox.Name = "txtAccBox";
            this.txtAccBox.ReadOnly = true;
            this.txtAccBox.Size = new System.Drawing.Size(171, 26);
            this.txtAccBox.TabIndex = 56;
            this.txtAccBox.Text = "0";
            this.txtAccBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(189, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 14);
            this.label3.TabIndex = 55;
            this.label3.Text = "الرصيد:";
            // 
            // textBox_name_fk
            // 
            this.textBox_name_fk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox_name_fk.ForeColor = System.Drawing.Color.Black;
            this.textBox_name_fk.Location = new System.Drawing.Point(12, 24);
            this.textBox_name_fk.Name = "textBox_name_fk";
            this.textBox_name_fk.ReadOnly = true;
            this.textBox_name_fk.Size = new System.Drawing.Size(139, 23);
            this.textBox_name_fk.TabIndex = 54;
            this.textBox_name_fk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_id_fk
            // 
            this.textBox_id_fk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox_id_fk.ForeColor = System.Drawing.Color.Black;
            this.textBox_id_fk.Location = new System.Drawing.Point(154, 24);
            this.textBox_id_fk.Name = "textBox_id_fk";
            this.textBox_id_fk.ReadOnly = true;
            this.textBox_id_fk.Size = new System.Drawing.Size(96, 23);
            this.textBox_id_fk.TabIndex = 53;
            this.textBox_id_fk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_id_fk.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_id_fk_KeyDown);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.txtCustName);
            this.groupBox7.Controls.Add(this.txtCust_id_fk);
            this.groupBox7.Controls.Add(this.txtAccCustMax);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.txtAccCust);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Location = new System.Drawing.Point(681, 10);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(260, 121);
            this.groupBox7.TabIndex = 54;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "بيانات العميل";
            // 
            // txtCustName
            // 
            this.txtCustName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCustName.ForeColor = System.Drawing.Color.Black;
            this.txtCustName.Location = new System.Drawing.Point(17, 27);
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.ReadOnly = true;
            this.txtCustName.Size = new System.Drawing.Size(139, 23);
            this.txtCustName.TabIndex = 51;
            this.txtCustName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCust_id_fk
            // 
            this.txtCust_id_fk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtCust_id_fk.ForeColor = System.Drawing.Color.Black;
            this.txtCust_id_fk.Location = new System.Drawing.Point(158, 27);
            this.txtCust_id_fk.Name = "txtCust_id_fk";
            this.txtCust_id_fk.ReadOnly = true;
            this.txtCust_id_fk.Size = new System.Drawing.Size(96, 23);
            this.txtCust_id_fk.TabIndex = 50;
            this.txtCust_id_fk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCust_id_fk.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCust_id_fk_KeyDown);
            // 
            // txtAccCustMax
            // 
            this.txtAccCustMax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtAccCustMax.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccCustMax.ForeColor = System.Drawing.Color.Red;
            this.txtAccCustMax.Location = new System.Drawing.Point(17, 86);
            this.txtAccCustMax.Name = "txtAccCustMax";
            this.txtAccCustMax.ReadOnly = true;
            this.txtAccCustMax.Size = new System.Drawing.Size(172, 26);
            this.txtAccCustMax.TabIndex = 40;
            this.txtAccCustMax.Text = "0";
            this.txtAccCustMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label18.Location = new System.Drawing.Point(194, 86);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 14);
            this.label18.TabIndex = 39;
            this.label18.Text = "حد الدين:";
            // 
            // txtAccCust
            // 
            this.txtAccCust.BackColor = System.Drawing.Color.Gray;
            this.txtAccCust.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAccCust.ForeColor = System.Drawing.Color.White;
            this.txtAccCust.Location = new System.Drawing.Point(17, 58);
            this.txtAccCust.Name = "txtAccCust";
            this.txtAccCust.ReadOnly = true;
            this.txtAccCust.Size = new System.Drawing.Size(171, 26);
            this.txtAccCust.TabIndex = 15;
            this.txtAccCust.Text = "0";
            this.txtAccCust.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label12.Location = new System.Drawing.Point(194, 64);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 14);
            this.label12.TabIndex = 14;
            this.label12.Text = "الرصيد:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioButtLetar);
            this.groupBox5.Controls.Add(this.radioButtCach);
            this.groupBox5.Location = new System.Drawing.Point(948, 50);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(196, 45);
            this.groupBox5.TabIndex = 43;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "نوع الفاتورة";
            // 
            // radioButtLetar
            // 
            this.radioButtLetar.AutoSize = true;
            this.radioButtLetar.Location = new System.Drawing.Point(33, 19);
            this.radioButtLetar.Name = "radioButtLetar";
            this.radioButtLetar.Size = new System.Drawing.Size(51, 20);
            this.radioButtLetar.TabIndex = 1;
            this.radioButtLetar.TabStop = true;
            this.radioButtLetar.Text = "آجل";
            this.radioButtLetar.UseVisualStyleBackColor = true;
            this.radioButtLetar.CheckedChanged += new System.EventHandler(this.radioButtLetar_CheckedChanged);
            // 
            // radioButtCach
            // 
            this.radioButtCach.AutoSize = true;
            this.radioButtCach.Location = new System.Drawing.Point(102, 19);
            this.radioButtCach.Name = "radioButtCach";
            this.radioButtCach.Size = new System.Drawing.Size(48, 20);
            this.radioButtCach.TabIndex = 0;
            this.radioButtCach.TabStop = true;
            this.radioButtCach.Text = "نقدا";
            this.radioButtCach.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.AllowDrop = true;
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.Color.Silver;
            this.dateTimePicker1.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(947, 105);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(132, 23);
            this.dateTimePicker1.TabIndex = 32;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(1085, 110);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 14);
            this.label14.TabIndex = 16;
            this.label14.Text = "التاريخ:";
            // 
            // textIdBill
            // 
            this.textIdBill.BackColor = System.Drawing.Color.Gray;
            this.textIdBill.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textIdBill.ForeColor = System.Drawing.Color.White;
            this.textIdBill.Location = new System.Drawing.Point(948, 16);
            this.textIdBill.Name = "textIdBill";
            this.textIdBill.ReadOnly = true;
            this.textIdBill.Size = new System.Drawing.Size(131, 26);
            this.textIdBill.TabIndex = 6;
            this.textIdBill.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(1074, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 14);
            this.label1.TabIndex = 3;
            this.label1.Text = "رقم الفاتورة: ";
            // 
            // panDown
            // 
            this.panDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panDown.Controls.Add(this.statusStrip1);
            this.panDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDown.Location = new System.Drawing.Point(0, 619);
            this.panDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDown.MaximumSize = new System.Drawing.Size(1161, 31);
            this.panDown.MinimumSize = new System.Drawing.Size(1161, 31);
            this.panDown.Name = "panDown";
            this.panDown.Size = new System.Drawing.Size(1161, 31);
            this.panDown.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.UserId,
            this.UserName,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5,
            this.UserIdAdd,
            this.UserNameAdd,
            this.toolStripStatusLabel8,
            this.toolStripStatusLabel9,
            this.idOpration,
            this.nameOpration,
            this.toolStripStatusLabel12,
            this.toolStripStatusLabel13,
            this.StatPosting,
            this.toolStripStatusLabel15,
            this.toolStripStatusLabel16,
            this.CurrId,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.Discount_percentage});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.MaximumSize = new System.Drawing.Size(1161, 31);
            this.statusStrip1.MinimumSize = new System.Drawing.Size(1161, 31);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1161, 31);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(84, 26);
            this.toolStripStatusLabel1.Text = "المستخدم الحالي:";
            // 
            // UserId
            // 
            this.UserId.ForeColor = System.Drawing.Color.White;
            this.UserId.Name = "UserId";
            this.UserId.Size = new System.Drawing.Size(40, 26);
            this.UserId.Text = "UserId";
            // 
            // UserName
            // 
            this.UserName.ForeColor = System.Drawing.Color.White;
            this.UserName.Name = "UserName";
            this.UserName.Size = new System.Drawing.Size(62, 26);
            this.UserName.Text = "UserName";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel4.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(15, 26);
            this.toolStripStatusLabel4.Text = "||";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(81, 26);
            this.toolStripStatusLabel5.Text = "اضافة المستخدم:";
            // 
            // UserIdAdd
            // 
            this.UserIdAdd.ForeColor = System.Drawing.Color.White;
            this.UserIdAdd.Name = "UserIdAdd";
            this.UserIdAdd.Size = new System.Drawing.Size(62, 26);
            this.UserIdAdd.Text = "UserIdAdd";
            // 
            // UserNameAdd
            // 
            this.UserNameAdd.ForeColor = System.Drawing.Color.White;
            this.UserNameAdd.Name = "UserNameAdd";
            this.UserNameAdd.Size = new System.Drawing.Size(84, 26);
            this.UserNameAdd.Text = "UserNameAdd";
            // 
            // toolStripStatusLabel8
            // 
            this.toolStripStatusLabel8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel8.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel8.Name = "toolStripStatusLabel8";
            this.toolStripStatusLabel8.Size = new System.Drawing.Size(15, 26);
            this.toolStripStatusLabel8.Text = "||";
            // 
            // toolStripStatusLabel9
            // 
            this.toolStripStatusLabel9.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel9.Name = "toolStripStatusLabel9";
            this.toolStripStatusLabel9.Size = new System.Drawing.Size(39, 26);
            this.toolStripStatusLabel9.Text = "العملية:";
            // 
            // idOpration
            // 
            this.idOpration.ForeColor = System.Drawing.Color.White;
            this.idOpration.Name = "idOpration";
            this.idOpration.Size = new System.Drawing.Size(43, 26);
            this.idOpration.Text = "OpraId";
            // 
            // nameOpration
            // 
            this.nameOpration.ForeColor = System.Drawing.Color.White;
            this.nameOpration.Name = "nameOpration";
            this.nameOpration.Size = new System.Drawing.Size(65, 26);
            this.nameOpration.Text = "OpraName";
            // 
            // toolStripStatusLabel12
            // 
            this.toolStripStatusLabel12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel12.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel12.Name = "toolStripStatusLabel12";
            this.toolStripStatusLabel12.Size = new System.Drawing.Size(15, 26);
            this.toolStripStatusLabel12.Text = "||";
            // 
            // toolStripStatusLabel13
            // 
            this.toolStripStatusLabel13.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel13.Name = "toolStripStatusLabel13";
            this.toolStripStatusLabel13.Size = new System.Drawing.Size(57, 26);
            this.toolStripStatusLabel13.Text = "حالة السند:";
            // 
            // StatPosting
            // 
            this.StatPosting.ForeColor = System.Drawing.Color.White;
            this.StatPosting.Name = "StatPosting";
            this.StatPosting.Size = new System.Drawing.Size(67, 26);
            this.StatPosting.Text = "StatPosting";
            // 
            // toolStripStatusLabel15
            // 
            this.toolStripStatusLabel15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel15.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel15.Name = "toolStripStatusLabel15";
            this.toolStripStatusLabel15.Size = new System.Drawing.Size(15, 26);
            this.toolStripStatusLabel15.Text = "||";
            // 
            // toolStripStatusLabel16
            // 
            this.toolStripStatusLabel16.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel16.Name = "toolStripStatusLabel16";
            this.toolStripStatusLabel16.Size = new System.Drawing.Size(53, 26);
            this.toolStripStatusLabel16.Text = "رقم العملة:";
            // 
            // CurrId
            // 
            this.CurrId.ForeColor = System.Drawing.Color.White;
            this.CurrId.Name = "CurrId";
            this.CurrId.Size = new System.Drawing.Size(40, 26);
            this.CurrId.Text = "CurrId";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(136, 26);
            this.toolStripStatusLabel2.Text = "التفقيط والمبلغ بعملة المخزون";
            this.toolStripStatusLabel2.Visible = false;
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel3.ForeColor = System.Drawing.Color.White;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(15, 26);
            this.toolStripStatusLabel3.Text = "||";
            // 
            // Discount_percentage
            // 
            this.Discount_percentage.ForeColor = System.Drawing.Color.White;
            this.Discount_percentage.Name = "Discount_percentage";
            this.Discount_percentage.Size = new System.Drawing.Size(118, 26);
            this.Discount_percentage.Text = "Discount_percentage";
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.label13);
            this.panUp.Controls.Add(this.txtSerch);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.MaximumSize = new System.Drawing.Size(1161, 31);
            this.panUp.MinimumSize = new System.Drawing.Size(1161, 31);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(1161, 31);
            this.panUp.TabIndex = 0;
            this.panUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panUp_Paint);
            this.panUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panUp_MouseDown);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Right;
            this.label13.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Location = new System.Drawing.Point(949, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(212, 27);
            this.label13.TabIndex = 9;
            this.label13.Text = "        فاتورة مبيعات  ";
            // 
            // txtSerch
            // 
            this.txtSerch.BackColor = System.Drawing.Color.DimGray;
            this.txtSerch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSerch.Dock = System.Windows.Forms.DockStyle.Left;
            this.txtSerch.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerch.ForeColor = System.Drawing.Color.White;
            this.txtSerch.Location = new System.Drawing.Point(30, 0);
            this.txtSerch.Name = "txtSerch";
            this.txtSerch.Size = new System.Drawing.Size(316, 27);
            this.txtSerch.TabIndex = 8;
            this.txtSerch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSerch.TextChanged += new System.EventHandler(this.txtSerch_TextChanged);
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(0, 0);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 31);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 10;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click_1);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            // 
            // SaleBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1161, 650);
            this.ControlBox = false;
            this.Controls.Add(this.panMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1161, 650);
            this.Name = "SaleBill";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form4";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.SaleBill_Load);
            this.panMain.ResumeLayout(false);
            this.panFill.ResumeLayout(false);
            this.panFillFill.ResumeLayout(false);
            this.panFFUp.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVBody)).EndInit();
            this.panFFDawn.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panFillDawn.ResumeLayout(false);
            this.groupBoxOprea.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panFillUp.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.panDown.ResumeLayout(false);
            this.panDown.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panFill;
        private System.Windows.Forms.Panel panDown;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSerch;
        private System.Windows.Forms.Panel panFillFill;
        private System.Windows.Forms.Panel panFFUp;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panFFDawn;
        private System.Windows.Forms.Panel panFillDawn;
        private System.Windows.Forms.Panel panFillUp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBoxOprea;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textIdBill;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtSum;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtAccCust;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtAccCustMax;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox textNote;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton radioButtLetar;
        private System.Windows.Forms.RadioButton radioButtCach;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TextBox textBox_name_fk;
        private System.Windows.Forms.TextBox textBox_id_fk;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.TextBox txtCust_id_fk;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel UserId;
        private System.Windows.Forms.ToolStripStatusLabel UserName;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel UserIdAdd;
        private System.Windows.Forms.ToolStripStatusLabel UserNameAdd;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel8;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel9;
        private System.Windows.Forms.ToolStripStatusLabel idOpration;
        private System.Windows.Forms.ToolStripStatusLabel nameOpration;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel12;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel13;
        private System.Windows.Forms.ToolStripStatusLabel StatPosting;
        private System.Windows.Forms.TextBox textDebtWord;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttNext;
        private System.Windows.Forms.Button buttFrist;
        private System.Windows.Forms.TextBox CountRows;
        private System.Windows.Forms.Button buttBack;
        private System.Windows.Forms.Button buttLast;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBoxSavePosting;
        private System.Windows.Forms.Button buttPrint;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button buttAdd;
        private System.Windows.Forms.Button buttPosting;
        private System.Windows.Forms.Button buttEdite;
        private System.Windows.Forms.Button buttDelete;
        private System.Windows.Forms.TextBox txtAccBoxMax;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAccBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel15;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel16;
        private System.Windows.Forms.ToolStripStatusLabel CurrId;
        private System.Windows.Forms.DataGridView DGVBody;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel Discount_percentage;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridViewTextBoxColumn idBodyBill;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
    }
}