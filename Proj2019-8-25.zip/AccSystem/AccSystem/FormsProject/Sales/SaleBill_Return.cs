﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;
using AccSystem.FormsProject.Accounts;
using NumberToWord;

namespace AccSystem.FormsProject.Sales
{
    public partial class SaleBill_Return : Form
    {
        public SaleBill_Return(string idUser, Dictionary<string, bool> pre, List<string> idNameOpra)
        {
            InitializeComponent();
            UserId.Text = idUser;
            UserName.Text = userSql.GetNameUser(idUser);
            ButtnPre.Clear();
            ButtnPre = pre;
            if (idNameOpra.Count == 2)
            {
                nameOpration.Text = idNameOpra[1];
                idOpration.Text = idNameOpra[0];
            }
            else MessageBox.Show("لم نستقبل تعريف العمليه");
            CurrId.Text = currSql.GetIdCurrStock();

        }

        #region
        //////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس
        /// </summary>
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>
        ///////////////////////////////////////////////////////////////////////////////

        #endregion

        #region المتغيرات
        #region الواجهات
        IteamListBill iteamListBill; //واجهة اظهار اختيار الاصناف
        SupportBoxUserList sbu; //واجهة اظهار اختيار الصناديق

        #endregion
        #region الاستعلامات
        UsersSQL userSql = new UsersSQL(); //دوال المستخدمين
        AccountSQL AccSql = new AccountSQL(); //دوال الحسابات
        BillSalesReturnSQL billSalesSql = new BillSalesReturnSQL();
        CurrSQL currSql = new CurrSQL();
        PostingSQL postingSql = new PostingSQL();
        #endregion
        #region فلاجات وتحكم

        int indexHaed = -1; //معرفة موقع الفاتورة في الجدول عند التنقل
        string flagAddOrEdit = ""; //معرفة نوع العملية اضافة ام تعديل عند الحفظ
        static string ExchingOld = "0"; //يخزن اخر سعر صرف عشان اذا غير السعر وطلع خطا لانه الصيغه موش صح يرجع السعر القديم
        string OpenOrClose; //فتح او اغلاق الكتابة ل اي خليه في الجريد فيو
        static bool stingPosting = false;
        #endregion

        Dictionary<string, bool> ButtnPre = new Dictionary<string, bool>(); //الصلاحيات
        ///////////////////////////////////////////////////////
        List<BillParametr> BillParmBeforUpdate = new List<BillParametr>();//لحفظ تفاصيل الفاتورة قبل التعديل
        List<BillParametr> BillParmAfterUpdate = new List<BillParametr>();//لحفظ تفاصيل الفاتورة بعد التعديل
        BillParametr BillParm;


        DataTable DTHaed;
        DataTable DTBody;



        #endregion
        #region الدوال
        #region جلب بيانات
        /*
        جلب الفواتير
        جلب تفاصيل الفواتير
        جلب العملاء
        جلب الصناديق
        جلب الكميات المتبقية من الاصناف

        */
        #region جلب جميع الفواتير من القاعدة
        void fillData(string NormalOrSerch)
        {
            if (DTHaed != null)
                DTHaed = null;

            DTHaed = new DataTable();

            if (NormalOrSerch == "All")
                DTHaed = billSalesSql.GetAllSalesHaed();

            else if (NormalOrSerch == "Serch")
                DTHaed = billSalesSql.SaerchSalesHaed(txtSerch.Text);
            else
            {
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            }
               
            try
            {
                if (DTHaed.Rows.Count > 0)
                { indexHaed = 0; FillTextBox(indexHaed); }
                else if (DTHaed.Rows.Count == 0)
                { ClearAllTextBox(); DGVBody.Rows.Clear(); FillTextBoxCountRows(indexHaed.ToString()); }
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString()); }

        }
        void Delet(string Return_bill_id = "-1")
        {
            billSalesSql.Delet(Return_bill_id);
            fillData("All");
            //DELETE FROM [dbo].[SupportCatchHead]
            //  WHERE Support_id = 1
        }
        #endregion
        #region تعبئة الحقول حسب رقم الصف في الجدول
        void FillTextBox(int indexRows)
        {
            /*

            */
            if (DTHaed.Rows.Count > 0 && indexRows < DTHaed.Rows.Count && indexRows >= 0)
            {

                int i = indexRows;

                /*
                 
                */
                #region الاستعلام 
                /*
                       
             Bill_id, 0
             TypeBill.Type_neme, 1
             Date_salesbill, 2
            .Cust_id_fk,  3
            .Cust_name, 4
            .Box_id_fk,  5
            .Box_name,  6
            BoxUser_id,7
            User_id, 8
            User_name 9
            .Total,10
            .Note,11
            .Bill_id_fk, 12
            .posting, 13
            
                
                 
                */
                #endregion

                textIdBill.Text = DTHaed.Rows[i][0].ToString();

                if (DTHaed.Rows[i][1].ToString() == "نقدا")
                    radioButtCach.Checked = true;
                else radioButtLetar.Checked = true;

                dateTimePicker1.Value =
                Convert.ToDateTime(DTHaed.Rows[i][2].ToString());

                txtCust_id_fk.Text= 
                    DTHaed.Rows[i][3].ToString();
                txtCustName.Text =
                    DTHaed.Rows[i][4].ToString();
                textBox_id_fk.Text = 
                    DTHaed.Rows[i][5].ToString();
                textBox_name_fk.Text = 
                    DTHaed.Rows[i][6].ToString();
                textBox_id_fk.Tag =
                    DTHaed.Rows[i][7].ToString();
                UserIdAdd.Text= 
                    DTHaed.Rows[i][8].ToString();
                UserNameAdd.Text= 
                    DTHaed.Rows[i][9].ToString();
                /*
            .Total,10
            .Note,11
            .Bill_id_fk, 12
            .posting, 13*/
             
                txtTotal.Text = 
                    DTHaed.Rows[i][10].ToString();
                label7.Tag =
                  DTHaed.Rows[i][10].ToString();

                textNote.Text = 
                    DTHaed.Rows[i][11].ToString();
                txtBill_id_fk.Text=
                      DTHaed.Rows[i][12].ToString();
              
               

                try
                {
                    #region شرح عمل الداله
                    /*
                    اذا كان السند مرحل خلي الحاله حقه مرحل
                    والغي تفعيل زرار الترحيل والتعديل سواء معاه 
                    صلاحيات او لا 

                    */
                    /*
                    اذا السند لم يكن مرحل خلي الحاله حقه غير مرحل
                    وافتح له زرار الترحيل والتعديل حسب حقه الصلاحيات    
                    */
                    #endregion
                    IsPosting(Convert.ToBoolean(DTHaed.Rows[i][13].ToString()));
                }

                catch (Exception ee) { MessageBox.Show(ee.ToString()); }
              

               

                ShowBody(textIdBill.Text);
                FillTextBoxCountRows((indexHaed + 1).ToString());

            }
            else
            {
                MessageBox.Show("index is: " + indexRows, "DTcount is: " + DTHaed.Rows.Count);
            }


        }
        #endregion
        #region جلب تفاصيل الفاتورة المحددة
        void ShowBody(string textIdBill = "-1")
        {//Done


            if (DTBody != null)
                DTBody = null;
            DTBody = new DataTable();
            DTBody = billSalesSql.GetSalesBody(textIdBill);


            #region بستقبل البيانات التالية عند استدعاء الداله
            /*
                  SalesBillBody.Bill_body_id 0
                , ItemUnit.idItemUnit 1
                , Items.barc   2
                , Items.Item_name 3
                , Units.Unit_name 4
                , Quantity 5
                , Part 6
                , PriceQuantity  7
                , PricePart  8
                , TotaQuan  9
                , TotaPart  10
                , Total  11
                , Units.Unit_part  12   
      
            */
            #endregion



            DGVBody.Rows.Clear();


            if (DTBody != null && DTBody.Rows.Count > 0)
            {
                for (int i = 0; i < DTBody.Rows.Count; i++)
                {


                    DGVBody.Rows.Add
                    (
                    DTBody.Rows[i][0].ToString(), //idBody
                    DTBody.Rows[i][1].ToString(), //itemUnitid
                    i+1, //التسلسل
                    DTBody.Rows[i][2].ToString(), //رقم الصنف
                    DTBody.Rows[i][3].ToString(), //اسم الصنف
                    DTBody.Rows[i][4].ToString(), // الوحدة 
                    DTBody.Rows[i][5].ToString(), // الكمية وحدة
                    DTBody.Rows[i][6].ToString(), // الكمية جزء
                    DTBody.Rows[i][7].ToString(), //سعر الوحدة
                    DTBody.Rows[i][8].ToString(), //سعر الجزء 
                    DTBody.Rows[i][9].ToString(), //اجمالي الوحدة
                    DTBody.Rows[i][10].ToString(), //اجمالي الجزء 
                    DTBody.Rows[i][11].ToString(), //اجمالي 
                    DTBody.Rows[i][12].ToString(), // اجزاء الوحدة 
                    null, // المتبقي وحدة 
                    null // المتبقي جزء
                    );
                    //داله تجيب الحد الاعلى والادنى لكل عمله



                } //endForAddData



            }
            //  else MessageBox.Show("idEntry is null can't show body","رقم السند = "+ idEntry);


        }
        #endregion
        #region واجهة واحدة لعرض بيانات الصناديق او العملاء
        void ShowListBoxsUser(KeyEventArgs e, string BoxOrCoust)
        {
            if (e.KeyData == Keys.F9)
            {

                sbu = new SupportBoxUserList(
                    (UserId.Text == null) ? "-1" : UserId.Text,
                    (textBox_id_fk.Tag == null ? "-1" : textBox_id_fk.Tag.ToString()), BoxOrCoust
                    );
                sbu.ShowDialog();
                if (sbu.stateSelect == true)
                {
                    if (BoxOrCoust == "Box")
                    {
                        textBox_id_fk.Text = SupportBoxUserList.SupCatParmHaed.Box_id;
                        textBox_id_fk.Tag = SupportBoxUserList.SupCatParmHaed.BoxUser_id;
                        textBox_name_fk.Text = SupportBoxUserList.SupCatParmHaed.Box_name;


                        txtAccBox.Text =
                             AccSql.Acount(AccSql.GetAccCurrId4BoxId(textBox_id_fk.Text)); //دالة تجيب رصيد الحساب
                        txtAccBoxMax.Text =
                             AccSql.MaxAccount(AccSql.GetAccCurrId4BoxId(textBox_id_fk.Text)); //دالة تجيب  الحد الاعلى للدين
                    }
                    else
                    {
                        txtCust_id_fk.Text = SupportBoxUserList.SupCatParmHaed.Box_id;
                        txtCustName.Text = SupportBoxUserList.SupCatParmHaed.Box_name;
                        txtAccCust.Text = AccSql.Acount(SupportBoxUserList.SupCatParmHaed.Curr_id);
                        txtAccCustMax.Text = AccSql.MaxAccount(SupportBoxUserList.SupCatParmHaed.Curr_id);

                    }

                    SupportBoxUserList.SupCatParmHaed.Box_id = null;
                    SupportBoxUserList.SupCatParmHaed.BoxUser_id = null;
                    SupportBoxUserList.SupCatParmHaed.Box_name = null;
                    SupportBoxUserList.SupCatParmHaed.Acc_id_fk = null;
                    SupportBoxUserList.SupCatParmHaed.Acc_name = null;
                    SupportBoxUserList.SupCatParmHaed.Curr_name = null;
                    SupportBoxUserList.SupCatParmHaed.Curr_echange = null;
                    SupportBoxUserList.SupCatParmHaed.Curr_id = null;
                    sbu.stateSelect = false;
                    sbu = null;
                }


            }
        }
        #endregion

        Dictionary<string, string> QunAndPart(string SaleBillid, string UniteItem_id)
        {
            /*
            هذي الداله بستخدمه عند التعديل لما احدد ع الصنف يجيب لي كم المباع حقه
            */
            Dictionary<string, string> QuAndPar =new  Dictionary<string, string>();
            DataTable DTBody = new DataTable();
            DTBody = billSalesSql.GetItemsReturnBill(SaleBillid);
            #region البيانات الي استقبلها
            /*
                 idItemUnit_fk 0
              , Items.barc 1
              , Items.Item_name 2
              , Units.Unit_name 3
              , Quantity الكمية وحدة المتاحة 4
              , Part الكمية جزء المتاحة 5
             ,  Selling_price 6
             ,  Selling_part 7
             ,Unit_part 8
            */
            #endregion
            if (DTBody != null && DTBody.Rows.Count > 0)
            {
                for (int i = 0; i < DTBody.Rows.Count; i++)
                 if(UniteItem_id== DTBody.Rows[i][0].ToString())
                    {
                        QuAndPar.Add("Quantity", DTBody.Rows[i][4].ToString()); //
                        QuAndPar.Add("Part", DTBody.Rows[i][5].ToString()); //Part
                        break;

                    }
                
             }
            return QuAndPar;
        }
        #region تفحص رقم مرجع الفاتورة الي رجعت بموجبها
        void CheckSaleBill(string SaleBillid)
        {
            string CustId = billSalesSql.GetCustId4SalesRefrenc(SaleBillid);
            if (CustId != string.Empty)
            {
                MessageBox.Show("موجود");
              
                txtCust_id_fk.Text = CustId;
                txtCustName.Text = billSalesSql.GetNameCust(CustId);
                txtAccCust.Text = AccSql.Acount(AccSql.GetAccCurrId4CustomerId(CustId));
                txtAccCustMax.Text = AccSql.MaxAccount(AccSql.GetAccCurrId4CustomerId(CustId));
                DataTable DTBody = new DataTable();
              //  MessageBox.Show();
                DTBody = billSalesSql.GetItemsReturnBill(SaleBillid);
                #region البيانات الي استقبلها
                /*
                     idItemUnit_fk 0
                  , Items.barc 1
                  , Items.Item_name 2
                  , Units.Unit_name 3
                  , Quantity الكمية وحدة المتاحة 4
                  , Part الكمية جزء المتاحة 5
                 ,  Selling_price 6
                 ,  Selling_part 7
                 ,Unit_part 8
                */
                #endregion

                if (DTBody!=null&& DTBody.Rows.Count > 0)
                {
                    DGVBody.Rows.Clear();
                    for(int i=0;i< DTBody.Rows.Count; i++)
                    {
                        DGVBody.Rows.Add
                            (
                             null
                            , DTBody.Rows[i][0].ToString()
                            , (i + 1).ToString()
                            , DTBody.Rows[i][1].ToString()
                            , DTBody.Rows[i][2].ToString()
                            , DTBody.Rows[i][3].ToString()
                            , "0"
                            , "0"
                            , DTBody.Rows[i][6].ToString()
                            , DTBody.Rows[i][7].ToString()
                            , "0"
                            , "0"
                            , "0"
                            , DTBody.Rows[i][8].ToString()
                            , DTBody.Rows[i][4].ToString()
                            , DTBody.Rows[i][5].ToString()
                            );
                    }
                }

            }
            else { MessageBox.Show(" غير موجود"); txtBill_id_fk.Text = string.Empty; }
        }
        #endregion

        #endregion
        #region تفعيل والغاء تفعيل

        #region داله الصلاحيات
        void Permissions(string AddOrLoad)
        {
            if (ButtnPre.Count > 0)
            {
                #region البيانات المستلمه
                /*
            ButtnPreCheck.Add("Showed", Convert.ToBoolean(DTpr.Rows[0][2].ToString()));
            ButtnPreCheck.Add("Inserted", Convert.ToBoolean(DTpr.Rows[0][3].ToString()));
            ButtnPreCheck.Add("EditeDate", Convert.ToBoolean(DTpr.Rows[0][4].ToString()));
            ButtnPreCheck.Add("Posting", Convert.ToBoolean(DTpr.Rows[0][5].ToString()));
            ButtnPreCheck.Add("Saerch", Convert.ToBoolean(DTpr.Rows[0][6].ToString()));
            ButtnPreCheck.Add("Printed", Convert.ToBoolean(DTpr.Rows[0][7].ToString()));
            ButtnPreCheck.Add("Updated", Convert.ToBoolean(DTpr.Rows[0][8].ToString()));
            ButtnPreCheck.Add("Deleted", Convert.ToBoolean(DTpr.Rows[0][9].ToString()));
                */
                #endregion
                bool result;
                if (AddOrLoad == "Load")
                {
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Deleted", out result))
                        buttDelete.Enabled = result;
                    // MessageBox.Show(result.ToString());
                    else MessageBox.Show("لما نستقبل صلاحية الحذف");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Inserted", out result))
                        buttAdd.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية الاضافة");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Updated", out result))
                        buttEdite.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية التعديل");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Posting", out result))
                        buttPosting.Enabled = result;  //اذا قد تم ترحيل هذا السند يكون فولس برجع له
                    else MessageBox.Show("لما نستقبل صلاحية الترحيل");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Printed", out result))
                        buttPrint.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية الطباعة");
                }
                else if (AddOrLoad == "Add")
                {
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("EditeDate", out result))
                        dateTimePicker1.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية تعديل التاريخ");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Posting", out result))
                    {
                        //buttPosting.Enabled = result;  //اذا قد تم ترحيل هذا السند يكون فولس برجع له
                        checkBoxSavePosting.Checked = false;
                        checkBoxSavePosting.Enabled = result;
                    }

                    else MessageBox.Show("لما نستقبل صلاحية الترحيل");
                    Dictionary<string, string> info = userSql.GetInfoUser(UserId.Text);
                    if (info.Count > 0)
                    {
                        /*
                info.Add("SaleLater", dt.Rows[0][0].ToString());
                info.Add("Discount", dt.Rows[0][1].ToString());
                info.Add("Discount_percentage", dt.Rows[0][2].ToString());
                        */
                        string res;
                        if (info.TryGetValue("SaleLater", out res))
                        {
                            //MessageBox.Show(res);
                            radioButtLetar.Enabled = Convert.ToBoolean(res);
                        }
                        else MessageBox.Show("لم نستقبل صلاحية البيع الاجل", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        
                        if (info.TryGetValue("Discount_percentage", out res))
                        {
                            Discount_percentage.Text = res;
                            //MessageBox.Show(res);
                        }
                        else MessageBox.Show("لم نستقبل قيمة التخفيض", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    }
                    else MessageBox.Show("خطا في جلب بيانات العميل للتخفيض وللاجل");
                }
            }

        }
        #endregion
        #region تفريغ جميع الحقول
        void ClearAllTextBox()
        {

            textIdBill.Text = string.Empty; //تسلسل الفاتورة
            textBox_id_fk.Text = string.Empty; //رقم الصندوق 
            txtBill_id_fk.Text = string.Empty; //رقم المرجع
            try
            {
                textBox_id_fk.Tag = null; //رقم مستخدم الصندوق
            }
            catch(Exception e) { MessageBox.Show(e.ToString(), "Error textBox_id_fk.Tag=null"); }
            textBox_name_fk.Text = string.Empty; //اسم الصندوق 

            txtAccCust.Text = string.Empty; // رصيد العميل
            txtAccCustMax.Text = string.Empty; // حد الدين للعميل 
            txtAccBox.Text = string.Empty;  // رصيد الصندوق
            txtAccBoxMax.Text = string.Empty; // حد الدين للصندوق 
            txtCust_id_fk.Text = string.Empty; // رقم العميل 
            txtCustName.Text = string.Empty; // اسم العميل 
            radioButtCach.Checked = false; // نقدا
            radioButtLetar.Checked = false; // اجل
            textNote.Text = string.Empty;
            
            txtTotal.Text = "0";

            textDebtWord.Text = string.Empty;
            dateTimePicker1.Enabled = false;
            DGVBody.Rows.Clear();

        }
        #endregion

        #endregion
        #region تحقق


        void IsPosting(bool state)
        {
            if (state)
            {
                StatPosting.Text = "مرحل";
                stingPosting = true;
            }
            else
            {
                StatPosting.Text = "غير مرحل";
                stingPosting = false;
            }
        }

        #endregion
        #region عمليات
        #region لتحريك الواجهة
        void MoveForm(MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion
        #region عدد الفواتير وفي السجل رقم كم الان
        void FillTextBoxCountRows(string index)
        {
            if (DTHaed != null  && DTHaed.Rows.Count > 0 && Convert.ToDouble(index) >= 0)
            {
                CountRows.Text = index + " - " +
                   DTHaed.Rows.Count.ToString();
            }
               
            else
                CountRows.Text = "0 - 0";
        }
        #endregion
        #region التالي السابق الاخير الاول
        int indexHaedButt(string btName, ref int index)
        {
            /*
            
            
            */
            if (DTHaed.Rows.Count > 0)
            {



                if (btName == "Frist")
                {

                    //  index = 0;
                    return index = 0;

                }
                else if (btName == "Next")
                {
                    if (index < DTHaed.Rows.Count - 1)
                        return ++index;
                    else { MessageBox.Show("اخر سجل"); return index; }

                }
                else if (btName == "Back")
                {
                    if (index > 0)
                        return --index;
                    else { MessageBox.Show("اول سجل"); return index; }
                }
                else if (btName == "Last")
                {
                    return index = DTHaed.Rows.Count - 1;

                }

            }
            else
                MessageBox.Show("لا يوجد سندات في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return index = -1;

        }
        #endregion
        #region تهئية الازرار و الحقول لتكون قابلة للكتابة حسب العملية اضافة او عرض او تعديل
        

        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {
            //Doneeeeee
            /////////عند التعديل وجديد//////////////
            #region هولا واصل حالتهم للقراءة فقط

            textIdBill.ReadOnly = true;

            textBox_id_fk.ReadOnly = true;
            textBox_name_fk.ReadOnly = true;
            txtAccBox.ReadOnly = true;
            txtAccBoxMax.ReadOnly = true;

            txtCust_id_fk.ReadOnly = true;
            txtCustName.ReadOnly = true;
            txtAccCust.ReadOnly = true;
            txtAccCustMax.ReadOnly = true;

        
            txtTotal.ReadOnly = true; //ارجع رجعهم ترو
            textDebtWord.ReadOnly = true;
            #endregion

            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات

                txtBill_id_fk.ReadOnly = false;
                textNote.ReadOnly = false;
                #region ارصدة العميل والصندوق
                txtAccCust.Enabled = true;
                txtAccCustMax.Enabled= true;
                txtAccBox.Enabled = true;
                txtAccBoxMax.Enabled = true;
                label12.Enabled = true;
                label18.Enabled = true;
                label3.Enabled = true;
                label2.Enabled = true;
                #endregion
                Permissions("Add"); //استدعاء الصلاحيات
                DGVBody.Columns[13].Visible = true;
                DGVBody.Columns[14].Visible = true;
                DGVBody.Columns[15].Visible = true;
                // dateTimePicker1.Enabled = true;
                /////////////////////

                radioButtCach.Enabled = true;
                radioButtCach.Checked = true;
                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
               // buttSerch.Enabled = false;
                buttPosting.Enabled = false;
                buttPrint.Enabled = false;

                ////////////////////////////////////////////
                //for (int i = 0; i < 2; i++)
                //{
                DGVBody.AllowUserToAddRows = true;
                DGVBody.AllowUserToDeleteRows = true;
                DGVBody.MultiSelect = false;
                // DGVBody.SelectionMode = DataGridViewSelectionMode.CellSelect;
                DGVBody.ReadOnly = false;


                //}



                if (flagEditeOrAddOrSave == "Edite")
                {

                    

                }


            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                txtBill_id_fk.ReadOnly = true;
                textNote.ReadOnly = true;
                radioButtCach.Enabled = false;
                radioButtLetar.Enabled = false;
                ////////////////////////////////////////////////
                checkBoxSavePosting.Checked = false;
                checkBoxSavePosting.Enabled = false;
                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                //DGVBody.Columns[0].Visible = true;

                #region ارصدة العميل والصندوق
                txtAccCust.Enabled = false;
                txtAccCustMax.Enabled = false;
                txtAccBox.Enabled = false;
                txtAccBoxMax.Enabled = false;
                txtAccCust.Text = string.Empty;
                txtAccCustMax.Text = string.Empty;
                txtAccBox.Text = string.Empty;
                txtAccBoxMax.Text = string.Empty;
                label12.Enabled = false;
                label18.Enabled = false;
                label3.Enabled = false;
                label2.Enabled = false;
               
                #endregion
                DGVBody.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                DGVBody.AllowUserToAddRows = false;
                DGVBody.AllowUserToDeleteRows = false;
               
                dateTimePicker1.Enabled = false;
                Permissions("Load"); //استدعاء الصلاحيات
                                     ///////////////////
                DGVBody.Columns[13].Visible = false;
                DGVBody.Columns[14].Visible = false;
                DGVBody.Columns[15].Visible = false;
                //فعل البوتونات

                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
                //buttSerch.Enabled = true;
                //buttPosting.Enabled = true; //اذا قد تم ترحيل هذا السند يكون فولس برجع له

                /////////////////////////




            }


        }
        #endregion
        #region التهئية لعملية الاضافة
        void ForamtingAdd()
        {
            ClearAllTextBox();
            textIdBill.Text = billSalesSql.GetMaxIdBillHaed("Return_bill_id", "ReturnSalesBillHead");
            dateTimePicker1.Value = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd"));
            dateTimePicker1.CustomFormat = "yyyy/MM/dd";
            DGVBody.Rows.Clear(); //التفاصيل


        }
        #endregion
        #region تخزين البيانات قبل وبعد التعديل
        void SetDataBodyAfterEdite()
        {
            try
            {
                BillParmAfterUpdate.Clear();


                if ((DGVBody.Rows.Count) > 0)
                {

                    for (int i = 0; i < DGVBody.Rows.Count; i++)
                    {
                        #region

                        if (
                        #region

                        DGVBody.Rows[i].Cells[1].Value != null && //idUnitItem  
                        DGVBody.Rows[i].Cells[6].Value != null && // QuUi 
                        DGVBody.Rows[i].Cells[7].Value != null && //QuPart 
                        DGVBody.Rows[i].Cells[8].Value != null && //PricQu
                        DGVBody.Rows[i].Cells[9].Value != null && //PricPart
                        textIdBill.Text != string.Empty //رقم السند
                        #endregion
                        )
                        {
                            if (BillParm != null)
                                BillParm = null;
                            BillParm = new BillParametr();

                            #region




                            BillParm.idItemUnit =
                                    DGVBody.Rows[i].Cells[1].Value.ToString(); // 

                            BillParm.Quantity =
                                    DGVBody.Rows[i].Cells[6].Value.ToString(); // 

                            BillParm.Part =
                                    DGVBody.Rows[i].Cells[7].Value.ToString();// 

                            BillParm.Selling_price =
                                    DGVBody.Rows[i].Cells[8].Value.ToString(); // 

                            BillParm.price_part =
                                    DGVBody.Rows[i].Cells[9].Value.ToString(); //

                            BillParm.Total =
                                 DGVBody.Rows[i].Cells[12].Value.ToString(); //


                            BillParmAfterUpdate.Add(BillParm);
                            #endregion




                        }
                        #endregion

                    }
                    MessageBox.Show(BillParmAfterUpdate.Count.ToString(), "عدد العناصر بعد");

                }
                else MessageBox.Show("لا يوجد عناصر في التافصيل");
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "Error in Func SetDataEntriBodyABeforEdite()");
            }


        }
        void SetDataBodyBeforEdite()
        {
            try
            {
                BillParmBeforUpdate.Clear();

                if ((DGVBody.Rows.Count) > 0)
                {

                    for (int i = 0; i < DGVBody.Rows.Count; i++)
                    {
                        #region

                        if (
                        #region

                        DGVBody.Rows[i].Cells[0].Value != null && //idBody
                        DGVBody.Rows[i].Cells[1].Value != null && //idUnitItem  
                        DGVBody.Rows[i].Cells[6].Value != null && // QuUi 
                        DGVBody.Rows[i].Cells[7].Value != null && //QuPart 
                        DGVBody.Rows[i].Cells[8].Value != null && //PricQu
                        DGVBody.Rows[i].Cells[9].Value != null && //PricPart
                        textIdBill.Text != string.Empty //رقم السند
                        #endregion
                        )
                        {
                            if (BillParm != null)
                                BillParm = null;
                            BillParm = new BillParametr();

                            #region  

                            BillParm.Bill_body_id =
                                    DGVBody.Rows[i].Cells[0].Value.ToString();//

                            BillParm.idItemUnit =
                                    DGVBody.Rows[i].Cells[1].Value.ToString(); // 

                            BillParm.Quantity =
                                    DGVBody.Rows[i].Cells[6].Value.ToString(); // 
                                                                             
                            BillParm.Part =
                                    DGVBody.Rows[i].Cells[7].Value.ToString();// 

                            BillParm.Selling_price =
                                    DGVBody.Rows[i].Cells[8].Value.ToString(); // 
                            
                            BillParm.price_part =
                                    DGVBody.Rows[i].Cells[9].Value.ToString(); //

                            BillParm.Total=
                                 DGVBody.Rows[i].Cells[12].Value.ToString(); //

                            BillParmBeforUpdate.Add(BillParm);
                            #endregion




                        }
                        #endregion

                    }

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.ToString(), "Error in Func SetDataEntriBodyABeforEdite()");
            }
        }
        #endregion
        void StopAlphaInColumn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (OpenOrClose == "CloseAlpha")
            {     //IsPunctuation الفواصل العشرية
                if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsPunctuation(e.KeyChar))
                {
                    e.Handled = true;
                }

            }
            else if (OpenOrClose == "OpenAll") e.Handled = false;

            else if (OpenOrClose == "CloseAll")
            {
                e.Handled = true;

            }
            else if(OpenOrClose == "OpenNumber")
            {
                if (!char.IsDigit(e.KeyChar)&& !char.IsControl(e.KeyChar))
                {
                    e.Handled = true;
                }

            }
            // OpenOrClose = string.Empty;
        }
        void StopAlphaFromDataGridView_EditingControlShowing(DataGridViewEditingControlShowingEventArgs e, int IndexColums)
        { //Doneeeeee
            try
            {
                int CurrentCellColumIndex = -1;
                //used in even dataGridView_EditingControlShowing
                e.Control.KeyPress -= new KeyPressEventHandler(StopAlphaInColumn_KeyPress);

                CurrentCellColumIndex = DGVBody.CurrentCell.ColumnIndex;



                if (CurrentCellColumIndex == IndexColums)
                {
                    TextBox tb = e.Control as TextBox;
                    if (tb != null)
                    {
                        tb.KeyPress += new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
                        //  tb.KeyPress+=new KeyPressEventHandler(StopAlphaInTextBox);
                    }
                }
            }
            catch { MessageBox.Show("StopAlphaFromDataGridView_EditingControlShowing Function", "Error"); }



        }

        void ShowListItems(object sender, KeyEventArgs e)
        {

            if (e.KeyData == Keys.F9 || e.KeyData == Keys.Delete)
            {
                if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                {
                   



                    if (e.KeyData == Keys.Delete && OpenOrClose == "CloseAll")
                    {
                        e.Handled = true;
                    }
                    else
                    {

                       // int i = DGVBody.CurrentCell.RowIndex;
                        int j = DGVBody.CurrentCell.ColumnIndex;
                        if (   textBox_id_fk.Tag != null
                            && txtCust_id_fk.Text != string.Empty
                            && txtBill_id_fk.Text!=string.Empty)
                        {
                            if (j == 3)
                            {
                                #region
                                List<string> ItemFound = new List<string>();
                                if (DGVBody.Rows.Count > 0)
                                {
                                    for (int i = 0; i < DGVBody.Rows.Count; i++)
                                        if (DGVBody.Rows[i].Cells[1].Value != null)
                                            ItemFound.Add(DGVBody.Rows[i].Cells[1].Value.ToString());
                                }
                                iteamListBill = new IteamListBill(ItemFound);
                                iteamListBill.ShowDialog();
                                if (IteamListBill.ItemSelection.Count > 0)
                                {

                                    //  MessageBox.Show(IteamListBill.ItemSelection.Count.ToString());
                                    for (int i = 0; i < IteamListBill.ItemSelection.Count; i++)
                                    {
                                        DGVBody.Rows.Add
                                            (
                                            null,
                                            IteamListBill.ItemSelection[i].idItemUnit,
                                            DGVBody.Rows.Count,
                                            IteamListBill.ItemSelection[i].barc,
                                            IteamListBill.ItemSelection[i].Item_name,
                                            IteamListBill.ItemSelection[i].Unit_name,
                                            IteamListBill.ItemSelection[i].Quantity,
                                            IteamListBill.ItemSelection[i].Part,
                                            IteamListBill.ItemSelection[i].Selling_price,
                                            IteamListBill.ItemSelection[i].price_part,
                                            "0",
                                            "0",
                                            "0",
                                            IteamListBill.ItemSelection[i].Unit_part

                                            );
                                    }
                                    IteamListBill.ItemSelection.Clear();

                                    //MessageBox.Show("u seclct[i" + i + "]= " + IteamListBill.ItemSelection[i].Item_name);
                                }
                                else MessageBox.Show("لم يتم اختيار اي صنف");
                                #endregion

                            }
                        }
                        else
                        {
                            MessageBox.Show("يرجى تعبئة رأس السند اولا", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            if (txtCust_id_fk.Text == string.Empty)
                                txtCust_id_fk.Focus();
                            else if (textBox_id_fk.Tag == null)
                                textBox_id_fk.Focus();
                            else if (txtBill_id_fk.Text == string.Empty)
                                txtBill_id_fk.Focus();
                        } 
                    }
                }
            }
        }
        void afterCellEndEditDataGridView()
        { //Doneeeee

            if (DGVBody.Rows.Count > 0)
            {
                if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                {



                    int i = DGVBody.CurrentCell.RowIndex;
                    int j = DGVBody.CurrentCell.ColumnIndex;

                    if (j == 6) // الكمية وحدة 
                    {
                        #region
                        if (DGVBody.Rows[i].Cells[1].Value == null // idUniteItem برجع لذا الصف
                            && DGVBody.Rows[i].Cells[6].Value != null // الكمية وحدة
                            && DGVBody.Rows[i].Cells[7].Value != null // الكمية جزء
                            && DGVBody.Rows[i].Cells[8].Value != null // سعر الوحدة
                            && DGVBody.Rows[i].Cells[9].Value != null  // سعر الجزء
                            && DGVBody.Rows[i].Cells[12].Value != null  // الاجمالي الكلي
                            ) //رقم الحساب
                        {
                            DGVBody.Rows[i].Cells[6].Value = ExchingOld; //نحفظ قيمة الكمية وحدة قبل التعديل

                        }

                        //يروح يتحقق من الكمية وحدة حسب  المتبقي معي   
                        if (DGVBody.Rows[i].Cells[6].Value != null //الكمية وحدة 
                            && DGVBody.Rows[i].Cells[1].Value != null) //idUniteItem
                        {
                            #region
                            try
                            {
                                #region
                                if (DGVBody.Rows[i].Cells[14].Value != null //المتبقي وحدة
                                  )
                                {
                                    #region

                                    if (Convert.ToDouble(DGVBody.Rows[i].Cells[14].Value.ToString()) < Convert.ToDouble(DGVBody.Rows[i].Cells[6].Value.ToString()))
                                    {
                                        MessageBox.Show(" \n    الكمية وحدة المدخلة اكبر من المتوفرة   \n  " + "الكمية المتوفرة هي  = " + DGVBody.Rows[i].Cells[14].Value.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                        DGVBody.Rows[i].Cells[6].Value = ExchingOld;
                                    }
                                    

                                    #endregion
                                }

                                else
                                {
                                    #region

                                    if (Convert.ToDouble(DGVBody.Rows[i].Cells[6].Value.ToString()) <= 0)
                                    {
                                        MessageBox.Show("الكمية وحدة لا يمكن ان تكون صفر او اقل منها");
                                        //DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                    }
                                    DGVBody.Rows[i].Cells[6].Value = ExchingOld;
                                    #endregion
                                }
                                ExchingOld = DGVBody.Rows[i].Cells[6].Value.ToString();
                                #endregion
                            }
                            catch
                            {
                                MessageBox.Show(" خطأ في صيغة ادخال الكمية وحدة", "^^", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                                DGVBody.Rows[i].Cells[6].Value = ExchingOld;//الكمية وحدة 

                            }
                            try
                            {
                                DGVBody.Rows[i].Cells[10].Value = //اجمالي وحدة 
                                    ((Convert.ToDouble(DGVBody.Rows[i].Cells[6].Value) * // الكمية  وحدة
                                        Convert.ToDouble(DGVBody.Rows[i].Cells[8].Value)).ToString()); //سعر الوحدة
                                DGVBody.Rows[i].Cells[12].Value =
                                         ((Convert.ToDouble(DGVBody.Rows[i].Cells[10].Value) + // اجمالي  وحدة
                                           Convert.ToDouble(DGVBody.Rows[i].Cells[11].Value)).ToString()); // اجمالي الجزء


                            }
                            catch
                            {
                                MessageBox.Show("صيغة ادخال الكميات  خاطئة", "", MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                            
                                DGVBody.Rows[i].Cells[6].Value = "0"; //الكمية وحدة 


                            }
                            #endregion

                        }
                        else
                        {
                           
                            DGVBody.CurrentRow.Cells[6].ReadOnly = true;
                        }

                        #endregion
                    }
                    if (j == 7) // الكمية جزء
                    {
                        #region

                        if (DGVBody.Rows[i].Cells[13].Value != null //اجزاء الوحدة 

                            )
                        {
                            #region تحت التعليق
                            //if (DGVBody.Rows[i].Cells[7].Value == null)
                            //{
                            //    MessageBox.Show("الحقل قيمة فارغة", "الكمية جزء ", MessageBoxButtons.OK,
                            //           MessageBoxIcon.Error);
                            //    DGVBody.Rows[i].Cells[7].Value = "0";
                            //}

                            //if (DGVBody.Rows[i].Cells[13].Value.ToString() == "1")//اذا كانت    اجزاء الوحدة تساوي الواحد
                            //    DGVBody.Rows[i].Cells[7].Value = "0";
                            #endregion
                            #region
                            if (DGVBody.Rows[i].Cells[1].Value == null // idUniteItem برجع لذا الصف
                                && DGVBody.Rows[i].Cells[6].Value != null // الكمية وحدة
                                && DGVBody.Rows[i].Cells[7].Value != null // الكمية جزء
                                && DGVBody.Rows[i].Cells[8].Value != null // سعر الوحدة
                                && DGVBody.Rows[i].Cells[9].Value != null  // سعر الجزء
                                && DGVBody.Rows[i].Cells[12].Value != null  // الاجمالي الكلي
                                ) //رقم الحساب
                            {
                                DGVBody.Rows[i].Cells[7].Value = ExchingOld; //نحفظ قيمة الكمية جزء قبل التعديل

                            }

                            //يروح يتحقق من الكمية وحدة حسب  المتبقي معي   
                            if (DGVBody.Rows[i].Cells[7].Value != null //الكمية وحدة 
                                && DGVBody.Rows[i].Cells[1].Value != null) //idUniteItem
                            {
                                #region
                                try
                                {
                                    #region
                                    if (DGVBody.Rows[i].Cells[15].Value != null //المتبقي وحدة
                                      )
                                    {
                                        #region

                                        if (Convert.ToDouble(DGVBody.Rows[i].Cells[15].Value.ToString()) < Convert.ToDouble(DGVBody.Rows[i].Cells[7].Value.ToString()))
                                        {
                                            MessageBox.Show(" \n    الكمية وحدة المدخلة اكبر من المتوفرة   \n  " + "الكمية المتوفرة هي  = " + DGVBody.Rows[i].Cells[15].Value.ToString(), "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                            DGVBody.Rows[i].Cells[7].Value = ExchingOld;
                                        }
                                        else if (
                                      Convert.ToInt32(DGVBody.Rows[i].Cells[7].Value) >
                                      Convert.ToInt32(DGVBody.Rows[i].Cells[13].Value))
                                        {
                                            int De = 0;
                                            int Va = Convert.ToInt32(DGVBody.Rows[i].Cells[7].Value);

                                            while (Va >
                                            Convert.ToInt32(DGVBody.Rows[i].Cells[13].Value))
                                            {
                                                Va -= Convert.ToInt32(DGVBody.Rows[i].Cells[13].Value);
                                                De++;
                                            }
                                            DGVBody.Rows[i].Cells[6].Value =
                                                Convert.ToInt32(DGVBody.Rows[i].Cells[6].Value)
                                                + De;
                                            DGVBody.Rows[i].Cells[7].Value = Va;
                                          //  MessageBox.Show(Va.ToString() + "  الاجزاء ", De.ToString() + " الوحدات ");

                                        }


                                        #endregion
                                    }

                                    else
                                    {
                                        #region

                                        if (Convert.ToDouble(DGVBody.Rows[i].Cells[7].Value.ToString()) < 0)
                                        {
                                            MessageBox.Show("الكمية وحدة لا يمكن ان تكون  اقل من الصفر ");
                                            //DGViewEntryBody.Rows[i].Cells[4].Value = ExchingOld;
                                        }
                                        DGVBody.Rows[i].Cells[7].Value = ExchingOld;
                                        #endregion
                                    }
                                    ExchingOld = DGVBody.Rows[i].Cells[7].Value.ToString();
                                    #endregion
                                }
                                catch
                                {
                                    MessageBox.Show(" خطأ في صيغة ادخال الكمية وحدة", "^^", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);
                                    DGVBody.Rows[i].Cells[7].Value = ExchingOld;//الكمية وحدة 

                                }
                                try
                                {
                                   

                                    DGVBody.Rows[i].Cells[11].Value = //اجمالي وحدة 
                                        ((Convert.ToDouble(DGVBody.Rows[i].Cells[7].Value) * // الكمية  وحدة
                                            Convert.ToDouble(DGVBody.Rows[i].Cells[9].Value)).ToString()); //سعر الوحدة
                                    DGVBody.Rows[i].Cells[12].Value=
                                          ((Convert.ToDouble(DGVBody.Rows[i].Cells[10].Value) + // اجمالي  وحدة
                                            Convert.ToDouble(DGVBody.Rows[i].Cells[11].Value)).ToString()); // اجمالي الجزء
                                   

                                }
                                catch
                                {
                                    MessageBox.Show("صيغة ادخال الكميات  خاطئة", "", MessageBoxButtons.OK,
                                        MessageBoxIcon.Error);

                                    DGVBody.Rows[i].Cells[6].Value = "0"; //الكمية وحدة 


                                }
                                #endregion

                            }
                            else
                            {

                                DGVBody.CurrentRow.Cells[6].ReadOnly = true;
                            }

                            #endregion


                        }



                        #endregion
                    }

                  



                }

            }


        }
        void cellClickDataGridView()
        { //عند الضغط على الخليه يستقبل فلاج نوع العمليه عشان يتحكم في الكتابة عليها
            try
            { //Doneeeeeeeee
                #region


                //   MessageBox.Show(DGVBodyIndex.ToString(),"DGVInde");
                if (DGVBody.Rows.Count > 0)
                {
                   
                    int i = DGVBody.CurrentCell.RowIndex;
                    int j = DGVBody.CurrentCell.ColumnIndex;

                    if ((flagAddOrEdit == "Add" || flagAddOrEdit == "Edite"))
                    {

                        //DGViewEntryBody.AllowUserToAddRows = true;
                        //DGViewEntryBody.AllowUserToDeleteRows = true;
                        #region


                        DGVBody.Rows[i].Cells[3].ReadOnly = false;
                        if
                        (
                        DGVBody.Rows[i].Cells[1].Value != null && //   idUniteItem
                        DGVBody.Rows[i].Cells[3].Value != null && //  رقم الصنف
                        DGVBody.Rows[i].Cells[4].Value != null &&    // اسم الصنف
                        DGVBody.Rows[i].Cells[8].Value != null &&    //  سعر الوحدة 
                        DGVBody.Rows[i].Cells[9].Value != null //   سعر الجزء
                        )
                        {
                            #region اذا كان رقم واسم الحساب والعملة وسعر الصرف وحساب

                            DGVBody.Rows[i].Cells[0].ReadOnly = true; //التسلسل
                            DGVBody.Rows[i].Cells[3].ReadOnly = false;//رقم الصنف
                            DGVBody.Rows[i].Cells[4].ReadOnly = true; // اسم الصنف
                            DGVBody.Rows[i].Cells[5].ReadOnly = true;// الوحدة
                            DGVBody.Rows[i].Cells[6].ReadOnly = false; // الكمية وحدة
                            DGVBody.Rows[i].Cells[7].ReadOnly = false; // الكمية جزء
                            DGVBody.Rows[i].Cells[8].ReadOnly = true; // سعر الوحدة  
                            DGVBody.Rows[i].Cells[9].ReadOnly = true; // سعر الجزء 
                            DGVBody.Rows[i].Cells[10].ReadOnly = true; // اجمالي وحدة
                            DGVBody.Rows[i].Cells[11].ReadOnly = true; // اجمالي جزء
                            DGVBody.Rows[i].Cells[12].ReadOnly = true; // اجمالي كلي
                            DGVBody.Rows[i].Cells[13].ReadOnly = true; // اجزاء الوحدة
                            DGVBody.Rows[i].Cells[14].ReadOnly = true; // المتبقي الوحدة
                            DGVBody.Rows[i].Cells[15].ReadOnly = true; // المتبقي جزء

                            string idUnitItem = (DGVBody.Rows[i].Cells[1]).Value.ToString();


                            if (idUnitItem != string.Empty)
                            {
                                #region تحديد اذا كانت للوحدة اجزاء ام لا

                                if ((DGVBody.Rows[i].Cells[13]).Value.ToString() == "1")
                                {
                                    DGVBody.Rows[i].Cells[7].ReadOnly = true;  //وقف الكمية جزء
                                    DGVBody.Rows[i].Cells[6].ReadOnly = false; // الكمية وحدة
                                   
                                }
                                else 
                                {
                                    DGVBody.Rows[i].Cells[7].ReadOnly = false;  // الكمية جزء
                                    DGVBody.Rows[i].Cells[6].ReadOnly = false; // الكمية وحدة
                                }
                                #region يخزن سعر الصرف قبل التعديل


                                #endregion

                                #endregion
                                #region يجيب الرصيد المباع من هذا الصنف 

                                  
                               Dictionary<string, string> QunAndPartNow = new Dictionary<string, string>();
                                QunAndPartNow = QunAndPart(txtBill_id_fk.Text == string.Empty ? "-1" : txtBill_id_fk.Text, idUnitItem);
                                //billSalesSql.GetQuantetyUiteAndPart4UiteItemIdNow(idUnitItem);
                                string result;
                                if (QunAndPartNow.TryGetValue("Quantity", out result))
                                    DGVBody.Rows[i].Cells[14].Value = result;
                                else MessageBox.Show("لا يوجد كميات لهذا الصنف", "1", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                ///////////////////////////////////////////////////////////////
                                if (QunAndPartNow.TryGetValue("Part", out result))
                                    DGVBody.Rows[i].Cells[15].Value = result;
                                else MessageBox.Show("لا يوجد كميات لهذا الصنف", "2", MessageBoxButtons.OK, MessageBoxIcon.Warning);


                                #endregion

                            }
                            else
                            {
                                MessageBox.Show("UnitItemId is null", " in function cellClickDataGridView() ");
                            }
                            #endregion

                        }
                        else if (DGVBody.Rows[i].Cells[3].Value == null && DGVBody.Rows.Count == 1)
                        {

                            DGVBody.Rows[0].Cells[3].ReadOnly = false;
                           
                        }
                        #endregion

                        
                    }
                    else if (flagAddOrEdit == "Load" || flagAddOrEdit == "Save")
                    {
                        

                        #region ايقاف جميع خلايا الداتا جريت
                        if(DGVBody.RowCount>0)
                        for(int x=0;x< DGVBody.ColumnCount;x++)
                        DGVBody.Rows[i].Cells[x].ReadOnly = true; 
                       

                        #endregion
                    }
                } 

                #endregion
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString(), "Error in function cellClickDataGridView() "); }
        }
        void EditingControlShowingDataGridView(object sender, DataGridViewEditingControlShowingEventArgs e)
        { //Doneeeeeeee
          //جعل خصائص الخلايا مثل التكست بوكس


            if (DGVBody.CurrentCell.ColumnIndex == 3 && e.Control is DataGridViewTextBoxEditingControl)
            {
                OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 3); //ايقاف الكتابة كاملة
                                                                                                 //DataGridViewTextBoxEditingControl tb = e.Control as DataGridViewTextBoxEditingControl;
                //////DataGridViewTextBoxEditingControl tb = e.Control as DataGridViewTextBoxEditingControl;
                

                //////tb.KeyDown -= ShowListItems;

                //////tb.KeyDown += ShowListItems; //عرض شاشة الحسابات


            }

            /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 4)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 4); }
            /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 5)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 5); }

            /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 6)
            { OpenOrClose = "OpenNumber"; StopAlphaFromDataGridView_EditingControlShowing(e, 6); } //ايقاف الاحرف فقط
                                                                                                   /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 7)
            { OpenOrClose = "OpenNumber"; StopAlphaFromDataGridView_EditingControlShowing(e, 7); }
            /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 8)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 8); }
            /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 9)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 9); }
            /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 10)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 10); }
            /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 11)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 11); }
            /////////////////////////////////////
            else if (DGVBody.CurrentCell.ColumnIndex == 12)
            { OpenOrClose = "CloseAll"; StopAlphaFromDataGridView_EditingControlShowing(e, 12); }
            /////////////////////////////////////



        }

        #region داله تحويل اللغه
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }


        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }
        #endregion

        void TotaleBill()
        {

            decimal Tot = 0;
            if (DGVBody.RowCount > 0)
            {
                for(int i=0;i<DGVBody.RowCount; i++)
                {
                    if(   DGVBody.Rows[i].Cells[1].Value != null // idUniteItem برجع لذا الصف
                                && DGVBody.Rows[i].Cells[6].Value != null // الكمية وحدة
                                && DGVBody.Rows[i].Cells[7].Value != null // الكمية جزء
                                && DGVBody.Rows[i].Cells[8].Value != null // سعر الوحدة
                                && DGVBody.Rows[i].Cells[9].Value != null  // سعر الجزء
                                && DGVBody.Rows[i].Cells[12].Value != null
                        // الاجمالي الكلي)
                        )
                    {
                        try {
                            Tot += Convert.ToInt32(DGVBody.Rows[i].Cells[12].Value);
                        }catch(Exception e) { MessageBox.Show(e.ToString()); Tot = 0; }
                    }
                }
               
                txtTotal.Text = Tot.ToString();
            }
        }

        #endregion
        #region اضافة حذف وتعديل
        void InsertNewBill()
        {
            if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {

                List<string> TotaleAndExching = ShowCulc();
                if (TotaleAndExching.Count == 2)
              { 
                dateTimePicker1.Format = DateTimePickerFormat.Short;
                string idBillHaed
                         = billSalesSql.InsertNewSalesHaed
                         (
                         (radioButtCach.Checked == true ? "1" : "2"),
                         dateTimePicker1.Value.ToShortDateString(),
                         txtCust_id_fk.Text,
                         (textBox_id_fk.Tag).ToString(),
                        TotaleAndExching[0],
                        txtBill_id_fk.Text==string.Empty?"NULL": txtBill_id_fk.Text,
                         textNote.Text,
                         TotaleAndExching[1]

                          ); //اعمل اضافة للراس واحفظ الاي دي حقه


                for (int i = 0; i < DGVBody.Rows.Count; i++)
                {
                    if (
                           DGVBody.Rows[i].Cells[1].Value != null //UniteItemId
                        && DGVBody.Rows[i].Cells[3].Value != null
                        && DGVBody.Rows[i].Cells[6].Value != null
                        && DGVBody.Rows[i].Cells[7].Value != null
                        && DGVBody.Rows[i].Cells[8].Value != null
                        && DGVBody.Rows[i].Cells[9].Value != null
                        && DGVBody.Rows[i].Cells[12].Value != null
                        )
                    {
                        /*

                        */





                        billSalesSql.InsertNewSalesBody(
                            idBillHaed,
                            DGVBody.Rows[i].Cells[1].Value.ToString(),//UniteItemId
                            DGVBody.Rows[i].Cells[6].Value.ToString(), //Qu
                            DGVBody.Rows[i].Cells[7].Value.ToString(), //Part
                            DGVBody.Rows[i].Cells[8].Value.ToString(), //PriceQu
                            DGVBody.Rows[i].Cells[9].Value.ToString(), //PricePart
                            DGVBody.Rows[i].Cells[12].Value.ToString() //Totale
                            );



                    }
                }

                MessageBox.Show("تمت الاضافة بنجاح");
                if (
                          checkBoxSavePosting.Checked == true
                          &&
                          checkBoxSavePosting.Enabled == true
                          )
                {
                     posting(idBillHaed);
                    MessageBox.Show("انسخ داله الترحيل عند الاضافة");

                }
               

               
                FormatingTextBoxAndButt("Save");
                flagAddOrEdit = "";
                fillData("All");
                
            }
                
            }
            else
            {
                FormatingTextBoxAndButt("Save");
                flagAddOrEdit = "";
                fillData("All");
            }

        }
        void UpdateBill()
        {
            if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                List<string> TotaleAndExching = ShowCulc();
                if (TotaleAndExching.Count == 2)  //اذا شاشة الحاسبة رجعت المبلغ المقبوض وسعر الصرف ادخل مالم اتعامس لك
                { 
              
                #region اذا عدد العناصر قبل التعديل يساوي عدد العناصر بعد التعديل
                if ((BillParmAfterUpdate.Count >= BillParmBeforUpdate.Count))
                {
                    

                    #endregion


                    //يضيف صفوف جديدة في الجدول
                    #region
                    int index = 0;

                    for (int i = 0; i < BillParmAfterUpdate.Count; i++)
                    {
                       

                        if (BillParmBeforUpdate.Count > index)
                        {
                            billSalesSql.UpdateSalesBody(
                      textIdBill.Text,
                      BillParmBeforUpdate[i].Bill_body_id,
                      BillParmAfterUpdate[index].idItemUnit,
                      BillParmAfterUpdate[index].Quantity,
                      BillParmAfterUpdate[index].Part,
                      BillParmAfterUpdate[index].Selling_price,
                      BillParmAfterUpdate[index].price_part,
                       BillParmAfterUpdate[index].Total
                      );
                           
                            index++;

                        }
                        else if (BillParmAfterUpdate.Count > index)
                        {

                            billSalesSql.InsertNewSalesBody(
                      textIdBill.Text,
                      BillParmAfterUpdate[index].idItemUnit,
                      BillParmAfterUpdate[index].Quantity,
                      BillParmAfterUpdate[index].Part,
                      BillParmAfterUpdate[index].Selling_price,
                      BillParmAfterUpdate[index].price_part,
                      BillParmAfterUpdate[index].Total);
                           
                            index++;
                        }


                     

                    }

                    //
                    #endregion
                }


                else if ((BillParmAfterUpdate.Count < BillParmBeforUpdate.Count))
                {
                    // MessageBox.Show("قبل التعديل اكبر");
                    #region
                    //يحذف جميع الصفوف من الجدول ويرجع يمليهم من جديد
                    int index = 0;

                    for (int i = 0; i < BillParmBeforUpdate.Count; i++)
                    {
                        if (BillParmAfterUpdate.Count > index)
                        {
                            billSalesSql.UpdateSalesBody(
                  textIdBill.Text,
                  BillParmBeforUpdate[i].Bill_body_id,
                  BillParmAfterUpdate[index].idItemUnit,
                  BillParmAfterUpdate[index].Quantity,
                  BillParmAfterUpdate[index].Part,
                  BillParmAfterUpdate[index].Selling_price,
                  BillParmAfterUpdate[index].price_part,
                   BillParmAfterUpdate[index].Total
                  );
                            
                            index++;

                        }
                        else if (BillParmBeforUpdate.Count > index)
                        {
                           
                            billSalesSql.DeletSalesBody
                                    (
                                  textIdBill.Text, BillParmBeforUpdate[i].Bill_body_id
                                   );
                            index++;
                        }
                    }
                    #endregion

                }
                //ناقصها متغير في حال ما دخل البيانات صح في الحسابه ما يعدلش ولا يضيف

                billSalesSql.UpdateSalesHaed(
                         textIdBill.Text,
                         (radioButtCach.Checked == true ? "1" : "2"),
                         dateTimePicker1.Value.ToShortDateString(),
                         txtCust_id_fk.Text,
                         textBox_id_fk.Tag.ToString(),
                         TotaleAndExching[0],
                         txtBill_id_fk.Text == string.Empty ? "NULL" : txtBill_id_fk.Text,
                         textNote.Text,
                         TotaleAndExching[1]
                         );
              
                MessageBox.Show("تم التعديل بنجاح");
                // ShowMesgBoxWarningsAccNull();
                if (checkBoxSavePosting.Checked == true)
                {
                     posting(textIdBill.Text);
                    MessageBox.Show("حفظ وترحيل" + "\n" + "شغل داله الترحيل", "تعديل");
                }
                FormatingTextBoxAndButt("Save");
                flagAddOrEdit = "";
                fillData("All");

            }  
            }

            else
            {
                FormatingTextBoxAndButt("Save");
                flagAddOrEdit = "";
                fillData("All");
            }

        }
        List<string> ShowCulc()
        { 
            /*
            عند الحفظ تظهر شاشة كم المبلغ المقبوض وكم المتبقي
            */
            List<string> TotalAndExching = new List<string>();
            if (radioButtCach.Checked == true)
            {
                TotalAndExching.Clear();
                if (currSql.CurrBoxUserIsLocal(textBox_id_fk.Tag.ToString()))
                {
                    /*
                    اذا كانت محلية اظهر له الحسابة العادي ويحط سعر الصرف 1 عند الحفظ والمبلغ المحلي
                    */

                    FrmAmountReceivedForgn Culc = new FrmAmountReceivedForgn(txtTotal.Text, textIdBill.Text);
                    Culc.ShowDialog();
                    if (FrmAmountReceivedForgn.State)
                    {
                        
                        TotalAndExching.Add(txtTotal.Text);//المبلغ
                        TotalAndExching.Add("1");//سعر الصرف
                    }
                    else { TotalAndExching.Clear(); }
                }
                else
                {
                    
                    List<string> CurrData=currSql.GetCurrNameAndExching4idUserBox(textBox_id_fk.Tag.ToString());
                    if (CurrData.Count > 0)
                    {
                        
                        FrmAmountReceived Cluc = new FrmAmountReceived(txtTotal.Text, textIdBill.Text, CurrData[0], CurrData[1]);
                        Cluc.ShowDialog();
                        if (Cluc.State)
                        {
                            
                            TotalAndExching.Add(Cluc.txtTotalForg.Text);//المبلغ
                            TotalAndExching.Add(Cluc.txtExching.Text);//سعر الصرف
                        }

                    }
                }
            }
            else if (radioButtLetar.Checked == true)
            {
                TotalAndExching.Clear();
               
                if (currSql.CurrCustomersIsLocal(txtCust_id_fk.Text))
                {
                  
                    TotalAndExching.Add(txtTotal.Text);//المبلغ
                    TotalAndExching.Add("1");//سعر الصرف
                }
                else
                {
                   
                    List<string> CurrData = currSql.GetCurrNameAndExching4Customers(txtCust_id_fk.ToString());
                    if (CurrData.Count > 0)
                    {

                        FrmAmountReceived Cluc = new FrmAmountReceived(txtTotal.Text, textIdBill.Text, CurrData[0], CurrData[1]);
                        Cluc.ShowDialog();
                        if (Cluc.State)
                        {

                            TotalAndExching.Add(Cluc.txtTotalForg.Text);//المبلغ
                            TotalAndExching.Add(Cluc.txtExching.Text);//سعر الصرف
                        }

                    }
                }
            }
            return TotalAndExching;

        }
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                #region

                if (
                    textIdBill.Text != string.Empty &&
                    textBox_id_fk.Text != string.Empty && 
                    textBox_id_fk.Tag != null &&
                    txtCust_id_fk.Text != string.Empty &&
                    (radioButtCach.Checked==true||radioButtLetar.Checked==true)
                    )
                {
                    #region
                    /*
                    اولا يتحقق من التالي
                    رقم الصندوق موش فارغ
                    رقم مستخدمين الصناديق موش فارغ
                    رقم السند  موش فارغ 
                    رقم العميل موش فارغ
                    نقدا او اجل موش فارغ
                    
                    */
                    #endregion

                    if ( Convert.ToDecimal(txtTotal.Text) > 0  )
                    {

                        if (radioButtCach.Checked == true) //اذا كان ب نقدا    
                        
                            if (Convert.ToDecimal(txtAccCust.Text) <= 0)
                            InsertNewBill();
                            else  
             MessageBox.Show("يوجد دين على هذا العميل لا يمكن ارجاع مبلغ", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                         
                        else if (radioButtLetar.Checked == true)
                            InsertNewBill();
                        

                     
                    }
                    else MessageBox.Show("اجمالي الفاتورة ليس اكبر من الصفر", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                }
                else if
                    (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }

                #endregion

            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (textIdBill.Text != string.Empty &&
                    textBox_id_fk.Text != string.Empty &&
                    textBox_id_fk.Tag != null &&
                    txtCust_id_fk.Text != string.Empty &&
                    (radioButtCach.Checked == true || radioButtLetar.Checked == true)
                     )
                {
                    #region ملاحظة
                    /*
                   
                    */
                    #endregion
                    if (Convert.ToDecimal(txtTotal.Text) > 0)
                    {
                        if (radioButtCach.Checked == true) //اذا كان ب نقدا
                          if (Convert.ToDecimal(txtAccCust.Text) <= 0) // اذا كان رصيده اقل او يساوي الصفر رجع له فلوس 
                                UpdateBill();
                          else
                                MessageBox.Show("لا يمكن الدفع نقدا وعلى هذا العميل دين", "", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        
                        else if (radioButtLetar.Checked == true)// اجل اقبل
                                 UpdateBill();
                        


                    }


                    else MessageBox.Show("اجمالي الفاتورة يساوي الصفر لا يمكن التعديل","",MessageBoxButtons.OK,MessageBoxIcon.Stop);


                    }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if

            }
                
            }
        void posting(string RefPost = "-1")
        {
            /*
            قبل عمليه الترحيل
            اذا كانت حاله السند غير مرحله
            اروح اتاكد من جدول اليومية اذا كان موجود هناك او لا
            في حال كان موجود خليه يطلع 
            رساله خطأ للمستخدم يرجى مراجعة الدعم الفني
            خطأ في عمليه الترحيل
            مالم يرحل طبيعي

             */
            if (
                postingSql.CheckPostingOrNot(idOpration.Text, RefPost) //يفحص من جدول اليومية
                &&
                RefPost != "-1"
                &&
                stingPosting == false //يفحص حاله السند من جدول سندات القبض
                )
            {
                MessageBox.Show("لا يمكن ترحيل هذا السند" + "\n" + "يرجى مراجعة مدير النظام او الدعم الفني", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                MessageBox.Show(RefPost, "حالته موش مرحل وهو مرحل مغالط");
            }
            else if (
                !postingSql.CheckPostingOrNot(idOpration.Text, RefPost)
                &&
                RefPost == "-1")
            {
                MessageBox.Show("خطأ في رقم المرجع عند الترحيل", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else if
                (
                !postingSql.CheckPostingOrNot(idOpration.Text, RefPost)
                &&
                  RefPost != "-1"
                )
            {

                postingSql.PostSupportCatch(RefPost, idOpration.Text, UserId.Text);
                fillData("All");

            }


            /*
            باقي عند تشغيل البرنامج يروح يحفظ جميع السندات الي مشيك عليهم انهم مرحلين
            بعدين يروح يفحص في اليومية العامة اذا مهلوش يحفظه
            عشان يعرض داتا جريت فيو يوجد سندات فيها اخطاء يرجى مراجعة الدعم الفني او مدير النظام
            */

        }

        #endregion
        #endregion
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }


        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            //داله عشان احرك الفورم 
            MoveForm(e);
            
        }

      

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

        private void pictureClose_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

      

     

        private void buttPrint_Click(object sender, EventArgs e)
        {
            Reports.ReturnSalesBill item = new Reports.ReturnSalesBill();
            item.Refresh();
            item.SetParameterValue("@Return_bill_id", this.textIdBill.Text);
            Reports.frm_Reports f = new Reports.frm_Reports();

            f.crystalReportViewer1.ReportSource = item;
            f.Refresh();
            f.ShowDialog();

        }

        private void buttPosting_Click(object sender, EventArgs e)
        {
            if (textIdBill.Text != string.Empty && !stingPosting)
            {
                posting(textIdBill.Text);
            }
            else { MessageBox.Show("قد تم ترحيل السند سابقا", "", MessageBoxButtons.OK, MessageBoxIcon.Stop); }


        }
      
       
        private void textBox_id_fk_KeyDown(object sender, KeyEventArgs e)
        {
            ShowListBoxsUser(e,"Box");
        }

        private void txtCust_id_fk_KeyDown(object sender, KeyEventArgs e)
        {
            if(flagAddOrEdit=="Add"|| flagAddOrEdit == "Edite")
            {
                ShowListBoxsUser(e, "Coust");
                try {
                    if (Convert.ToDecimal(txtAccCust.Text) > 0)
                    { radioButtCach.Checked = false; radioButtCach.Enabled = false; }
                    } catch { }
                
            }
           

        }

        private void SaleBill_Load(object sender, EventArgs e)
        {
            fillData("All");
            flagAddOrEdit = "Load";

            dateTimePicker1.Format = DateTimePickerFormat.Custom;

            dateTimePicker1.CustomFormat = "yyyy/MM/dd";

            FormatingTextBoxAndButt("Load");
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            stingPosting = false;//حاله السند غير مرحل
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SetDataBodyAfterEdite();
            SendDataToAddOrEdit(flagAddOrEdit);
           
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            FillTextBox(indexHaedButt("Next", ref indexHaed));
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {

            if (!stingPosting)
            {
                flagAddOrEdit = "Edite";
                SetDataBodyBeforEdite();  
                FormatingTextBoxAndButt(flagAddOrEdit);
                if (txtCust_id_fk.Text != string.Empty)
                {
                    txtAccCust.Text = AccSql.Acount(AccSql.GetAccCurrId4CustomerId(txtCust_id_fk.Text));
                    txtAccCustMax.Text = AccSql.MaxAccount(AccSql.GetAccCurrId4CustomerId(txtCust_id_fk.Text));
                }
            }
            else MessageBox.Show("السند مرحل لايمكن تعديله", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Stop);
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            FillTextBox(indexHaedButt("Back", ref indexHaed));
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            FillTextBox(indexHaedButt("Frist", ref indexHaed));
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            FillTextBox(indexHaedButt("Last", ref indexHaed));
        }

        private void DGVBody_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            EditingControlShowingDataGridView(sender, e);
        }

        private void DGVBody_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cellClickDataGridView();
        }

        private void DGVBody_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            afterCellEndEditDataGridView();
        }

        private void txtTotal_TextChanged(object sender, EventArgs e)
        {
            try
            {
                ToWord toWord = new ToWord(Convert.ToDecimal(txtTotal.Text), new CurrencyInfo(CurrId.Text));
                textDebtWord.Text = toWord.ConvertToArabic();
            }
            catch
            {

                textDebtWord.Text = String.Empty;
            }
        }

        private void DGVBody_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            TotaleBill();
        }

        private void DGVBody_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
            TotaleBill();
        }

        private void DGVBody_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            TotaleBill();
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
                indexHaed = -1;
               fillData("Serch");
        }

        private void txtDiscount_Leave(object sender, EventArgs e)
        {
            
        }

        private void radioButtLetar_CheckedChanged(object sender, EventArgs e)
        {
            //if(radioButtLetar.Checked==true&& txtCust_id_fk.Text != string.Empty)
            //{
            //    txtAccCust.Text = AccSql.Acount(AccSql.GetAccCurrId4CustomerId(txtCust_id_fk.Text));
            //    txtAccCustMax.Text = AccSql.MaxAccount(AccSql.GetAccCurrId4CustomerId(txtCust_id_fk.Text));
            //}
                
        }

        private void txtDiscount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void label7_DoubleClick(object sender, EventArgs e)
        {
            if(DTHaed!=null&&DTHaed.Rows.Count>0)
            MessageBox.Show(label7.Tag.ToString());
        }
       
        private void txtBill_id_fk_Leave(object sender, EventArgs e)
        { if(flagAddOrEdit=="Add"|| flagAddOrEdit== "Edite")
            CheckSaleBill(txtBill_id_fk.Text);
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (textIdBill.Text != string.Empty)
            {
                if (!stingPosting && !postingSql.CheckPostingOrNot(idOpration.Text, textIdBill.Text))
                {
                    Delet(textIdBill.Text);
                }
                else MessageBox.Show("السند مرحل لايمكن حذفه", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }
    }
}
