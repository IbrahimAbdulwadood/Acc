﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class AddQun : Form
    {
        string ItemId;
        public AddQun(string ItemId)
        {
            InitializeComponent();
            this.ItemId = ItemId;
         
        }

       
        int i;
      static  public int indeex=-1;
        DataTable datatable;
       
        ClassesProject.ItemsSQL Acc = new ClassesProject.ItemsSQL();
        public bool stateSelect = false;

        private void ListCurrencyNamesForm_Load(object sender, EventArgs e)
        {
           datatable = Acc.GetItemInfo(ItemId);
            #region البيانات التي تتعبي في الجدول
            /*
       ItemUnit.idItemUnit
       , Items.barc
       , Items.Item_name
       , Units.Unit_name

          
           */
            #endregion


            if (datatable.Rows.Count > 0)
            {
                dataGridView1.Rows.Clear();

                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(
                       datatable.Rows[i][0].ToString(),
                       datatable.Rows[i][1].ToString(),
                        datatable.Rows[i][2].ToString(),
                       datatable.Rows[i][3].ToString(),
                       "0",
                       "0"
                        );
                    }
     
            }
            if (dataGridView1.Rows.Count == 0)

            {
                // bunifuThinButton21.ButtonText = "لا يوجد عملات";
                btnSelect.Visible = false;
                labelError.Visible = true;
                labelError.Text = "لا يوجد وحدات لهذا الصنف";


            }




        }

       

       
       
       

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            
            stateSelect = true;
            indeex = dataGridView1.CurrentCell.RowIndex;
            Close();
           

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {

            if (dataGridView1.Rows.Count > 0)
            {
                if (DialogResult.Yes == MessageBox.Show("تاكيد اضافة الكميات", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question))
                {

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                        if (dataGridView1.Rows[i].Cells[4].Value != null
                         && dataGridView1.Rows[i].Cells[4].Value.ToString() != "0")
                            Acc.InsertNewFirstBalance(
                                dataGridView1.Rows[i].Cells[0].Value.ToString()
                                , dataGridView1.Rows[i].Cells[4].Value.ToString()
                                , dataGridView1.Rows[i].Cells[5].Value.ToString()
                                );
                    MessageBox.Show("تم اضافة الكميات بنجاح");
                }
                
            }
            
        }
    }
}
