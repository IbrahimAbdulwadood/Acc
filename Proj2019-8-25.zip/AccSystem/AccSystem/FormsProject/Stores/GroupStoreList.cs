﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class GroupStoreList : Form
    {
       
        public GroupStoreList()
        {
            InitializeComponent();
            //this.UnitsId = UnitsId;
         
        }

       
        int i;
        static  public int indeeex;
        public bool stateSelect = true;

      
        DataTable datatableGroup =new DataTable();
        ClassesProject.GroupStoredSQL groupClass = new ClassesProject.GroupStoredSQL();
       

        private void ListCurrencyNamesForm_Load(object sender, EventArgs e)
        {
            datatableGroup = groupClass.GetAllGroup();
           
            /*
           [Group_id] ,[Group_name],[Acc_sales_fk] ,[Acc_purchases_cost_fk],
           [Acc_return_sales_fk] ,[Acc_return_purchases_fk] ,[Acc_discount_allow_fk] 
           ,[Acc_discount_gained_fk] ,[Acc_stored_fk] ,[Acc_quantity_free_fk]
           */
            if (datatableGroup.Rows.Count > 0)
            {

                for (i = 0; i < datatableGroup.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add
                    (
                        datatableGroup.Rows[i][0].ToString(), datatableGroup.Rows[i][1].ToString()

                     );
                }

            }
          //لا يوجد مجموعات مخزنية }
               
                else
                {
                    bunifuThinButton21.Visible = false;
                    label1.Visible = true;
                    label1.Text = "لا يوجد مجموعات مخزنية";
                }




            





        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());
           
          
           
            //setIndex();

        }

        private void ItemGroupList_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            indeeex = dataGridView1.CurrentCell.RowIndex;
            MessageBox.Show(indeeex.ToString());
            Close();
        }
    }
}
