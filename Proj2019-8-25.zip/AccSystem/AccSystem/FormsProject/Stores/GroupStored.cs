﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class GroupStored : Form
    {
        public GroupStored()
        {
            InitializeComponent();
        }


        #region داله تغيير اللغه عند الادخال تستخدم في التكست بوكس
        

        ////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// داله خارجية تستقبل اسم اللغه و تحولها حسب الطلب و تستدعى عند الحدث انتر وليف
        /// </summary>
        /// <param name="inputName"></param>
        /// <returns></returns>
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }
       
        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }


        ///
        ///
        ///
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        #endregion
        #region داله لتحريك الفورم عند الضغط بالماوس

        /// <summary>
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس
        /// </summary>
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>

        #endregion


        ClassesProject.GroupStoredSQL groupStore = new ClassesProject.GroupStoredSQL();
        DataTable dataTableGroupStore;
        ClassesProject.AccDefintionSQL accDefin = new ClassesProject.AccDefintionSQL();
        GroupStoredLists.AccList accList;

        List<string> ErrorAccNotSet = new List<string>();
        public string flagAddOrEdit = "";

        //////////////////////////////////////////////////////////

        void FillTextBox(int indexRows)
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (dataGridView1.Rows.Count > 0)
            {

                int i = indexRows;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */

                /*
          /*
        a.Group_id 0
            ,a.Group_name 1
            ,a.Acc_sales_fk  2
            ,a.Acc_sales_id 3
            ,a.Acc_sales_name 4
            ,a.Acc_cost_fk 5
            ,a.Acc_cost_id 6
            ,a.Acc_cost_name 7
            ,a.Acc_return_sales_fk 8
            ,a.Acc_return_sales_id 9
            ,a.Acc_return_sales_name 10
            ,a.Acc_stored_fk 11
            ,a.Acc_stored_id 12
            ,a.Acc_stored_name 13
         */

                Group_id.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                Group_name.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                Acc_sales_fk.Tag = dataGridView1.Rows[i].Cells[2].Value.ToString();
                Acc_sales_fk.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                Acc_sales_fk_name.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
                Acc_purchases_cost_fk.Tag = dataGridView1.Rows[i].Cells[5].Value.ToString();
                Acc_purchases_cost_fk.Text = dataGridView1.Rows[i].Cells[6].Value.ToString();
                Acc_purchases_cost_fk_name.Text = dataGridView1.Rows[i].Cells[7].Value.ToString();
                Acc_return_sales_fk.Tag = dataGridView1.Rows[i].Cells[8].Value.ToString();
                Acc_return_sales_fk.Text = dataGridView1.Rows[i].Cells[9].Value.ToString();
                Acc_return_sales_fk_name.Text = dataGridView1.Rows[i].Cells[10].Value.ToString();
                Acc_stored_fk.Tag = dataGridView1.Rows[i].Cells[11].Value.ToString();
                Acc_stored_fk.Text = dataGridView1.Rows[i].Cells[12].Value.ToString();
                Acc_stored_fk_name.Text = dataGridView1.Rows[i].Cells[13].Value.ToString();


                FillTextBoxCountRows((i + 1).ToString());
              
            }



        }
        void fillData(string NormalOrSerch)
        {

            dataTableGroupStore = new DataTable();

            if (NormalOrSerch == "All")
                //يستعلم عن جميع الصناديق 
                dataTableGroupStore = groupStore.GaetGroupAll();
           if(dataTableGroupStore!=null&& dataTableGroupStore.Rows.Count > 0)
            {
                MessageBox.Show("ملان" + dataTableGroupStore.Rows.Count.ToString());
            }
            else
                MessageBox.Show("لا يوجد بيانات لعرضها" + "");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridView1.Rows.Clear();
                /*
        a.Group_id 0
            ,a.Group_name 1
            ,a.Acc_sales_fk  2
            ,a.Acc_sales_id 3
            ,a.Acc_sales_name 4
            ,a.Acc_cost_fk 5
            ,a.Acc_cost_id 6
            ,a.Acc_cost_name 7
            ,a.Acc_return_sales_fk 8
            ,a.Acc_return_sales_id 9
            ,a.Acc_return_sales_name 10
            ,a.Acc_stored_fk 11
            ,a.Acc_stored_id 12
            ,a.Acc_stored_name 13
         */
                for (int i = 0; i < dataTableGroupStore.Rows.Count; i++)
                {
                    MessageBox.Show(dataTableGroupStore.Rows[i][0].ToString());
                    MessageBox.Show(dataTableGroupStore.Rows[i][1].ToString());
                    dataGridView1.Rows.Add
                     (
                      dataTableGroupStore.Rows[i][0].ToString()
                     ,dataTableGroupStore.Rows[i][1].ToString()
                     ,dataTableGroupStore.Rows[i][2].ToString()
                     ,dataTableGroupStore.Rows[i][3].ToString()
                     ,dataTableGroupStore.Rows[i][4].ToString()
                     ,dataTableGroupStore.Rows[i][5].ToString()
                     ,dataTableGroupStore.Rows[i][6].ToString()
                     ,dataTableGroupStore.Rows[i][7].ToString()
                     ,dataTableGroupStore.Rows[i][8].ToString()
                     ,dataTableGroupStore.Rows[i][9].ToString()
                     ,dataTableGroupStore.Rows[i][10].ToString()
                     ,dataTableGroupStore.Rows[i][11].ToString()
                     ,dataTableGroupStore.Rows[i][12].ToString()
                     ,dataTableGroupStore.Rows[i][13].ToString()
                     );
                   
                }
                if (dataGridView1.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    Group_id.Text = string.Empty;
                    Group_name.Text = string.Empty;
                    Acc_sales_fk.Text = string.Empty;
                    Acc_sales_fk_name.Text = string.Empty;
                    Acc_purchases_cost_fk.Text = string.Empty;
                    Acc_purchases_cost_fk_name.Text = string.Empty;
                    Acc_return_sales_fk.Text = string.Empty;
                    Acc_return_sales_fk_name.Text = string.Empty;
                    Acc_stored_fk.Text = string.Empty;
                    Acc_stored_fk_name.Text = string.Empty;
                    //    Acc_quantity_free_fk.Text = string.Empty;

                    //dataGridViewUsers.Rows.Clear();
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch { }

        }
        void Delet()
        {
            List<string> data = new List<string>();
            data = groupStore.ChaeckCanDelet(Group_id.Text);
            if (data.Count > 0)
            {
                MessageBox.Show("لا يمكن الحذف يوجد فئات مرتبطة بهذه المجموعة", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (DialogResult.Yes == MessageBox.Show("؟تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                groupStore.Delet(Group_id.Text);
                fillData("All");

            }

        }

        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                Group_name.ReadOnly = false;


                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                Acc_sales_fk.ReadOnly = true;
                Acc_purchases_cost_fk.ReadOnly = true;
                Acc_sales_fk.ReadOnly = true;
                Acc_purchases_cost_fk.ReadOnly = true;
                Acc_return_sales_fk.ReadOnly = true;
       
              
                Acc_stored_fk.ReadOnly = true;
         

                /////////////////////
               

                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
                /////////////////مستخدمين الصندوق//////////////////
              
              

                if (flagEditeOrAddOrSave == "Edite")
                {

                    Acc_sales_fk.ReadOnly = true;


                }
            

            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                Group_name.ReadOnly = true;



                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                Acc_sales_fk.ReadOnly = true;
                Acc_purchases_cost_fk.ReadOnly = true;
                Acc_sales_fk.ReadOnly = true;
                Acc_purchases_cost_fk.ReadOnly = true;
                Acc_return_sales_fk.ReadOnly = true;
            //    Acc_return_purchases_fk.ReadOnly = true;
              
                Acc_stored_fk.ReadOnly = true;
          //      Acc_quantity_free_fk.ReadOnly = true;


                ///////////////////
              
                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
                /////////////////////////
                

            }


        }
        void ForamtingAdd()
        {
         
            Group_id.Text = groupStore.GetMaxIdGroup();
            Group_name.Text = string.Empty;
        
            Group_name.Text = string.Empty;
            Acc_sales_fk.Text = string.Empty;
            Acc_sales_fk_name.Text = string.Empty;
            Acc_purchases_cost_fk.Text = string.Empty;
            Acc_purchases_cost_fk_name.Text = string.Empty;
            Acc_return_sales_fk.Text = string.Empty;
            Acc_return_sales_fk_name.Text = string.Empty;
            Acc_stored_fk.Text = string.Empty;
            Acc_stored_fk_name.Text = string.Empty;
            

            Group_name.Focus();

        }

        int indexBoxsButt(string btName, string GroupId)
        {
            /*
            داله لايجاد اندكس العمله حسب رقم العمله
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (GroupId == dataGridView1.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < dataGridView1.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return dataGridView1.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد عملات في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }

        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + dataGridView1.Rows.Count.ToString();
        }

        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }
  
        void SendAccNullToListError()
        {
            string mesg = "لن تستطيع استخدام الاصناف المرتبطة بهذه المجموعة لعدم اختيار الحساب المتأثر في القيود";
            ErrorAccNotSet.Clear();
            if (Acc_sales_fk.Text == string.Empty)
                ErrorAccNotSet.Add(" ||فواتير المبيعات||  " +mesg+" || ");
             if (Acc_purchases_cost_fk.Text == string.Empty)
                ErrorAccNotSet.Add(" ||المشتريات||  " + mesg+" || ");
             if (Acc_return_sales_fk.Text == string.Empty)
                ErrorAccNotSet.Add(" ||مردود المبيعات||  " + mesg+" || ");
             //if (Acc_return_purchases_fk.Text == string.Empty)
             //   ErrorAccNotSet.Add(" ||مردود المشتريات||  " + mesg+" || ");
           
             if (Acc_stored_fk.Text == string.Empty)
                ErrorAccNotSet.Add(" ||تكلفة المخزون الحالي||  " + mesg+" || ");
             //if (Acc_quantity_free_fk.Text == string.Empty)
             //   ErrorAccNotSet.Add(" ||الكميات المجانية||  " + mesg+" ||");

        }
      
        void ShowMesgBoxWarningsAccNull()
        {
            if (ErrorAccNotSet.Count > 0)
            {
                int i = ErrorAccNotSet.Count;
               // MessageBox.Show(ErrorAccNotSet.Count.ToString());
                foreach (var item in ErrorAccNotSet)
                {
                    MessageBox.Show(item, " تنبيـــة "+(--i), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                ErrorAccNotSet.Clear();
            }
        }

       
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (Group_name.Text != string.Empty
                    && Acc_sales_fk.Text != string.Empty
                      && Acc_purchases_cost_fk.Text != string.Empty
                        && Acc_return_sales_fk.Text != string.Empty
                          && Acc_stored_fk.Text != string.Empty
                    )
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        

                       
                        groupStore.InsertNewGroupStored
                             (
                            Group_name.Text,
                            (Acc_sales_fk.Tag == null ? "NULL" : Acc_sales_fk.Tag.ToString()),
                            (Acc_purchases_cost_fk.Tag == null ? "NULL" : Acc_purchases_cost_fk.Tag.ToString()),
                            (Acc_return_sales_fk.Tag == null ? "NULL" : Acc_return_sales_fk.Tag.ToString()),
                            "NULL" ,
                             "NULL" ,
                           "NULL" ,
                            (Acc_stored_fk.Tag == null ? "NULL" : Acc_stored_fk.Tag.ToString()),
                             "NULL" 
                         );
                        //داله تخزن الحسابات الي ما حددها عشان ينبه المستخدم
                        SendAccNullToListError();

                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                        //عرض رسائل التنبية الخاصه ب الحساب الغير مربوطة
                        ShowMesgBoxWarningsAccNull();
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }


                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }



            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (Group_name.Text != string.Empty
                    && Acc_sales_fk.Text != string.Empty
                      && Acc_purchases_cost_fk.Text != string.Empty
                        && Acc_return_sales_fk.Text != string.Empty
                          && Acc_stored_fk.Text != string.Empty
                    )
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        SendAccNullToListError();

                        groupStore.UpdateGroupStore
                            (
                             Group_id.Text,
                             Group_name.Text
                             //,
                            //(Acc_sales_fk.Tag == null ? "NULL" : Acc_sales_fk.Tag.ToString()),
                            //(Acc_purchases_cost_fk.Tag == null ? "NULL" : Acc_purchases_cost_fk.Tag.ToString()),
                            //(Acc_return_sales_fk.Tag == null ? "NULL" : Acc_return_sales_fk.Tag.ToString()),
                            //"NULL" ,
                            //"NULL",
                            //"NULL" ,
                            //(Acc_stored_fk.Tag == null ? "NULL" : Acc_stored_fk.Tag.ToString()),
                            //"NULL" 
                            );

                        MessageBox.Show("تم التعديل بنجاح");
                        ShowMesgBoxWarningsAccNull();
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }

                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }




        ///////////////////////////////////////////////////////////

        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            //داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

       

   

       
     

       

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

    

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

      

        private void butSave_Click(object sender, EventArgs e)
        {
           SendDataToAddOrEdit(flagAddOrEdit);
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            flagAddOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Last", Group_id.Text));
           
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Back", Group_id.Text));
           
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Next", Group_id.Text));
           
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Frist", Group_id.Text));
            
        }

      
       
      

      

        private void Box_id_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void dataGridView1_SelectionChanged_1(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox(dataGridView1.CurrentCell.RowIndex);
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GroupStored_Load(object sender, EventArgs e)
        {
            fillData("All");
            FormatingTextBoxAndButt("Load");
            dataGridView1.Select();
        }

        private void Group_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopNumberInTextBox(e);
        }

        private void txtSerch_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void Group_name_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        string[] GetDataSelectedAccLis(string idAccFather, string TitleName)
        {
            string[] data = new string[3];
            // accList = new GroupStoredLists.AccList(accDefin.GetIdAccSalesFather());
            accList = new GroupStoredLists.AccList(idAccFather);
            accList.labelTitle.Text = TitleName;
            accList.ShowDialog();
            if (accList.stateSelect == true
                && GroupStoredLists.AccList.indeex != -1
                && dataGridView1.Rows.Count > 0)
            {
                int indexCurrInDatGrV = GroupStoredLists.AccList.indeex;
                //Acc_sales_fk.Text =
                //    accList.dataGridView1.Rows[indexCurrInDatGrV].Cells[0].Value
                //    .ToString();
                data[0] =
                   accList.dataGridView1.Rows[indexCurrInDatGrV].Cells[0].Value
                   .ToString();
                //Acc_sales_fk_name.Text = accList.dataGridView1.Rows[indexCurrInDatGrV].Cells[1].Value
                //    .ToString();
               data[1] = accList.dataGridView1.Rows[indexCurrInDatGrV].Cells[1].Value
                    .ToString();
                data[2] = accList.dataGridView1.Rows[indexCurrInDatGrV].Cells[2].Value
                    .ToString();
                accList = null;
               
                try
                {
                    
                   // return data;
                }
                catch (Exception e) { MessageBox.Show(e.ToString()); }

               
            }
            return data;
        }
        void ShowAccList(string nameAcc)
        {
            string[] data = new string[2];
            switch (nameAcc)
            {
                case "AccSales":
                    if (accDefin.AccSalesFatherNotNull())
                    { //يتحقق اذا حساب الاب للمبيعات موش فارغ يدخل يفتح لسته اضافة حساب للمجموعة
                        MessageBox.Show(accDefin.GetIdAccSalesFather(), "حساب المبيعات");
                        data = GetDataSelectedAccLis(accDefin.GetIdAccSalesFather(),"حسابات المبيعات");
                        Acc_sales_fk.Text = data[0];
                        Acc_sales_fk_name.Text = data[1];
                        Acc_sales_fk.Tag = data[2];

                    }
                    else
                    {
                        MessageBox.Show("غير معرف في شاشة تعريف الحسابات", " حساب المبيعات", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                        break;
                case "AccReturnSales":
                    if (accDefin.AccSalesReturnFatherNotNull())
                    { //يتحقق اذا حساب الاب للمبيعات موش فارغ يدخل يفتح لسته اضافة حساب للمجموعة
                        MessageBox.Show(accDefin.GetIdAccSalesReturnFather(), "حساب مردود المبيعات");
                        data = GetDataSelectedAccLis(accDefin.GetIdAccSalesReturnFather(),"حسابات مردود المبيعات");
                        Acc_return_sales_fk.Text = data[0];
                        Acc_return_sales_fk_name.Text = data[1];
                        Acc_return_sales_fk.Tag = data[2];

                    }
                    else
                    {
                        MessageBox.Show("غير معرف في شاشة تعريف الحسابات", " حساب مردود المبيعات", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;
                case "AccPurchasesCost":
                    if (accDefin.AccCostFatherNotNull())
                    { //يتحقق اذا حساب الاب للمبيعات موش فارغ يدخل يفتح لسته اضافة حساب للمجموعة
                        MessageBox.Show(accDefin.GetIdAccPurchasesFather(), "حساب تكلفة المبيعات");
                        data = GetDataSelectedAccLis(accDefin.GetIdAccPurchasesFather(), "حسابات تكلفة المبيعات");
                        Acc_purchases_cost_fk.Text = data[0];
                        Acc_purchases_cost_fk_name.Text = data[1];
                        Acc_purchases_cost_fk.Tag = data[2];

                    }
                    else
                    {
                        MessageBox.Show("غير معرف في شاشة تعريف الحسابات", " حساب مردود المبيعات", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    break;
                case "AccStored":
                    if (accDefin.AccStoredFatherNotNull())
                    { //يتحقق اذا حساب الاب للمبيعات موش فارغ يدخل يفتح لسته اضافة حساب للمجموعة
                        MessageBox.Show(accDefin.GetIdAccStoredFather(), "حساب مخزون البضاعه");
                        data = GetDataSelectedAccLis(accDefin.GetIdAccStoredFather(), "حسابات  مخزون البضاعة ");
                        Acc_stored_fk.Text = data[0];
                        Acc_stored_fk_name.Text = data[1];
                        Acc_stored_fk.Tag = data[2];

                    }
                    else
                    {
                        MessageBox.Show("غير معرف في شاشة تعريف الحسابات", " حساب مردود المبيعات", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    
                    break;


            }

        }

        //bool CheckIfAccDefineFound(string nameAcc)
        //{
        //    //يفحص اذا كان الحساب الاب الي قبل 
        //    /*
        //    داله تفحص اذا كان الحساب الاب الي قبل الحساب الفرعي بواحد موجود في جدول تعريف الحسابات 1
        //    اذا موش موجود ترجع 0
        //    عشان احدد هل افتح له اللسته حق تحديد الحساب الفرعي لهذا الحساب  
        //    ولا اطلع له رساله يرجى تعريف الحساب من شاشه تعريف الحسابات
            
        //    */
           
        //    DataTable CheckAccDef = new DataTable();
            
        //       if (CheckAccDef.Rows[0][0].ToString() != "NULL"&& nameAcc== "AccSales")
        //            {
        //               return true;
        //            }
        //      else return false;
                  

           
        //}
        private void Acc_sales_fk_KeyDown(object sender, KeyEventArgs e)
        {
            if (flagAddOrEdit == "Add" || flagAddOrEdit == "Edite")
                if (e.KeyData == Keys.F9)
            {
                ShowAccList("AccSales");
            }
        }

        private void Acc_return_sales_fk_KeyDown(object sender, KeyEventArgs e)
        {
            //Acc_return_sales_fk
            if (flagAddOrEdit == "Add" || flagAddOrEdit == "Edite")
                if (e.KeyData == Keys.F9)
                {
                    ShowAccList("AccReturnSales");
                }

        }

        private void Acc_purchases_cost_fk_KeyDown(object sender, KeyEventArgs e)
        {
            if (flagAddOrEdit == "Add" || flagAddOrEdit == "Edite")
                if (e.KeyData == Keys.F9)
                {
                    ShowAccList("AccPurchasesCost");
                }
        }

       

      

       
       
        private void Acc_stored_fk_KeyDown(object sender, KeyEventArgs e)
        {
            if (flagAddOrEdit == "Add" || flagAddOrEdit == "Edite")
                if (e.KeyData == Keys.F9)
                {
                    ShowAccList("AccStored");
                }
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (Group_id.Text != string.Empty)
                Delet();
        }
    }
}
