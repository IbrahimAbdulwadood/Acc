﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores.GroupStoredLists
{
    public partial class AccList : Form
    {
        string AccFatherId;
        public AccList(string AccFatherId)
        {
            InitializeComponent();
            this.AccFatherId = AccFatherId;
         
        }

       
        int i;
      static  public int indeex=-1;
        DataTable datatable;
        ClassesProject.AccountSQL Acc = new ClassesProject.AccountSQL();
        public bool stateSelect = false;

        private void ListCurrencyNamesForm_Load(object sender, EventArgs e)
        {
           datatable = Acc.GetAllFr3iAcc(AccFatherId);
            #region البيانات التي تتعبي في الجدول
            /*
           SELECT 
            [Acc_id]
           ,[Acc_name]
           ,[AccCrrid]

          
           */
            #endregion


            if (datatable.Rows.Count > 0)
            {
                dataGridView1.Rows.Clear();

                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(
                       datatable.Rows[i][0].ToString(),
                       datatable.Rows[i][1].ToString(),
                       datatable.Rows[i][2].ToString()
                        );
                    }
     
            }
            if (dataGridView1.Rows.Count == 0)

            {
                // bunifuThinButton21.ButtonText = "لا يوجد عملات";
                bunifuThinButton21.Visible = false;
                labelError.Visible = true;
                labelError.Text = "لا يوجد حسابات";


            }




        }

       

       
       
       

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            
            stateSelect = true;
            indeex = dataGridView1.CurrentCell.RowIndex;
            Close();
           

        }
    }
}
