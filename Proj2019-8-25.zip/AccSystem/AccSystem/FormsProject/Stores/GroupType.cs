﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class GroupType : Form
    {
        public GroupType()
        {
            InitializeComponent();
        }


        #region داله تغيير اللغه عند الادخال تستخدم في التكست بوكس


        ////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// داله خارجية تستقبل اسم اللغه و تحولها حسب الطلب و تستدعى عند الحدث انتر وليف
        /// </summary>
        /// <param name="inputName"></param>
        /// <returns></returns>
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }

        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }


        ///
        ///
        ///
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        #endregion
        #region داله لتحريك الفورم عند الضغط بالماوس

        /// <summary>
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس
        /// </summary>
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        /// 
        /// 
        /// <param name="e"></param>

        #endregion
        #region المتغيرات

        ClassesProject.ItemsTypesSQL itemsTypeSql = new ClassesProject.ItemsTypesSQL();
        DataTable dataTableItemsTypeSql;

        GroupStoreList groupList;

        List<string> ErrorAccNotSet = new List<string>();
        public string flagAddOrEdit = "";

        #endregion
        #region الدوال

        #region التعامل مع قاعدة البيانات

        void fillData(string NormalOrSerch)
        {

            dataTableItemsTypeSql = new DataTable();

            if (NormalOrSerch == "All")
                //يستعلم عن جميع الصناديق 
                dataTableItemsTypeSql = itemsTypeSql.GetAllItemType();

            else if (NormalOrSerch == "Serch")
                dataTableItemsTypeSql = itemsTypeSql.Serch(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridView1.Rows.Clear();

                for (int i = 0; i < dataTableItemsTypeSql.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add
                     (
                     dataTableItemsTypeSql.Rows[i][0].ToString(), dataTableItemsTypeSql.Rows[i][1].ToString(),
                     dataTableItemsTypeSql.Rows[i][2].ToString(), dataTableItemsTypeSql.Rows[i][3].ToString()

                     );
                }
                if (dataGridView1.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    ItemType_id.Text = string.Empty;
                    ItemType_name.Text = string.Empty;
                    Group_id_fk.Text = string.Empty;
                    Group_name.Text = string.Empty;

                  
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch { }

        }
        void Delet()
        {
            List<string> data = new List<string>();
            data = itemsTypeSql.ChaeckCanDelet(ItemType_id.Text);
            if (data.Count > 0)
            {
                MessageBox.Show("لا يمكن الحذف يوجد اصناف مرتبطة بهذه الوحدة", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (DialogResult.Yes == MessageBox.Show("؟تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                itemsTypeSql.Delet(ItemType_id.Text);
                fillData("All");

            }

        }


        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (ItemType_name.Text != string.Empty && Group_id_fk.Text != string.Empty)
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {

                        itemsTypeSql.InsertNewItemType(Group_id_fk.Text, ItemType_name.Text);


                        //داله تخزن الحسابات الي ما حددها عشان ينبه المستخدم
                        //   SendAccNullToListError();

                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                        //عرض رسائل التنبية الخاصه ب الحساب الغير مربوطة
                        //  ShowMesgBoxWarningsAccNull();
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }


                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }



            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (ItemType_name.Text != string.Empty)
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        // SendAccNullToListError();
                        itemsTypeSql.UpdateItemType(ItemType_name.Text, ItemType_id.Text);
                        MessageBox.Show("تم التعديل بنجاح");
                        ShowMesgBoxWarningsAccNull();
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }

                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }


        #endregion

        #region التحكم بالواجهه
        void FillTextBox(int indexRows)
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (dataGridView1.Rows.Count > 0)
            {

                int i = indexRows;
               // dataGridView1.ClearSelection();
            //    dataGridView1.SelectedRows[i].Selected = true;
                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */
           

                ItemType_id.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                ItemType_name.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                Group_id_fk.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                Group_name.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                
                FillTextBoxCountRows((i + 1).ToString());

            }



        }
        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + dataGridView1.Rows.Count.ToString();
        }
        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                ItemType_name.ReadOnly = false;


                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                Group_name.ReadOnly = true;
                Group_id_fk.ReadOnly = true;


                /////////////////////
                txtSerch.ReadOnly = true;

                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
                /////////////////مستخدمين الصندوق//////////////////



                if (flagEditeOrAddOrSave == "Edite")
                {
                   
                }


            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                ItemType_name.ReadOnly = true;



                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                Group_name.ReadOnly = true;
                Group_id_fk.ReadOnly = true;

                
                ///////////////////
                txtSerch.ReadOnly = false;
                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;

                /////////////////////////
                txtSerch.Text = string.Empty;
              

            }


        }
        void ForamtingAdd()
        {
            ItemType_id.Text = string.Empty;
            ItemType_name.Text = string.Empty;
            Group_id_fk.Text = string.Empty;
            Group_name.Text = string.Empty;
            Group_id_fk.Focus();
       
        }
        int indexBoxsButt(string btName, string ItemId)
        {
            /*
            داله لايجاد اندكس العمله حسب رقم العمله
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (ItemId == dataGridView1.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < dataGridView1.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return dataGridView1.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد اصناف في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
        void SendAccNullToListError()
        {
            //string mesg = "لن تستطيع استخدام الاصناف المرتبطة بهذه المجموعة لعدم اختيار الحساب المتأثر في القيود";
            //ErrorAccNotSet.Clear();
            //if (Acc_sales_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||فواتير المبيعات||  " + mesg + " || ");
            //if (Acc_purchases_cost_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||المشتريات||  " + mesg + " || ");
            //if (Acc_return_sales_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||مردود المبيعات||  " + mesg + " || ");
            //if (Acc_return_purchases_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||مردود المشتريات||  " + mesg + " || ");
            //if (Acc_discount_allow_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||الخصومات المسموح بها||  " + mesg + " || ");
            //if (Acc_discount_gained_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||الخصومات المكتسبة||  " + mesg + " || ");
            //if (Acc_stored_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||تكلفة المخزون الحالي||  " + mesg + " || ");
            //if (Acc_quantity_free_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||الكميات المجانية||  " + mesg + " ||");

        }

        void ShowMesgBoxWarningsAccNull()
        {
            if (ErrorAccNotSet.Count > 0)
            {
                int i = ErrorAccNotSet.Count;
                // MessageBox.Show(ErrorAccNotSet.Count.ToString());
                foreach (var item in ErrorAccNotSet)
                {
                    MessageBox.Show(item, " تنبيـــة " + (--i), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                ErrorAccNotSet.Clear();
            }
        }
        void ShowListGroupStore(KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9)
            {
                if (flagAddOrEdit == "Add"||flagAddOrEdit == "Edite")
                {

                    groupList = new GroupStoreList();
                    groupList.ShowDialog();


                    if (groupList.stateSelect && groupList.dataGridView1.RowCount > 0)
                    {
                        int indexAccInDatGrV = GroupStoreList.indeeex;
                        Group_id_fk.Text = groupList.dataGridView1.Rows[indexAccInDatGrV].Cells[0].Value.ToString();
                        Group_name.Text = groupList.dataGridView1.Rows[indexAccInDatGrV].Cells[1].Value.ToString();
                        ItemType_id.Text = (Group_id_fk.Text != string.Empty ? itemsTypeSql.GetMaxIdItemType(Group_id_fk.Text) : string.Empty);



                    }
                }

            }


        }
     
        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        #endregion

        #endregion
      
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel_main_Paint(object sender, PaintEventArgs e)
        {

        }

      

        private void panFillUpUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_Main_Center_Center_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxAllCurr_Enter(object sender, EventArgs e)
        {

        }

        private void groupBoxData_Enter_1(object sender, EventArgs e)
        {

        }

        private void panel_Main_cenetr_up_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panUp_Paint_1(object sender, PaintEventArgs e)
        {

        }



        private void CurrName_TextChanged(object sender, EventArgs e)
        {

        }

       

       

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

       

        private void pictureclose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));

        }

        private void groupBoxOprea_Enter_1(object sender, EventArgs e)
        {

        }

        private void GroupType_Load(object sender, EventArgs e)
        {
            fillData("All");
            FormatingTextBoxAndButt("Load");
            dataGridView1.Select();
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SendDataToAddOrEdit(flagAddOrEdit);
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            flagAddOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Last", ItemType_id.Text));
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Next", ItemType_id.Text));
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

        private void ItemType_id_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Group_id_fk_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Group_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox(dataGridView1.CurrentCell.RowIndex);
        }

        private void Group_id_fk_KeyDown(object sender, KeyEventArgs e)
        {
            ShowListGroupStore(e);
        }

        private void Group_name_KeyDown(object sender, KeyEventArgs e)
        {
            ShowListGroupStore(e);
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Frist", ItemType_id.Text));
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Back", ItemType_id.Text));
        }

        private void Group_id_fk_TextChanged(object sender, EventArgs e)
        {
         
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (ItemType_id.Text != string.Empty)
                Delet();
        }
    }
}
