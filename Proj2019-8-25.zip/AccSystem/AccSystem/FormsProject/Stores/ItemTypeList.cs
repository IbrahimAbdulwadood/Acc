﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class ItemTypeList : Form
    {
       
        public ItemTypeList()
        {
            InitializeComponent();
            //this.UnitsId = UnitsId;
         
        }

       
        int i;
        static  public int indeex;
        public bool stateSelect = false;

        DataTable datatable;
        DataTable datatableGroup =new DataTable();
        ClassesProject.GroupStoredSQL groupClass = new ClassesProject.GroupStoredSQL();
        ClassesProject.ItemsTypesSQL itemsTyp = new ClassesProject.ItemsTypesSQL();

        private void ListCurrencyNamesForm_Load(object sender, EventArgs e)
        {
            datatableGroup = groupClass.GetAllGroup();
           
            /*
           [Group_id] ,[Group_name],[Acc_sales_fk] ,[Acc_purchases_cost_fk],
           [Acc_return_sales_fk] ,[Acc_return_purchases_fk] ,[Acc_discount_allow_fk] 
           ,[Acc_discount_gained_fk] ,[Acc_stored_fk] ,[Acc_quantity_free_fk]
           */
            if (datatableGroup.Rows.Count > 0)
            {
              
                    comboBox1.DataSource = datatableGroup;
                    comboBox1.ValueMember = datatableGroup.Columns[0].ToString();
                    comboBox1.DisplayMember = datatableGroup.Columns[1].ToString();
               


            }
          //لا يوجد مجموعات مخزنية }
               
                else
                {
                    bunifuThinButton21.Visible = false;
                    label1.Visible = true;
                panel2.Visible = true;
                    label1.Text = "لا يوجد مجموعات مخزنية";
                }




            





        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());
            if (dataGridView1.Rows.Count > 0)
            {
                indeex = dataGridView1.CurrentCell.RowIndex;
                stateSelect = true;
            }
            
            Close();
            //setIndex();

        }

        private void ItemGroupList_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
         
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
                datatable = new DataTable();
                dataGridView1.Rows.Clear();
            if (comboBox1.ValueMember != "") { 
            try
            {
                datatable = itemsTyp.GetAllItemTypeFromGroup(comboBox1.SelectedValue.ToString());


                if (datatable.Rows.Count > 0)
                {

                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add
                        (
                            datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString()

                         );
                    }


                }
            }
            catch (Exception ee) { MessageBox.Show(ee.ToString()); }
            }
        }
     
        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            datatable = new DataTable();
            dataGridView1.Rows.Clear();

            if (comboBox1.ValueMember != "")
            {
                try
                {
                   
                    datatable = itemsTyp.GetAllItemTypeFromGroup(comboBox1.SelectedValue.ToString());


                    if (datatable.Rows.Count > 0)
                    {
                        bunifuThinButton21.Visible = true;
                        label1.Visible = false;
                        panel2.Visible = false;
                        for (i = 0; i < datatable.Rows.Count; i++)
                        {
                            dataGridView1.Rows.Add
                            (
                                datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString()

                             );
                        }


                    }
                    else
                    {
                        bunifuThinButton21.Visible = false;
                          label1.Visible = true;
                        panel2.Visible = true;
                        label1.Text = "لا يوجد فئات لهذه المجموعة";
                    }
                }
                catch (Exception ee) { MessageBox.Show(ee.ToString()); }
            }
        
    
}
    }
}
