﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class ItemUnitList : Form
    {
        string[] UnitsId;
        public ItemUnitList(string[] UnitsId)
        {
            InitializeComponent();
            this.UnitsId = UnitsId;
         
        }

       
        int i;
      static  public int indeex;
        public bool stateSelect = true;
        DataTable datatable;
        ClassesProject.ItemsSQL itemsClass = new ClassesProject.ItemsSQL();
        private void ListCurrencyNamesForm_Load(object sender, EventArgs e)
        {
            datatable = itemsClass.GetAllUnit();
            bool b;
            if (datatable.Rows.Count > 0)
            {
                if (UnitsId != null)
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        b = true;
                        for (int j = 0; j < UnitsId.Length; j++)
                        {





                            if (UnitsId[j] == datatable.Rows[i][0].ToString())
                            {


                                b = false;
                            }



                        }
                        if (b)
                        {
                            dataGridView1.Rows.Add
                                (
                                datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString()
                              , datatable.Rows[i][2].ToString(), datatable.Rows[i][3].ToString()
                                );
                        }

                    }

                     if (dataGridView1.Rows.Count == 0)

                    {
                       // bunifuThinButton21.ButtonText = "لا يوجد عملات";
                        bunifuThinButton21.Visible = false;
                        label1.Visible = true;
                        label1.Text = "لا يوجد وحدات";
                    }

                   }
                else
                {
                    for (i = 0; i < datatable.Rows.Count; i++)
                    {
                        dataGridView1.Rows.Add(
                            datatable.Rows[i][0].ToString(), datatable.Rows[i][1].ToString(),
                            datatable.Rows[i][2].ToString(), datatable.Rows[i][3].ToString()
                            );
                    }

                }
            }

            


        }

       

       
       
       

        private void pictureClose_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            pictureClose.BackColor = Color.Red;
        }
       
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(dataGridView1.CurrentCell.RowIndex.ToString());
            indeex = dataGridView1.CurrentCell.RowIndex;
            Close();
            //setIndex();

        }
    }
}
