﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class Items : Form
    {
        public Items()
        {
            InitializeComponent();
        }



        #region جميع الدوال والمتغيرات

        #region المتغيرات
        DataTable dataTableItems;
        DataTable dataTableUnitsItim;

        List<string> ErrorAccNotSet = new List<string>();
         string flagAddOrEdit = "";
        string ItemType_id_fk_beforUpdate = "";

        ClassesProject.ItemsSQL itemClass = new ClassesProject.ItemsSQL();
        ItemUnitList listUnit;
        ItemTypeList groupList;

        #endregion

        #region الدوال

        #region التعامل مع قاعدة البيانات

        void fillData(string NormalOrSerch)
        {
            if (dataTableItems == null)
                dataTableItems = new DataTable();
            else
                dataTableItems = null;
            dataTableItems = new DataTable();

            if (NormalOrSerch == "All")
                //يستعلم عن جميع الصناديق 
                dataTableItems = itemClass.GetAllItems();

            else if (NormalOrSerch == "Serch")
                dataTableItems = itemClass.Serch(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridView1.Rows.Clear();

                for (int i = 0; i < dataTableItems.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add
                     (
                     dataTableItems.Rows[i][0].ToString(),
                     dataTableItems.Rows[i][1].ToString(),
                     dataTableItems.Rows[i][2].ToString(),
                     dataTableItems.Rows[i][3].ToString(),
                    dataTableItems.Rows[i][6].ToString(), 
                    dataTableItems.Rows[i][5].ToString()

                     );
                }
                if (dataGridView1.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    Item_id.Text = string.Empty;
                    Item_name.Text = string.Empty;
                    ItemType_id_fk.Text = string.Empty;
                    ItemType_name.Text = string.Empty;
                    Item_Serall.Text = string.Empty;
                    Item_No_From_Type.Text = string.Empty;
                    dataGridViewUnits.Rows.Clear();
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch { }

        }
        void Delet()
        {
            List<string> data = new List<string>();
            data = itemClass.ChaeckCanDelet(Item_id.Text);
            if (data.Count > 0)
            {
                MessageBox.Show("لا يمكن الحذف يوجد عمليات مرتبطة بهذا الصندوق", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (DialogResult.Yes == MessageBox.Show("؟تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                itemClass.Delet(Item_id.Text);
                fillData("All");

            }

        }
        void ShowUnitsItem(string idItem)
        {


            {
                string[] SumQuntityItem = new string[2];
                dataTableUnitsItim = itemClass.GetUintsItem(Item_id.Text);
               

                dataGridViewUnits.Rows.Clear();
                /*
                                                         dataTable
                idItemUnit , Unit_id_fk , Unit_name , Selling_price , Prime_cost , Minimum , Maxmum
                   [0]         [1]           [2]           [3]            [4]         [5]      [6]
                --------------------------------------------------------------------------------------
                                                          dataGridViwe
                idItemUnit  , Unit_id_fk , Unit_name , SumQuntityItem[0]= QuantityUnitNow , 
                SumQuntityItem[1]=QuantityPartNow , Selling_price , Prime_cost , Minimum , Maxmum
                
                */
                for (int i = 0; i < dataTableUnitsItim.Rows.Count; i++)
                {
                    SumQuntityItem = itemClass.GetSumQuntityItemUnitNow(dataTableUnitsItim.Rows[i][0].ToString());
                    // كميات الاصناف عن طريق جميع فواتير المبيعات وطرح المردودمنها وجمع المشتريات وطرح المردود منها عاده موش جاهز
                    dataGridViewUnits.Rows.Add
                        (
                        dataTableUnitsItim.Rows[i][0].ToString(), dataTableUnitsItim.Rows[i][1].ToString(),
                         dataTableUnitsItim.Rows[i][2].ToString(), SumQuntityItem[0], SumQuntityItem[1],
                         dataTableUnitsItim.Rows[i][3].ToString(), dataTableUnitsItim.Rows[i][4].ToString(),
                          dataTableUnitsItim.Rows[i][5].ToString(), dataTableUnitsItim.Rows[i][6].ToString(),
                          (bool)(dataTableUnitsItim.Rows[i][7])
                        );
                }
                //هنا داله الي تعبي العملات حق المستخدم
            }

        }

        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (Item_name.Text != string.Empty && ItemType_id_fk.Text != string.Empty)
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {

                        itemClass.InsertNewItem(Item_name.Text, ItemType_id_fk.Text);


                        //داله تخزن الحسابات الي ما حددها عشان ينبه المستخدم
                        //   SendAccNullToListError();

                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                        //عرض رسائل التنبية الخاصه ب الحساب الغير مربوطة
                        //  ShowMesgBoxWarningsAccNull();
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }


                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }



            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (Item_name.Text != string.Empty)
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        // SendAccNullToListError();
                        if(ItemType_id_fk_beforUpdate== ItemType_id_fk.Text)
                        itemClass.UpdateItem(Item_id.Text, Item_name.Text);
                        //يعدل الاسم فقط
                        else
                            itemClass.UpdateItemAll(Item_id.Text, Item_name.Text, ItemType_id_fk.Text);
                        for (int i = 0; i < dataGridViewUnits.Rows.Count; i++)
                        {
                            //MessageBox.Show(dataGridViewUnits.Rows[i].Cells[5].Value.ToString());
                            itemClass.UpdateUintsItem(
                               dataGridViewUnits.Rows[i].Cells[0].Value.ToString(),
                              dataGridViewUnits.Rows[i].Cells[5].Value.ToString(), //price
                              (dataGridViewUnits.Rows[i].Cells[7].Value.ToString() ==
                              string.Empty ? "NULL" : dataGridViewUnits.Rows[i].Cells[7].Value.ToString()),

                              (dataGridViewUnits.Rows[i].Cells[8].Value.ToString() ==
                              string.Empty ? "NULL" : dataGridViewUnits.Rows[i].Cells[8].Value.ToString()),
                              ((bool)(dataGridViewUnits.Rows[i].Cells[9].Value)==true?"1":"0")
                              );
                            #region ترتيب البيانات في الداتا جريت فيو حق الوحدات
                            /*
                                                         dataTable
                idItemUnit , Unit_id_fk , Unit_name , Selling_price , Prime_cost , Minimum , Maxmum
                   [0]         [1]           [2]           [3]            [4]         [5]      [6]
                --------------------------------------------------------------------------------------
                                                          dataGridViwe
                idItemUnit  , Unit_id_fk , Unit_name , SumQuntityItem[0]= QuantityUnitNow , 
                   [0]             [1]         [2]                          [3]
                SumQuntityItem[1]=QuantityPartNow , Selling_price , Prime_cost , Minimum , Maxmum
                  [4]                                   [5]             [6]       [7]       [8]
                */
                            #endregion
                        }

                        MessageBox.Show("تم التعديل بنجاح");
                        ShowMesgBoxWarningsAccNull();
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }

                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }


        #endregion

        #region التحكم بالواجهه
        void FillTextBox(int indexRows)
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (dataGridView1.Rows.Count > 0)
            {

                int i = indexRows;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */
                

                Item_id.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                Item_name.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                ItemType_id_fk.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                ItemType_name.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                Item_Serall.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
                Item_No_From_Type.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
                ShowUnitsItem(Item_id.Text);
                FillTextBoxCountRows((i + 1).ToString());

            }



        }
        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + dataGridView1.Rows.Count.ToString();
        }
        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                Item_name.ReadOnly = false;


                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                ItemType_name.ReadOnly = true;
                ItemType_id_fk.ReadOnly = true;


                /////////////////////
                txtSerch.ReadOnly = true;

                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
                /////////////////مستخدمين الصندوق//////////////////
                


                if (flagEditeOrAddOrSave == "Edite")
                {
                    buttAddUnit.Enabled = true;
                    buttAddUnit.Visible = true;
                    ItemType_id_fk_beforUpdate = ItemType_id_fk.Text;
                    // dataGridViewCurr.Columns[1].ReadOnly = false;
                    //  dataGridViewCurr.Columns[2].ReadOnly = false;
                    for (int i = 0; i < 9; i++)
                    {
                        if (i == 5 || i == 7 || i == 8)
                        {
                            dataGridViewUnits.Columns[i].ReadOnly = false;
                            //dataGridViewUnits.Columns[i].DefaultCellStyle.BackColor = Color.Aquamarine;
                            //dataGridViewUnits.Columns[i].HeaderText = "";
                            //dataGridViewUnits.Columns[i].DefaultCellStyle.ForeColor = Color.BurlyWood;
                        }
                    }
                   
                    dataGridViewUnits.SelectionMode = DataGridViewSelectionMode.CellSelect;
                    // Acc_sales_fk.ReadOnly = true;


                }


            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                Item_name.ReadOnly = true;



                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                ItemType_name.ReadOnly = true;
                ItemType_id_fk.ReadOnly = true;

                for(int i = 0; i < 9; i++)
                {   
                     dataGridViewUnits.Columns[i].ReadOnly = true;
                }

                dataGridViewUnits.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                ///////////////////
                txtSerch.ReadOnly = false;
                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;

                /////////////////////////
                txtSerch.Text = string.Empty;
                buttAddUnit.Enabled = false;
                buttAddUnit.Visible = false;

            }


        }
        void ForamtingAdd()
        {
            Item_id.Text = itemClass.GetMaxIdItem();
            Item_name.Text = string.Empty;
            ItemType_id_fk.Text = string.Empty;
            ItemType_name.Text = string.Empty;
            Item_Serall.Text = string.Empty;
            Item_No_From_Type.Text = string.Empty;
            Item_name.Focus();
            dataGridViewUnits.Rows.Clear();


        }
        int indexBoxsButt(string btName, string ItemId)
        {
            /*
            داله لايجاد اندكس العمله حسب رقم العمله
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (ItemId == dataGridView1.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < dataGridView1.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return dataGridView1.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد اصناف في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }
        void SendAccNullToListError()
        {
            //string mesg = "لن تستطيع استخدام الاصناف المرتبطة بهذه المجموعة لعدم اختيار الحساب المتأثر في القيود";
            //ErrorAccNotSet.Clear();
            //if (Acc_sales_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||فواتير المبيعات||  " + mesg + " || ");
            //if (Acc_purchases_cost_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||المشتريات||  " + mesg + " || ");
            //if (Acc_return_sales_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||مردود المبيعات||  " + mesg + " || ");
            //if (Acc_return_purchases_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||مردود المشتريات||  " + mesg + " || ");
            //if (Acc_discount_allow_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||الخصومات المسموح بها||  " + mesg + " || ");
            //if (Acc_discount_gained_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||الخصومات المكتسبة||  " + mesg + " || ");
            //if (Acc_stored_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||تكلفة المخزون الحالي||  " + mesg + " || ");
            //if (Acc_quantity_free_fk.Text == string.Empty)
            //    ErrorAccNotSet.Add(" ||الكميات المجانية||  " + mesg + " ||");

        }

        void ShowMesgBoxWarningsAccNull()
        {
            if (ErrorAccNotSet.Count > 0)
            {
                int i = ErrorAccNotSet.Count;
                // MessageBox.Show(ErrorAccNotSet.Count.ToString());
                foreach (var item in ErrorAccNotSet)
                {
                    MessageBox.Show(item, " تنبيـــة " + (--i), MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                ErrorAccNotSet.Clear();
            }
        }
        void ShowListGroupStore(KeyEventArgs e)
        {
            if (e.KeyData == Keys.F9)
            {
                if (flagAddOrEdit == "Add" || ((flagAddOrEdit == "Edite" && !itemClass.CanEditeIdGroup(Item_id.Text))))
                {

                    groupList = new ItemTypeList();
                    groupList.ShowDialog();


                    if (groupList.stateSelect && groupList.dataGridView1.RowCount > 0)
                    {
                        int indexAccInDatGrV = ItemTypeList.indeex;

                        ItemType_id_fk.Text = groupList.dataGridView1.Rows[indexAccInDatGrV].Cells[0].Value.ToString();
                        ItemType_name.Text = groupList.dataGridView1.Rows[indexAccInDatGrV].Cells[1].Value.ToString();




                    }
                }

            }


        }
        void ShowUnitsList()
        {

            /*

          * عرفنا مصفوفة فارغه لتخزين العملات الموجود للمستخدم
          * اذا كان معاه عملات
          * المصفوفة تاخذ حجم عدد العملات المتاحه للمستخدم
          * ونخزن فيها ارقام العملات مثل ما هو مبين في الفوريه
          * هئنا الابوكجت الخاص بواجه العملات وارسلنا لها العملات الي موجوده مع المسخدم
          * وعرضنا له الواجهه
          * 
     */

            string[] unitId = null;
            if (dataGridViewUnits.RowCount > 0)
            {
                unitId = new string[dataGridViewUnits.RowCount];
                for (int i = 0; i < dataGridViewUnits.RowCount; i++)
                {
                    unitId[i] = dataGridViewUnits.Rows[i].Cells[1].Value.ToString();
                }
            }

            listUnit = new ItemUnitList(unitId);
            listUnit.ShowDialog();

            /*
             * معي متغير داخل الواجهه حق العملات من نوع بولين اذا كان مفعل
             * و عدد الصفوف في الجريد حق العملات اكبر من 1 ادخل الشرط
             * 
        */

            if (listUnit.stateSelect && listUnit.dataGridView1.RowCount > 0)
            {
                int indexUserInDatGrV = ItemUnitList.indeex;
                /*
           *  اندكس العمله حسب الداتا جريت فيو
                 *  عشان نجيب رقمها كما مكتوب قي الاسفل* 
      */
                string idUnitsInDB = listUnit.dataGridView1.Rows[indexUserInDatGrV].Cells[0].Value.ToString();


                itemClass.InsertUnitToItem(idUnitsInDB, Item_id.Text);
                ShowUnitsItem(Item_id.Text);
            }
        }
        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(object sender ,KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }
        #region ايقاف الاحرف في الداتا جريت فيو
       
        void StopAlphaFromDataGridView_EditingControlShowing(DataGridViewEditingControlShowingEventArgs e, int IndexColums)
        {
            //used in even dataGridView_EditingControlShowing
            e.Control.KeyPress -= new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
            if (dataGridViewUnits.CurrentCell.ColumnIndex == IndexColums)
            {
                TextBox tb = e.Control as TextBox;
                if (tb != null)
                {
                    tb.KeyPress += new KeyPressEventHandler(StopAlphaInColumn_KeyPress);
                    //  tb.KeyPress+=new KeyPressEventHandler(StopAlphaInTextBox);
                }
            }


        }
        void StopAlphaInColumn_KeyPress(object sender, KeyPressEventArgs e)
        { //IsPunctuation الفواصل العشرية
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && !char.IsPunctuation(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        #endregion


        #endregion

        #endregion



        #endregion

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }





        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBoxData_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));


        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;

        }

        private void Items_Load(object sender, EventArgs e)
        {
            fillData("All");
            FormatingTextBoxAndButt("Load");
            dataGridView1.Select();
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void panUp_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxData_Enter_1(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
       
        private void buttAddUnit_Click(object sender, EventArgs e)
        {
            ShowUnitsList();
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SendDataToAddOrEdit(flagAddOrEdit);
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            flagAddOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Last", Item_id.Text));
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Next", Item_id.Text));
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

        private void Item_id_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void Group_id_fk_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void Group_name_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox(dataGridView1.CurrentCell.RowIndex);
        }
     
        private void Group_id_fk_KeyDown(object sender, KeyEventArgs e)
        {
            ShowListGroupStore(e);
        }

        private void Group_name_KeyDown(object sender, KeyEventArgs e)
        {
            ShowListGroupStore(e);
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Frist", Item_id.Text));
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            dataGridView1.ClearSelection();
            FillTextBox(indexBoxsButt("Back", Item_id.Text));
        }

        private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;

        }

        private void dataGridViewUnits_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (Item_id.Text != string.Empty)
                Delet();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void dataGridViewUnits_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            
        }
        #region   ايقاف الاحرف في الداتا جريت فيو العمود 5
       
        private void dataGridViewUnits_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            StopAlphaFromDataGridView_EditingControlShowing(e, 5);
        }

        #endregion
        AddQun AddQun;
        private void btnAddQun_Click(object sender, EventArgs e)
        {
            AddQun = new AddQun(Item_id.Text);
            AddQun.ShowDialog();
        }
    }
}
