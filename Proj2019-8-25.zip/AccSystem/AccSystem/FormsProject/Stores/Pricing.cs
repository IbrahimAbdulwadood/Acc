﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;
namespace AccSystem.FormsProject.Stores
{
    public partial class Pricing : Form
    {
        string[] AccPricingExist;
        public Pricing()
        {
            InitializeComponent();
        }
        int i;
        static public int indeex;
        public bool stateSelect = true;
        DataTable datatable = new DataTable();
        ClassesProject.ItemsSQL itemsql = new ClassesProject.ItemsSQL();
        ConnectionDB con = new ConnectionDB();

        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        //////////////////////////////////////////////////////////////////////
        List<string> idItemUnit = new List<string>();

        DataTable Push(bool b)
        {
            //الداله اذا استقبلت فوولس يعني يشتي جميع الاصناف
            //اذا استقبلت ترووو تشتي اصناف محددة
            idItemUnit.Clear();
            //عرفنا ليسته عشان تحفظ ارقام الاصناف الي حددناهم
            #region اذا اشتي اصناف محدد
            if (b) //اذا كان تروو يعني يشتي اصناف محددة
                if (dataGridView1.RowCount > 0)
                {
                    //يتاكد قبل ما يدخل هل في عناصر عشان يحددهم
                    //اذا كان في عناصر نعبيهم في اللسته الي عرفناه فوق
                    //اذا كان في اصناف في الدتا جريت
                    for (int i = 0; i < dataGridView1.RowCount; i++)
                    {
                        if (Convert.ToBoolean(dataGridView1.Rows[i].Cells[4].Value) == true)
                        { //اذا كان مؤشر على هذا الصنف ضيفه
                            idItemUnit.Add(dataGridView1.Rows[i].Cells[5].Value.ToString());
                        }
                    }
                }
            #endregion
            string
                quary = " SELECT   ";
            quary += " Items.barc, ";
            quary += " Items.Item_name, ";
            quary += " Units.Unit_name, ";
            quary += " ItemUnit.Selling_price, ";
            quary += " ItemUnit.idItemUnit ";
            quary += " FROM  ";
            quary += "  Items INNER JOIN ";
            quary += "  ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN ";
            quary += "  Units ON ItemUnit.Unit_id_fk = Units.Unit_id ";
            #region اذا اشتي اصناف محددة
            if (b)
            {
                quary += "  WHERE        (ItemUnit.idItemUnit in( ";
                if (idItemUnit.Count > 0) //اذا كان حجم اللسته اكبر من الصفر
                {
                    quary += idItemUnit[0];
                    for (int i = 1; i < idItemUnit.Count; i++)
                        quary += " ," + idItemUnit[i];
                }
                else  //اذا اللسته فاضي
                    quary += "-1";
                quary += " )) ";
            }
            #endregion
            quary += " order by  Items.barc  ";

           // MessageBox.Show(quary);
            con.OpenConnetion();
            DataTable dt = con.Query(quary, true);
            con.CloseConnetion();

            return dt;
            #region الاستعلام
            /*

SELECT   Items.barc, Items.Item_name, Units.Unit_name, ItemUnit.Selling_price
FROM    Items INNER JOIN
       ItemUnit ON Items.Item_id = ItemUnit.Item_id_fk INNER JOIN
     Units ON ItemUnit.Unit_id_fk = Units.Unit_id
       WHERE  (ItemUnit.idItemUnit in(1,2,3,4,5))
        order by  Items.barc

        */
            #endregion



        }
        /// <summary>
        /// ///////////////////////////////
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            stateSelect = false;
            this.Close();
        }

        private void pictureclose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));

        }

        private void Pricing_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet4.DataTable1' table. You can move, or remove it, as needed.
        // this.dataTable1TableAdapter.Fill(this.dataSet4.DataTable1);


            Push(false);
            dataGridView1.Rows.Clear();
            datatable = Push(false);
          //  dataGridView1.DataSource = datatable;
            if (datatable.Rows.Count > 0)
            {
                for (int i = 0; i < datatable.Rows.Count; i++)
                    dataGridView1.Rows.Add
                        (
                       datatable.Rows[i][0].ToString(),
                        datatable.Rows[i][1].ToString(),
                         datatable.Rows[i][2].ToString(),
                          datatable.Rows[i][3].ToString(),
                            null,
                            datatable.Rows[i][4].ToString()
                        );
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    dataGridView1.Rows[i].Cells[4].ReadOnly = false;
            }

        }
        
           
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           


        }

   

     

        private void button2_Click(object sender, EventArgs e)
        {

            dataGridView2.Rows.Clear();
            datatable = Push(true);
            if (datatable.Rows.Count > 0)
            {
                for (int i = 0; i < datatable.Rows.Count; i++)
                    dataGridView2.Rows.Add
                        (
                       datatable.Rows[i][0].ToString(),
                         datatable.Rows[i][1].ToString(),
                        datatable.Rows[i][2].ToString(),
                         datatable.Rows[i][3].ToString(),
                            datatable.Rows[i][4].ToString()
                        );

            }

            Reports.Items t = new Reports.Items();
            t.SetDataSource(datatable);
            Reports.frm_Reports f = new Reports.frm_Reports();
            f.crystalReportViewer1.ReportSource = t;
            f.ShowDialog();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Reports.AllP item = new Reports.AllP();
            Reports.frm_Reports f = new Reports.frm_Reports();
            f.crystalReportViewer1.ReportSource = item;
            f.ShowDialog();
        }
    }
}
