﻿namespace AccSystem.FormsProject.Stores
{
    partial class Stocking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Stocking));
            this.panel_main = new System.Windows.Forms.Panel();
            this.groupBoxOprea = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panFillUpUp = new System.Windows.Forms.Panel();
            this.panel_Main_Center_Center = new System.Windows.Forms.Panel();
            this.groupBoxAllCurr = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel_Main_cenetr_up = new System.Windows.Forms.Panel();
            this.groupBoxData = new System.Windows.Forms.GroupBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.date1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.CurrId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panUp = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.bunifuTileButton2 = new Bunifu.Framework.UI.BunifuTileButton();
            this.bunifuTileButton1 = new Bunifu.Framework.UI.BunifuTileButton();
            this.buttNext = new Bunifu.Framework.UI.BunifuTileButton();
            this.buttLast = new Bunifu.Framework.UI.BunifuTileButton();
            this.buttFrist = new Bunifu.Framework.UI.BunifuTileButton();
            this.buttBack = new Bunifu.Framework.UI.BunifuTileButton();
            this.buttDelete = new Bunifu.Framework.UI.BunifuTileButton();
            this.butSave = new Bunifu.Framework.UI.BunifuTileButton();
            this.buttEdite = new Bunifu.Framework.UI.BunifuTileButton();
            this.buttAdd = new Bunifu.Framework.UI.BunifuTileButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.panel_main.SuspendLayout();
            this.groupBoxOprea.SuspendLayout();
            this.panFillUpUp.SuspendLayout();
            this.panel_Main_Center_Center.SuspendLayout();
            this.groupBoxAllCurr.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_Main_cenetr_up.SuspendLayout();
            this.groupBoxData.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_main
            // 
            this.panel_main.Controls.Add(this.groupBoxOprea);
            this.panel_main.Controls.Add(this.panel1);
            this.panel_main.Controls.Add(this.panFillUpUp);
            this.panel_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_main.Location = new System.Drawing.Point(0, 0);
            this.panel_main.Name = "panel_main";
            this.panel_main.Size = new System.Drawing.Size(986, 548);
            this.panel_main.TabIndex = 0;
            this.panel_main.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_main_Paint);
            // 
            // groupBoxOprea
            // 
            this.groupBoxOprea.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxOprea.Controls.Add(this.bunifuTileButton2);
            this.groupBoxOprea.Controls.Add(this.bunifuTileButton1);
            this.groupBoxOprea.Controls.Add(this.textBox3);
            this.groupBoxOprea.Controls.Add(this.buttNext);
            this.groupBoxOprea.Controls.Add(this.buttLast);
            this.groupBoxOprea.Controls.Add(this.buttFrist);
            this.groupBoxOprea.Controls.Add(this.buttBack);
            this.groupBoxOprea.Controls.Add(this.buttDelete);
            this.groupBoxOprea.Controls.Add(this.butSave);
            this.groupBoxOprea.Controls.Add(this.buttEdite);
            this.groupBoxOprea.Controls.Add(this.buttAdd);
            this.groupBoxOprea.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBoxOprea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxOprea.ForeColor = System.Drawing.Color.Black;
            this.groupBoxOprea.Location = new System.Drawing.Point(0, 379);
            this.groupBoxOprea.Name = "groupBoxOprea";
            this.groupBoxOprea.Size = new System.Drawing.Size(986, 136);
            this.groupBoxOprea.TabIndex = 37;
            this.groupBoxOprea.TabStop = false;
            this.groupBoxOprea.Text = "العمليات";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox3.Enabled = false;
            this.textBox3.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(179, 49);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(114, 33);
            this.textBox3.TabIndex = 8;
            this.textBox3.Text = "111-1111";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 515);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(986, 33);
            this.panel1.TabIndex = 36;
            // 
            // panFillUpUp
            // 
            this.panFillUpUp.Controls.Add(this.panel_Main_Center_Center);
            this.panFillUpUp.Controls.Add(this.panel_Main_cenetr_up);
            this.panFillUpUp.Controls.Add(this.panUp);
            this.panFillUpUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panFillUpUp.Location = new System.Drawing.Point(0, 0);
            this.panFillUpUp.Name = "panFillUpUp";
            this.panFillUpUp.Size = new System.Drawing.Size(986, 376);
            this.panFillUpUp.TabIndex = 35;
            this.panFillUpUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panFillUpUp_Paint);
            // 
            // panel_Main_Center_Center
            // 
            this.panel_Main_Center_Center.Controls.Add(this.groupBoxAllCurr);
            this.panel_Main_Center_Center.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main_Center_Center.Location = new System.Drawing.Point(0, 174);
            this.panel_Main_Center_Center.Name = "panel_Main_Center_Center";
            this.panel_Main_Center_Center.Size = new System.Drawing.Size(986, 202);
            this.panel_Main_Center_Center.TabIndex = 45;
            this.panel_Main_Center_Center.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Main_Center_Center_Paint);
            // 
            // groupBoxAllCurr
            // 
            this.groupBoxAllCurr.Controls.Add(this.dataGridView1);
            this.groupBoxAllCurr.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxAllCurr.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxAllCurr.Location = new System.Drawing.Point(0, 0);
            this.groupBoxAllCurr.Name = "groupBoxAllCurr";
            this.groupBoxAllCurr.Size = new System.Drawing.Size(986, 202);
            this.groupBoxAllCurr.TabIndex = 1;
            this.groupBoxAllCurr.TabStop = false;
            this.groupBoxAllCurr.Text = "تفاصيل الجـرد";
            this.groupBoxAllCurr.Enter += new System.EventHandler(this.groupBoxAllCurr_Enter);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column8,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column7,
            this.Column5,
            this.Column6,
            this.Column1});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 19);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(980, 180);
            this.dataGridView1.TabIndex = 41;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column8
            // 
            this.Column8.HeaderText = "رقم الجرد";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Visible = false;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "المخزن";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "الكمية الافتراضية وحدة";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "الكمية الافتراضية جزء";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "الكمية  الفعلية وحدة";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "الكمية  الفعلية جزء";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "العجز وحدة";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "العجز جزء";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Visible = false;
            // 
            // panel_Main_cenetr_up
            // 
            this.panel_Main_cenetr_up.Controls.Add(this.groupBoxData);
            this.panel_Main_cenetr_up.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Main_cenetr_up.Location = new System.Drawing.Point(0, 44);
            this.panel_Main_cenetr_up.Name = "panel_Main_cenetr_up";
            this.panel_Main_cenetr_up.Size = new System.Drawing.Size(986, 130);
            this.panel_Main_cenetr_up.TabIndex = 44;
            this.panel_Main_cenetr_up.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Main_cenetr_up_Paint);
            // 
            // groupBoxData
            // 
            this.groupBoxData.Controls.Add(this.dateTimePicker2);
            this.groupBoxData.Controls.Add(this.label10);
            this.groupBoxData.Controls.Add(this.textBox8);
            this.groupBoxData.Controls.Add(this.date1);
            this.groupBoxData.Controls.Add(this.label7);
            this.groupBoxData.Controls.Add(this.textBox5);
            this.groupBoxData.Controls.Add(this.label6);
            this.groupBoxData.Controls.Add(this.textBox4);
            this.groupBoxData.Controls.Add(this.textBox2);
            this.groupBoxData.Controls.Add(this.label3);
            this.groupBoxData.Controls.Add(this.CurrId);
            this.groupBoxData.Controls.Add(this.label2);
            this.groupBoxData.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxData.ForeColor = System.Drawing.Color.Black;
            this.groupBoxData.Location = new System.Drawing.Point(0, 0);
            this.groupBoxData.Name = "groupBoxData";
            this.groupBoxData.Size = new System.Drawing.Size(986, 128);
            this.groupBoxData.TabIndex = 39;
            this.groupBoxData.TabStop = false;
            this.groupBoxData.Text = "البيانات";
            this.groupBoxData.Enter += new System.EventHandler(this.groupBoxData_Enter_1);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.AllowDrop = true;
            this.dateTimePicker2.CalendarMonthBackground = System.Drawing.Color.Silver;
            this.dateTimePicker2.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker2.Location = new System.Drawing.Point(573, 93);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(172, 23);
            this.dateTimePicker2.TabIndex = 38;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(513, 98);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(45, 16);
            this.label10.TabIndex = 31;
            this.label10.Text = "البيان:";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.Color.Silver;
            this.textBox8.ForeColor = System.Drawing.Color.Black;
            this.textBox8.Location = new System.Drawing.Point(196, 90);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(311, 24);
            this.textBox8.TabIndex = 30;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // date1
            // 
            this.date1.AutoSize = true;
            this.date1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.date1.ForeColor = System.Drawing.Color.Black;
            this.date1.Location = new System.Drawing.Point(751, 93);
            this.date1.Name = "date1";
            this.date1.Size = new System.Drawing.Size(54, 16);
            this.date1.TabIndex = 27;
            this.date1.Text = "التـاريخ:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(453, 63);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 16);
            this.label7.TabIndex = 25;
            this.label7.Text = "إجمالي عجز:";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.Color.Silver;
            this.textBox5.ForeColor = System.Drawing.Color.Black;
            this.textBox5.Location = new System.Drawing.Point(277, 55);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(167, 24);
            this.textBox5.TabIndex = 24;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(751, 60);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 16);
            this.label6.TabIndex = 23;
            this.label6.Text = "إجمالي زيادة:";
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.Color.Silver;
            this.textBox4.ForeColor = System.Drawing.Color.Black;
            this.textBox4.Location = new System.Drawing.Point(573, 60);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(172, 24);
            this.textBox4.TabIndex = 22;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.Gray;
            this.textBox2.ForeColor = System.Drawing.Color.White;
            this.textBox2.Location = new System.Drawing.Point(277, 25);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(167, 24);
            this.textBox2.TabIndex = 17;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(453, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 16);
            this.label3.TabIndex = 18;
            this.label3.Text = "المخزن:";
            // 
            // CurrId
            // 
            this.CurrId.BackColor = System.Drawing.Color.Gray;
            this.CurrId.ForeColor = System.Drawing.Color.White;
            this.CurrId.Location = new System.Drawing.Point(573, 25);
            this.CurrId.Multiline = true;
            this.CurrId.Name = "CurrId";
            this.CurrId.ReadOnly = true;
            this.CurrId.Size = new System.Drawing.Size(172, 24);
            this.CurrId.TabIndex = 1;
            this.CurrId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.CurrId.TextChanged += new System.EventHandler(this.CurrId_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(751, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "رقم الجـرد:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.pictureBox1);
            this.panUp.Controls.Add(this.pictureBox2);
            this.panUp.Controls.Add(this.label1);
            this.panUp.Controls.Add(this.textBox1);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(986, 44);
            this.panUp.TabIndex = 43;
            this.panUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panUp_Paint_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(806, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 27);
            this.label1.TabIndex = 9;
            this.label1.Text = "الجـــرد";
            this.label1.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.DimGray;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(50, 6);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(316, 24);
            this.textBox1.TabIndex = 8;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // bunifuTileButton2
            // 
            this.bunifuTileButton2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuTileButton2.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuTileButton2.colorActive = System.Drawing.Color.SteelBlue;
            this.bunifuTileButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTileButton2.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton2.Image")));
            this.bunifuTileButton2.ImagePosition = 15;
            this.bunifuTileButton2.ImageZoom = 50;
            this.bunifuTileButton2.LabelPosition = 31;
            this.bunifuTileButton2.LabelText = "طباعة";
            this.bunifuTileButton2.Location = new System.Drawing.Point(515, 18);
            this.bunifuTileButton2.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton2.Name = "bunifuTileButton2";
            this.bunifuTileButton2.Size = new System.Drawing.Size(66, 100);
            this.bunifuTileButton2.TabIndex = 12;
            // 
            // bunifuTileButton1
            // 
            this.bunifuTileButton1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuTileButton1.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bunifuTileButton1.colorActive = System.Drawing.Color.SteelBlue;
            this.bunifuTileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTileButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton1.Image")));
            this.bunifuTileButton1.ImagePosition = 15;
            this.bunifuTileButton1.ImageZoom = 50;
            this.bunifuTileButton1.LabelPosition = 31;
            this.bunifuTileButton1.LabelText = "ترحيل";
            this.bunifuTileButton1.Location = new System.Drawing.Point(595, 19);
            this.bunifuTileButton1.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton1.Name = "bunifuTileButton1";
            this.bunifuTileButton1.Size = new System.Drawing.Size(66, 100);
            this.bunifuTileButton1.TabIndex = 11;
            // 
            // buttNext
            // 
            this.buttNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.colorActive = System.Drawing.Color.Gray;
            this.buttNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttNext.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttNext.ForeColor = System.Drawing.Color.White;
            this.buttNext.Image = ((System.Drawing.Image)(resources.GetObject("buttNext.Image")));
            this.buttNext.ImagePosition = 15;
            this.buttNext.ImageZoom = 50;
            this.buttNext.LabelPosition = 31;
            this.buttNext.LabelText = "التالي";
            this.buttNext.Location = new System.Drawing.Point(302, 19);
            this.buttNext.Margin = new System.Windows.Forms.Padding(6);
            this.buttNext.Name = "buttNext";
            this.buttNext.Size = new System.Drawing.Size(66, 100);
            this.buttNext.TabIndex = 7;
            // 
            // buttLast
            // 
            this.buttLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.colorActive = System.Drawing.Color.Gray;
            this.buttLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttLast.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttLast.ForeColor = System.Drawing.Color.White;
            this.buttLast.Image = ((System.Drawing.Image)(resources.GetObject("buttLast.Image")));
            this.buttLast.ImagePosition = 15;
            this.buttLast.ImageZoom = 50;
            this.buttLast.LabelPosition = 31;
            this.buttLast.LabelText = "الاخير";
            this.buttLast.Location = new System.Drawing.Point(28, 19);
            this.buttLast.Margin = new System.Windows.Forms.Padding(6);
            this.buttLast.Name = "buttLast";
            this.buttLast.Size = new System.Drawing.Size(66, 100);
            this.buttLast.TabIndex = 6;
            // 
            // buttFrist
            // 
            this.buttFrist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.colorActive = System.Drawing.Color.Gray;
            this.buttFrist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFrist.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttFrist.ForeColor = System.Drawing.Color.White;
            this.buttFrist.Image = ((System.Drawing.Image)(resources.GetObject("buttFrist.Image")));
            this.buttFrist.ImagePosition = 15;
            this.buttFrist.ImageZoom = 50;
            this.buttFrist.LabelPosition = 31;
            this.buttFrist.LabelText = "الاول";
            this.buttFrist.Location = new System.Drawing.Point(378, 19);
            this.buttFrist.Margin = new System.Windows.Forms.Padding(6);
            this.buttFrist.Name = "buttFrist";
            this.buttFrist.Size = new System.Drawing.Size(66, 100);
            this.buttFrist.TabIndex = 5;
            // 
            // buttBack
            // 
            this.buttBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.colorActive = System.Drawing.Color.Gray;
            this.buttBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBack.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttBack.ForeColor = System.Drawing.Color.White;
            this.buttBack.Image = ((System.Drawing.Image)(resources.GetObject("buttBack.Image")));
            this.buttBack.ImagePosition = 15;
            this.buttBack.ImageZoom = 50;
            this.buttBack.LabelPosition = 31;
            this.buttBack.LabelText = "السابق";
            this.buttBack.Location = new System.Drawing.Point(104, 19);
            this.buttBack.Margin = new System.Windows.Forms.Padding(6);
            this.buttBack.Name = "buttBack";
            this.buttBack.Size = new System.Drawing.Size(66, 100);
            this.buttBack.TabIndex = 4;
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.colorActive = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.ImagePosition = 15;
            this.buttDelete.ImageZoom = 50;
            this.buttDelete.LabelPosition = 31;
            this.buttDelete.LabelText = "حذف";
            this.buttDelete.Location = new System.Drawing.Point(673, 19);
            this.buttDelete.Margin = new System.Windows.Forms.Padding(6);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(66, 100);
            this.buttDelete.TabIndex = 3;
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.ImagePosition = 15;
            this.butSave.ImageZoom = 50;
            this.butSave.LabelPosition = 31;
            this.butSave.LabelText = "حفظ";
            this.butSave.Location = new System.Drawing.Point(829, 19);
            this.butSave.Margin = new System.Windows.Forms.Padding(6);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(66, 100);
            this.butSave.TabIndex = 2;
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.colorActive = System.Drawing.Color.Gray;
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.ImagePosition = 15;
            this.buttEdite.ImageZoom = 50;
            this.buttEdite.LabelPosition = 31;
            this.buttEdite.LabelText = "تعديل";
            this.buttEdite.Location = new System.Drawing.Point(751, 19);
            this.buttEdite.Margin = new System.Windows.Forms.Padding(6);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(66, 100);
            this.buttEdite.TabIndex = 1;
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.color = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.ImagePosition = 15;
            this.buttAdd.ImageZoom = 50;
            this.buttAdd.LabelPosition = 31;
            this.buttAdd.LabelText = "جديد";
            this.buttAdd.Location = new System.Drawing.Point(907, 19);
            this.buttAdd.Margin = new System.Windows.Forms.Padding(6);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(66, 100);
            this.buttAdd.TabIndex = 0;
            // 
            // pictureBox1
            // 
        //    this.pictureBox1.Image = global::AccSystem.Properties.Resources.Refresh_50px;
            this.pictureBox1.Location = new System.Drawing.Point(888, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 34);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::AccSystem.Properties.Resources.Search_32px;
            this.pictureBox2.Location = new System.Drawing.Point(382, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 27);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(12, 3);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 27);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 7;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            this.pictureClose.MouseHover += new System.EventHandler(this.pictureclose_MouseHover);
            // 
            // Stocking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 548);
            this.Controls.Add(this.panel_main);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Stocking";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Text = "Customers";
            this.panel_main.ResumeLayout(false);
            this.groupBoxOprea.ResumeLayout(false);
            this.groupBoxOprea.PerformLayout();
            this.panFillUpUp.ResumeLayout(false);
            this.panel_Main_Center_Center.ResumeLayout(false);
            this.groupBoxAllCurr.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_Main_cenetr_up.ResumeLayout(false);
            this.groupBoxData.ResumeLayout(false);
            this.groupBoxData.PerformLayout();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_main;
        private System.Windows.Forms.Panel panFillUpUp;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.Panel panel_Main_Center_Center;
        private System.Windows.Forms.Panel panel_Main_cenetr_up;
        private System.Windows.Forms.GroupBox groupBoxData;
        private System.Windows.Forms.TextBox CurrId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxAllCurr;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label date1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBoxOprea;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton2;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton1;
        private System.Windows.Forms.TextBox textBox3;
        private Bunifu.Framework.UI.BunifuTileButton buttNext;
        private Bunifu.Framework.UI.BunifuTileButton buttLast;
        private Bunifu.Framework.UI.BunifuTileButton buttFrist;
        private Bunifu.Framework.UI.BunifuTileButton buttBack;
        private Bunifu.Framework.UI.BunifuTileButton buttDelete;
        private Bunifu.Framework.UI.BunifuTileButton butSave;
        private Bunifu.Framework.UI.BunifuTileButton buttEdite;
        private Bunifu.Framework.UI.BunifuTileButton buttAdd;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}