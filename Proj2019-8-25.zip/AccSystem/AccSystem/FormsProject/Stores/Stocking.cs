﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class Stocking : Form
    {
        public Stocking()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel_main_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxOprea_Enter(object sender, EventArgs e)
        {

        }

        private void buttNext_Click(object sender, EventArgs e)
        {

        }

        private void buttLast_Click(object sender, EventArgs e)
        {

        }

        private void buttFrist_Click(object sender, EventArgs e)
        {

        }

        private void buttBack_Click(object sender, EventArgs e)
        {

        }

        private void buttDelete_Click(object sender, EventArgs e)
        {

        }

        private void butSave_Click(object sender, EventArgs e)
        {

        }

        private void buttEdite_Click(object sender, EventArgs e)
        {

        }

        private void buttAdd_Click(object sender, EventArgs e)
        {

        }

        private void panFillUpUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_Main_Center_Center_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxAllCurr_Enter(object sender, EventArgs e)
        {

        }

        private void groupBoxData_Enter_1(object sender, EventArgs e)
        {

        }

        private void panel_Main_cenetr_up_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panUp_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void CurrId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void CurrName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureclose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));

        }
    }
}
