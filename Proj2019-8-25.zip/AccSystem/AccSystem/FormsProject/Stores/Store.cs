﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using AccSystem.ClassesProject;
namespace AccSystem.FormsProject.Stores

{
    public partial class Store : Form
    {
        StoreSql storesql = new StoreSql();
        DataTable dataTable;
        public string flagAddOrEdit = "";
         

        public Store()
        {
            InitializeComponent();
           
        }
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }

        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        void MoveForm(MouseEventArgs e)
        {

            ///      نعملها في الحدث ماوووس داون//داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        private void SendMessage(IntPtr handle, object wM_NCLBUTTONDOWN, object hT_CAPTION, int v)
        {
            throw new NotImplementedException();
        }

        void FillTextBox()
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            int i = dataGridView1.CurrentCell.RowIndex;

            /*
              يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
              i
            
            */

            storesId.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            StoresName.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textaddrass.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            txtPhone.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            textnote.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();

            FillTextBoxCountRows((i + 1).ToString());



        }
       void fillData(string NormalOrSerch)
        {

            dataTable = new DataTable();
            if (NormalOrSerch == "All")
                //يستعلم عن جميع المخازن
                dataTable = storesql.GetAllStores();
            else if (NormalOrSerch == "Serch")
                dataTable = storesql.Serch(txtSerch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridView1.Rows.Clear();

                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString(), dataTable.Rows[i][4].ToString());
                }
                if (dataGridView1.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                   storesId.Text = string.Empty;
                 StoresName.Text = string.Empty;
                  textaddrass.Text = string.Empty;
                    txtPhone.Text = string.Empty;
                   textnote.Text = string.Empty;
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch { }

        }
        

        
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (StoresName.Text != string.Empty && textaddrass.Text != string.Empty )
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                       
                      storesql.InsertNewStores(storesId.Text, StoresName.Text, textaddrass.Text,txtPhone.Text, textnote.Text);

                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }


                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }



            }
            else if (flagAddOrEditLo == "Edite")
            {
                if (StoresName.Text != string.Empty && textaddrass.Text != string.Empty)
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                       storesql.UpdateStore(storesId.Text, StoresName.Text, textaddrass.Text,txtPhone.Text, textnote.Text);
                        MessageBox.Show("تم التعديل بنجاح");
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }

                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if

        }

        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)
        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات
                StoresName.ReadOnly = false;
                textaddrass.ReadOnly = false;
                txtPhone.ReadOnly = false;
                textnote.ReadOnly = false;
                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;


            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
               
                StoresName.ReadOnly = true;
                textaddrass.ReadOnly = true;
                txtPhone.ReadOnly = true;
                textnote.ReadOnly = true;
                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;

            }


        }
        void ForamtingAdd()
        {
            storesId.Text = storesql.GetMaxId();
            StoresName.Text = "";
            textaddrass.Text = "";
            txtPhone.Text = "";
            textnote.Text = "";
      

 



        }

        void FillTextBoxFromButtMove(int i)
        {
            if (i >= 0)
            {
                dataGridView1.ClearSelection();
                storesId.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                StoresName.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                textaddrass.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                txtPhone.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                textnote.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();




                FillTextBoxCountRows((i + 1).ToString());
            }
        }
        int indexCurrButt(string btName, string storeId)
        {
            /*
            داله لايجاد اندكس المخزن حسب رقم المخزن
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (storeId == dataGridView1.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < dataGridView1.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    return dataGridView1.Rows.Count - 1;
                }
                else return -1;
            }
            else MessageBox.Show("لا يوجد مخازن في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }

        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + dataGridView1.Rows.Count.ToString();
        }

        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel_main_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxOprea_Enter(object sender, EventArgs e)
        {

        }

        private void buttNext_Click(object sender, EventArgs e)
        {

        }

        private void buttLast_Click(object sender, EventArgs e)
        {

        }

        private void buttFrist_Click(object sender, EventArgs e)
        {

        }

        private void buttBack_Click(object sender, EventArgs e)
        {

        }

        private void buttDelete_Click(object sender, EventArgs e)
        {

        }

        private void panFillUpUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_Main_Center_Center_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxAllCurr_Enter(object sender, EventArgs e)
        {

        }

        private void groupBoxData_Enter_1(object sender, EventArgs e)
        {

        }

        private void panel_Main_cenetr_up_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panUp_Paint_1(object sender, PaintEventArgs e)
        {

        }


        
        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void CurrId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void CurrName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureclose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));

        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void butSave_Click(object sender, EventArgs e)
        {



            SendDataToAddOrEdit(flagAddOrEdit);
        }

        private void Store_Load(object sender, EventArgs e)

        {
            fillData("All");
            FormatingTextBoxAndButt("Load");
            dataGridView1.Select();

        }

        private void buttEdite_Click(object sender, EventArgs e)
        {
            flagAddOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Down || e.KeyData == Keys.Up)
            {
                if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                    FillTextBox();
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void buttFrist_Click_1(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCurrButt("Frist", storesId.Text));


        }

        private void buttLast_Click_1(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCurrButt("Last", storesId.Text));

        }

        private void buttNext_Click_1(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCurrButt("Next", storesId.Text));

        }

        private void buttBack_Click_1(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexCurrButt("Back", storesId.Text));


        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {

            MoveForm(e);
        }

        private void storesId_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void StoresName_Enter(object sender, EventArgs e)
        {

            //تحويل اللغه عند الضغط ع التكست بوكس الى عربي 
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {

            StopAlphaInTextBox(e);
        }

        private void textaddrass_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopNumberInTextBox(e);
        }

        private void StoresName_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopNumberInTextBox(e);
        }

        private void txtSerch_TextChanged(object sender, EventArgs e)
        {
             fillData("Serch");
        }
    }
}
