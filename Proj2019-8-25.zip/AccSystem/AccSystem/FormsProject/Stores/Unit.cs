﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Stores
{
    public partial class Unit : Form
    {
        ClassesProject.UnitSql unitClass = new ClassesProject.UnitSql();
        DataTable dataTable;
        public string flagAddOrEdit = "";
        public Unit()
        {
            InitializeComponent();
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// داله خارجية تستقبل اسم اللغه و تحولها حسب الطلب و تستدعى عند الحدث انتر وليف
        /// </summary>
        /// <param name="inputName"></param>
        /// <returns></returns>
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }

        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }


        /////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>                                                                                  ///
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس                                        ///
        ///                                                                                           ///
        /// </summary>                                                                               ///
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        void MoveForm(MouseEventArgs e)
        {

            ///      نعملها في الحدث ماوووس داون//داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        /// 
        /// 
        /// <param name="e"></param>


        /// <summary>
        /// 
        /// 
        /// </summary>
        void FillTextBox()
        {
            /*
            المتغير
            i
            يحفظ رقم الصف المؤشر عليه
            
            */
            if (dataGridView1.Rows.Count > 0)
            {

                int i = dataGridView1.CurrentCell.RowIndex;

                /*
                  يعبي كل تكست ب قيمتها من الداتا جريت فيو حسب قيمة المتغير 
                  i

                */


                txtid.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                txtname.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                txtrf.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                txtpart.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();

                FillTextBoxCountRows((i + 1).ToString());
            }
        }



       
        /// </summary>
        void fillData(string NormalOrSerch)
        {

            dataTable = new DataTable();
            if (NormalOrSerch == "All")
                //يستعلم عن جميع الوحدات
                dataTable = unitClass.GetAllUnit();
            else if (NormalOrSerch == "Serch")
                dataTable = unitClass.Serch(txtSearch.Text);
            else
                MessageBox.Show("fillData" + "لم تكن التعبئة من بحث او لووود");
            try
            {
                //تفريغ الداتا جريت قبل التعبئة عشان التكرار
                dataGridView1.Rows.Clear();

                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    dataGridView1.Rows.Add(dataTable.Rows[i][0].ToString(), dataTable.Rows[i][1].ToString(), dataTable.Rows[i][2].ToString(), dataTable.Rows[i][3].ToString());
                }
                if (dataGridView1.Rows.Count > 0)
                {
                    FillTextBoxCountRows((1).ToString());
                }
                else if (dataGridView1.Rows.Count == 0)
                {
                    txtid.Text = string.Empty;
                    txtname.Text = string.Empty;
                   txtrf.Text = string.Empty;
                    txtpart.Text = string.Empty;
                    FillTextBoxCountRows((0).ToString());
                }

            }
            catch { }

        }
        void Delet()
        {
            List<string> data = new List<string>();
            data = unitClass.ChaeckCanDelet(txtid.Text);
            if (data.Count > 0)
            {
                MessageBox.Show("لا يمكن الحذف يوجد اصناف مرتبطة بهذه الوحدة", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (DialogResult.Yes == MessageBox.Show("؟تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Warning))
            {
                unitClass.Delet(txtid.Text);
                fillData("All");

            }

        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="flagAddOrEditLo"></param>
        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                if (txtname.Text != string.Empty && txtrf.Text != string.Empty && txtpart.Text != string.Empty)
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        // string[] data = { CurrName.Text, CurrSumbolAR.Text, CurrSumbolEN.Text, CurrFakah.Text, CurrEchanqe.Text, (CurrIsLocal.Checked ? "1" : "0"), (CurrIsStock.Checked ? "1" : "0"), (CurrMaximum.Text != string.Empty ? CurrMaximum.Text : "0"), (CurrMinimum.Text != string.Empty ? CurrMinimum.Text : "0") };
                        unitClass.InsertNewUnit(txtid.Text, txtname.Text, txtrf.Text, txtpart.Text);

                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }


                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه الاضافة", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");
                }
            }
            ///////////////////////////////////////////////////////////////////////////////////
            ///////////////////////////////////////////////////////////////////////////////////
            //if (flagAddOrEditLo == "DELETE")
            //{
            //    unitClass.DELETEunit(txtid.Text);
            //    MessageBox.Show("تم الحذف");
            //    fillData("All");
            //}











            ///////////////////////////////////////////////
            else if (flagAddOrEditLo == "Edite")
            {
                if (txtname.Text != string.Empty && txtrf.Text != string.Empty && txtpart.Text != string.Empty)
                {
                    if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {
                        unitClass.UpdateUnit(txtid.Text, txtname.Text, txtrf.Text, txtpart.Text);
                        MessageBox.Show("تم التعديل بنجاح");
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }
                    else
                    {
                        FormatingTextBoxAndButt("Save");
                        flagAddOrEdit = "";
                        fillData("All");
                    }

                }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData("All");

                } //end else if
            } //end else if
        
        }
 
             /// </summary>
        /// <param name="flagEditeOrAddOrSave"></param>
        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {

            /////////عند التعديل وجديد//////////////
            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add" )
            {
                //فعل التكستات
                txtname.ReadOnly = false;
                txtrf.ReadOnly = false;
             txtpart.ReadOnly = false;
                
                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;

               

            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load"|| flagEditeOrAddOrSave == "DELETE")
            {
                txtname.ReadOnly = true;
                txtrf.ReadOnly = true;
                txtpart.ReadOnly = true;
               
                //فعل البوتونات
                buttDelete.Enabled = true;
                buttAdd.Enabled = true;
                buttEdite.Enabled = true;
                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
            }
            


        }


        /// <summary>
        /// 
        /// 
        /// 
        /// </summary>

        void ForamtingAdd()
        {
            txtid.Text = unitClass.GetMaxId();
            txtname.Text = "";
            txtrf.Text = "";
            txtpart.Text = ""; }
        void FillTextBoxFromButtMove(int i)
        {
            if (i >= 0)
            {
                dataGridView1.ClearSelection();
                txtid.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
                txtname.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                txtrf.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                txtpart.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
                
                FillTextBoxCountRows((i + 1).ToString());
            }

        }

        int indexunitButt(string btName, string unitId)
        {
            /*
            داله لايجاد اندكس الوحدة حسب رقم الوحدة
            وترجع الاندكس الجديد حسب نوع التنقل
            اذا كان الاول ترجع صفر
            اذا كان التالي ترجع الاندكس زائد واحد
            اذا كان السابق ترجع الاندكس ناقص واحد
            واذا كان الاخير ترجع عدد الصفوف في الداتا جريت ناقص واحد
            
            */
            if (dataGridView1.Rows.Count > 0)
            {
                int i;
                for (i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (unitId == dataGridView1.Rows[i].Cells[0].Value.ToString())
                        break;

                }

                if (btName == "Frist")
                {
                    return 0;
                }
                else if (btName == "Next")
                {
                    if (i < dataGridView1.Rows.Count - 1)
                        return ++i;
                    else { MessageBox.Show("اخر سجل"); return i; }

                }
                else if (btName == "Back")
                {
                    if (i > 0)
                        return --i;
                    else { MessageBox.Show("اول سجل"); return i; }
                }
                else if (btName == "Last")
                {
                    if (i<dataGridView1.Rows.Count - 1)
                    {
                        
                        MessageBox.Show("اخر سجل");
                        return dataGridView1.Rows.Count - 1;

                    }
                   
                }
                else  return -1;
            }
            else MessageBox.Show("لا توجد  وحدات في قاعدة البيانات", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return -1;
        }

        void FillTextBoxCountRows(string index)
        {

            CountRows.Text = index + " - " + dataGridView1.Rows.Count.ToString();
        }

        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

       

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));

        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;

        }

        private void panUp_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void Unit_Load(object sender, EventArgs e)
        {

            fillData("All");
            FormatingTextBoxAndButt("Load");
            dataGridView1.Select();
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void butSave_Click(object sender, EventArgs e)
        {
            SendDataToAddOrEdit(flagAddOrEdit);
        }

        private void buttEdite_Click(object sender, EventArgs e)
        {

            flagAddOrEdit = "Edite";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexunitButt("Last", txtid.Text));

        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexunitButt("Back", txtid.Text));

        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexunitButt("Next", txtid.Text));

        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            FillTextBoxFromButtMove(indexunitButt("Frist", txtid.Text));

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void dataGridView1_KeyUp(object sender, KeyEventArgs e)
        {

            if (e.KeyData == Keys.Down || e.KeyData == Keys.Up)
            {
                if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                    FillTextBox();
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (flagAddOrEdit != "Add" && flagAddOrEdit != "Edite")
                FillTextBox();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            fillData("Serch");
        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            MoveForm(e);
        }

        private void txtid_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txtname_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void txtrf_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

        private void txtpart_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            Delet();
            fillData("All");
          //  dataGridView1.DataSource = unitClass.GetAllUnit();
            FillTextBox();
        }
    }
}
