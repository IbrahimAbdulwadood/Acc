﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
 
using AccSystem.ClassesProject;

namespace AccSystem.FormsProject.Sys
{
    public partial class AddDataBase : Form
    {
        DataBaseSqlcs dbs = new DataBaseSqlcs();
        public AddDataBase()
        {
            InitializeComponent();
        }
        ClassesProject.ConnectionDB con = new ConnectionDB();
        
        private void groupBoxData_Enter(object sender, EventArgs e)
        {

        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close(); 
        }

        private void buttAdd_Click(object sender, EventArgs e)
        {
           dbs.addBase();
            MessageBox.Show("تم إنشاء نسخة إحتياطية بنجاح", "", MessageBoxButtons.OK);

        }
    }
}
