﻿namespace AccSystem.FormsProject.Sys
{
    partial class CompanyInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CompanyInfo));
            this.panMain = new System.Windows.Forms.Panel();
            this.panFill = new System.Windows.Forms.Panel();
            this.groupBoxData = new System.Windows.Forms.GroupBox();
            this.butEdite = new System.Windows.Forms.Button();
            this.butSave = new System.Windows.Forms.Button();
            this.Com_email = new System.Windows.Forms.TextBox();
            this.Com_fax = new System.Windows.Forms.TextBox();
            this.Com_phone = new System.Windows.Forms.TextBox();
            this.Com_address_en = new System.Windows.Forms.TextBox();
            this.Com_address_ar = new System.Windows.Forms.TextBox();
            this.Com_name_en = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttAddImage = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Com_name_ar = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panDown = new System.Windows.Forms.Panel();
            this.panUp = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.panMain.SuspendLayout();
            this.panFill.SuspendLayout();
            this.groupBoxData.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panFill);
            this.panMain.Controls.Add(this.panDown);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1050, 500);
            this.panMain.TabIndex = 0;
            // 
            // panFill
            // 
            this.panFill.Controls.Add(this.groupBoxData);
            this.panFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFill.Location = new System.Drawing.Point(0, 37);
            this.panFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFill.Name = "panFill";
            this.panFill.Size = new System.Drawing.Size(1050, 431);
            this.panFill.TabIndex = 2;
            // 
            // groupBoxData
            // 
            this.groupBoxData.Controls.Add(this.butEdite);
            this.groupBoxData.Controls.Add(this.butSave);
            this.groupBoxData.Controls.Add(this.Com_email);
            this.groupBoxData.Controls.Add(this.Com_fax);
            this.groupBoxData.Controls.Add(this.Com_phone);
            this.groupBoxData.Controls.Add(this.Com_address_en);
            this.groupBoxData.Controls.Add(this.Com_address_ar);
            this.groupBoxData.Controls.Add(this.Com_name_en);
            this.groupBoxData.Controls.Add(this.groupBox1);
            this.groupBoxData.Controls.Add(this.label6);
            this.groupBoxData.Controls.Add(this.label5);
            this.groupBoxData.Controls.Add(this.label3);
            this.groupBoxData.Controls.Add(this.label2);
            this.groupBoxData.Controls.Add(this.Com_name_ar);
            this.groupBoxData.Controls.Add(this.label1);
            this.groupBoxData.Controls.Add(this.label7);
            this.groupBoxData.Controls.Add(this.label4);
            this.groupBoxData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxData.ForeColor = System.Drawing.Color.Black;
            this.groupBoxData.Location = new System.Drawing.Point(0, 0);
            this.groupBoxData.Name = "groupBoxData";
            this.groupBoxData.Size = new System.Drawing.Size(1050, 431);
            this.groupBoxData.TabIndex = 34;
            this.groupBoxData.TabStop = false;
            this.groupBoxData.Text = "البيانات";
            // 
            // butEdite
            // 
            this.butEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butEdite.FlatAppearance.BorderSize = 0;
            this.butEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butEdite.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butEdite.ForeColor = System.Drawing.Color.White;
            this.butEdite.Image = ((System.Drawing.Image)(resources.GetObject("butEdite.Image")));
            this.butEdite.Location = new System.Drawing.Point(587, 242);
            this.butEdite.Name = "butEdite";
            this.butEdite.Size = new System.Drawing.Size(54, 82);
            this.butEdite.TabIndex = 120;
            this.butEdite.Text = "تعديل";
            this.butEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butEdite.UseVisualStyleBackColor = false;
            this.butEdite.Click += new System.EventHandler(this.butEdite_Click);
            // 
            // butSave
            // 
            this.butSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.butSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.butSave.FlatAppearance.BorderSize = 0;
            this.butSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.butSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.butSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.butSave.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSave.ForeColor = System.Drawing.Color.White;
            this.butSave.Image = ((System.Drawing.Image)(resources.GetObject("butSave.Image")));
            this.butSave.Location = new System.Drawing.Point(648, 242);
            this.butSave.Name = "butSave";
            this.butSave.Size = new System.Drawing.Size(54, 82);
            this.butSave.TabIndex = 7;
            this.butSave.Text = "حفظ";
            this.butSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.butSave.UseVisualStyleBackColor = false;
            this.butSave.Click += new System.EventHandler(this.butSave_Click);
            // 
            // Com_email
            // 
            this.Com_email.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Com_email.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Com_email.Location = new System.Drawing.Point(279, 129);
            this.Com_email.Name = "Com_email";
            this.Com_email.ReadOnly = true;
            this.Com_email.Size = new System.Drawing.Size(608, 23);
            this.Com_email.TabIndex = 6;
            this.Com_email.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Com_email.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Com_email_KeyDown);
            // 
            // Com_fax
            // 
            this.Com_fax.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Com_fax.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Com_fax.Location = new System.Drawing.Point(279, 100);
            this.Com_fax.Name = "Com_fax";
            this.Com_fax.ReadOnly = true;
            this.Com_fax.Size = new System.Drawing.Size(222, 23);
            this.Com_fax.TabIndex = 5;
            this.Com_fax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Com_fax.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Com_fax_KeyDown);
            this.Com_fax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Com_fax_KeyPress);
            // 
            // Com_phone
            // 
            this.Com_phone.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Com_phone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Com_phone.Location = new System.Drawing.Point(665, 100);
            this.Com_phone.Name = "Com_phone";
            this.Com_phone.ReadOnly = true;
            this.Com_phone.Size = new System.Drawing.Size(222, 23);
            this.Com_phone.TabIndex = 4;
            this.Com_phone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Com_phone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Com_phone_KeyDown);
            this.Com_phone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Com_phone_KeyPress);
            // 
            // Com_address_en
            // 
            this.Com_address_en.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Com_address_en.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Com_address_en.Location = new System.Drawing.Point(279, 67);
            this.Com_address_en.Name = "Com_address_en";
            this.Com_address_en.ReadOnly = true;
            this.Com_address_en.Size = new System.Drawing.Size(222, 23);
            this.Com_address_en.TabIndex = 3;
            this.Com_address_en.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Com_address_en.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Com_address_en_KeyDown);
            // 
            // Com_address_ar
            // 
            this.Com_address_ar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Com_address_ar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Com_address_ar.Location = new System.Drawing.Point(279, 38);
            this.Com_address_ar.Name = "Com_address_ar";
            this.Com_address_ar.ReadOnly = true;
            this.Com_address_ar.Size = new System.Drawing.Size(222, 23);
            this.Com_address_ar.TabIndex = 1;
            this.Com_address_ar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Com_address_ar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Com_address_ar_KeyDown);
            // 
            // Com_name_en
            // 
            this.Com_name_en.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Com_name_en.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Com_name_en.Location = new System.Drawing.Point(665, 67);
            this.Com_name_en.Name = "Com_name_en";
            this.Com_name_en.ReadOnly = true;
            this.Com_name_en.Size = new System.Drawing.Size(222, 23);
            this.Com_name_en.TabIndex = 2;
            this.Com_name_en.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Com_name_en.Enter += new System.EventHandler(this.Com_name_en_Enter);
            this.Com_name_en.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Com_name_en_KeyDown);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttAddImage);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(12, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(240, 312);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "شعار الشركة:";
            // 
            // buttAddImage
            // 
            this.buttAddImage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAddImage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAddImage.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.buttAddImage.FlatAppearance.BorderSize = 0;
            this.buttAddImage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAddImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAddImage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAddImage.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttAddImage.ForeColor = System.Drawing.Color.White;
            this.buttAddImage.Image = ((System.Drawing.Image)(resources.GetObject("buttAddImage.Image")));
            this.buttAddImage.Location = new System.Drawing.Point(3, 269);
            this.buttAddImage.Name = "buttAddImage";
            this.buttAddImage.Size = new System.Drawing.Size(234, 40);
            this.buttAddImage.TabIndex = 126;
            this.buttAddImage.Text = "جديد";
            this.buttAddImage.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttAddImage.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttAddImage.UseVisualStyleBackColor = false;
            this.buttAddImage.Click += new System.EventHandler(this.button6_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Location = new System.Drawing.Point(3, 19);
            this.pictureBox1.MaximumSize = new System.Drawing.Size(240, 240);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(234, 240);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(507, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(150, 16);
            this.label6.TabIndex = 30;
            this.label6.Text = "عنوان الشركة انجليزي:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(507, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 16);
            this.label5.TabIndex = 29;
            this.label5.Text = "عنوان الشركة عربي:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(893, 129);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 28;
            this.label3.Text = "الايميل:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(507, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 16);
            this.label2.TabIndex = 27;
            this.label2.Text = "رقم الفاكس:";
            // 
            // Com_name_ar
            // 
            this.Com_name_ar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Com_name_ar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Com_name_ar.Location = new System.Drawing.Point(665, 39);
            this.Com_name_ar.Name = "Com_name_ar";
            this.Com_name_ar.ReadOnly = true;
            this.Com_name_ar.Size = new System.Drawing.Size(222, 23);
            this.Com_name_ar.TabIndex = 0;
            this.Com_name_ar.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Com_name_ar.Enter += new System.EventHandler(this.Com_name_ar_Enter);
            this.Com_name_ar.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Com_name_ar_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(893, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "اسم الشركة عربي:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(893, 100);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 16);
            this.label7.TabIndex = 26;
            this.label7.Text = "رقم الهاتف:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(893, 70);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 16);
            this.label4.TabIndex = 19;
            this.label4.Text = "اسم الشركة انجليزي:";
            // 
            // panDown
            // 
            this.panDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDown.Location = new System.Drawing.Point(0, 468);
            this.panDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDown.Name = "panDown";
            this.panDown.Size = new System.Drawing.Size(1050, 32);
            this.panDown.TabIndex = 1;
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.label13);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(1050, 37);
            this.panUp.TabIndex = 0;
            this.panUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panUp_Paint);
            this.panUp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panUp_MouseDown);
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Location = new System.Drawing.Point(840, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(205, 27);
            this.label13.TabIndex = 9;
            this.label13.Text = "        بيانات الشركة";
            this.label13.MouseDown += new System.Windows.Forms.MouseEventHandler(this.label13_MouseDown);
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(12, 3);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 27);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 7;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            this.pictureClose.MouseHover += new System.EventHandler(this.pictureClose_MouseHover);
            // 
            // CompanyInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1050, 500);
            this.Controls.Add(this.panMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CompanyInfo";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "بيانات الشركة";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.CompanyInfo_Load);
            this.panMain.ResumeLayout(false);
            this.panFill.ResumeLayout(false);
            this.groupBoxData.ResumeLayout(false);
            this.groupBoxData.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panFill;
        private System.Windows.Forms.Panel panDown;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.GroupBox groupBoxData;
        private System.Windows.Forms.TextBox Com_name_ar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.TextBox Com_email;
        private System.Windows.Forms.TextBox Com_fax;
        private System.Windows.Forms.TextBox Com_phone;
        private System.Windows.Forms.TextBox Com_address_en;
        private System.Windows.Forms.TextBox Com_address_ar;
        private System.Windows.Forms.TextBox Com_name_en;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button butEdite;
        private System.Windows.Forms.Button butSave;
        private System.Windows.Forms.Button buttAddImage;
    }
}