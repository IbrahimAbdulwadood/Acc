﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;

namespace AccSystem.FormsProject.Sys
{
    public partial class CompanyInfo : Form
    {
        MemoryStream ms;
        ClassesProject.CompanyInfoSQL comInfo = new ClassesProject.CompanyInfoSQL();
        DataTable dt;
        ClassesProject.ConnectionDB con = new ClassesProject.ConnectionDB();
        System.Data.SqlClient.SqlCommand cmd;
        byte[] ImageByteArray = new byte[] { };
      

       
        #region دوال مساعدة


        ////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// داله خارجية تستقبل اسم اللغه و تحولها حسب الطلب و تستدعى عند الحدث انتر وليف
        /// </summary>
        /// <param name="inputName"></param>
        /// <returns></returns>
        public static InputLanguage GetInputLanguageByName(string inputName)
        {
            foreach (InputLanguage lang in InputLanguage.InstalledInputLanguages)
            {
                if (lang.Culture.EnglishName.ToLower().StartsWith(inputName))
                {
                    return lang;
                }
            }
            return null;
        }

        private void SetKeyboardLayout(InputLanguage layout)
        {
            InputLanguage.CurrentInputLanguage = layout;
            //  هذه دالة تحویل اللغة تستقبل بارمتر مختصر لاسم اللغة المطلوب التحویل 
            //  الیها
        }


        ///
        ///
        ///
        //////////////////////////////////////////////////////////////////////////////////////////////////////


        /////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>                                                                                  ///
        /// دالة خارجية لتحريك الفورم عند الضغط في الماوس                                        ///
        ///                                                                                           ///
        /// </summary>                                                                               ///
        /// <param name="sender"></param>
        /// 
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();

        void MoveForm(MouseEventArgs e)
        {

            ///      نعملها في الحدث ماوووس داون//داله عشان احرك الفورم 

            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }

        /// 
        /// 
        /// <param name="e"></param>
        /// 
        /// 
        ///     //داله عشان احرك الفورم 
        /// //ننسخها في الحدث MouseDown
        ///    //if (e.Button == MouseButtons.Left)
        ///    //{
        ///    //    ReleaseCapture();
        ///    //    SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        ///    //}
        ///
        ///
        ///////////////////////////////////////////////////////////////////////////////


        /// <summary>
        /// /
        /// </summary>
        /// 
          #endregion
        void FormatingTextBoxAndButt(string EditeOrSaveOrLoad)
        {
            if (EditeOrSaveOrLoad == "Save" || EditeOrSaveOrLoad == "Load")
            {
                Com_name_ar.ReadOnly = true;
                Com_name_en.ReadOnly = true;
                Com_phone.ReadOnly = true;
                Com_fax.ReadOnly = true;
                Com_address_ar.ReadOnly = true;
                Com_address_en.ReadOnly = true;
                Com_email.ReadOnly = true;

                butSave.Enabled = false;
                butEdite.Enabled = true;
                buttAddImage.Enabled = false;
            }
            else if (EditeOrSaveOrLoad == "Edite")
            {
                Com_name_ar.ReadOnly = false;
                Com_name_en.ReadOnly = false;
                Com_phone.ReadOnly = false;
                Com_fax.ReadOnly = false;
                Com_address_ar.ReadOnly = false;
                Com_address_en.ReadOnly = false;
                Com_email.ReadOnly = false;

                butSave.Enabled = true;
                butEdite.Enabled = false;
                buttAddImage.Enabled = true;
            }
        }
        void EdateImg()
        {

            if (pictureBox1.Image != null)
            {
                if (comInfo.CheckIfExistRowInCompanyInfoTable())
                {
                    cmd = new System.Data.SqlClient.SqlCommand(" UPDATE[dbo].[Company] SET [Com_logo]= @Com_logo ", con.conn);
                    conv_photo();

                    try
                    {
                        con.OpenConnetion();
                        int n = cmd.ExecuteNonQuery();
                        con.CloseConnetion();
                        if (n > 0)
                        {
                            MessageBox.Show("تم تعديل الشعار");
                            //loaddata();
                        }
                        else
                            MessageBox.Show("فشل تعديل الشعار");
                    }
                    catch (InvalidOperationException ee) { MessageBox.Show(ee.ToString()); }


                }
                else
                {
                    cmd = new System.Data.SqlClient.SqlCommand("INSERT INTO [dbo].[Company] ([Com_logo])   VALUES ( @Com_logo)", con.conn);
                    conv_photo();
                    try
                    {
                        con.OpenConnetion();
                        int n = cmd.ExecuteNonQuery();
                        con.CloseConnetion();
                        if (n > 0)
                        {
                            MessageBox.Show("record inserted");
                            // loaddata();
                        }
                        else
                            MessageBox.Show("insertion failed");
                    }
                    catch (Exception ee) { MessageBox.Show(ee.ToString()); }
                }
            }
        }
        string bemoo(string a)
        {
            if(a!="NULL")
            a = "'" + a + "'";
            return a;
        }

        void FillData()
        {
            dt = new DataTable();
           dt     = comInfo.GetDataCompany();
        
            if (dt.Rows.Count > 0)
            {
               
                //[Com_name_ar],[Com_name_en] ,[Com_phone] ,[Com_fax]  
                //,[Com_address_ar]  ,[Com_address_en]  ,[Com_email]
                Com_name_ar.Text = dt.Rows[0][0].ToString();
                Com_name_en.Text = dt.Rows[0][1].ToString();
                Com_phone.Text = dt.Rows[0][2].ToString();
                Com_fax.Text = dt.Rows[0][3].ToString();
                Com_address_ar.Text = dt.Rows[0][4].ToString();
                Com_address_en.Text = dt.Rows[0][5].ToString();
                Com_email.Text = dt.Rows[0][6].ToString();
                try
                {
                    if ((dt.Rows[0][7]) != System.DBNull.Value)
                    {

                        ImageByteArray = ((byte[])(dt.Rows[0][7]));
                     
                        pictureBox1.Image = Image.FromStream(new MemoryStream(ImageByteArray));

                    }
                    else
                    {
                        pictureBox1.Image = null;
                    }
                }
                catch(Exception ee) { MessageBox.Show(ee.ToString()); }

              

            }
            else
            {
                Com_name_ar.Text = string.Empty;
                Com_name_en.Text = string.Empty;
                Com_phone.Text = string.Empty;
                Com_fax.Text = string.Empty;
                Com_address_ar.Text = string.Empty;
                Com_address_en.Text = string.Empty;
                Com_email.Text = string.Empty;
                pictureBox1.Image = null;
            }

        }
        void StopNumberInTextBox(KeyPressEventArgs e)
        {
            if ((e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }

        void StopAlphaInTextBox(KeyPressEventArgs e)
        {
            if (!(e.KeyChar >= '0' && e.KeyChar <= '9') && ((e.KeyChar != 8) && (e.KeyChar != 10)))
            {
                e.Handled = true;
            }
            else
                e.Handled = false;
        }
        void EnterLikeTap(KeyEventArgs e)
        {
            //Copy Name Fun in Event KeyDown
            if (e.KeyCode == Keys.Enter)
            {

                SendKeys.Send("{TAB}");
            }
        }

        ///////////////////
        public CompanyInfo()
        {
            InitializeComponent();
        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }


        private void label5_Click(object sender, EventArgs e)
        {

        }
        
        private void CompanyInfo_Load(object sender, EventArgs e)
        {
            FillData();
            FormatingTextBoxAndButt("Load");
        }



      
        void conv_photo()
        {
            //converting photo to binary data
            if (pictureBox1.Image != null)
            {
                //using FileStream:(will not work while updating, if image is not changed)
                //FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open, FileAccess.Read);
                //byte[] photo_aray = new byte[fs.Length];
                //fs.Read(photo_aray, 0, photo_aray.Length);  

                //using MemoryStream:
                ms = new MemoryStream();
                pictureBox1.Image.Save(ms, ImageFormat.Jpeg);
                byte[] photo_aray = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(photo_aray, 0, photo_aray.Length);
                cmd.Parameters.AddWithValue("@Com_logo", photo_aray);
            }
        }
    
        private void butSave_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("هل تريد تغيير البيانات؟", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                
               
              
               
               comInfo.UpdateCompany((Com_name_ar.Text == string.Empty ? "NULL" : bemoo(Com_name_ar.Text)),
              (Com_name_en.Text == string.Empty ? "NULL" : bemoo(Com_name_en.Text)),
              (Com_phone.Text == string.Empty ? "NULL" : Com_phone.Text),
              (Com_fax.Text == string.Empty ? "NULL" : Com_fax.Text),
              (Com_address_ar.Text == string.Empty ? "NULL" : bemoo(Com_address_ar.Text)),
              (Com_address_en.Text == string.Empty ? "NULL" : bemoo(Com_address_en.Text)),
              (Com_email.Text == string.Empty ? "NULL" : bemoo(Com_email.Text)));

                EdateImg();

                }
           
            FillData();
            FormatingTextBoxAndButt("Save");
        }
    
        private void butEdite_Click(object sender, EventArgs e)
        {
           
            FormatingTextBoxAndButt("Edite");
        }

        private void Com_phone_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

        private void panUp_MouseDown(object sender, MouseEventArgs e)
        {
            MoveForm(e);
        }

        private void label13_MouseDown(object sender, MouseEventArgs e)
        {
            MoveForm(e);
        }

        private void Com_name_ar_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("ar"));
        }

        private void Com_name_en_Enter(object sender, EventArgs e)
        {
            SetKeyboardLayout(GetInputLanguageByName("en"));
        }
      
        private void Com_name_ar_KeyDown(object sender, KeyEventArgs e)
        {
            EnterLikeTap(e);
        }

        private void Com_address_ar_KeyDown(object sender, KeyEventArgs e)
        {
            EnterLikeTap(e);
        }

        private void Com_name_en_KeyDown(object sender, KeyEventArgs e)
        {
            EnterLikeTap(e);
        }

        private void Com_address_en_KeyDown(object sender, KeyEventArgs e)
        {
            EnterLikeTap(e);
        }

        private void Com_phone_KeyDown(object sender, KeyEventArgs e)
        {
            EnterLikeTap(e);
        }

        private void Com_fax_KeyDown(object sender, KeyEventArgs e)
        {
            EnterLikeTap(e);
        }

        private void Com_email_KeyDown(object sender, KeyEventArgs e)
        {
            EnterLikeTap(e);
        }

        private void Com_fax_KeyPress(object sender, KeyPressEventArgs e)
        {
            StopAlphaInTextBox(e);
        }

      
      
        private void button6_Click(object sender, EventArgs e)
        {
            OpenFileDialog o = new OpenFileDialog();
            o.Filter = "ملفات الصور| *.JPG;*.PNG; *.GIF";
            if (o.ShowDialog() == DialogResult.OK)
            {
               
                pictureBox1.Image = new Bitmap(o.FileName);
            }
           
        }
    }
}
