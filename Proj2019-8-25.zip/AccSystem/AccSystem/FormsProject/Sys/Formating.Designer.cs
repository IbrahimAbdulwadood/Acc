﻿namespace AccSystem.FormsProject.Sys
{
    partial class Formating
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Formating));
            this.panMain = new System.Windows.Forms.Panel();
            this.panFill = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.buttCustomers = new System.Windows.Forms.Button();
            this.buttSuppliers = new System.Windows.Forms.Button();
            this.buttUserPermissions = new System.Windows.Forms.Button();
            this.buttCompanyData = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttFirstTimeIteam = new System.Windows.Forms.Button();
            this.buttIteam = new System.Windows.Forms.Button();
            this.buttUnits = new System.Windows.Forms.Button();
            this.buttItemTypes = new System.Windows.Forms.Button();
            this.buttGroupStored = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttBox = new System.Windows.Forms.Button();
            this.buttOpeningBalance = new System.Windows.Forms.Button();
            this.buttAcc = new System.Windows.Forms.Button();
            this.buttAccDefine = new System.Windows.Forms.Button();
            this.buttCurr = new System.Windows.Forms.Button();
            this.panDown = new System.Windows.Forms.Panel();
            this.panUp = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.panMain.SuspendLayout();
            this.panFill.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panFill);
            this.panMain.Controls.Add(this.panDown);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(997, 645);
            this.panMain.TabIndex = 0;
            // 
            // panFill
            // 
            this.panFill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panFill.Controls.Add(this.panel2);
            this.panFill.Controls.Add(this.panel1);
            this.panFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panFill.Location = new System.Drawing.Point(0, 32);
            this.panFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panFill.Name = "panFill";
            this.panFill.Size = new System.Drawing.Size(997, 581);
            this.panFill.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(429, 581);
            this.panel2.TabIndex = 1;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Controls.Add(this.buttCustomers);
            this.groupBox3.Controls.Add(this.buttSuppliers);
            this.groupBox3.Controls.Add(this.buttUserPermissions);
            this.groupBox3.Controls.Add(this.buttCompanyData);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 15.75F);
            this.groupBox3.ForeColor = System.Drawing.Color.White;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(423, 581);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "النظام";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.panel8);
            this.groupBox4.Controls.Add(this.panel7);
            this.groupBox4.Controls.Add(this.panel6);
            this.groupBox4.Controls.Add(this.panel5);
            this.groupBox4.Controls.Add(this.panel4);
            this.groupBox4.Controls.Add(this.panel3);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox4.ForeColor = System.Drawing.Color.White;
            this.groupBox4.Location = new System.Drawing.Point(3, 352);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(417, 226);
            this.groupBox4.TabIndex = 235;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "فريــــق المشروع";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.DimGray;
            this.panel8.Controls.Add(this.label5);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(3, 189);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(411, 32);
            this.panel8.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.Image = ((System.Drawing.Image)(resources.GetObject("label5.Image")));
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label5.Location = new System.Drawing.Point(136, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(275, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "      م/ هيثم ابراهيم الكحلاني";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.label6);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(3, 157);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(411, 32);
            this.panel7.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Dock = System.Windows.Forms.DockStyle.Right;
            this.label6.Image = ((System.Drawing.Image)(resources.GetObject("label6.Image")));
            this.label6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label6.Location = new System.Drawing.Point(168, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(243, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "      م/ نورا عبده الشميري";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.DimGray;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(3, 125);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(411, 32);
            this.panel6.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Right;
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label4.Location = new System.Drawing.Point(134, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(277, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "      م/ صهيب مطهر الشميري";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label3);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(3, 93);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(411, 32);
            this.panel5.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Image = ((System.Drawing.Image)(resources.GetObject("label3.Image")));
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label3.Location = new System.Drawing.Point(159, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(252, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "      م/ اسماء علي الجعدي";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DimGray;
            this.panel4.Controls.Add(this.label2);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(3, 61);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(411, 32);
            this.panel4.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Right;
            this.label2.Image = ((System.Drawing.Image)(resources.GetObject("label2.Image")));
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label2.Location = new System.Drawing.Point(132, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(279, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "      م/ اسامة محمد الدبعي   ";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(3, 29);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(411, 32);
            this.panel3.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(130, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(281, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "      م/ ابراهيم عمار الدبعي    ";
            // 
            // buttCustomers
            // 
            this.buttCustomers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttCustomers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttCustomers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttCustomers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttCustomers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttCustomers.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttCustomers.ForeColor = System.Drawing.Color.White;
            this.buttCustomers.Image = ((System.Drawing.Image)(resources.GetObject("buttCustomers.Image")));
            this.buttCustomers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttCustomers.Location = new System.Drawing.Point(15, 121);
            this.buttCustomers.Name = "buttCustomers";
            this.buttCustomers.Size = new System.Drawing.Size(146, 72);
            this.buttCustomers.TabIndex = 234;
            this.buttCustomers.Text = "العملاء";
            this.buttCustomers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttCustomers.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttCustomers.UseVisualStyleBackColor = false;
            // 
            // buttSuppliers
            // 
            this.buttSuppliers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttSuppliers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttSuppliers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttSuppliers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttSuppliers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttSuppliers.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttSuppliers.ForeColor = System.Drawing.Color.White;
            this.buttSuppliers.Image = ((System.Drawing.Image)(resources.GetObject("buttSuppliers.Image")));
            this.buttSuppliers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttSuppliers.Location = new System.Drawing.Point(15, 199);
            this.buttSuppliers.Name = "buttSuppliers";
            this.buttSuppliers.Size = new System.Drawing.Size(392, 72);
            this.buttSuppliers.TabIndex = 233;
            this.buttSuppliers.Text = "الموردين";
            this.buttSuppliers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttSuppliers.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttSuppliers.UseVisualStyleBackColor = false;
            // 
            // buttUserPermissions
            // 
            this.buttUserPermissions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttUserPermissions.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttUserPermissions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttUserPermissions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttUserPermissions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttUserPermissions.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttUserPermissions.ForeColor = System.Drawing.Color.White;
            this.buttUserPermissions.Image = ((System.Drawing.Image)(resources.GetObject("buttUserPermissions.Image")));
            this.buttUserPermissions.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttUserPermissions.Location = new System.Drawing.Point(15, 42);
            this.buttUserPermissions.Name = "buttUserPermissions";
            this.buttUserPermissions.Size = new System.Drawing.Size(392, 72);
            this.buttUserPermissions.TabIndex = 231;
            this.buttUserPermissions.Text = "المستخدمين  والصلاحيات";
            this.buttUserPermissions.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttUserPermissions.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttUserPermissions.UseVisualStyleBackColor = false;
            // 
            // buttCompanyData
            // 
            this.buttCompanyData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttCompanyData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttCompanyData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttCompanyData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttCompanyData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttCompanyData.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttCompanyData.ForeColor = System.Drawing.Color.White;
            this.buttCompanyData.Image = ((System.Drawing.Image)(resources.GetObject("buttCompanyData.Image")));
            this.buttCompanyData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttCompanyData.Location = new System.Drawing.Point(167, 121);
            this.buttCompanyData.Name = "buttCompanyData";
            this.buttCompanyData.Size = new System.Drawing.Size(240, 72);
            this.buttCompanyData.TabIndex = 230;
            this.buttCompanyData.Text = "بيانات الشركة";
            this.buttCompanyData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttCompanyData.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttCompanyData.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(429, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(568, 581);
            this.panel1.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttFirstTimeIteam);
            this.groupBox2.Controls.Add(this.buttIteam);
            this.groupBox2.Controls.Add(this.buttUnits);
            this.groupBox2.Controls.Add(this.buttItemTypes);
            this.groupBox2.Controls.Add(this.buttGroupStored);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 15.75F);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(0, 293);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(568, 288);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "الاصناف";
            // 
            // buttFirstTimeIteam
            // 
            this.buttFirstTimeIteam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFirstTimeIteam.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFirstTimeIteam.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttFirstTimeIteam.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttFirstTimeIteam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttFirstTimeIteam.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttFirstTimeIteam.ForeColor = System.Drawing.Color.White;
            this.buttFirstTimeIteam.Image = ((System.Drawing.Image)(resources.GetObject("buttFirstTimeIteam.Image")));
            this.buttFirstTimeIteam.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttFirstTimeIteam.Location = new System.Drawing.Point(14, 190);
            this.buttFirstTimeIteam.Name = "buttFirstTimeIteam";
            this.buttFirstTimeIteam.Size = new System.Drawing.Size(533, 72);
            this.buttFirstTimeIteam.TabIndex = 219;
            this.buttFirstTimeIteam.Text = "مخزون اول الـــــــــمده";
            this.buttFirstTimeIteam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttFirstTimeIteam.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttFirstTimeIteam.UseVisualStyleBackColor = false;
            // 
            // buttIteam
            // 
            this.buttIteam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttIteam.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttIteam.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttIteam.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttIteam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttIteam.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttIteam.ForeColor = System.Drawing.Color.White;
            this.buttIteam.Image = ((System.Drawing.Image)(resources.GetObject("buttIteam.Image")));
            this.buttIteam.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttIteam.Location = new System.Drawing.Point(14, 112);
            this.buttIteam.Name = "buttIteam";
            this.buttIteam.Size = new System.Drawing.Size(286, 72);
            this.buttIteam.TabIndex = 218;
            this.buttIteam.Text = "الاصناف";
            this.buttIteam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttIteam.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttIteam.UseVisualStyleBackColor = false;
            // 
            // buttUnits
            // 
            this.buttUnits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttUnits.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttUnits.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttUnits.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttUnits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttUnits.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttUnits.ForeColor = System.Drawing.Color.White;
            this.buttUnits.Image = ((System.Drawing.Image)(resources.GetObject("buttUnits.Image")));
            this.buttUnits.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttUnits.Location = new System.Drawing.Point(306, 112);
            this.buttUnits.Name = "buttUnits";
            this.buttUnits.Size = new System.Drawing.Size(241, 72);
            this.buttUnits.TabIndex = 217;
            this.buttUnits.Text = "الوحدات";
            this.buttUnits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttUnits.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttUnits.UseVisualStyleBackColor = false;
            // 
            // buttItemTypes
            // 
            this.buttItemTypes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttItemTypes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttItemTypes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttItemTypes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttItemTypes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttItemTypes.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttItemTypes.ForeColor = System.Drawing.Color.White;
            this.buttItemTypes.Image = ((System.Drawing.Image)(resources.GetObject("buttItemTypes.Image")));
            this.buttItemTypes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttItemTypes.Location = new System.Drawing.Point(14, 34);
            this.buttItemTypes.Name = "buttItemTypes";
            this.buttItemTypes.Size = new System.Drawing.Size(209, 72);
            this.buttItemTypes.TabIndex = 216;
            this.buttItemTypes.Text = "فئات الاصناف";
            this.buttItemTypes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttItemTypes.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttItemTypes.UseVisualStyleBackColor = false;
            // 
            // buttGroupStored
            // 
            this.buttGroupStored.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttGroupStored.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttGroupStored.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttGroupStored.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttGroupStored.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttGroupStored.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttGroupStored.ForeColor = System.Drawing.Color.White;
            this.buttGroupStored.Image = ((System.Drawing.Image)(resources.GetObject("buttGroupStored.Image")));
            this.buttGroupStored.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttGroupStored.Location = new System.Drawing.Point(229, 34);
            this.buttGroupStored.Name = "buttGroupStored";
            this.buttGroupStored.Size = new System.Drawing.Size(318, 72);
            this.buttGroupStored.TabIndex = 215;
            this.buttGroupStored.Text = "المجموعات المخــــــزنية";
            this.buttGroupStored.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttGroupStored.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttGroupStored.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttBox);
            this.groupBox1.Controls.Add(this.buttOpeningBalance);
            this.groupBox1.Controls.Add(this.buttAcc);
            this.groupBox1.Controls.Add(this.buttAccDefine);
            this.groupBox1.Controls.Add(this.buttCurr);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(568, 293);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "الحسابات";
            // 
            // buttBox
            // 
            this.buttBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBox.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttBox.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBox.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttBox.ForeColor = System.Drawing.Color.White;
            this.buttBox.Image = ((System.Drawing.Image)(resources.GetObject("buttBox.Image")));
            this.buttBox.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttBox.Location = new System.Drawing.Point(14, 198);
            this.buttBox.Name = "buttBox";
            this.buttBox.Size = new System.Drawing.Size(533, 73);
            this.buttBox.TabIndex = 221;
            this.buttBox.Text = "الصناديق";
            this.buttBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttBox.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttBox.UseVisualStyleBackColor = false;
            this.buttBox.Click += new System.EventHandler(this.buttBox_Click);
            // 
            // buttOpeningBalance
            // 
            this.buttOpeningBalance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttOpeningBalance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttOpeningBalance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttOpeningBalance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttOpeningBalance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttOpeningBalance.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttOpeningBalance.ForeColor = System.Drawing.Color.White;
            this.buttOpeningBalance.Image = ((System.Drawing.Image)(resources.GetObject("buttOpeningBalance.Image")));
            this.buttOpeningBalance.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttOpeningBalance.Location = new System.Drawing.Point(14, 120);
            this.buttOpeningBalance.Name = "buttOpeningBalance";
            this.buttOpeningBalance.Size = new System.Drawing.Size(286, 72);
            this.buttOpeningBalance.TabIndex = 213;
            this.buttOpeningBalance.Text = "رصـــيد افتتاحي";
            this.buttOpeningBalance.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttOpeningBalance.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttOpeningBalance.UseVisualStyleBackColor = false;
            // 
            // buttAcc
            // 
            this.buttAcc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAcc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAcc.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAcc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAcc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAcc.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttAcc.ForeColor = System.Drawing.Color.White;
            this.buttAcc.Image = ((System.Drawing.Image)(resources.GetObject("buttAcc.Image")));
            this.buttAcc.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttAcc.Location = new System.Drawing.Point(14, 42);
            this.buttAcc.Name = "buttAcc";
            this.buttAcc.Padding = new System.Windows.Forms.Padding(20, 0, 40, 0);
            this.buttAcc.Size = new System.Drawing.Size(322, 72);
            this.buttAcc.TabIndex = 212;
            this.buttAcc.Text = "الدليل المحاسبي";
            this.buttAcc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttAcc.UseVisualStyleBackColor = false;
            // 
            // buttAccDefine
            // 
            this.buttAccDefine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAccDefine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAccDefine.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAccDefine.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAccDefine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAccDefine.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttAccDefine.ForeColor = System.Drawing.Color.White;
            this.buttAccDefine.Image = ((System.Drawing.Image)(resources.GetObject("buttAccDefine.Image")));
            this.buttAccDefine.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttAccDefine.Location = new System.Drawing.Point(306, 120);
            this.buttAccDefine.Name = "buttAccDefine";
            this.buttAccDefine.Size = new System.Drawing.Size(241, 72);
            this.buttAccDefine.TabIndex = 211;
            this.buttAccDefine.Text = "تعريف الحسابات";
            this.buttAccDefine.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttAccDefine.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttAccDefine.UseVisualStyleBackColor = false;
            // 
            // buttCurr
            // 
            this.buttCurr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttCurr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttCurr.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttCurr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttCurr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttCurr.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold);
            this.buttCurr.ForeColor = System.Drawing.Color.White;
            this.buttCurr.Image = ((System.Drawing.Image)(resources.GetObject("buttCurr.Image")));
            this.buttCurr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttCurr.Location = new System.Drawing.Point(342, 42);
            this.buttCurr.Name = "buttCurr";
            this.buttCurr.Size = new System.Drawing.Size(205, 72);
            this.buttCurr.TabIndex = 188;
            this.buttCurr.Text = "العملات";
            this.buttCurr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttCurr.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttCurr.UseVisualStyleBackColor = false;
            // 
            // panDown
            // 
            this.panDown.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panDown.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDown.Location = new System.Drawing.Point(0, 613);
            this.panDown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDown.Name = "panDown";
            this.panDown.Size = new System.Drawing.Size(997, 32);
            this.panDown.TabIndex = 1;
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.label13);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(997, 32);
            this.panUp.TabIndex = 0;
            this.panUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panUp_Paint);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Dock = System.Windows.Forms.DockStyle.Right;
            this.label13.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label13.Location = new System.Drawing.Point(704, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(293, 27);
            this.label13.TabIndex = 9;
            this.label13.Text = "           شاشة تهئية النظام  ";
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Dock = System.Windows.Forms.DockStyle.Left;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(0, 0);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(34, 32);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 7;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            this.pictureClose.MouseHover += new System.EventHandler(this.pictureClose_MouseHover);
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // Formating
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(997, 645);
            this.Controls.Add(this.panMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Formating";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "Form4";
            this.panMain.ResumeLayout(false);
            this.panFill.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panFill;
        private System.Windows.Forms.Panel panDown;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttCurr;
        private System.Windows.Forms.Button buttAccDefine;
        private System.Windows.Forms.Button buttAcc;
        private System.Windows.Forms.Button buttOpeningBalance;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button buttGroupStored;
        private System.Windows.Forms.Button buttItemTypes;
        private System.Windows.Forms.Button buttUnits;
        private System.Windows.Forms.Button buttIteam;
        private System.Windows.Forms.Button buttBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button buttFirstTimeIteam;
        private System.Windows.Forms.Button buttCustomers;
        private System.Windows.Forms.Button buttSuppliers;
        private System.Windows.Forms.Button buttUserPermissions;
        private System.Windows.Forms.Button buttCompanyData;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
    }
}