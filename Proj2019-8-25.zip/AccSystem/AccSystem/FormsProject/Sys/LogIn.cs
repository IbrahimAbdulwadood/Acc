﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;

namespace AccSystem.FormsProject.Sys
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }
        UsersSQL user = new UsersSQL();
        Dictionary<string, string> idUserAndName = new Dictionary<string, string>();
        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttLogin_Click(object sender, EventArgs e)
        {
            if (txtUserId.Text != string.Empty && txtUserPass.Text != string.Empty)
            {


                idUserAndName.Clear();
                idUserAndName = user.Login(txtUserId.Text, txtUserPass.Text);
                if (idUserAndName.Count > 0)
                {

                    if (user.StateUser(txtUserId.Text))
                    {
                        string nameUserr;

                        if (idUserAndName.TryGetValue(idUserAndName.Keys.ElementAt(0), out nameUserr))
                        {
                            MessageBox.Show(nameUserr, "مرحبا", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            Program.State = true;
                            Program.idUser = idUserAndName.Keys.ElementAt(0);
                            Program.nameUser = nameUserr;
                            Close();
                        }
                        else MessageBox.Show("2المستخدم غير موجود");
                    }
                    else MessageBox.Show(" \n مـرحبـا \n  " + idUserAndName[idUserAndName.Keys.ElementAt(0)] + "\n "+" حسابك موقف حاليا راجع الادارة ", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else MessageBox.Show("المستخدم غير موجود","خطأ",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            else MessageBox.Show("الحقول فارغة", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);


        }

        private void buttExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
