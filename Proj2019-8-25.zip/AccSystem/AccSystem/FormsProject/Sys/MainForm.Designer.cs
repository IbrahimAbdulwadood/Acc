﻿namespace AccSystem.FormsProject.Sys
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panMain = new System.Windows.Forms.Panel();
            this.panLeft = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panRight = new System.Windows.Forms.Panel();
            this.panRightFill = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttCustomers = new System.Windows.Forms.Button();
            this.buttBox = new System.Windows.Forms.Button();
            this.buttMyProfile = new System.Windows.Forms.Button();
            this.buttCustomerAccRep = new System.Windows.Forms.Button();
            this.buttGroupStored = new System.Windows.Forms.Button();
            this.buttOpeningBalance = new System.Windows.Forms.Button();
            this.buttUserPermissions = new System.Windows.Forms.Button();
            this.buttAccDefine = new System.Windows.Forms.Button();
            this.buttUnits = new System.Windows.Forms.Button();
            this.buttBoxMoveAccRepo = new System.Windows.Forms.Button();
            this.buttCompanyData = new System.Windows.Forms.Button();
            this.buttSalesReturn = new System.Windows.Forms.Button();
            this.buttItemTypes = new System.Windows.Forms.Button();
            this.buttPostingNon = new System.Windows.Forms.Button();
            this.buttAccStatementRep = new System.Windows.Forms.Button();
            this.buttSupportCatch = new System.Windows.Forms.Button();
            this.buttSupportExchang = new System.Windows.Forms.Button();
            this.buttOfferPrice = new System.Windows.Forms.Button();
            this.buttIteam = new System.Windows.Forms.Button();
            this.buttDailyRep = new System.Windows.Forms.Button();
            this.buttEntries = new System.Windows.Forms.Button();
            this.buttCurr = new System.Windows.Forms.Button();
            this.buttSales = new System.Windows.Forms.Button();
            this.buttAcc = new System.Windows.Forms.Button();
            this.panRightHaed = new System.Windows.Forms.Panel();
            this.toolStripMain = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.mangerStingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.تهئيةالحساباتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Curr = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Account = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_AccDefinition = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_BalanceOpen = new System.Windows.Forms.ToolStripMenuItem();
            this.تهئيةالمبيعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Customers = new System.Windows.Forms.ToolStripMenuItem();
            this.تسعيرةالاصنافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.تهئيةالمخازنToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_GroupStored = new System.Windows.Forms.ToolStripMenuItem();
            this.فئاتالاصنافToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Unit = new System.Windows.Forms.ToolStripMenuItem();
            this.TSM_Items = new System.Windows.Forms.ToolStripMenuItem();
            this.mangerSysAccToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.المدخلاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.الدليلالمحاسبيToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.رصيدافتتاحيToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.بياناتالصناديقToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.العملياتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.قيديدويToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سندقبضToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.سندصرفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إلغاءترحيلToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mangerSysPuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.العملياتToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.فاتورةمبيعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.مردودمبيعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.عرضسعرToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ادارةالعملاءToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton3 = new System.Windows.Forms.ToolStripDropDownButton();
            this.انشاءنسخةاحتياطيةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.استعادةنسخةاحتياطيةToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.تغييركلمةالمرورToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.إدارةالمستخدمينToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.buttTS_RefrechPre = new System.Windows.Forms.ToolStripButton();
            this.panDawon = new System.Windows.Forms.Panel();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.IdUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.NameUser = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.فلانToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.فلانToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.فلانToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.فلانToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.نوراالشميريToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.هيثمالكحلانيToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panUp = new System.Windows.Forms.Panel();
            this.labTitle = new System.Windows.Forms.Label();
            this.pictureClose = new System.Windows.Forms.PictureBox();
            this.التقاريرToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.صافيالمبيعاتToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panMain.SuspendLayout();
            this.panLeft.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panRight.SuspendLayout();
            this.panRightFill.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panRightHaed.SuspendLayout();
            this.toolStripMain.SuspendLayout();
            this.panDawon.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).BeginInit();
            this.SuspendLayout();
            // 
            // panMain
            // 
            this.panMain.Controls.Add(this.panLeft);
            this.panMain.Controls.Add(this.panRight);
            this.panMain.Controls.Add(this.panDawon);
            this.panMain.Controls.Add(this.panUp);
            this.panMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panMain.Location = new System.Drawing.Point(0, 0);
            this.panMain.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panMain.Name = "panMain";
            this.panMain.Size = new System.Drawing.Size(1501, 900);
            this.panMain.TabIndex = 0;
            // 
            // panLeft
            // 
            this.panLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panLeft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panLeft.Controls.Add(this.pictureBox1);
            this.panLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panLeft.Location = new System.Drawing.Point(0, 35);
            this.panLeft.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panLeft.Name = "panLeft";
            this.panLeft.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.panLeft.Size = new System.Drawing.Size(1184, 832);
            this.panLeft.TabIndex = 3;
            this.panLeft.Paint += new System.Windows.Forms.PaintEventHandler(this.panLeft_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::AccSystem.Properties.Resources.maxresdefault;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1180, 828);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panRight
            // 
            this.panRight.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.panRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panRight.Controls.Add(this.panRightFill);
            this.panRight.Controls.Add(this.panRightHaed);
            this.panRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.panRight.Location = new System.Drawing.Point(1184, 35);
            this.panRight.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panRight.Name = "panRight";
            this.panRight.Size = new System.Drawing.Size(317, 832);
            this.panRight.TabIndex = 2;
            // 
            // panRightFill
            // 
            this.panRightFill.AutoScroll = true;
            this.panRightFill.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.panRightFill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panRightFill.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panRightFill.Controls.Add(this.groupBox1);
            this.panRightFill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panRightFill.Location = new System.Drawing.Point(0, 25);
            this.panRightFill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panRightFill.Name = "panRightFill";
            this.panRightFill.Size = new System.Drawing.Size(317, 807);
            this.panRightFill.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.AccessibleDescription = "";
            this.groupBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.ScrollBar;
            this.groupBox1.AutoSize = true;
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Controls.Add(this.buttCustomers);
            this.groupBox1.Controls.Add(this.buttBox);
            this.groupBox1.Controls.Add(this.buttMyProfile);
            this.groupBox1.Controls.Add(this.buttCustomerAccRep);
            this.groupBox1.Controls.Add(this.buttGroupStored);
            this.groupBox1.Controls.Add(this.buttOpeningBalance);
            this.groupBox1.Controls.Add(this.buttUserPermissions);
            this.groupBox1.Controls.Add(this.buttAccDefine);
            this.groupBox1.Controls.Add(this.buttUnits);
            this.groupBox1.Controls.Add(this.buttBoxMoveAccRepo);
            this.groupBox1.Controls.Add(this.buttCompanyData);
            this.groupBox1.Controls.Add(this.buttSalesReturn);
            this.groupBox1.Controls.Add(this.buttItemTypes);
            this.groupBox1.Controls.Add(this.buttPostingNon);
            this.groupBox1.Controls.Add(this.buttAccStatementRep);
            this.groupBox1.Controls.Add(this.buttSupportCatch);
            this.groupBox1.Controls.Add(this.buttSupportExchang);
            this.groupBox1.Controls.Add(this.buttOfferPrice);
            this.groupBox1.Controls.Add(this.buttIteam);
            this.groupBox1.Controls.Add(this.buttDailyRep);
            this.groupBox1.Controls.Add(this.buttEntries);
            this.groupBox1.Controls.Add(this.buttCurr);
            this.groupBox1.Controls.Add(this.buttSales);
            this.groupBox1.Controls.Add(this.buttAcc);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBox1.Size = new System.Drawing.Size(298, 934);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "الوصول السريع";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // buttCustomers
            // 
            this.buttCustomers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttCustomers.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttCustomers.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttCustomers.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttCustomers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttCustomers.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttCustomers.ForeColor = System.Drawing.Color.White;
            this.buttCustomers.Image = ((System.Drawing.Image)(resources.GetObject("buttCustomers.Image")));
            this.buttCustomers.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttCustomers.Location = new System.Drawing.Point(150, 471);
            this.buttCustomers.Name = "buttCustomers";
            this.buttCustomers.Size = new System.Drawing.Size(124, 50);
            this.buttCustomers.TabIndex = 229;
            this.buttCustomers.Text = "العملاء";
            this.buttCustomers.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttCustomers.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttCustomers.UseVisualStyleBackColor = false;
            this.buttCustomers.Click += new System.EventHandler(this.buttCustomers_Click);
            // 
            // buttBox
            // 
            this.buttBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBox.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttBox.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBox.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttBox.ForeColor = System.Drawing.Color.White;
            this.buttBox.Image = ((System.Drawing.Image)(resources.GetObject("buttBox.Image")));
            this.buttBox.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttBox.Location = new System.Drawing.Point(20, 136);
            this.buttBox.Name = "buttBox";
            this.buttBox.Size = new System.Drawing.Size(124, 50);
            this.buttBox.TabIndex = 220;
            this.buttBox.Text = "الصناديق";
            this.buttBox.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttBox.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttBox.UseVisualStyleBackColor = false;
            this.buttBox.Click += new System.EventHandler(this.buttBox_Click);
            // 
            // buttMyProfile
            // 
            this.buttMyProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttMyProfile.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttMyProfile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttMyProfile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttMyProfile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttMyProfile.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.buttMyProfile.ForeColor = System.Drawing.Color.White;
            this.buttMyProfile.Image = ((System.Drawing.Image)(resources.GetObject("buttMyProfile.Image")));
            this.buttMyProfile.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttMyProfile.Location = new System.Drawing.Point(20, 471);
            this.buttMyProfile.Name = "buttMyProfile";
            this.buttMyProfile.Size = new System.Drawing.Size(124, 50);
            this.buttMyProfile.TabIndex = 218;
            this.buttMyProfile.Text = "حسابي";
            this.buttMyProfile.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttMyProfile.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttMyProfile.UseVisualStyleBackColor = false;
            this.buttMyProfile.Click += new System.EventHandler(this.buttMyProfile_Click);
            // 
            // buttCustomerAccRep
            // 
            this.buttCustomerAccRep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttCustomerAccRep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttCustomerAccRep.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttCustomerAccRep.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttCustomerAccRep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttCustomerAccRep.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttCustomerAccRep.ForeColor = System.Drawing.Color.White;
            this.buttCustomerAccRep.Image = ((System.Drawing.Image)(resources.GetObject("buttCustomerAccRep.Image")));
            this.buttCustomerAccRep.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttCustomerAccRep.Location = new System.Drawing.Point(22, 863);
            this.buttCustomerAccRep.Name = "buttCustomerAccRep";
            this.buttCustomerAccRep.Size = new System.Drawing.Size(254, 50);
            this.buttCustomerAccRep.TabIndex = 215;
            this.buttCustomerAccRep.Text = "حركة عميل";
            this.buttCustomerAccRep.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttCustomerAccRep.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttCustomerAccRep.UseVisualStyleBackColor = false;
            this.buttCustomerAccRep.Click += new System.EventHandler(this.buttCustomerAccRep_Click);
            // 
            // buttGroupStored
            // 
            this.buttGroupStored.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttGroupStored.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttGroupStored.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttGroupStored.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttGroupStored.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttGroupStored.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
            this.buttGroupStored.ForeColor = System.Drawing.Color.White;
            this.buttGroupStored.Image = ((System.Drawing.Image)(resources.GetObject("buttGroupStored.Image")));
            this.buttGroupStored.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttGroupStored.Location = new System.Drawing.Point(20, 695);
            this.buttGroupStored.Name = "buttGroupStored";
            this.buttGroupStored.Size = new System.Drawing.Size(252, 50);
            this.buttGroupStored.TabIndex = 214;
            this.buttGroupStored.Text = "المجموعات المخــــــزنية";
            this.buttGroupStored.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttGroupStored.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttGroupStored.UseVisualStyleBackColor = false;
            this.buttGroupStored.Click += new System.EventHandler(this.buttGroupStored_Click);
            // 
            // buttOpeningBalance
            // 
            this.buttOpeningBalance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttOpeningBalance.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttOpeningBalance.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttOpeningBalance.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttOpeningBalance.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttOpeningBalance.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttOpeningBalance.ForeColor = System.Drawing.Color.White;
            this.buttOpeningBalance.Image = ((System.Drawing.Image)(resources.GetObject("buttOpeningBalance.Image")));
            this.buttOpeningBalance.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttOpeningBalance.Location = new System.Drawing.Point(20, 639);
            this.buttOpeningBalance.Name = "buttOpeningBalance";
            this.buttOpeningBalance.Size = new System.Drawing.Size(252, 50);
            this.buttOpeningBalance.TabIndex = 212;
            this.buttOpeningBalance.Text = "رصـــيد افتتاحي";
            this.buttOpeningBalance.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttOpeningBalance.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttOpeningBalance.UseVisualStyleBackColor = false;
            this.buttOpeningBalance.Click += new System.EventHandler(this.buttOpeningBalance_Click);
            // 
            // buttUserPermissions
            // 
            this.buttUserPermissions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttUserPermissions.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttUserPermissions.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttUserPermissions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttUserPermissions.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttUserPermissions.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttUserPermissions.ForeColor = System.Drawing.Color.White;
            this.buttUserPermissions.Image = ((System.Drawing.Image)(resources.GetObject("buttUserPermissions.Image")));
            this.buttUserPermissions.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttUserPermissions.Location = new System.Drawing.Point(20, 528);
            this.buttUserPermissions.Name = "buttUserPermissions";
            this.buttUserPermissions.Size = new System.Drawing.Size(254, 50);
            this.buttUserPermissions.TabIndex = 211;
            this.buttUserPermissions.Text = "المستخدمين  والصلاحيات";
            this.buttUserPermissions.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttUserPermissions.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttUserPermissions.UseVisualStyleBackColor = false;
            this.buttUserPermissions.Click += new System.EventHandler(this.buttUserPermissions_Click);
            // 
            // buttAccDefine
            // 
            this.buttAccDefine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAccDefine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAccDefine.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAccDefine.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAccDefine.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAccDefine.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttAccDefine.ForeColor = System.Drawing.Color.White;
            this.buttAccDefine.Image = ((System.Drawing.Image)(resources.GetObject("buttAccDefine.Image")));
            this.buttAccDefine.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttAccDefine.Location = new System.Drawing.Point(20, 751);
            this.buttAccDefine.Name = "buttAccDefine";
            this.buttAccDefine.Size = new System.Drawing.Size(252, 50);
            this.buttAccDefine.TabIndex = 210;
            this.buttAccDefine.Text = "تعريف الحسابات";
            this.buttAccDefine.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttAccDefine.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttAccDefine.UseVisualStyleBackColor = false;
            this.buttAccDefine.Click += new System.EventHandler(this.buttAccDefine_Click);
            // 
            // buttUnits
            // 
            this.buttUnits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttUnits.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttUnits.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttUnits.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttUnits.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttUnits.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttUnits.ForeColor = System.Drawing.Color.White;
            this.buttUnits.Image = ((System.Drawing.Image)(resources.GetObject("buttUnits.Image")));
            this.buttUnits.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttUnits.Location = new System.Drawing.Point(20, 807);
            this.buttUnits.Name = "buttUnits";
            this.buttUnits.Size = new System.Drawing.Size(124, 50);
            this.buttUnits.TabIndex = 209;
            this.buttUnits.Text = "الوحدات";
            this.buttUnits.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttUnits.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttUnits.UseVisualStyleBackColor = false;
            this.buttUnits.Click += new System.EventHandler(this.buttUnits_Click);
            // 
            // buttBoxMoveAccRepo
            // 
            this.buttBoxMoveAccRepo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBoxMoveAccRepo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBoxMoveAccRepo.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttBoxMoveAccRepo.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttBoxMoveAccRepo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBoxMoveAccRepo.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttBoxMoveAccRepo.ForeColor = System.Drawing.Color.White;
            this.buttBoxMoveAccRepo.Image = ((System.Drawing.Image)(resources.GetObject("buttBoxMoveAccRepo.Image")));
            this.buttBoxMoveAccRepo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttBoxMoveAccRepo.Location = new System.Drawing.Point(150, 583);
            this.buttBoxMoveAccRepo.Name = "buttBoxMoveAccRepo";
            this.buttBoxMoveAccRepo.Size = new System.Drawing.Size(124, 50);
            this.buttBoxMoveAccRepo.TabIndex = 208;
            this.buttBoxMoveAccRepo.Text = "حركة صندوق";
            this.buttBoxMoveAccRepo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttBoxMoveAccRepo.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttBoxMoveAccRepo.UseVisualStyleBackColor = false;
            this.buttBoxMoveAccRepo.Click += new System.EventHandler(this.buttBoxMoveAccRepo_Click);
            // 
            // buttCompanyData
            // 
            this.buttCompanyData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttCompanyData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttCompanyData.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttCompanyData.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttCompanyData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttCompanyData.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttCompanyData.ForeColor = System.Drawing.Color.White;
            this.buttCompanyData.Image = ((System.Drawing.Image)(resources.GetObject("buttCompanyData.Image")));
            this.buttCompanyData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttCompanyData.Location = new System.Drawing.Point(20, 583);
            this.buttCompanyData.Name = "buttCompanyData";
            this.buttCompanyData.Size = new System.Drawing.Size(124, 50);
            this.buttCompanyData.TabIndex = 207;
            this.buttCompanyData.Text = "بيانات الشركة";
            this.buttCompanyData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttCompanyData.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttCompanyData.UseVisualStyleBackColor = false;
            this.buttCompanyData.Click += new System.EventHandler(this.buttCompanyData_Click);
            // 
            // buttSalesReturn
            // 
            this.buttSalesReturn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttSalesReturn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttSalesReturn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttSalesReturn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttSalesReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttSalesReturn.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttSalesReturn.ForeColor = System.Drawing.Color.White;
            this.buttSalesReturn.Image = ((System.Drawing.Image)(resources.GetObject("buttSalesReturn.Image")));
            this.buttSalesReturn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttSalesReturn.Location = new System.Drawing.Point(150, 80);
            this.buttSalesReturn.Name = "buttSalesReturn";
            this.buttSalesReturn.Size = new System.Drawing.Size(124, 50);
            this.buttSalesReturn.TabIndex = 202;
            this.buttSalesReturn.Text = "مردود مبيعات";
            this.buttSalesReturn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttSalesReturn.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttSalesReturn.UseVisualStyleBackColor = false;
            this.buttSalesReturn.Click += new System.EventHandler(this.buttSalesReturn_Click);
            // 
            // buttItemTypes
            // 
            this.buttItemTypes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttItemTypes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttItemTypes.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttItemTypes.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttItemTypes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttItemTypes.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttItemTypes.ForeColor = System.Drawing.Color.White;
            this.buttItemTypes.Image = ((System.Drawing.Image)(resources.GetObject("buttItemTypes.Image")));
            this.buttItemTypes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttItemTypes.Location = new System.Drawing.Point(154, 807);
            this.buttItemTypes.Name = "buttItemTypes";
            this.buttItemTypes.Size = new System.Drawing.Size(122, 50);
            this.buttItemTypes.TabIndex = 199;
            this.buttItemTypes.Text = "فئات الاصناف";
            this.buttItemTypes.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttItemTypes.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttItemTypes.UseVisualStyleBackColor = false;
            this.buttItemTypes.Click += new System.EventHandler(this.buttItemTypes_Click);
            // 
            // buttPostingNon
            // 
            this.buttPostingNon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttPostingNon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttPostingNon.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttPostingNon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttPostingNon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttPostingNon.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttPostingNon.ForeColor = System.Drawing.Color.White;
            this.buttPostingNon.Image = ((System.Drawing.Image)(resources.GetObject("buttPostingNon.Image")));
            this.buttPostingNon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttPostingNon.Location = new System.Drawing.Point(20, 415);
            this.buttPostingNon.Name = "buttPostingNon";
            this.buttPostingNon.Size = new System.Drawing.Size(252, 50);
            this.buttPostingNon.TabIndex = 197;
            this.buttPostingNon.Text = "الغــــاء الترحيل";
            this.buttPostingNon.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttPostingNon.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttPostingNon.UseVisualStyleBackColor = false;
            this.buttPostingNon.Click += new System.EventHandler(this.buttPostingNon_Click);
            // 
            // buttAccStatementRep
            // 
            this.buttAccStatementRep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAccStatementRep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAccStatementRep.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAccStatementRep.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAccStatementRep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAccStatementRep.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttAccStatementRep.ForeColor = System.Drawing.Color.White;
            this.buttAccStatementRep.Image = ((System.Drawing.Image)(resources.GetObject("buttAccStatementRep.Image")));
            this.buttAccStatementRep.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttAccStatementRep.Location = new System.Drawing.Point(150, 247);
            this.buttAccStatementRep.Name = "buttAccStatementRep";
            this.buttAccStatementRep.Size = new System.Drawing.Size(124, 50);
            this.buttAccStatementRep.TabIndex = 196;
            this.buttAccStatementRep.Text = "كشف حسابات";
            this.buttAccStatementRep.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttAccStatementRep.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttAccStatementRep.UseVisualStyleBackColor = false;
            this.buttAccStatementRep.Click += new System.EventHandler(this.buttAccStatementRep_Click);
            // 
            // buttSupportCatch
            // 
            this.buttSupportCatch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttSupportCatch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttSupportCatch.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttSupportCatch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttSupportCatch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttSupportCatch.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttSupportCatch.ForeColor = System.Drawing.Color.White;
            this.buttSupportCatch.Image = ((System.Drawing.Image)(resources.GetObject("buttSupportCatch.Image")));
            this.buttSupportCatch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttSupportCatch.Location = new System.Drawing.Point(150, 303);
            this.buttSupportCatch.Name = "buttSupportCatch";
            this.buttSupportCatch.Size = new System.Drawing.Size(124, 50);
            this.buttSupportCatch.TabIndex = 194;
            this.buttSupportCatch.Text = "سند قبض";
            this.buttSupportCatch.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttSupportCatch.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttSupportCatch.UseVisualStyleBackColor = false;
            this.buttSupportCatch.Click += new System.EventHandler(this.buttSupportCatch_Click);
            // 
            // buttSupportExchang
            // 
            this.buttSupportExchang.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttSupportExchang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttSupportExchang.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttSupportExchang.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttSupportExchang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttSupportExchang.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttSupportExchang.ForeColor = System.Drawing.Color.White;
            this.buttSupportExchang.Image = ((System.Drawing.Image)(resources.GetObject("buttSupportExchang.Image")));
            this.buttSupportExchang.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttSupportExchang.Location = new System.Drawing.Point(20, 303);
            this.buttSupportExchang.Name = "buttSupportExchang";
            this.buttSupportExchang.Size = new System.Drawing.Size(124, 50);
            this.buttSupportExchang.TabIndex = 193;
            this.buttSupportExchang.Text = "سند صرف";
            this.buttSupportExchang.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttSupportExchang.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttSupportExchang.UseVisualStyleBackColor = false;
            this.buttSupportExchang.Click += new System.EventHandler(this.buttSupportExchang_Click);
            // 
            // buttOfferPrice
            // 
            this.buttOfferPrice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttOfferPrice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttOfferPrice.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttOfferPrice.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttOfferPrice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttOfferPrice.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttOfferPrice.ForeColor = System.Drawing.Color.White;
            this.buttOfferPrice.Image = ((System.Drawing.Image)(resources.GetObject("buttOfferPrice.Image")));
            this.buttOfferPrice.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttOfferPrice.Location = new System.Drawing.Point(22, 359);
            this.buttOfferPrice.Name = "buttOfferPrice";
            this.buttOfferPrice.Size = new System.Drawing.Size(122, 50);
            this.buttOfferPrice.TabIndex = 192;
            this.buttOfferPrice.Text = "تسعيرة الاصناف";
            this.buttOfferPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttOfferPrice.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttOfferPrice.UseVisualStyleBackColor = false;
            this.buttOfferPrice.Click += new System.EventHandler(this.buttOfferPrice_Click);
            // 
            // buttIteam
            // 
            this.buttIteam.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttIteam.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttIteam.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttIteam.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttIteam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttIteam.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttIteam.ForeColor = System.Drawing.Color.White;
            this.buttIteam.Image = ((System.Drawing.Image)(resources.GetObject("buttIteam.Image")));
            this.buttIteam.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttIteam.Location = new System.Drawing.Point(150, 359);
            this.buttIteam.Name = "buttIteam";
            this.buttIteam.Size = new System.Drawing.Size(124, 50);
            this.buttIteam.TabIndex = 191;
            this.buttIteam.Text = "الاصناف";
            this.buttIteam.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttIteam.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttIteam.UseVisualStyleBackColor = false;
            this.buttIteam.Click += new System.EventHandler(this.buttIteam_Click);
            // 
            // buttDailyRep
            // 
            this.buttDailyRep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDailyRep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDailyRep.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDailyRep.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttDailyRep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDailyRep.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttDailyRep.ForeColor = System.Drawing.Color.White;
            this.buttDailyRep.Image = ((System.Drawing.Image)(resources.GetObject("buttDailyRep.Image")));
            this.buttDailyRep.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttDailyRep.Location = new System.Drawing.Point(20, 191);
            this.buttDailyRep.Name = "buttDailyRep";
            this.buttDailyRep.Padding = new System.Windows.Forms.Padding(20, 0, 40, 0);
            this.buttDailyRep.Size = new System.Drawing.Size(252, 50);
            this.buttDailyRep.TabIndex = 190;
            this.buttDailyRep.Text = "شاشة الاستعلامات";
            this.buttDailyRep.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttDailyRep.UseVisualStyleBackColor = false;
            this.buttDailyRep.Click += new System.EventHandler(this.buttDailyRep_Click);
            // 
            // buttEntries
            // 
            this.buttEntries.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEntries.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEntries.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttEntries.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttEntries.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEntries.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttEntries.ForeColor = System.Drawing.Color.White;
            this.buttEntries.Image = ((System.Drawing.Image)(resources.GetObject("buttEntries.Image")));
            this.buttEntries.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttEntries.Location = new System.Drawing.Point(20, 247);
            this.buttEntries.Name = "buttEntries";
            this.buttEntries.Size = new System.Drawing.Size(124, 50);
            this.buttEntries.TabIndex = 188;
            this.buttEntries.Text = "سند قيد";
            this.buttEntries.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttEntries.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttEntries.UseVisualStyleBackColor = false;
            this.buttEntries.Click += new System.EventHandler(this.buttEntries_Click);
            // 
            // buttCurr
            // 
            this.buttCurr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttCurr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttCurr.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttCurr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttCurr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttCurr.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttCurr.ForeColor = System.Drawing.Color.White;
            this.buttCurr.Image = ((System.Drawing.Image)(resources.GetObject("buttCurr.Image")));
            this.buttCurr.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttCurr.Location = new System.Drawing.Point(152, 136);
            this.buttCurr.Name = "buttCurr";
            this.buttCurr.Size = new System.Drawing.Size(122, 50);
            this.buttCurr.TabIndex = 187;
            this.buttCurr.Text = "العملات";
            this.buttCurr.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttCurr.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttCurr.UseVisualStyleBackColor = false;
            this.buttCurr.Click += new System.EventHandler(this.buttCurr_Click);
            // 
            // buttSales
            // 
            this.buttSales.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttSales.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttSales.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttSales.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttSales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttSales.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttSales.ForeColor = System.Drawing.Color.White;
            this.buttSales.Image = ((System.Drawing.Image)(resources.GetObject("buttSales.Image")));
            this.buttSales.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttSales.Location = new System.Drawing.Point(20, 79);
            this.buttSales.Name = "buttSales";
            this.buttSales.Size = new System.Drawing.Size(124, 50);
            this.buttSales.TabIndex = 185;
            this.buttSales.Text = "فاتورة مبيعات";
            this.buttSales.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttSales.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttSales.UseVisualStyleBackColor = false;
            this.buttSales.Click += new System.EventHandler(this.buttSales_Click);
            // 
            // buttAcc
            // 
            this.buttAcc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAcc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAcc.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAcc.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAcc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAcc.Font = new System.Drawing.Font("Tahoma", 9.95F, System.Drawing.FontStyle.Bold);
            this.buttAcc.ForeColor = System.Drawing.Color.White;
            this.buttAcc.Image = ((System.Drawing.Image)(resources.GetObject("buttAcc.Image")));
            this.buttAcc.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttAcc.Location = new System.Drawing.Point(20, 24);
            this.buttAcc.Name = "buttAcc";
            this.buttAcc.Padding = new System.Windows.Forms.Padding(20, 0, 40, 0);
            this.buttAcc.Size = new System.Drawing.Size(254, 50);
            this.buttAcc.TabIndex = 172;
            this.buttAcc.Text = "الدليل المحاسبي";
            this.buttAcc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttAcc.UseVisualStyleBackColor = false;
            this.buttAcc.Click += new System.EventHandler(this.buttAcc_Click);
            // 
            // panRightHaed
            // 
            this.panRightHaed.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panRightHaed.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panRightHaed.Controls.Add(this.toolStripMain);
            this.panRightHaed.Dock = System.Windows.Forms.DockStyle.Top;
            this.panRightHaed.Location = new System.Drawing.Point(0, 0);
            this.panRightHaed.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panRightHaed.Name = "panRightHaed";
            this.panRightHaed.Size = new System.Drawing.Size(317, 25);
            this.panRightHaed.TabIndex = 0;
            // 
            // toolStripMain
            // 
            this.toolStripMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toolStripMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolStripMain.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton2,
            this.toolStripDropDownButton3,
            this.toolStripSeparator4,
            this.buttTS_RefrechPre});
            this.toolStripMain.Location = new System.Drawing.Point(0, 0);
            this.toolStripMain.Name = "toolStripMain";
            this.toolStripMain.Size = new System.Drawing.Size(315, 23);
            this.toolStripMain.TabIndex = 0;
            this.toolStripMain.Text = "toolStrip1";
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mangerStingToolStripMenuItem,
            this.mangerSysAccToolStripMenuItem,
            this.mangerSysPuToolStripMenuItem});
            this.toolStripDropDownButton2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(116, 20);
            this.toolStripDropDownButton2.Text = "القائمة الرئيسية";
            this.toolStripDropDownButton2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolStripDropDownButton2.Click += new System.EventHandler(this.toolStripDropDownButton2_Click);
            // 
            // mangerStingToolStripMenuItem
            // 
            this.mangerStingToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator2,
            this.تهئيةالحساباتToolStripMenuItem,
            this.تهئيةالمبيعاتToolStripMenuItem,
            this.تهئيةالمخازنToolStripMenuItem});
            this.mangerStingToolStripMenuItem.Name = "mangerStingToolStripMenuItem";
            this.mangerStingToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.mangerStingToolStripMenuItem.Text = "ادارة النظام";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(149, 6);
            // 
            // تهئيةالحساباتToolStripMenuItem
            // 
            this.تهئيةالحساباتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSM_Curr,
            this.TSM_Account,
            this.TSM_AccDefinition,
            this.TSM_BalanceOpen});
            this.تهئيةالحساباتToolStripMenuItem.Name = "تهئيةالحساباتToolStripMenuItem";
            this.تهئيةالحساباتToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.تهئيةالحساباتToolStripMenuItem.Text = "تهئية الحسابات";
            // 
            // TSM_Curr
            // 
            this.TSM_Curr.Image = ((System.Drawing.Image)(resources.GetObject("TSM_Curr.Image")));
            this.TSM_Curr.Name = "TSM_Curr";
            this.TSM_Curr.Size = new System.Drawing.Size(160, 26);
            this.TSM_Curr.Text = "العملات";
            this.TSM_Curr.Click += new System.EventHandler(this.TSM_Curr_Click);
            // 
            // TSM_Account
            // 
            this.TSM_Account.Image = ((System.Drawing.Image)(resources.GetObject("TSM_Account.Image")));
            this.TSM_Account.Name = "TSM_Account";
            this.TSM_Account.Size = new System.Drawing.Size(160, 26);
            this.TSM_Account.Text = "الدليل المحاسبي";
            this.TSM_Account.Click += new System.EventHandler(this.TSM_Account_Click);
            // 
            // TSM_AccDefinition
            // 
            this.TSM_AccDefinition.Image = ((System.Drawing.Image)(resources.GetObject("TSM_AccDefinition.Image")));
            this.TSM_AccDefinition.Name = "TSM_AccDefinition";
            this.TSM_AccDefinition.Size = new System.Drawing.Size(160, 26);
            this.TSM_AccDefinition.Text = "تعريف الحسابات";
            this.TSM_AccDefinition.Click += new System.EventHandler(this.TSM_AccDefinition_Click);
            // 
            // TSM_BalanceOpen
            // 
            this.TSM_BalanceOpen.Image = ((System.Drawing.Image)(resources.GetObject("TSM_BalanceOpen.Image")));
            this.TSM_BalanceOpen.Name = "TSM_BalanceOpen";
            this.TSM_BalanceOpen.Size = new System.Drawing.Size(160, 26);
            this.TSM_BalanceOpen.Text = "رصيد افتتاحي";
            this.TSM_BalanceOpen.Click += new System.EventHandler(this.TSM_BalanceOpen_Click);
            // 
            // تهئيةالمبيعاتToolStripMenuItem
            // 
            this.تهئيةالمبيعاتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSM_Customers,
            this.تسعيرةالاصنافToolStripMenuItem});
            this.تهئيةالمبيعاتToolStripMenuItem.Name = "تهئيةالمبيعاتToolStripMenuItem";
            this.تهئيةالمبيعاتToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.تهئيةالمبيعاتToolStripMenuItem.Text = "تهئية المبيعات";
            // 
            // TSM_Customers
            // 
            this.TSM_Customers.Image = ((System.Drawing.Image)(resources.GetObject("TSM_Customers.Image")));
            this.TSM_Customers.Name = "TSM_Customers";
            this.TSM_Customers.Size = new System.Drawing.Size(161, 26);
            this.TSM_Customers.Text = "ادارة العملاء";
            this.TSM_Customers.Click += new System.EventHandler(this.TSM_Customers_Click);
            // 
            // تسعيرةالاصنافToolStripMenuItem
            // 
            this.تسعيرةالاصنافToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("تسعيرةالاصنافToolStripMenuItem.Image")));
            this.تسعيرةالاصنافToolStripMenuItem.Name = "تسعيرةالاصنافToolStripMenuItem";
            this.تسعيرةالاصنافToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.تسعيرةالاصنافToolStripMenuItem.Text = "تسعيرة الاصناف";
            this.تسعيرةالاصنافToolStripMenuItem.Click += new System.EventHandler(this.تسعيرةالاصنافToolStripMenuItem_Click);
            // 
            // تهئيةالمخازنToolStripMenuItem
            // 
            this.تهئيةالمخازنToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TSM_GroupStored,
            this.فئاتالاصنافToolStripMenuItem,
            this.TSM_Unit,
            this.TSM_Items});
            this.تهئيةالمخازنToolStripMenuItem.Name = "تهئيةالمخازنToolStripMenuItem";
            this.تهئيةالمخازنToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.تهئيةالمخازنToolStripMenuItem.Text = "تهئية المخزون";
            // 
            // TSM_GroupStored
            // 
            this.TSM_GroupStored.Name = "TSM_GroupStored";
            this.TSM_GroupStored.Size = new System.Drawing.Size(176, 26);
            this.TSM_GroupStored.Text = "المجموعات المخزنية";
            this.TSM_GroupStored.Click += new System.EventHandler(this.TSM_GroupStored_Click);
            // 
            // فئاتالاصنافToolStripMenuItem
            // 
            this.فئاتالاصنافToolStripMenuItem.Name = "فئاتالاصنافToolStripMenuItem";
            this.فئاتالاصنافToolStripMenuItem.Size = new System.Drawing.Size(176, 26);
            this.فئاتالاصنافToolStripMenuItem.Text = "فئات الاصناف";
            this.فئاتالاصنافToolStripMenuItem.Click += new System.EventHandler(this.فئاتالاصنافToolStripMenuItem_Click);
            // 
            // TSM_Unit
            // 
            this.TSM_Unit.Name = "TSM_Unit";
            this.TSM_Unit.Size = new System.Drawing.Size(176, 26);
            this.TSM_Unit.Text = "الوحدات";
            this.TSM_Unit.Click += new System.EventHandler(this.TSM_Unit_Click);
            // 
            // TSM_Items
            // 
            this.TSM_Items.Image = ((System.Drawing.Image)(resources.GetObject("TSM_Items.Image")));
            this.TSM_Items.Name = "TSM_Items";
            this.TSM_Items.Size = new System.Drawing.Size(176, 26);
            this.TSM_Items.Text = "الاصناف";
            this.TSM_Items.Click += new System.EventHandler(this.TSM_Items_Click);
            // 
            // mangerSysAccToolStripMenuItem
            // 
            this.mangerSysAccToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.المدخلاتToolStripMenuItem,
            this.العملياتToolStripMenuItem});
            this.mangerSysAccToolStripMenuItem.Name = "mangerSysAccToolStripMenuItem";
            this.mangerSysAccToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.mangerSysAccToolStripMenuItem.Text = "نظام الحسابات";
            // 
            // المدخلاتToolStripMenuItem
            // 
            this.المدخلاتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.الدليلالمحاسبيToolStripMenuItem1,
            this.رصيدافتتاحيToolStripMenuItem,
            this.toolStripSeparator3,
            this.بياناتالصناديقToolStripMenuItem});
            this.المدخلاتToolStripMenuItem.Name = "المدخلاتToolStripMenuItem";
            this.المدخلاتToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.المدخلاتToolStripMenuItem.Text = "المدخلات";
            // 
            // الدليلالمحاسبيToolStripMenuItem1
            // 
            this.الدليلالمحاسبيToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("الدليلالمحاسبيToolStripMenuItem1.Image")));
            this.الدليلالمحاسبيToolStripMenuItem1.Name = "الدليلالمحاسبيToolStripMenuItem1";
            this.الدليلالمحاسبيToolStripMenuItem1.Size = new System.Drawing.Size(159, 26);
            this.الدليلالمحاسبيToolStripMenuItem1.Text = "الدليل المحاسبي";
            this.الدليلالمحاسبيToolStripMenuItem1.Click += new System.EventHandler(this.الدليلالمحاسبيToolStripMenuItem1_Click);
            // 
            // رصيدافتتاحيToolStripMenuItem
            // 
            this.رصيدافتتاحيToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("رصيدافتتاحيToolStripMenuItem.Image")));
            this.رصيدافتتاحيToolStripMenuItem.Name = "رصيدافتتاحيToolStripMenuItem";
            this.رصيدافتتاحيToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.رصيدافتتاحيToolStripMenuItem.Text = "رصيد افتتاحي";
            this.رصيدافتتاحيToolStripMenuItem.Click += new System.EventHandler(this.رصيدافتتاحيToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(156, 6);
            // 
            // بياناتالصناديقToolStripMenuItem
            // 
            this.بياناتالصناديقToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("بياناتالصناديقToolStripMenuItem.Image")));
            this.بياناتالصناديقToolStripMenuItem.Name = "بياناتالصناديقToolStripMenuItem";
            this.بياناتالصناديقToolStripMenuItem.Size = new System.Drawing.Size(159, 26);
            this.بياناتالصناديقToolStripMenuItem.Text = "بيانات الصناديق";
            this.بياناتالصناديقToolStripMenuItem.Click += new System.EventHandler(this.بياناتالصناديقToolStripMenuItem_Click);
            // 
            // العملياتToolStripMenuItem
            // 
            this.العملياتToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.قيديدويToolStripMenuItem,
            this.سندقبضToolStripMenuItem,
            this.سندصرفToolStripMenuItem,
            this.إلغاءترحيلToolStripMenuItem});
            this.العملياتToolStripMenuItem.Name = "العملياتToolStripMenuItem";
            this.العملياتToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.العملياتToolStripMenuItem.Text = "العمليات";
            // 
            // قيديدويToolStripMenuItem
            // 
            this.قيديدويToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("قيديدويToolStripMenuItem.Image")));
            this.قيديدويToolStripMenuItem.Name = "قيديدويToolStripMenuItem";
            this.قيديدويToolStripMenuItem.Size = new System.Drawing.Size(156, 26);
            this.قيديدويToolStripMenuItem.Text = "قيد يدوي";
            this.قيديدويToolStripMenuItem.Click += new System.EventHandler(this.قيديدويToolStripMenuItem_Click);
            // 
            // سندقبضToolStripMenuItem
            // 
            this.سندقبضToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("سندقبضToolStripMenuItem.Image")));
            this.سندقبضToolStripMenuItem.Name = "سندقبضToolStripMenuItem";
            this.سندقبضToolStripMenuItem.Size = new System.Drawing.Size(156, 26);
            this.سندقبضToolStripMenuItem.Text = "سند قبض";
            this.سندقبضToolStripMenuItem.Click += new System.EventHandler(this.سندقبضToolStripMenuItem_Click);
            // 
            // سندصرفToolStripMenuItem
            // 
            this.سندصرفToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("سندصرفToolStripMenuItem.Image")));
            this.سندصرفToolStripMenuItem.Name = "سندصرفToolStripMenuItem";
            this.سندصرفToolStripMenuItem.Size = new System.Drawing.Size(156, 26);
            this.سندصرفToolStripMenuItem.Text = "سند صرف";
            this.سندصرفToolStripMenuItem.Click += new System.EventHandler(this.سندصرفToolStripMenuItem_Click);
            // 
            // إلغاءترحيلToolStripMenuItem
            // 
            this.إلغاءترحيلToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("إلغاءترحيلToolStripMenuItem.Image")));
            this.إلغاءترحيلToolStripMenuItem.Name = "إلغاءترحيلToolStripMenuItem";
            this.إلغاءترحيلToolStripMenuItem.Size = new System.Drawing.Size(156, 26);
            this.إلغاءترحيلToolStripMenuItem.Text = "إلغاء ترحيل";
            this.إلغاءترحيلToolStripMenuItem.Click += new System.EventHandler(this.إلغاءترحيلToolStripMenuItem_Click);
            // 
            // mangerSysPuToolStripMenuItem
            // 
            this.mangerSysPuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.العملياتToolStripMenuItem2,
            this.التقاريرToolStripMenuItem});
            this.mangerSysPuToolStripMenuItem.Name = "mangerSysPuToolStripMenuItem";
            this.mangerSysPuToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.mangerSysPuToolStripMenuItem.Text = "نظام المبيعات";
            // 
            // العملياتToolStripMenuItem2
            // 
            this.العملياتToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.فاتورةمبيعاتToolStripMenuItem,
            this.مردودمبيعاتToolStripMenuItem,
            this.عرضسعرToolStripMenuItem,
            this.ادارةالعملاءToolStripMenuItem1});
            this.العملياتToolStripMenuItem2.Name = "العملياتToolStripMenuItem2";
            this.العملياتToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.العملياتToolStripMenuItem2.Text = "العمليات";
            // 
            // فاتورةمبيعاتToolStripMenuItem
            // 
            this.فاتورةمبيعاتToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("فاتورةمبيعاتToolStripMenuItem.Image")));
            this.فاتورةمبيعاتToolStripMenuItem.Name = "فاتورةمبيعاتToolStripMenuItem";
            this.فاتورةمبيعاتToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.فاتورةمبيعاتToolStripMenuItem.Text = "فاتورة مبيعات";
            this.فاتورةمبيعاتToolStripMenuItem.Click += new System.EventHandler(this.فاتورةمبيعاتToolStripMenuItem_Click);
            // 
            // مردودمبيعاتToolStripMenuItem
            // 
            this.مردودمبيعاتToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("مردودمبيعاتToolStripMenuItem.Image")));
            this.مردودمبيعاتToolStripMenuItem.Name = "مردودمبيعاتToolStripMenuItem";
            this.مردودمبيعاتToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.مردودمبيعاتToolStripMenuItem.Text = "مردود مبيعات";
            this.مردودمبيعاتToolStripMenuItem.Click += new System.EventHandler(this.مردودمبيعاتToolStripMenuItem_Click);
            // 
            // عرضسعرToolStripMenuItem
            // 
            this.عرضسعرToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("عرضسعرToolStripMenuItem.Image")));
            this.عرضسعرToolStripMenuItem.Name = "عرضسعرToolStripMenuItem";
            this.عرضسعرToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.عرضسعرToolStripMenuItem.Text = "تسعيرة الاصناف";
            this.عرضسعرToolStripMenuItem.Click += new System.EventHandler(this.عرضسعرToolStripMenuItem_Click);
            // 
            // ادارةالعملاءToolStripMenuItem1
            // 
            this.ادارةالعملاءToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("ادارةالعملاءToolStripMenuItem1.Image")));
            this.ادارةالعملاءToolStripMenuItem1.Name = "ادارةالعملاءToolStripMenuItem1";
            this.ادارةالعملاءToolStripMenuItem1.Size = new System.Drawing.Size(161, 26);
            this.ادارةالعملاءToolStripMenuItem1.Text = "ادارة العملاء";
            this.ادارةالعملاءToolStripMenuItem1.Click += new System.EventHandler(this.ادارةالعملاءToolStripMenuItem1_Click);
            // 
            // toolStripDropDownButton3
            // 
            this.toolStripDropDownButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.انشاءنسخةاحتياطيةToolStripMenuItem,
            this.استعادةنسخةاحتياطيةToolStripMenuItem,
            this.toolStripSeparator1,
            this.تغييركلمةالمرورToolStripMenuItem,
            this.إدارةالمستخدمينToolStripMenuItem});
            this.toolStripDropDownButton3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripDropDownButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton3.Image")));
            this.toolStripDropDownButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton3.Name = "toolStripDropDownButton3";
            this.toolStripDropDownButton3.Size = new System.Drawing.Size(33, 20);
            this.toolStripDropDownButton3.Text = "toolStripDropDownButton3";
            this.toolStripDropDownButton3.Click += new System.EventHandler(this.toolStripDropDownButton3_Click);
            // 
            // انشاءنسخةاحتياطيةToolStripMenuItem
            // 
            this.انشاءنسخةاحتياطيةToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("انشاءنسخةاحتياطيةToolStripMenuItem.Image")));
            this.انشاءنسخةاحتياطيةToolStripMenuItem.Name = "انشاءنسخةاحتياطيةToolStripMenuItem";
            this.انشاءنسخةاحتياطيةToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.انشاءنسخةاحتياطيةToolStripMenuItem.Text = "انشاء نسخة احتياطية";
            // 
            // استعادةنسخةاحتياطيةToolStripMenuItem
            // 
            this.استعادةنسخةاحتياطيةToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("استعادةنسخةاحتياطيةToolStripMenuItem.Image")));
            this.استعادةنسخةاحتياطيةToolStripMenuItem.Name = "استعادةنسخةاحتياطيةToolStripMenuItem";
            this.استعادةنسخةاحتياطيةToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.استعادةنسخةاحتياطيةToolStripMenuItem.Text = "استعادة نسخة احتياطية";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(187, 6);
            // 
            // تغييركلمةالمرورToolStripMenuItem
            // 
            this.تغييركلمةالمرورToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("تغييركلمةالمرورToolStripMenuItem.Image")));
            this.تغييركلمةالمرورToolStripMenuItem.Name = "تغييركلمةالمرورToolStripMenuItem";
            this.تغييركلمةالمرورToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.تغييركلمةالمرورToolStripMenuItem.Text = "تغيير كلمة المرور";
            // 
            // إدارةالمستخدمينToolStripMenuItem
            // 
            this.إدارةالمستخدمينToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("إدارةالمستخدمينToolStripMenuItem.Image")));
            this.إدارةالمستخدمينToolStripMenuItem.Name = "إدارةالمستخدمينToolStripMenuItem";
            this.إدارةالمستخدمينToolStripMenuItem.Size = new System.Drawing.Size(190, 22);
            this.إدارةالمستخدمينToolStripMenuItem.Text = "إدارة المستخدمين";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 23);
            // 
            // buttTS_RefrechPre
            // 
            this.buttTS_RefrechPre.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.buttTS_RefrechPre.Image = ((System.Drawing.Image)(resources.GetObject("buttTS_RefrechPre.Image")));
            this.buttTS_RefrechPre.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.buttTS_RefrechPre.Name = "buttTS_RefrechPre";
            this.buttTS_RefrechPre.Size = new System.Drawing.Size(24, 20);
            this.buttTS_RefrechPre.Text = "تحديث صلاحياتي";
            this.buttTS_RefrechPre.Click += new System.EventHandler(this.buttTS_RefrechPre_Click);
            // 
            // panDawon
            // 
            this.panDawon.Controls.Add(this.statusStrip1);
            this.panDawon.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panDawon.Location = new System.Drawing.Point(0, 867);
            this.panDawon.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panDawon.Name = "panDawon";
            this.panDawon.Size = new System.Drawing.Size(1501, 33);
            this.panDawon.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.IdUser,
            this.NameUser,
            this.toolStripStatusLabel3,
            this.toolStripStatusLabel4,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel6,
            this.toolStripStatusLabel7,
            this.toolStripDropDownButton1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 0);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(12, 0, 1, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1501, 33);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(60, 28);
            this.toolStripStatusLabel1.Text = "المستخدم :";
            // 
            // IdUser
            // 
            this.IdUser.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.IdUser.Name = "IdUser";
            this.IdUser.Size = new System.Drawing.Size(44, 28);
            this.IdUser.Text = "IdUser";
            this.IdUser.Visible = false;
            // 
            // NameUser
            // 
            this.NameUser.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.NameUser.Name = "NameUser";
            this.NameUser.Size = new System.Drawing.Size(66, 28);
            this.NameUser.Text = "NameUser";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(15, 28);
            this.toolStripStatusLabel3.Text = "||";
            // 
            // toolStripStatusLabel4
            // 
            this.toolStripStatusLabel4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toolStripStatusLabel4.Name = "toolStripStatusLabel4";
            this.toolStripStatusLabel4.Size = new System.Drawing.Size(104, 28);
            this.toolStripStatusLabel4.Text = "وقت الدخول للنظام : ";
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(65, 28);
            this.toolStripStatusLabel5.Text = "TimeLogin";
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripStatusLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            this.toolStripStatusLabel6.Size = new System.Drawing.Size(15, 28);
            this.toolStripStatusLabel6.Text = "||";
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            this.toolStripStatusLabel7.Size = new System.Drawing.Size(118, 28);
            this.toolStripStatusLabel7.Text = "toolStripStatusLabel7";
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.فلانToolStripMenuItem3,
            this.فلانToolStripMenuItem2,
            this.فلانToolStripMenuItem1,
            this.فلانToolStripMenuItem,
            this.نوراالشميريToolStripMenuItem,
            this.هيثمالكحلانيToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(33, 31);
            this.toolStripDropDownButton1.Text = "عمل الطلاب";
            // 
            // فلانToolStripMenuItem3
            // 
            this.فلانToolStripMenuItem3.Image = ((System.Drawing.Image)(resources.GetObject("فلانToolStripMenuItem3.Image")));
            this.فلانToolStripMenuItem3.Name = "فلانToolStripMenuItem3";
            this.فلانToolStripMenuItem3.Size = new System.Drawing.Size(144, 22);
            this.فلانToolStripMenuItem3.Text = "ابراهيم الدبعي";
            // 
            // فلانToolStripMenuItem2
            // 
            this.فلانToolStripMenuItem2.Image = ((System.Drawing.Image)(resources.GetObject("فلانToolStripMenuItem2.Image")));
            this.فلانToolStripMenuItem2.Name = "فلانToolStripMenuItem2";
            this.فلانToolStripMenuItem2.Size = new System.Drawing.Size(144, 22);
            this.فلانToolStripMenuItem2.Text = "اسامة الدبعي";
            // 
            // فلانToolStripMenuItem1
            // 
            this.فلانToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("فلانToolStripMenuItem1.Image")));
            this.فلانToolStripMenuItem1.Name = "فلانToolStripMenuItem1";
            this.فلانToolStripMenuItem1.Size = new System.Drawing.Size(144, 22);
            this.فلانToolStripMenuItem1.Text = "أسماء الجعدي";
            // 
            // فلانToolStripMenuItem
            // 
            this.فلانToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("فلانToolStripMenuItem.Image")));
            this.فلانToolStripMenuItem.Name = "فلانToolStripMenuItem";
            this.فلانToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.فلانToolStripMenuItem.Text = "صهيب المشيري";
            // 
            // نوراالشميريToolStripMenuItem
            // 
            this.نوراالشميريToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("نوراالشميريToolStripMenuItem.Image")));
            this.نوراالشميريToolStripMenuItem.Name = "نوراالشميريToolStripMenuItem";
            this.نوراالشميريToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.نوراالشميريToolStripMenuItem.Text = "نورا الشميري";
            // 
            // هيثمالكحلانيToolStripMenuItem
            // 
            this.هيثمالكحلانيToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("هيثمالكحلانيToolStripMenuItem.Image")));
            this.هيثمالكحلانيToolStripMenuItem.Name = "هيثمالكحلانيToolStripMenuItem";
            this.هيثمالكحلانيToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.هيثمالكحلانيToolStripMenuItem.Text = "هيثم الكحلاني";
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.labTitle);
            this.panUp.Controls.Add(this.pictureClose);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(1501, 35);
            this.panUp.TabIndex = 0;
            this.panUp.Paint += new System.Windows.Forms.PaintEventHandler(this.panUp_Paint);
            // 
            // labTitle
            // 
            this.labTitle.AutoSize = true;
            this.labTitle.Dock = System.Windows.Forms.DockStyle.Right;
            this.labTitle.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labTitle.ForeColor = System.Drawing.Color.White;
            this.labTitle.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labTitle.Location = new System.Drawing.Point(1116, 0);
            this.labTitle.Name = "labTitle";
            this.labTitle.Size = new System.Drawing.Size(385, 27);
            this.labTitle.TabIndex = 11;
            this.labTitle.Text = "نظام محاسبي مالي وإدارة المبيعات";
            // 
            // pictureClose
            // 
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureClose.Image = ((System.Drawing.Image)(resources.GetObject("pictureClose.Image")));
            this.pictureClose.Location = new System.Drawing.Point(6, 3);
            this.pictureClose.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureClose.Name = "pictureClose";
            this.pictureClose.Size = new System.Drawing.Size(30, 28);
            this.pictureClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureClose.TabIndex = 10;
            this.pictureClose.TabStop = false;
            this.pictureClose.Click += new System.EventHandler(this.pictureClose_Click);
            this.pictureClose.MouseLeave += new System.EventHandler(this.pictureClose_MouseLeave);
            this.pictureClose.MouseHover += new System.EventHandler(this.pictureClose_MouseHover);
            // 
            // التقاريرToolStripMenuItem
            // 
            this.التقاريرToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.صافيالمبيعاتToolStripMenuItem});
            this.التقاريرToolStripMenuItem.Name = "التقاريرToolStripMenuItem";
            this.التقاريرToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.التقاريرToolStripMenuItem.Text = "التقارير";
            // 
            // صافيالمبيعاتToolStripMenuItem
            // 
            this.صافيالمبيعاتToolStripMenuItem.Name = "صافيالمبيعاتToolStripMenuItem";
            this.صافيالمبيعاتToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.صافيالمبيعاتToolStripMenuItem.Text = "صافي المبيعات";
            this.صافيالمبيعاتToolStripMenuItem.Click += new System.EventHandler(this.صافيالمبيعاتToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1501, 900);
            this.Controls.Add(this.panMain);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.Name = "MainForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "الشاشة الرئيسية";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panMain.ResumeLayout(false);
            this.panLeft.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panRight.ResumeLayout(false);
            this.panRightFill.ResumeLayout(false);
            this.panRightFill.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.panRightHaed.ResumeLayout(false);
            this.panRightHaed.PerformLayout();
            this.toolStripMain.ResumeLayout(false);
            this.toolStripMain.PerformLayout();
            this.panDawon.ResumeLayout(false);
            this.panDawon.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureClose)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panMain;
        private System.Windows.Forms.Panel panLeft;
        private System.Windows.Forms.Panel panRight;
        private System.Windows.Forms.Panel panRightFill;
        private System.Windows.Forms.Panel panRightHaed;
        private System.Windows.Forms.Panel panDawon;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.ToolStrip toolStripMain;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton3;
        private System.Windows.Forms.ToolStripMenuItem انشاءنسخةاحتياطيةToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem استعادةنسخةاحتياطيةToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem تغييركلمةالمرورToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إدارةالمستخدمينToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureClose;
        private System.Windows.Forms.ToolStripMenuItem mangerStingToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem تهئيةالحساباتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TSM_Curr;
        private System.Windows.Forms.ToolStripMenuItem TSM_AccDefinition;
        private System.Windows.Forms.ToolStripMenuItem تهئيةالمبيعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem تهئيةالمخازنToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TSM_Unit;
        private System.Windows.Forms.ToolStripMenuItem TSM_GroupStored;
        private System.Windows.Forms.ToolStripMenuItem TSM_Items;
        private System.Windows.Forms.ToolStripMenuItem mangerSysAccToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem المدخلاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem الدليلالمحاسبيToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem رصيدافتتاحيToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem بياناتالصناديقToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem العملياتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem قيديدويToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سندقبضToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem سندصرفToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem إلغاءترحيلToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mangerSysPuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem العملياتToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem فاتورةمبيعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem مردودمبيعاتToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem عرضسعرToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ادارةالعملاءToolStripMenuItem1;
        private System.Windows.Forms.Label labTitle;
        private System.Windows.Forms.ToolStripMenuItem TSM_Account;
        private System.Windows.Forms.ToolStripMenuItem TSM_BalanceOpen;
        private System.Windows.Forms.ToolStripMenuItem TSM_Customers;
        private System.Windows.Forms.ToolStripMenuItem تسعيرةالاصنافToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttAcc;
        private System.Windows.Forms.Button buttSales;
        private System.Windows.Forms.Button buttCurr;
        private System.Windows.Forms.Button buttEntries;
        private System.Windows.Forms.Button buttDailyRep;
        private System.Windows.Forms.Button buttIteam;
        private System.Windows.Forms.Button buttOfferPrice;
        private System.Windows.Forms.Button buttSupportCatch;
        private System.Windows.Forms.Button buttSupportExchang;
        private System.Windows.Forms.Button buttAccStatementRep;
        private System.Windows.Forms.Button buttPostingNon;
        private System.Windows.Forms.Button buttItemTypes;
        private System.Windows.Forms.Button buttSalesReturn;
        private System.Windows.Forms.Button buttUserPermissions;
        private System.Windows.Forms.Button buttAccDefine;
        private System.Windows.Forms.Button buttUnits;
        private System.Windows.Forms.Button buttBoxMoveAccRepo;
        private System.Windows.Forms.Button buttCompanyData;
        private System.Windows.Forms.Button buttGroupStored;
        private System.Windows.Forms.Button buttOpeningBalance;
        private System.Windows.Forms.Button buttCustomerAccRep;
        private System.Windows.Forms.Button buttBox;
        private System.Windows.Forms.Button buttMyProfile;
        private System.Windows.Forms.Button buttCustomers;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel IdUser;
        private System.Windows.Forms.ToolStripStatusLabel NameUser;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel4;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem فلانToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem فلانToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem فلانToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem فلانToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem نوراالشميريToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem هيثمالكحلانيToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton buttTS_RefrechPre;
        private System.Windows.Forms.ToolStripMenuItem فئاتالاصنافToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem التقاريرToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem صافيالمبيعاتToolStripMenuItem;
    }
}

