﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.FormsProject;
using AccSystem.FormsProject.Sales;
using AccSystem.FormsProject.Accounts;
using AccSystem.FormsProject.Stores;

namespace AccSystem.FormsProject.Sys
{
    public partial class MainForm : Form
    {
       
        #region المتغيرات


       
        DataTable tb;
        Dictionary<string, string> ScreenUser
        = new Dictionary<string, string>();    //شاشات المستخدم المتاحة

            /*
                 باقي عند تشغيل البرنامج يروح يحفظ جميع السندات الي مشيك عليهم انهم مرحلين
     بعدين يروح يفحص في اليومية العامة اذا مهلوش يحفظه
              عشان يعرض داتا جريت فيو يوجد سندات فيها اخطاء يرجى مراجعة الدعم الفني او مدير النظام
      */
        Dictionary<string, string> GetAllScreenUser(string idUser)
        {
            /*
            الغرض من الداله نرسلها  رقم المستخدم
          ترجع لنا رقم الشاشة واسمها الي مرتبطها مع المستخدم 
            */
            ClassesProject.PermissionsSQL prem = new ClassesProject.PermissionsSQL();
            if (tb != null)
                tb = null;
            tb = new DataTable();
            Dictionary<string, string> ScreenUser = new Dictionary<string, string>();
            ScreenUser.Clear();
           tb = prem.GetAllPermissionsAllScreen(idUser,"Main");
            if (tb!=null&&tb.Rows.Count > 0)
               for(int i=0;i< tb.Rows.Count;i++)
                    if((bool)tb.Rows[i][2])
                  ScreenUser.Add(
                      tb.Rows[i][1].ToString(),//Screen_Name
                      tb.Rows[i][0].ToString() //Screen_id
                      );
          
            //if (ScreenUser.Count > 0)
            //    for (int i = 0; i < tb.Rows.Count; i++)
            //        MessageBox.Show(ScreenUser.Keys.ElementAt(i), (ScreenUser[ScreenUser.Keys.ElementAt(i)]));
            return ScreenUser;
            #region الاستعلام
            /*
            SELECT    
 Permissions.Screen_id_fk,Screens.Screen_Name, 
 Permissions.Showed, Permissions.Inserted,
 Permissions.EditeDate, Permissions.Posting,
 Permissions.Saerch, Permissions.Printed, 
 Permissions.Updated, Permissions.Deleted 
  FROM            Permissions INNER JOIN Screens ON Permissions.Screen_id_fk = Screens.Screen_id where Permissions.User_id_fk =1
            */
            #endregion
        }

        void ShowScreen(string nameScreen)
        {
            if (ScreenUser.Count > 0)
            {
                ClassesProject.ControlProj ConShwoFrm = new ClassesProject.ControlProj();
                string idScreen;

                if (ScreenUser.TryGetValue(nameScreen, out idScreen))
                {
                    //MessageBox.Show("nameScreen: " + nameScreen, "idScreen: "+idScreen);
                    ConShwoFrm.PlayForm(idScreen, nameScreen, IdUser.Text);
                }
                else
                {
                    MessageBox.Show("ليس لديك صلاحية لدخول هذه الشاشة","",MessageBoxButtons.OK,MessageBoxIcon.Stop);
                    //Console.WriteLine("Could not find the specified key.");
                }
            }
            else MessageBox.Show("لا تمتلك صلاحية اي شاشة من شاشات النظام");

        }
        #endregion

        public MainForm(string idUserrr,string nameUserrr)
        {
            
            InitializeComponent();
            IdUser.Text = idUserrr;
            NameUser.Text = nameUserrr;
            ScreenUser.Clear();
            ScreenUser =GetAllScreenUser(IdUser.Text);

        }
      
                                                 

     
     

        private void pictureClose_Click(object sender, EventArgs e)
        {
           
            this.Close();
        }
       
      

        private void panLeft_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureClose_MouseHover(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = Color.Red;
        }

        private void pictureClose_MouseLeave(object sender, EventArgs e)
        {
            this.pictureClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
        }

        private void toolStripDropDownButton2_Click(object sender, EventArgs e)
        {

        }

     

        private void toolStripDropDownButton3_Click(object sender, EventArgs e)
        {

        }

        private void panUp_Paint(object sender, PaintEventArgs e)
        {

        }
        

        private void MainForm_Load(object sender, EventArgs e)
        { 
            // فتح الاتصال من قاعده البيانات
         
        }

  

        //private void button39_Click(object sender, EventArgs e)
        //{
        //    Dictionary<string, bool> dict=new Dictionary<string, bool>();

        //    TestForm t = new TestForm(dict);
        //    t.ShowDialog();
        //}

        private void buttCurr_Click(object sender, EventArgs e)
        {
            ShowScreen("Currency");
       
        }

        private void buttAcc_Click(object sender, EventArgs e)
        {
            ShowScreen("Account");
        }

        private void buttPurchRequest_Click(object sender, EventArgs e)
        {
            ShowScreen("A"); //طلب شراء
        }

        private void buttPurch_Click(object sender, EventArgs e)
        {
            ShowScreen("purchBill");
        }

        private void buttSales_Click(object sender, EventArgs e)
        {
            ShowScreen("SaleBill");
        }

        private void buttOfferPrice_Click(object sender, EventArgs e)
        {
            ShowScreen("Pricing");
        }

        private void buttIteam_Click(object sender, EventArgs e)
        {
            ShowScreen("Items");
        }

        private void buttBox_Click(object sender, EventArgs e)
        {
            ShowScreen("Boxs");
        }

        private void buttDailyRep_Click(object sender, EventArgs e)
        {
            ShowScreen("FrmAllSelection");
        }

        private void buttAccStatementRep_Click(object sender, EventArgs e)
        {
            ShowScreen("FrmAllSelectAcc");
        }

        private void buttCustomers_Click(object sender, EventArgs e)
        {
            ShowScreen("Customers");
        }

        private void buttSuppliers_Click(object sender, EventArgs e)
        {
            ShowScreen("Suplliers");
        }

        private void buttMyProfile_Click(object sender, EventArgs e)
        {
             ShowScreen("MyAccount");
        }

        private void buttEntries_Click(object sender, EventArgs e)
        {
             ShowScreen("Entries");
        }

        private void buttSupportCatch_Click(object sender, EventArgs e)
        {
             ShowScreen("SupportCatch");
        }

        private void buttSupportExchang_Click(object sender, EventArgs e)
        {
             ShowScreen("SupportExchang");
        }

        private void buttBalanceSheetReport_Click(object sender, EventArgs e)
        {
            ShowScreen("ميزان المراجعة");
        }

        private void buttDB_Click(object sender, EventArgs e)
        {
            ShowScreen("قاعدة البيانات");
        }

        private void buttPosting_Click(object sender, EventArgs e)
        {
            ShowScreen("ترحيل");
        }

        private void buttPostingNon_Click(object sender, EventArgs e)
        {
            ShowScreen("FrmNonPosting");
        }

        private void buttCustomerAccRep_Click(object sender, EventArgs e)
        {
            ShowScreen("FrmRepCustAnalytical");
        }

        private void buttPurchReturn_Click(object sender, EventArgs e)
        {
            ShowScreen("مردود مشتريات");
        }

        private void buttSalesReturn_Click(object sender, EventArgs e)
        {
            ShowScreen("SaleBill_Return");
        }

        private void buttQueryScreen_Click(object sender, EventArgs e)
        {
            ShowScreen("شاشة الاستعلامات");
        }

        private void buttUserPermissions_Click(object sender, EventArgs e)
        {
            ShowScreen("Useres");
        }

        private void buttItemTypes_Click(object sender, EventArgs e)
        {
            ShowScreen("GroupType");
        }

        private void buttBoxMoveAccRepo_Click(object sender, EventArgs e)
        {
            ShowScreen("FrmRepBoxAnalytical");
        }

        private void buttCompanyData_Click(object sender, EventArgs e)
        {
            ShowScreen("CompanyInfo");
        }

        private void buttCalculator_Click(object sender, EventArgs e)
        {
            ShowScreen("حسابة");
        }

        private void buttFirstTimeIteam_Click(object sender, EventArgs e)
        {
            ShowScreen("firstBalanceBodge");  //مخزون اول المده
        }

        private void buttOpeningBalance_Click(object sender, EventArgs e)
        {
            ShowScreen("BalanceOpen"); //رصيد افتتاحي
        }

        private void buttSuppliersAccRep_Click(object sender, EventArgs e)
        {
            ShowScreen("حركة مورد"); //حركة مورد
        }

        private void buttGroupStored_Click(object sender, EventArgs e)
        {
            ShowScreen("GroupStored"); //المجموعات المخزنية
        }

        private void buttAccDefine_Click(object sender, EventArgs e)
        {
            ShowScreen("AccDefinition"); //تعريف الحسابات
        }

        private void buttItems_Click(object sender, EventArgs e)
        {
            ShowScreen("Items"); //الاصناف
        }

        private void buttTS_RefrechPre_Click(object sender, EventArgs e)
        {
          
            ScreenUser.Clear();
            ScreenUser = GetAllScreenUser(IdUser.Text);
            MessageBox.Show("تم تحديث الصلاحيات ","",MessageBoxButtons.OK,MessageBoxIcon.Information);


        }

        private void buttUnits_Click(object sender, EventArgs e)
        {
            ShowScreen("Unit"); //الوحدات
        }

        private void buttFrmRepBill4Item_Click(object sender, EventArgs e)
        {
            //تقرير صافي المبيعات
            ShowScreen("FrmRepBill4Item");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void TSM_Curr_Click(object sender, EventArgs e)
        {
            //Currn
        }

        private void TSM_Account_Click(object sender, EventArgs e)
        {
            //Acc
        }

        private void TSM_AccDefinition_Click(object sender, EventArgs e)
        {
            //Difin
            ShowScreen("AccDefinition");
        }

        private void TSM_BalanceOpen_Click(object sender, EventArgs e)
        {
            //OpenBalan
        }

        private void TSM_Customers_Click(object sender, EventArgs e)
        {
            //Cust
        }

        private void تسعيرةالاصنافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Prince
        }

        private void TSM_GroupStored_Click(object sender, EventArgs e)
        {
            //Group
            ShowScreen("GroupStored");
        }

        private void فئاتالاصنافToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Tipe
            ShowScreen("GroupType");
        }

        private void TSM_Unit_Click(object sender, EventArgs e)
        {
            //Unite
            ShowScreen("Unit"); //الوحدات
        }

        private void TSM_Items_Click(object sender, EventArgs e)
        {
            //Item
            ShowScreen("Items"); //الاصناف
        }

        private void الدليلالمحاسبيToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //Acc
        }

        private void رصيدافتتاحيToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Open
        }

        private void بياناتالصناديقToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Box
        }

        private void قيديدويToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Entry
           // ShowScreen("SupportExchang"); ShowScreen("SupportCatch");
            ShowScreen("Entries");
        }

        private void سندقبضToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Catch
           ShowScreen("SupportCatch"); //ShowScreen("Entries");
        }

        private void سندصرفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Exching
            ShowScreen("SupportExchang");
          //  ShowScreen("SupportCatch"); ShowScreen("Entries");
        }

        private void ترحيلToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void إلغاءترحيلToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //NonPosting
            ShowScreen("FrmNonPosting");
        }

        private void فاتورةمبيعاتToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void مردودمبيعاتToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void عرضسعرToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ادارةالعملاءToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void صافيالمبيعاتToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
