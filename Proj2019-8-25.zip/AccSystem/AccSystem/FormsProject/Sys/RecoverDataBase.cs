﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;
namespace AccSystem.FormsProject.Sys
{
    public partial class RecoverDataBase : Form
    {
        public RecoverDataBase()
        {
            InitializeComponent();
        }
        RecoverDatabasesqlcs redb = new RecoverDatabasesqlcs() ;
        DataBaseSqlcs dbs = new DataBaseSqlcs();
        private void buttAdd_Click(object sender, EventArgs e)
        {
            redb.Recoverdatabase();
            MessageBox.Show("تم إستعادة نسخة إحتياطية بنجاح","رسالة",MessageBoxButtons.OK);
        }

        private void pictureClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
