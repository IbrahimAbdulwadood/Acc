﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AccSystem.FormsProject.Sys
{
    public partial class TestImage : Form
    {
        public TestImage()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter adapter;
        DataTable tb; int rno = 0;
        MemoryStream ms;
        byte[] photo_aray;
        OpenFileDialog openFileDialog1 = new OpenFileDialog();
        private void button1_Click(object sender, EventArgs e)
        {
            //OpenFileDialog o = new OpenFileDialog();
            //o.Filter = "ملفات الصور| *.JPG;*.PNG; *.GIF";
            //if (o.ShowDialog() == DialogResult.OK)
            //{

            //}
            openFileDialog1.Filter = "jpeg|*.jpg|bmp|*.bmp|all files|*.*";
            DialogResult res = openFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            }
        }
        void loaddata()
        {
            adapter = new SqlDataAdapter("select id,name,photo from TestImage", con);
            adapter.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            tb = new DataTable(); adapter.Fill(tb);
        }
        void showdata()
        {
            if (tb.Rows.Count > 0)
            {
                textBox1.Text = tb.Rows[rno][0].ToString();
                textBox2.Text = tb.Rows[rno][1].ToString();
               
                pictureBox1.Image = null;
                try {
                    if (tb.Rows[rno][2] != System.DBNull.Value)
                    {
                        photo_aray = (byte[])tb.Rows[rno][2];
                        MemoryStream ms = new MemoryStream(photo_aray);
                        pictureBox1.Image = Image.FromStream(ms);
                    }
                }catch (Exception ee) { MessageBox.Show(ee.ToString()); }
            }
            else
                MessageBox.Show("No Records");
        }

        private void TestImage_Load(object sender, EventArgs e)
        {
            con = new SqlConnection("Data Source=.;Initial Catalog=AccSysDB1;Integrated Security=True");
            loaddata();
            showdata();
        }

        private void bttNew_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("select ISNULL( max(id)+10,1) from TestImage", con);
            con.Open();
            textBox1.Text = cmd.ExecuteScalar().ToString();
            con.Close();
            //  textBox2.Text = textBox3.Text = textBox4.Text = "";
            textBox2.Text = string.Empty;
            pictureBox1.Image = null;
        }
        void conv_photo()
        {
            //converting photo to binary data
            if (pictureBox1.Image != null)
            {
                //using FileStream:(will not work while updating, if image is not changed)
                //FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open, FileAccess.Read);
                //byte[] photo_aray = new byte[fs.Length];
                //fs.Read(photo_aray, 0, photo_aray.Length);  

                //using MemoryStream:
                ms = new MemoryStream();
                pictureBox1.Image.Save(ms, ImageFormat.Jpeg);
                byte[] photo_aray = new byte[ms.Length];
                ms.Position = 0;
                ms.Read(photo_aray, 0, photo_aray.Length);
                cmd.Parameters.AddWithValue("@photo", photo_aray);
            }
        }
        private void buttInsert_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("insert into TestImage(name,photo) values('" + textBox2.Text + "',@photo)", con);
            conv_photo();
            con.Open();
            int n = cmd.ExecuteNonQuery();
            con.Close();
            if (n > 0)
            {
                MessageBox.Show("record inserted");
                loaddata();
            }
            else
                MessageBox.Show("insertion failed");
        }

        private void buttUpdate_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("update TestImage set name='" + textBox2.Text + "', photo=@photo where id=" + textBox1.Text, con);
            conv_photo();
            con.Open();
            int n = cmd.ExecuteNonQuery();
            con.Close();
            if (n > 0)
            {
                MessageBox.Show("Record Updated");
                loaddata();
            }
            else
                MessageBox.Show("Updation Failed");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (rno < tb.Rows.Count - 1)
            {
                rno++; showdata();
            }
            else
                MessageBox.Show("Last record");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (rno > 0)
            {
                rno--; showdata();
            }
            else
                MessageBox.Show("First record");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                MessageBox.Show(dataGridView1.Rows.Count.ToString());
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    dataGridView1.Rows[i].Cells[0].ReadOnly = false;
                    if (dataGridView1.Rows[i].Cells[0].Value == null)
                    { MessageBox.Show("Rows[" + i.ToString() + "]Cells[0] is null"); }
                }
            }
            else { MessageBox.Show("Null"); }
                
        }
    }
}
