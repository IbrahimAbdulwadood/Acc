﻿namespace AccSystem.FormsProject.Sys
{
    partial class Useres
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Useres));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel_Main_up = new System.Windows.Forms.Panel();
            this.panUp = new System.Windows.Forms.Panel();
            this.buttClose = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel_Main_down = new System.Windows.Forms.Panel();
            this.panel_Main_Up_Up = new System.Windows.Forms.Panel();
            this.groupBoxData = new System.Windows.Forms.GroupBox();
            this.checkBoxSaleLater = new System.Windows.Forms.CheckBox();
            this.Discount_percentage = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBoxDiscount = new System.Windows.Forms.CheckBox();
            this.groupBoxState = new System.Windows.Forms.GroupBox();
            this.StateActivCheck = new System.Windows.Forms.RadioButton();
            this.StateStopCheck = new System.Windows.Forms.RadioButton();
            this.userId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.userName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel_Main_down_down = new System.Windows.Forms.Panel();
            this.groupBoxOprea = new System.Windows.Forms.GroupBox();
            this.buttSerch = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.buttNext = new System.Windows.Forms.Button();
            this.buttFrist = new System.Windows.Forms.Button();
            this.CountRows = new System.Windows.Forms.TextBox();
            this.buttBack = new System.Windows.Forms.Button();
            this.buttLast = new System.Windows.Forms.Button();
            this.buttDelete = new System.Windows.Forms.Button();
            this.buttSave = new System.Windows.Forms.Button();
            this.buttEdite = new System.Windows.Forms.Button();
            this.buttAdd = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.DGVBody = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.buttAddScreen2User = new System.Windows.Forms.Button();
            this.panel_Main_up.SuspendLayout();
            this.panUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel_Main_Up_Up.SuspendLayout();
            this.groupBoxData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Discount_percentage)).BeginInit();
            this.groupBoxState.SuspendLayout();
            this.groupBoxOprea.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGVBody)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Main_up
            // 
            this.panel_Main_up.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel_Main_up.Controls.Add(this.panUp);
            this.panel_Main_up.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Main_up.Location = new System.Drawing.Point(0, 0);
            this.panel_Main_up.Name = "panel_Main_up";
            this.panel_Main_up.Size = new System.Drawing.Size(925, 45);
            this.panel_Main_up.TabIndex = 0;
            // 
            // panUp
            // 
            this.panUp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panUp.Controls.Add(this.buttClose);
            this.panUp.Controls.Add(this.pictureBox2);
            this.panUp.Controls.Add(this.label1);
            this.panUp.Controls.Add(this.textBox1);
            this.panUp.Dock = System.Windows.Forms.DockStyle.Top;
            this.panUp.Location = new System.Drawing.Point(0, 0);
            this.panUp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panUp.Name = "panUp";
            this.panUp.Size = new System.Drawing.Size(925, 44);
            this.panUp.TabIndex = 44;
            // 
            // buttClose
            // 
            this.buttClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttClose.FlatAppearance.BorderColor = System.Drawing.Color.DimGray;
            this.buttClose.FlatAppearance.BorderSize = 0;
            this.buttClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttClose.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttClose.ForeColor = System.Drawing.Color.White;
            this.buttClose.Image = ((System.Drawing.Image)(resources.GetObject("buttClose.Image")));
            this.buttClose.Location = new System.Drawing.Point(12, 7);
            this.buttClose.Name = "buttClose";
            this.buttClose.Padding = new System.Windows.Forms.Padding(2);
            this.buttClose.Size = new System.Drawing.Size(25, 25);
            this.buttClose.TabIndex = 163;
            this.buttClose.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttClose.UseVisualStyleBackColor = false;
            this.buttClose.Click += new System.EventHandler(this.buttClose_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::AccSystem.Properties.Resources.Search_32px;
            this.pictureBox2.Location = new System.Drawing.Point(382, 7);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(30, 27);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(653, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(272, 27);
            this.label1.TabIndex = 9;
            this.label1.Text = "المستخدمين والصلاحيات";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.DimGray;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(50, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(316, 23);
            this.textBox1.TabIndex = 8;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel_Main_down
            // 
            this.panel_Main_down.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel_Main_down.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel_Main_down.Location = new System.Drawing.Point(0, 549);
            this.panel_Main_down.Name = "panel_Main_down";
            this.panel_Main_down.Size = new System.Drawing.Size(925, 35);
            this.panel_Main_down.TabIndex = 1;
            // 
            // panel_Main_Up_Up
            // 
            this.panel_Main_Up_Up.Controls.Add(this.groupBoxData);
            this.panel_Main_Up_Up.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Main_Up_Up.Location = new System.Drawing.Point(0, 45);
            this.panel_Main_Up_Up.Name = "panel_Main_Up_Up";
            this.panel_Main_Up_Up.Size = new System.Drawing.Size(925, 73);
            this.panel_Main_Up_Up.TabIndex = 2;
            // 
            // groupBoxData
            // 
            this.groupBoxData.Controls.Add(this.checkBoxSaleLater);
            this.groupBoxData.Controls.Add(this.Discount_percentage);
            this.groupBoxData.Controls.Add(this.label2);
            this.groupBoxData.Controls.Add(this.checkBoxDiscount);
            this.groupBoxData.Controls.Add(this.groupBoxState);
            this.groupBoxData.Controls.Add(this.userId);
            this.groupBoxData.Controls.Add(this.label3);
            this.groupBoxData.Controls.Add(this.userName);
            this.groupBoxData.Controls.Add(this.label7);
            this.groupBoxData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxData.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxData.ForeColor = System.Drawing.Color.Black;
            this.groupBoxData.Location = new System.Drawing.Point(0, 0);
            this.groupBoxData.Name = "groupBoxData";
            this.groupBoxData.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBoxData.Size = new System.Drawing.Size(925, 73);
            this.groupBoxData.TabIndex = 32;
            this.groupBoxData.TabStop = false;
            this.groupBoxData.Text = "البيانات";
            // 
            // checkBoxSaleLater
            // 
            this.checkBoxSaleLater.AutoSize = true;
            this.checkBoxSaleLater.Location = new System.Drawing.Point(281, 22);
            this.checkBoxSaleLater.Name = "checkBoxSaleLater";
            this.checkBoxSaleLater.Size = new System.Drawing.Size(83, 20);
            this.checkBoxSaleLater.TabIndex = 27;
            this.checkBoxSaleLater.Text = "البيع آجل";
            this.checkBoxSaleLater.UseVisualStyleBackColor = true;
            // 
            // Discount_percentage
            // 
            this.Discount_percentage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Discount_percentage.Location = new System.Drawing.Point(372, 39);
            this.Discount_percentage.Name = "Discount_percentage";
            this.Discount_percentage.ReadOnly = true;
            this.Discount_percentage.Size = new System.Drawing.Size(221, 23);
            this.Discount_percentage.TabIndex = 26;
            this.Discount_percentage.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(371, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(225, 16);
            this.label2.TabIndex = 25;
            this.label2.Text = "نسبة الخصم من اجمالي الفاتورة %";
            // 
            // checkBoxDiscount
            // 
            this.checkBoxDiscount.AutoSize = true;
            this.checkBoxDiscount.Location = new System.Drawing.Point(258, 42);
            this.checkBoxDiscount.Name = "checkBoxDiscount";
            this.checkBoxDiscount.Size = new System.Drawing.Size(107, 20);
            this.checkBoxDiscount.TabIndex = 23;
            this.checkBoxDiscount.Text = "يمكنه الخصم";
            this.checkBoxDiscount.UseVisualStyleBackColor = true;
            // 
            // groupBoxState
            // 
            this.groupBoxState.Controls.Add(this.StateActivCheck);
            this.groupBoxState.Controls.Add(this.StateStopCheck);
            this.groupBoxState.ForeColor = System.Drawing.Color.Black;
            this.groupBoxState.Location = new System.Drawing.Point(44, 15);
            this.groupBoxState.Name = "groupBoxState";
            this.groupBoxState.Size = new System.Drawing.Size(211, 48);
            this.groupBoxState.TabIndex = 22;
            this.groupBoxState.TabStop = false;
            this.groupBoxState.Text = "حالة الحساب";
            // 
            // StateActivCheck
            // 
            this.StateActivCheck.AutoSize = true;
            this.StateActivCheck.Location = new System.Drawing.Point(111, 18);
            this.StateActivCheck.Name = "StateActivCheck";
            this.StateActivCheck.Size = new System.Drawing.Size(56, 20);
            this.StateActivCheck.TabIndex = 1;
            this.StateActivCheck.TabStop = true;
            this.StateActivCheck.Text = "نشط";
            this.StateActivCheck.UseVisualStyleBackColor = true;
            // 
            // StateStopCheck
            // 
            this.StateStopCheck.AutoSize = true;
            this.StateStopCheck.Location = new System.Drawing.Point(32, 18);
            this.StateStopCheck.Name = "StateStopCheck";
            this.StateStopCheck.Size = new System.Drawing.Size(62, 20);
            this.StateStopCheck.TabIndex = 0;
            this.StateStopCheck.TabStop = true;
            this.StateStopCheck.Text = "موقف";
            this.StateStopCheck.UseVisualStyleBackColor = true;
            // 
            // userId
            // 
            this.userId.BackColor = System.Drawing.Color.DimGray;
            this.userId.ForeColor = System.Drawing.Color.White;
            this.userId.Location = new System.Drawing.Point(601, 15);
            this.userId.Name = "userId";
            this.userId.ReadOnly = true;
            this.userId.Size = new System.Drawing.Size(163, 23);
            this.userId.TabIndex = 1;
            this.userId.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(770, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "رقم المستخدم:";
            // 
            // userName
            // 
            this.userName.BackColor = System.Drawing.Color.Silver;
            this.userName.ForeColor = System.Drawing.Color.Black;
            this.userName.Location = new System.Drawing.Point(601, 40);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(163, 23);
            this.userName.TabIndex = 16;
            this.userName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(770, 37);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 16);
            this.label7.TabIndex = 19;
            this.label7.Text = "اسم المستخدم:";
            // 
            // panel_Main_down_down
            // 
            this.panel_Main_down_down.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Main_down_down.Location = new System.Drawing.Point(0, 118);
            this.panel_Main_down_down.Name = "panel_Main_down_down";
            this.panel_Main_down_down.Size = new System.Drawing.Size(925, 431);
            this.panel_Main_down_down.TabIndex = 3;
            // 
            // groupBoxOprea
            // 
            this.groupBoxOprea.BackColor = System.Drawing.Color.Transparent;
            this.groupBoxOprea.Controls.Add(this.buttSerch);
            this.groupBoxOprea.Controls.Add(this.panel2);
            this.groupBoxOprea.Controls.Add(this.buttDelete);
            this.groupBoxOprea.Controls.Add(this.buttSave);
            this.groupBoxOprea.Controls.Add(this.buttEdite);
            this.groupBoxOprea.Controls.Add(this.buttAdd);
            this.groupBoxOprea.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBoxOprea.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBoxOprea.ForeColor = System.Drawing.Color.Black;
            this.groupBoxOprea.Location = new System.Drawing.Point(3, 306);
            this.groupBoxOprea.Name = "groupBoxOprea";
            this.groupBoxOprea.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.groupBoxOprea.Size = new System.Drawing.Size(919, 122);
            this.groupBoxOprea.TabIndex = 37;
            this.groupBoxOprea.TabStop = false;
            this.groupBoxOprea.Text = "العمليات";
            // 
            // buttSerch
            // 
            this.buttSerch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttSerch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttSerch.FlatAppearance.BorderSize = 0;
            this.buttSerch.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttSerch.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttSerch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttSerch.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttSerch.ForeColor = System.Drawing.Color.White;
            this.buttSerch.Image = ((System.Drawing.Image)(resources.GetObject("buttSerch.Image")));
            this.buttSerch.Location = new System.Drawing.Point(518, 22);
            this.buttSerch.Name = "buttSerch";
            this.buttSerch.Size = new System.Drawing.Size(60, 93);
            this.buttSerch.TabIndex = 221;
            this.buttSerch.Text = "بحث";
            this.buttSerch.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttSerch.UseVisualStyleBackColor = false;
            this.buttSerch.Click += new System.EventHandler(this.buttSerch_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.buttNext);
            this.panel2.Controls.Add(this.buttFrist);
            this.panel2.Controls.Add(this.CountRows);
            this.panel2.Controls.Add(this.buttBack);
            this.panel2.Controls.Add(this.buttLast);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(3, 19);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(431, 100);
            this.panel2.TabIndex = 220;
            // 
            // buttNext
            // 
            this.buttNext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttNext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttNext.FlatAppearance.BorderSize = 0;
            this.buttNext.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttNext.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttNext.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttNext.ForeColor = System.Drawing.Color.White;
            this.buttNext.Image = ((System.Drawing.Image)(resources.GetObject("buttNext.Image")));
            this.buttNext.Location = new System.Drawing.Point(282, 14);
            this.buttNext.Name = "buttNext";
            this.buttNext.Size = new System.Drawing.Size(57, 82);
            this.buttNext.TabIndex = 169;
            this.buttNext.Text = "التالي";
            this.buttNext.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttNext.UseVisualStyleBackColor = false;
            this.buttNext.Click += new System.EventHandler(this.buttNext_Click);
            // 
            // buttFrist
            // 
            this.buttFrist.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttFrist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttFrist.FlatAppearance.BorderSize = 0;
            this.buttFrist.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttFrist.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttFrist.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttFrist.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttFrist.ForeColor = System.Drawing.Color.White;
            this.buttFrist.Image = ((System.Drawing.Image)(resources.GetObject("buttFrist.Image")));
            this.buttFrist.Location = new System.Drawing.Point(345, 14);
            this.buttFrist.Name = "buttFrist";
            this.buttFrist.Size = new System.Drawing.Size(57, 82);
            this.buttFrist.TabIndex = 168;
            this.buttFrist.Text = "الاول";
            this.buttFrist.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttFrist.UseVisualStyleBackColor = false;
            this.buttFrist.Click += new System.EventHandler(this.buttFrist_Click);
            // 
            // CountRows
            // 
            this.CountRows.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.CountRows.Enabled = false;
            this.CountRows.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountRows.Location = new System.Drawing.Point(143, 36);
            this.CountRows.Name = "CountRows";
            this.CountRows.ReadOnly = true;
            this.CountRows.Size = new System.Drawing.Size(133, 33);
            this.CountRows.TabIndex = 172;
            this.CountRows.Text = "1111-1111";
            this.CountRows.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttBack
            // 
            this.buttBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttBack.FlatAppearance.BorderSize = 0;
            this.buttBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttBack.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttBack.ForeColor = System.Drawing.Color.White;
            this.buttBack.Image = ((System.Drawing.Image)(resources.GetObject("buttBack.Image")));
            this.buttBack.Location = new System.Drawing.Point(79, 14);
            this.buttBack.Name = "buttBack";
            this.buttBack.Size = new System.Drawing.Size(57, 82);
            this.buttBack.TabIndex = 170;
            this.buttBack.Text = "السابق";
            this.buttBack.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttBack.UseVisualStyleBackColor = false;
            this.buttBack.Click += new System.EventHandler(this.buttBack_Click);
            // 
            // buttLast
            // 
            this.buttLast.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttLast.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttLast.FlatAppearance.BorderSize = 0;
            this.buttLast.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray;
            this.buttLast.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DimGray;
            this.buttLast.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttLast.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttLast.ForeColor = System.Drawing.Color.White;
            this.buttLast.Image = ((System.Drawing.Image)(resources.GetObject("buttLast.Image")));
            this.buttLast.Location = new System.Drawing.Point(15, 14);
            this.buttLast.Name = "buttLast";
            this.buttLast.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.buttLast.Size = new System.Drawing.Size(57, 82);
            this.buttLast.TabIndex = 171;
            this.buttLast.Text = "الاخير";
            this.buttLast.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttLast.UseVisualStyleBackColor = false;
            this.buttLast.Click += new System.EventHandler(this.buttLast_Click);
            // 
            // buttDelete
            // 
            this.buttDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttDelete.FlatAppearance.BorderSize = 0;
            this.buttDelete.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttDelete.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttDelete.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttDelete.ForeColor = System.Drawing.Color.White;
            this.buttDelete.Image = ((System.Drawing.Image)(resources.GetObject("buttDelete.Image")));
            this.buttDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttDelete.Location = new System.Drawing.Point(581, 70);
            this.buttDelete.Name = "buttDelete";
            this.buttDelete.Size = new System.Drawing.Size(142, 46);
            this.buttDelete.TabIndex = 219;
            this.buttDelete.Text = "حذف";
            this.buttDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttDelete.UseVisualStyleBackColor = false;
            this.buttDelete.Click += new System.EventHandler(this.buttDelete_Click);
            // 
            // buttSave
            // 
            this.buttSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttSave.FlatAppearance.BorderSize = 0;
            this.buttSave.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttSave.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttSave.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttSave.ForeColor = System.Drawing.Color.White;
            this.buttSave.Image = ((System.Drawing.Image)(resources.GetObject("buttSave.Image")));
            this.buttSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttSave.Location = new System.Drawing.Point(581, 22);
            this.buttSave.Name = "buttSave";
            this.buttSave.Size = new System.Drawing.Size(142, 46);
            this.buttSave.TabIndex = 218;
            this.buttSave.Text = "حفظ";
            this.buttSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttSave.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttSave.UseVisualStyleBackColor = false;
            this.buttSave.Click += new System.EventHandler(this.buttSave_Click);
            // 
            // buttEdite
            // 
            this.buttEdite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttEdite.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttEdite.FlatAppearance.BorderSize = 0;
            this.buttEdite.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttEdite.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttEdite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttEdite.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttEdite.ForeColor = System.Drawing.Color.White;
            this.buttEdite.Image = ((System.Drawing.Image)(resources.GetObject("buttEdite.Image")));
            this.buttEdite.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttEdite.Location = new System.Drawing.Point(729, 70);
            this.buttEdite.Name = "buttEdite";
            this.buttEdite.Size = new System.Drawing.Size(142, 46);
            this.buttEdite.TabIndex = 217;
            this.buttEdite.Text = "تعديل مستخدم";
            this.buttEdite.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttEdite.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttEdite.UseVisualStyleBackColor = false;
            this.buttEdite.Click += new System.EventHandler(this.buttEdite_Click);
            // 
            // buttAdd
            // 
            this.buttAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAdd.FlatAppearance.BorderSize = 0;
            this.buttAdd.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAdd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAdd.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttAdd.ForeColor = System.Drawing.Color.White;
            this.buttAdd.Image = ((System.Drawing.Image)(resources.GetObject("buttAdd.Image")));
            this.buttAdd.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttAdd.Location = new System.Drawing.Point(729, 22);
            this.buttAdd.Name = "buttAdd";
            this.buttAdd.Size = new System.Drawing.Size(142, 46);
            this.buttAdd.TabIndex = 216;
            this.buttAdd.Text = "إضافة مستخدم";
            this.buttAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.buttAdd.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.buttAdd.UseVisualStyleBackColor = false;
            this.buttAdd.Click += new System.EventHandler(this.buttAdd_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 118);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(925, 431);
            this.panel1.TabIndex = 4;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.DGVBody);
            this.groupBox1.Controls.Add(this.buttAddScreen2User);
            this.groupBox1.Controls.Add(this.groupBoxOprea);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(925, 431);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "واجهات المستخدم وصلاحياتها";
            // 
            // DGVBody
            // 
            this.DGVBody.AllowUserToAddRows = false;
            this.DGVBody.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DGVBody.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DGVBody.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGVBody.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.DGVBody.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DGVBody.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ButtonShadow;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVBody.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DGVBody.ColumnHeadersHeight = 30;
            this.DGVBody.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.DGVBody.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column11,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Column9,
            this.Column10});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DGVBody.DefaultCellStyle = dataGridViewCellStyle3;
            this.DGVBody.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGVBody.EnableHeadersVisualStyles = false;
            this.DGVBody.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.DGVBody.Location = new System.Drawing.Point(3, 64);
            this.DGVBody.Name = "DGVBody";
            this.DGVBody.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DGVBody.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DGVBody.RowHeadersVisible = false;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.Gray;
            this.DGVBody.RowsDefaultCellStyle = dataGridViewCellStyle5;
            this.DGVBody.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DGVBody.Size = new System.Drawing.Size(919, 242);
            this.DGVBody.TabIndex = 43;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ScreenId";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Visible = false;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "NameScreen";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Visible = false;
            // 
            // Column11
            // 
            this.Column11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Column11.HeaderText = "اسم الشاشة";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Width = 109;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "عرض";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "اضافة";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "تعديل";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "حذف";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "تعديل التاريخ";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "ترحيل";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "طباعة";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "بحث";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // buttAddScreen2User
            // 
            this.buttAddScreen2User.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttAddScreen2User.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttAddScreen2User.Dock = System.Windows.Forms.DockStyle.Top;
            this.buttAddScreen2User.FlatAppearance.BorderSize = 0;
            this.buttAddScreen2User.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttAddScreen2User.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(129)))), ((int)(((byte)(77)))));
            this.buttAddScreen2User.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttAddScreen2User.Font = new System.Drawing.Font("Tahoma", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttAddScreen2User.ForeColor = System.Drawing.Color.White;
            this.buttAddScreen2User.Image = ((System.Drawing.Image)(resources.GetObject("buttAddScreen2User.Image")));
            this.buttAddScreen2User.Location = new System.Drawing.Point(3, 18);
            this.buttAddScreen2User.Name = "buttAddScreen2User";
            this.buttAddScreen2User.Padding = new System.Windows.Forms.Padding(340, 0, 370, 0);
            this.buttAddScreen2User.Size = new System.Drawing.Size(919, 46);
            this.buttAddScreen2User.TabIndex = 217;
            this.buttAddScreen2User.Text = "شاشة جديدة للمستخدم";
            this.buttAddScreen2User.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttAddScreen2User.UseVisualStyleBackColor = false;
            this.buttAddScreen2User.Click += new System.EventHandler(this.buttAddScreen2User_Click);
            // 
            // Useres
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(925, 584);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_Main_down_down);
            this.Controls.Add(this.panel_Main_Up_Up);
            this.Controls.Add(this.panel_Main_down);
            this.Controls.Add(this.panel_Main_up);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Useres";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.RightToLeftLayout = true;
            this.Text = "Useres";
            this.Load += new System.EventHandler(this.Useres_Load);
            this.panel_Main_up.ResumeLayout(false);
            this.panUp.ResumeLayout(false);
            this.panUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel_Main_Up_Up.ResumeLayout(false);
            this.groupBoxData.ResumeLayout(false);
            this.groupBoxData.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Discount_percentage)).EndInit();
            this.groupBoxState.ResumeLayout(false);
            this.groupBoxState.PerformLayout();
            this.groupBoxOprea.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGVBody)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Main_up;
        private System.Windows.Forms.Panel panUp;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel_Main_down;
        private System.Windows.Forms.Panel panel_Main_Up_Up;
        private System.Windows.Forms.GroupBox groupBoxData;
        private System.Windows.Forms.GroupBox groupBoxState;
        private System.Windows.Forms.RadioButton StateActivCheck;
        private System.Windows.Forms.RadioButton StateStopCheck;
        private System.Windows.Forms.TextBox userId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox userName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel_Main_down_down;
        private System.Windows.Forms.GroupBox groupBoxOprea;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttAdd;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttDelete;
        private System.Windows.Forms.Button buttSave;
        private System.Windows.Forms.Button buttEdite;
        private System.Windows.Forms.DataGridView DGVBody;
        private System.Windows.Forms.Button buttAddScreen2User;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button buttNext;
        private System.Windows.Forms.Button buttFrist;
        private System.Windows.Forms.TextBox CountRows;
        private System.Windows.Forms.Button buttBack;
        private System.Windows.Forms.Button buttLast;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBoxDiscount;
        private System.Windows.Forms.NumericUpDown Discount_percentage;
        private System.Windows.Forms.Button buttSerch;
        private System.Windows.Forms.Button buttClose;
        private System.Windows.Forms.CheckBox checkBoxSaleLater;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column4;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column6;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column7;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column8;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column9;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column10;
    }
}