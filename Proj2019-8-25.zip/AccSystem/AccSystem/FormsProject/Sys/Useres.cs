﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;

namespace AccSystem.FormsProject.Sys
{
    public partial class Useres : Form
    {
        public Useres(Dictionary<string, bool> pre)
        {
            InitializeComponent();
            ButtnPre.Clear();
            ButtnPre = pre;
        }

        Dictionary<string, bool> ButtnPre = new Dictionary<string, bool>(); //الصلاحيات
        DataTable DTUserHaed;
        DataTable DTPermissionsBody;
        UsersSQL usersSQL=new UsersSQL();
        PermissionsSQL permissionsSQL=new PermissionsSQL();
        UserScreenList UserScreenList;
        int indexHaed = -1;

        public string flagAddOrEdit = "";

        #region الدوال

        #region

        void fillData()
        {
            try {
                if (DTUserHaed != null)
                    DTUserHaed = null;

                DTUserHaed = new DataTable();
                DTUserHaed = usersSQL.GetAllUser();
                DataTable a = new DataTable();
           

                try
                {
                    if (DTUserHaed != null && DTUserHaed.Rows.Count > 0)
                    { indexHaed = 0; FillTextBox(indexHaed);
                       // MessageBox.Show(DTUserHaed.Rows.Count.ToString(), "عدد المستخدمين");
                    }
                    else if (DTUserHaed.Rows.Count == 0)
                    {
                        ClearAllTextBox(); MessageBox.Show("لا يوجد مستخدمين");
                    }
                    else { MessageBox.Show("لا يوجد بيانات لعرضها"); }

                }
                catch (Exception ee) { MessageBox.Show(ee.ToString()); }
            }catch (Exception ee) { MessageBox.Show(ee.ToString()); }

        }
        #region الحذف
        List<string> GetBoxUserIdRelation4User(string AccId)
        {
            List<string> BoxUserId = new List<string>();
            DataTable DT = new DataTable();
            DT = usersSQL.GetBoxUserId4User(AccId);
            if (DT != null && DT.Rows.Count > 0)
            {
                // MessageBox.Show(DT.Rows.Count.ToString());
                for (int i = 0; i < DT.Rows.Count; i++)
                    BoxUserId.Add(DT.Rows[i][0].ToString());
            }

            return BoxUserId;

        }
        void Delet(string User_id = "-1")
        {
            List<string> BoxUserId = new List<string>();
            List<string> MessgError = new List<string>();
            List<string> MessgError2 = new List<string>();

            BoxUserId = GetBoxUserIdRelation4User(User_id);
            //  MessageBox.Show(AccCurr.Count.ToString());
            if (BoxUserId.Count > 0)
            {
                for (int i = 0; i < BoxUserId.Count; i++)
                {
                    DataTable DT = new DataTable();
                    try
                    {
                        DT = usersSQL.GetBoxUserOprtion(BoxUserId[i]);
                        if (DT != null && DT.Rows.Count > 0)
                        {
                            //  MessageBox.Show(DT.Rows.Count.ToString());
                            for (int j = 0; j < DT.Rows.Count; j++)
                                MessgError.Add(DT.Rows[j][0].ToString());
                        }

                    }
                    catch (Exception e) { MessageBox.Show(e.ToString()); }


                }
                MessgError2 = usersSQL.GetOprationWithOutBox(User_id);
                if (MessgError.Count > 0|| MessgError2.Count>0)
                        MessageBox.Show("لا يمكن الحذف لوجود عمليات مرتبطة بهذا المستخدم!!", " تنبية", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                else
                {
                    if (DialogResult.Yes == (MessageBox.Show("تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question)))
                    {
                        try
                        {
                            usersSQL.Delet(User_id);
                            // MessageBox.Show("تم عمليه الحذف بنجاح");
                            fillData();
                        }
                        catch { MessageBox.Show("لم يتم الحذف"); }

                    }
                }
            }
            else
            {
                if (DialogResult.Yes == (MessageBox.Show("تاكيد الحذف", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question)))
                {
                    usersSQL.Delet(User_id);
                   // MessageBox.Show("تم عمليه الحذف بنجاح");
                    fillData();
                }


            }



        }
        #endregion
        void FillTextBox(int indexRows)
        {
            /*

            */
            if (DTUserHaed.Rows.Count > 0 && indexRows < DTUserHaed.Rows.Count && indexRows >= 0)
            {

                int i = indexRows;

                /*
                 
                */
                #region
                /*

    SELECT 
           [User_id] 0
          ,[User_name] 1
          ,[Discount] 2
          ,[Discount_percentage] 3
          ,[State] 4
      FROM [dbo].[Users]
                */
                #endregion

                userId.Text = DTUserHaed.Rows[i][0].ToString();
                userName.Text = DTUserHaed.Rows[i][1].ToString();
                checkBoxDiscount.Checked = Convert.ToBoolean(DTUserHaed.Rows[i][2].ToString());
                Discount_percentage.Value = Convert.ToInt32(DTUserHaed.Rows[i][3].ToString());
                if (Convert.ToBoolean(DTUserHaed.Rows[i][4].ToString()))
                    StateActivCheck.Checked = true;
                else
                    StateStopCheck.Checked = true;
                checkBoxSaleLater.Checked = (bool)DTUserHaed.Rows[i][5];

                 ShowPermissions(userId.Text);
                FillTextBoxCountRows((indexHaed + 1).ToString());

            }
            else
            {
                MessageBox.Show("index is: " + indexRows, "DTcount is: " + DTUserHaed.Rows.Count);
            }


        }
        void FillTextBoxCountRows(string index)
        {
            if (Convert.ToUInt32(index) >= 0 && DTUserHaed != null && DTUserHaed.Rows.Count > 0)
                CountRows.Text = index + " - " +
                    DTUserHaed.Rows.Count.ToString();
            else
                CountRows.Text = "0 - 0";
        }
        void ClearAllTextBox()
        {
            userName.Text = string.Empty;
            Discount_percentage.Value = 0;
            checkBoxDiscount.Checked = false;
            StateActivCheck.Checked = false;
            StateStopCheck.Checked = false;
            DGVBody.Rows.Clear();

        }
        #region داله الصلاحيات
        void Permissions()
        {
            if (ButtnPre.Count > 0)
            {
                #region البيانات المستلمه
                /*
            ButtnPreCheck.Add("Showed", Convert.ToBoolean(DTpr.Rows[0][2].ToString()));
            ButtnPreCheck.Add("Inserted", Convert.ToBoolean(DTpr.Rows[0][3].ToString()));
            ButtnPreCheck.Add("EditeDate", Convert.ToBoolean(DTpr.Rows[0][4].ToString()));
            ButtnPreCheck.Add("Posting", Convert.ToBoolean(DTpr.Rows[0][5].ToString()));
            ButtnPreCheck.Add("Saerch", Convert.ToBoolean(DTpr.Rows[0][6].ToString()));
            ButtnPreCheck.Add("Printed", Convert.ToBoolean(DTpr.Rows[0][7].ToString()));
            ButtnPreCheck.Add("Updated", Convert.ToBoolean(DTpr.Rows[0][8].ToString()));
            ButtnPreCheck.Add("Deleted", Convert.ToBoolean(DTpr.Rows[0][9].ToString()));
                */
                #endregion
                bool result;
              
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Deleted", out result))
                        buttDelete.Enabled = result;
                    // MessageBox.Show(result.ToString());
                    else MessageBox.Show("لما نستقبل صلاحية الحذف");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Inserted", out result))
                        buttAdd.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية الاضافة");
                    /////////////////////////////////////////////////////
                    if (ButtnPre.TryGetValue("Updated", out result))
                        buttEdite.Enabled = result;
                    else MessageBox.Show("لما نستقبل صلاحية التعديل");
                /////////////////////////////////////////////////////
                   if (ButtnPre.TryGetValue("Saerch", out result))
                        buttSerch.Enabled = result; 
                
                   
                   else MessageBox.Show("لما نستقبل صلاحية التعديل");
                /////////////////////////////////////////////////////

            }

        }
        #endregion

        void ShowPermissions(string userId = "-1")
        {//Done


            if (DTPermissionsBody != null)
                DTPermissionsBody = null;
            DTPermissionsBody = new DataTable();
            DTPermissionsBody = permissionsSQL.GetAllPermissionsAllScreen(userId,"");


            #region Data From Table Permissions
            /*

                                       ( dataTable)
            Permissions.Screen_id_fk, 0
            ,Screens.Screen_Name  1
             Permissions.Showed, 2
             Permissions.Inserted, 3
             Permissions.EditeDate, 4
             Permissions.Posting, 5
             Permissions.Saerch,  6
             Permissions.Printed,  7
             Permissions.Updated, 8
             Permissions.Deleted 9
              ,Screens.Description 10
            
      
            */
            #endregion



            DGVBody.Rows.Clear();


            if (DTPermissionsBody != null && DTPermissionsBody.Rows.Count > 0)
            {
                for (int i = 0; i < DTPermissionsBody.Rows.Count; i++)
                {


                    DGVBody.Rows.Add
                    (
                    DTPermissionsBody.Rows[i][0].ToString(), //رقم الشاشة
                    DTPermissionsBody.Rows[i][1].ToString(), //اسم الشاشة
                    DTPermissionsBody.Rows[i][10].ToString(), //اسم الشاشة
                    DTPermissionsBody.Rows[i][2].ToString(), //عرض
                    DTPermissionsBody.Rows[i][3].ToString(), //اضافة
                    DTPermissionsBody.Rows[i][8].ToString(), //تعديل
                    DTPermissionsBody.Rows[i][9].ToString(), //حذف
                    DTPermissionsBody.Rows[i][4].ToString(), //تعديل التاريخ
                    DTPermissionsBody.Rows[i][5].ToString(), //ترحيل
                    DTPermissionsBody.Rows[i][7].ToString(), //طباعة
                    DTPermissionsBody.Rows[i][6].ToString()  //بحث
                    );
                    //داله تجيب الحد الاعلى والادنى لكل عمله



                } //endForAddData



            }
            //  else MessageBox.Show("idEntry is null can't show body","رقم السند = "+ idEntry);


        }

        int indexUserHeadButt(string btName, ref int index)
        {
            /*
            
            
            */
            if (DTUserHaed.Rows.Count > 0)
            {



                if (btName == "Frist")
                {

                    //  index = 0;
                    return index = 0;

                }
                else if (btName == "Next")
                {
                    if (index < DTUserHaed.Rows.Count - 1)
                        return ++index;
                    else { MessageBox.Show("اخر سجل"); return index; }

                }
                else if (btName == "Back")
                {
                    if (index > 0)
                        return --index;
                    else { MessageBox.Show("اول سجل"); return index; }
                }
                else if (btName == "Last")
                {
                    return index = DTUserHaed.Rows.Count - 1;

                }

            }
            else
                MessageBox.Show("لا يوجد مستخدمين في القاعدة", "تنبية", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return index = -1;

        }

        void FormatingTextBoxAndButt(string flagEditeOrAddOrSave)

        {
            //Doneeeeee
            /////////عند التعديل وجديد//////////////

            userId.ReadOnly = true;
          

            if (flagEditeOrAddOrSave == "Edite" || flagEditeOrAddOrSave == "Add")
            {
                //فعل التكستات

                userName.ReadOnly = false;
                Discount_percentage.ReadOnly = false;
                Discount_percentage.Enabled = true;
                checkBoxDiscount.Enabled = true;
                groupBoxState.Enabled = true;
                checkBoxSaleLater.Enabled = true;
                buttAddScreen2User.Enabled = true;
                buttAddScreen2User.Visible = true;
                //وقف البوتونات
                buttDelete.Enabled = false;
                buttAdd.Enabled = false;
                buttEdite.Enabled = false;
                buttNext.Enabled = false;
                buttBack.Enabled = false;
                buttFrist.Enabled = false;
                buttLast.Enabled = false;
                buttSerch.Enabled = false;
               

                
                DGVBody.MultiSelect = false;
              
                DGVBody.ReadOnly = false;


                for (int j = 3; j < DGVBody.ColumnCount; j++)//2
                    for (int i = 0; i < DGVBody.RowCount; i++)
                        DGVBody.Rows[i].Cells[j].ReadOnly = false;
                for(int i=0;i < DGVBody.RowCount; i++)
                        DGVBody.Rows[i].Cells[1].ReadOnly = true;
                
                   







            }

            if (flagEditeOrAddOrSave == "Save" || flagEditeOrAddOrSave == "Load")
            {
                userName.ReadOnly = true;
                Discount_percentage.ReadOnly = true;
                Discount_percentage.Enabled = false;
                checkBoxDiscount.Enabled = false;
                groupBoxState.Enabled = false;
                buttAddScreen2User.Enabled = false;
                buttAddScreen2User.Visible = false;
                ////////////////////////////////////////////////

                //////////////////الحسابات ما يقدر يدخل ارقامهم ادخال الا عن طريق الليسته////////////////////
                //DGVBody.Columns[0].Visible = true;

                checkBoxSaleLater.Enabled = false;

                Permissions(); //استدعاء الصلاحيات
                               ///////////////////
                DGVBody.ReadOnly = true;
                //فعل البوتونات

                buttNext.Enabled = true;
                buttBack.Enabled = true;
                buttFrist.Enabled = true;
                buttLast.Enabled = true;
               // buttSerch.Enabled = true;
                //buttPosting.Enabled = true; //اذا قد تم ترحيل هذا السند يكون فولس برجع له

                /////////////////////////




            }


        }
        void ForamtingAdd()
        {
            ClearAllTextBox();
            userId.Text = usersSQL.GetMaxIdUser();
            //DGVBody.Rows.Clear(); //التفاصيل


        }

        void SendDataToAddOrEdit(string flagAddOrEditLo)
        {
            if (flagAddOrEditLo == "Add")
            {
                #region

                if ( userName.Text != string.Empty &&
                    (StateActivCheck.Checked==true|| StateStopCheck.Checked==true) 
                    )
                {
                    if (MessageBox.Show("هل تريد الاضافة", "تنبية", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            

                                string idUserAdded
                                         = usersSQL.InsertNewUser(userName.Text, (checkBoxDiscount.Checked == true ? "1" : "0"), Discount_percentage.Value.ToString(), (StateActivCheck.Checked == true ? "1" :"0"),(checkBoxSaleLater.Checked==true?"1":"0"));

                                MessageBox.Show("كلمة السر الافتراضية هي 1", "تم الحفظ", MessageBoxButtons.OK, MessageBoxIcon.Information);



                                for (int i = 0; i < DGVBody.Rows.Count; i++)
                                {
                                    if (
                                        DGVBody.Rows[i].Cells[0].Value != null
                                       
                                        )
                                    {

                             permissionsSQL.InsertScreen2User(idUserAdded, DGVBody.Rows[i].Cells[0].Value.ToString());

                             permissionsSQL.UpdatePermissions(
                              idUserAdded,
                              DGVBody.Rows[i].Cells[0].Value.ToString(),
                        (Convert.ToBoolean(DGVBody.Rows[i].Cells[3].Value) == true ? "1" : "0"),
                        (Convert.ToBoolean(DGVBody.Rows[i].Cells[4].Value) == true ? "1" : "0"),
                        (Convert.ToBoolean(DGVBody.Rows[i].Cells[5].Value) == true ? "1" : "0"),
                        (Convert.ToBoolean(DGVBody.Rows[i].Cells[6].Value) == true ? "1" : "0"),
                        (Convert.ToBoolean(DGVBody.Rows[i].Cells[9].Value) == true ? "1" : "0"),
                        (Convert.ToBoolean(DGVBody.Rows[i].Cells[10].Value) == true ? "1" : "0"),
                        (Convert.ToBoolean(DGVBody.Rows[i].Cells[8].Value) == true ? "1" : "0"),
                        (Convert.ToBoolean(DGVBody.Rows[i].Cells[7].Value) == true ? "1" : "0")
                                            );

                                       


                                    }
                                }

                                MessageBox.Show("تمت الاضافة بنجاح");
                               
                               
                                FormatingTextBoxAndButt("Save");
                                flagAddOrEdit = "";
                                fillData();
                                
                            
                          
                        }
                        else
                        {
                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "";
                            fillData();
                        }
                    }
                    else MessageBox.Show("يجب تعبئة حقل اسم المستخدم و اختيار حاله المستخدم","",MessageBoxButtons.OK,MessageBoxIcon.Error);

                }
               

                #endregion

            
            else if (flagAddOrEditLo == "Edite")
            {
                if (userName.Text != string.Empty &&
                    (StateActivCheck.Checked == true || StateStopCheck.Checked == true)
                     )
                {
                   
                        if (MessageBox.Show(" هل تريد تعديل البيانات", "تحذير", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                        {
                            usersSQL.UpdateUsers
                            (userId.Text, userName.Text, (checkBoxDiscount.Checked == true ? "1" : "0"), Discount_percentage.Value.ToString(), StateActivCheck.Checked == true ? "1" : "0", checkBoxSaleLater.Checked==true?"1":"0");

                            if (DGVBody.RowCount>0)
                            {
                                for(int i = 0; i < DGVBody.RowCount; i++)
                                {
                                    permissionsSQL.UpdatePermissions(
                             userId.Text,
                             DGVBody.Rows[i].Cells[0].Value.ToString(),
                       (Convert.ToBoolean(DGVBody.Rows[i].Cells[3].Value) == true ? "1" : "0"),
                       (Convert.ToBoolean(DGVBody.Rows[i].Cells[4].Value) == true ? "1" : "0"),
                       (Convert.ToBoolean(DGVBody.Rows[i].Cells[5].Value) == true ? "1" : "0"),
                       (Convert.ToBoolean(DGVBody.Rows[i].Cells[6].Value) == true ? "1" : "0"),
                       (Convert.ToBoolean(DGVBody.Rows[i].Cells[9].Value) == true ? "1" : "0"),
                       (Convert.ToBoolean(DGVBody.Rows[i].Cells[10].Value) == true ? "1" : "0"),
                       (Convert.ToBoolean(DGVBody.Rows[i].Cells[8].Value) == true ? "1" : "0"),
                       (Convert.ToBoolean(DGVBody.Rows[i].Cells[7].Value) == true ? "1" : "0")
                                           );
                                }
                            }

                               

                                MessageBox.Show("تم التعديل بنجاح");
                                // ShowMesgBoxWarningsAccNull();
                               
                                FormatingTextBoxAndButt("Save");
                                flagAddOrEdit = "";
                                fillData();
                            }
                         else
                               {
                            FormatingTextBoxAndButt("Save");
                            flagAddOrEdit = "";
                            fillData();
                                 }
                      
                    }
                else if (MessageBox.Show("هل تريد التراجع عن عمليه التعديل ", "يوجد حقول فارغه", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    FormatingTextBoxAndButt("Save");
                    flagAddOrEdit = "";
                    fillData();

                } //end else if
            }
                
            } //end else if
       
        private void buttAdd_Click(object sender, EventArgs e)
        {
            ForamtingAdd();
            flagAddOrEdit = "Add";
            FormatingTextBoxAndButt(flagAddOrEdit);
        }
       
        private void buttEdite_Click(object sender, EventArgs e)
        {
            flagAddOrEdit = "Edite";
          
            FormatingTextBoxAndButt(flagAddOrEdit);
        }

        private void buttSave_Click(object sender, EventArgs e)
        {
            SendDataToAddOrEdit(flagAddOrEdit);
        }

        private void buttDelete_Click(object sender, EventArgs e)
        {
            if (userId.Text != string.Empty)
                Delet(userId.Text);
            
        }

        private void buttSerch_Click(object sender, EventArgs e)
        {
           
        }

        private void buttFrist_Click(object sender, EventArgs e)
        {
            FillTextBox(indexUserHeadButt("Frist", ref indexHaed));
        }

        private void buttNext_Click(object sender, EventArgs e)
        {
            FillTextBox(indexUserHeadButt("Next", ref indexHaed));
        }

        private void buttBack_Click(object sender, EventArgs e)
        {
            FillTextBox(indexUserHeadButt("Back", ref indexHaed));
        }

        private void buttLast_Click(object sender, EventArgs e)
        {
            FillTextBox(indexUserHeadButt("Last", ref indexHaed));
        }

        private void Useres_Load(object sender, EventArgs e)
        {
            fillData();
            flagAddOrEdit = "Load";
            FormatingTextBoxAndButt("Load");
        }

        private void buttClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttAddScreen2User_Click(object sender, EventArgs e)
        {

            if (flagAddOrEdit == "Add" || flagAddOrEdit == "Edite")
            { 
            List<string> idScreenFound = new List<string>();
            for (int i = 0; i < DGVBody.RowCount; i++)
                idScreenFound.Add(DGVBody.Rows[i].Cells[0].Value.ToString());
            UserScreenList = new UserScreenList(idScreenFound);
            UserScreenList.ShowDialog();
            if (UserScreenList.stateSelect == true && UserScreenList.ScreenIdSelected.Count > 0)
            {
                for (int i = 0; i < UserScreenList.ScreenIdSelected.Count; i++)
                {
                        // MessageBox.Show(UserScreenList.ScreenIdSelected.Keys.ElementAt(i), UserScreenList.ScreenIdSelected[UserScreenList.ScreenIdSelected.Keys.ElementAt(i)]);

                        DGVBody.Rows.Add
                      (
                       UserScreenList.ScreenIdSelected.Keys.ElementAt(i),
                       UserScreenList.ScreenIdSelected[UserScreenList.ScreenIdSelected.Keys.ElementAt(i)],
                       permissionsSQL.GetNameScreen(UserScreenList.ScreenIdSelected.Keys.ElementAt(i)),
                       false,
                       false,
                       false,
                       false,
                       false,
                       false,
                       false,
                       false
                      );
                        if(flagAddOrEdit == "Edite")
                        {
                            permissionsSQL.InsertScreen2User(userId.Text, UserScreenList.ScreenIdSelected.Keys.ElementAt(i));
                        }
                        
                }

                UserScreenList.ScreenIdSelected.Clear();
                UserScreenList.stateSelect = false;


            }
        }

           
           

        }

      

        #endregion

        #endregion

       

    }
}
