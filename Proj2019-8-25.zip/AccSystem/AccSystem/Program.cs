﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.FormsProject.Sys;
using AccSystem.FormsProject.Purchs;
using AccSystem.FormsProject.Accounts;
using AccSystem.FormsProject.Sales;
using AccSystem.FormsProject.Stores;
namespace AccSystem
{
    static class Program
    {
        public static bool State = false;
        public static string idUser=string.Empty;
        public static string nameUser=string.Empty;
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
          
            // Application.Run(new hhg());
            Application.Run(new LogIn());
            if (State)
               Application.Run(new MainForm(idUser,nameUser));
            //Application.Run(new FrmRepCustomerBalances());
            // SaleBill


        }

    }
}//E:\الجامعة\مشروع التخرج\DataBase\project\آخر تحديث\AccSystem\AccSystem\Program.cs
