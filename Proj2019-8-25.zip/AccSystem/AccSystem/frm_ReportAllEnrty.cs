﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AccSystem.ClassesProject;

using AccSystem.ClassesProject.ToWord;

namespace AccSystem
{
    public partial class frm_ReportAllEnrty : Form
    {
        ConnectionDB con = new ConnectionDB();
        EntriesSQL En = new EntriesSQL();
        public frm_ReportAllEnrty()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var dt = En.ReportEnrty("2"); /*
                                           عرفنا متغير من نوع فار يستقبل 
                                           * جدول 
                                           */

            Frm_print print = new Frm_print();
            CrystalReport1 rp = new CrystalReport1();
            rp.SetDataSource(dt);
           
            print.crystalReportViewer1.ReportSource = rp;

            print.Show();
            
        }
    }
}
