﻿namespace AccSystem
{
    partial class hhg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(hhg));
            this.pamain_Main = new System.Windows.Forms.Panel();
            this.pa_Main_Midam = new System.Windows.Forms.Panel();
            this.pa_Main_midam_midam = new System.Windows.Forms.Panel();
            this.pa_Main_midam_midam_down = new System.Windows.Forms.Panel();
            this.pa_Main_midam_down = new System.Windows.Forms.Panel();
            this.gB_Process = new System.Windows.Forms.GroupBox();
            this.bunifuTileButton1 = new Bunifu.Framework.UI.BunifuTileButton();
            this.pa_Main_midam_up = new System.Windows.Forms.Panel();
            this.pa_Main_down = new System.Windows.Forms.Panel();
            this.pa_Main_Up = new System.Windows.Forms.Panel();
            this.notification_item1 = new BunifuFrameworkManager.notification_item();
            this.pamain_Main.SuspendLayout();
            this.pa_Main_Midam.SuspendLayout();
            this.pa_Main_midam_midam.SuspendLayout();
            this.pa_Main_midam_down.SuspendLayout();
            this.gB_Process.SuspendLayout();
            this.SuspendLayout();
            // 
            // pamain_Main
            // 
            this.pamain_Main.Controls.Add(this.pa_Main_Midam);
            this.pamain_Main.Controls.Add(this.pa_Main_down);
            this.pamain_Main.Controls.Add(this.pa_Main_Up);
            this.pamain_Main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pamain_Main.Location = new System.Drawing.Point(0, 0);
            this.pamain_Main.Name = "pamain_Main";
            this.pamain_Main.Size = new System.Drawing.Size(903, 616);
            this.pamain_Main.TabIndex = 0;
            // 
            // pa_Main_Midam
            // 
            this.pa_Main_Midam.Controls.Add(this.pa_Main_midam_midam);
            this.pa_Main_Midam.Controls.Add(this.pa_Main_midam_down);
            this.pa_Main_Midam.Controls.Add(this.pa_Main_midam_up);
            this.pa_Main_Midam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pa_Main_Midam.Location = new System.Drawing.Point(0, 35);
            this.pa_Main_Midam.Name = "pa_Main_Midam";
            this.pa_Main_Midam.Size = new System.Drawing.Size(903, 560);
            this.pa_Main_Midam.TabIndex = 2;
            // 
            // pa_Main_midam_midam
            // 
            this.pa_Main_midam_midam.Controls.Add(this.notification_item1);
            this.pa_Main_midam_midam.Controls.Add(this.pa_Main_midam_midam_down);
            this.pa_Main_midam_midam.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pa_Main_midam_midam.Location = new System.Drawing.Point(0, 85);
            this.pa_Main_midam_midam.Name = "pa_Main_midam_midam";
            this.pa_Main_midam_midam.Size = new System.Drawing.Size(903, 328);
            this.pa_Main_midam_midam.TabIndex = 1;
            // 
            // pa_Main_midam_midam_down
            // 
            this.pa_Main_midam_midam_down.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pa_Main_midam_midam_down.Location = new System.Drawing.Point(0, 273);
            this.pa_Main_midam_midam_down.Name = "pa_Main_midam_midam_down";
            this.pa_Main_midam_midam_down.Size = new System.Drawing.Size(903, 55);
            this.pa_Main_midam_midam_down.TabIndex = 0;
            this.pa_Main_midam_midam_down.Paint += new System.Windows.Forms.PaintEventHandler(this.pa_Main_midam_midam_down_Paint);
            // 
            // pa_Main_midam_down
            // 
            this.pa_Main_midam_down.Controls.Add(this.gB_Process);
            this.pa_Main_midam_down.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pa_Main_midam_down.Location = new System.Drawing.Point(0, 413);
            this.pa_Main_midam_down.Name = "pa_Main_midam_down";
            this.pa_Main_midam_down.Size = new System.Drawing.Size(903, 147);
            this.pa_Main_midam_down.TabIndex = 0;
            // 
            // gB_Process
            // 
            this.gB_Process.Controls.Add(this.bunifuTileButton1);
            this.gB_Process.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gB_Process.Location = new System.Drawing.Point(0, 0);
            this.gB_Process.Name = "gB_Process";
            this.gB_Process.Size = new System.Drawing.Size(903, 147);
            this.gB_Process.TabIndex = 0;
            this.gB_Process.TabStop = false;
            // 
            // bunifuTileButton1
            // 
            this.bunifuTileButton1.BackColor = System.Drawing.Color.Gray;
            this.bunifuTileButton1.color = System.Drawing.Color.Gray;
            this.bunifuTileButton1.colorActive = System.Drawing.Color.MediumSeaGreen;
            this.bunifuTileButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuTileButton1.Font = new System.Drawing.Font("Century Gothic", 15.75F);
            this.bunifuTileButton1.ForeColor = System.Drawing.Color.White;
            this.bunifuTileButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuTileButton1.Image")));
            this.bunifuTileButton1.ImagePosition = 20;
            this.bunifuTileButton1.ImageZoom = 50;
            this.bunifuTileButton1.LabelPosition = 41;
            this.bunifuTileButton1.LabelText = "طباعة";
            this.bunifuTileButton1.Location = new System.Drawing.Point(209, 22);
            this.bunifuTileButton1.Margin = new System.Windows.Forms.Padding(6);
            this.bunifuTileButton1.Name = "bunifuTileButton1";
            this.bunifuTileButton1.Size = new System.Drawing.Size(85, 109);
            this.bunifuTileButton1.TabIndex = 0;
            this.bunifuTileButton1.Click += new System.EventHandler(this.bunifuTileButton1_Click);
            // 
            // pa_Main_midam_up
            // 
            this.pa_Main_midam_up.Dock = System.Windows.Forms.DockStyle.Top;
            this.pa_Main_midam_up.Location = new System.Drawing.Point(0, 0);
            this.pa_Main_midam_up.Name = "pa_Main_midam_up";
            this.pa_Main_midam_up.Size = new System.Drawing.Size(903, 85);
            this.pa_Main_midam_up.TabIndex = 0;
            // 
            // pa_Main_down
            // 
            this.pa_Main_down.BackColor = System.Drawing.Color.Gray;
            this.pa_Main_down.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pa_Main_down.Location = new System.Drawing.Point(0, 595);
            this.pa_Main_down.Name = "pa_Main_down";
            this.pa_Main_down.Size = new System.Drawing.Size(903, 21);
            this.pa_Main_down.TabIndex = 1;
            this.pa_Main_down.Paint += new System.Windows.Forms.PaintEventHandler(this.pa_Main_down_Paint);
            // 
            // pa_Main_Up
            // 
            this.pa_Main_Up.BackColor = System.Drawing.Color.Gray;
            this.pa_Main_Up.Dock = System.Windows.Forms.DockStyle.Top;
            this.pa_Main_Up.Location = new System.Drawing.Point(0, 0);
            this.pa_Main_Up.Name = "pa_Main_Up";
            this.pa_Main_Up.Size = new System.Drawing.Size(903, 35);
            this.pa_Main_Up.TabIndex = 0;
            this.pa_Main_Up.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pa_Main_Up_MouseDown);
            // 
            // notification_item1
            // 
            this.notification_item1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.notification_item1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.notification_item1.hasAction = true;
            this.notification_item1.isNew = true;
            this.notification_item1.Location = new System.Drawing.Point(0, 0);
            this.notification_item1.Margin = new System.Windows.Forms.Padding(4);
            this.notification_item1.Message = "Data";
            this.notification_item1.Name = "notification_item1";
            this.notification_item1.Size = new System.Drawing.Size(903, 273);
            this.notification_item1.TabIndex = 12;
            this.notification_item1.Title = "Ibrahim";
            // 
            // hhg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.ClientSize = new System.Drawing.Size(903, 616);
            this.Controls.Add(this.pamain_Main);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "hhg";
            this.Text = "@as";
            this.pamain_Main.ResumeLayout(false);
            this.pa_Main_Midam.ResumeLayout(false);
            this.pa_Main_midam_midam.ResumeLayout(false);
            this.pa_Main_midam_down.ResumeLayout(false);
            this.gB_Process.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pamain_Main;
        private System.Windows.Forms.Panel pa_Main_Midam;
        private System.Windows.Forms.Panel pa_Main_midam_midam;
        private System.Windows.Forms.Panel pa_Main_midam_midam_down;
        private System.Windows.Forms.Panel pa_Main_midam_down;
        private System.Windows.Forms.Panel pa_Main_midam_up;
        private System.Windows.Forms.Panel pa_Main_down;
        private System.Windows.Forms.Panel pa_Main_Up;
        private System.Windows.Forms.GroupBox gB_Process;
        private Bunifu.Framework.UI.BunifuTileButton bunifuTileButton1;
        private BunifuFrameworkManager.notification_item notification_item1;
    }
}